; Phase11 bounded extraction: MCVar.dll old image, VA 0x10004D80-0x10004F20
; Rizin disassembly and XREFs for 0x10004E2E

; --- bounded disassembly ---
       ╎╎   0x10004d80      das
       ╎╎   0x10004d81      add   byte [eax], al
       ╎╎   0x10004d83      mov   ebx, dword [ebp-0x04]
       ╎╎   0x10004d86      mov   edx, dword [esi]
       ╎╎   0x10004d88      push  0x00
       ╎╎   0x10004d8a      mov   ecx, esi
       ╎╎   0x10004d8c      mov   eax, dword [ebx]
       ╎╎   0x10004d8e      push  eax
       ╎╎   0x10004d8f      call  dword [edx+0x04]                     ; 4
       ╎╎   0x10004d92      mov   ecx, dword [esi+0x30]
       ╎╎   0x10004d95      test  ecx, ecx
       ╎╎   ;-- public: static class CResult * __cdecl CResult::DataConversion(void):
      ┌───< 0x10004d97      jz    0x10005391                           ; public: static class CResult * __cdecl CResult::DataConversion(void)
      │╎╎   0x10004d9d      push  esi
      │╎╎   0x10004d9e      call  0x100054dd
     ┌────< 0x10004da3      jmp   0x10005391
     ││╎╎   0x10004da8      lea   eax, dword [esi+0x1c]
     ││╎╎   0x10004dab      mov   ecx, esi
     ││╎╎   0x10004dad      push  eax
     ││╎╎   0x10004dae      call  0x10003af6
     ││╎╎   0x10004db3      test  eax, eax
     ││╎╎   0x10004db5      mov   dword [ebp-0x04], eax
    ┌─────< 0x10004db8      jz    0x100053c0
    │││╎╎   0x10004dbe      mov   ebx, dword [ebx]
    │││╎╎   0x10004dc0      mov   ecx, dword [esi+0x14]
    │││╎╎   0x10004dc3      push  ebx
    │││╎╎   0x10004dc4  ~   call  0x10001e18
    │││╎╎   ;-- public: static class CResult * __cdecl CResult::DataTooLarge(void):
    │││╎╎   0x10004dc5      dec   edi                                  ; public: static class CResult * __cdecl CResult::DataTooLarge(void)
    │││╎╎   0x10004dc6      sar   bh, 0x01
    │││╎╎   0x10004dc8      dec   dword [ecx+0x4d8dec45]
    │││╎╎   0x10004dce      in    al, dx
    │││└──< 0x10004dcf      jmp   0x10004d7e
    │││ ╎   0x10004dd1      mov   ecx, dword [esi+0x14]
    │││ ╎   0x10004dd4      lea   eax, dword [esi+0x24]
    │││ ╎   0x10004dd7      lea   ebx, dword [esi+0x18]
    │││ ╎   0x10004dda      push  esi
    │││ ╎   0x10004ddb      push  eax
    │││ ╎   0x10004ddc      push  ebx
    │││ ╎   0x10004ddd      call  0x10001af5
    │││ ╎   0x10004de2      test  eax, eax
    │││ ╎   0x10004de4      mov   dword [ebp-0x04], eax
    │││┌──< 0x10004de7      jz    0x10004dfa
    ││││╎   0x10004de9      push  0x10                                 ; 16
    ││││╎   0x10004deb      mov   ecx, esi
    ││││╎   0x10004ded      call  0x10004ca7
    ││││╎   0x10004df2  ~   mov   dword [ebp-0x18], eax
    ││││╎   ;-- public: struct NCDDE_BINARY_HEADER * __thiscall CXVariant::GetNcddeBinaryData(void *, int, int *):
    ││││╎   0x10004df3      inc   ebp                                  ; public: struct NCDDE_BINARY_HEADER * __thiscall CXVariant::GetNcddeBinaryData(void *, int, int *)
    ││││╎   0x10004df4      call  0xfffffffffbe89b86
    ││││    0x10004df9      test  byte [ebx-0x3381732], cl
    │││     0x10004dff      invalid
    │││     0x10004e00      inc   dword [ebp-0x3ba7640]
    │││ ┌─< 0x10004e06      jz    0x100053c0
    │││ │   0x10004e0c      mov   ebx, dword [ebx]
    │││ │   0x10004e0e      mov   ecx, dword [esi+0x14]
    │││ │   0x10004e11      push  ebx
    │││ │   0x10004e12      call  0x10001e18
    │││ │   0x10004e17      lea   ecx, dword [ebp-0x1c]
    │││ │   0x10004e1a      mov   dword [ebp-0x1c], eax
    │││ │   0x10004e1d      call  0x10007caf
    │││ │   0x10004e22      mov   eax, dword [ebp-0x04]
    │││ │   0x10004e25      mov   edx, dword [esi]
    │││ │   0x10004e27      push  0x00
    │││ │   0x10004e29      mov   ecx, esi
    │││ │   0x10004e2b      mov   eax, dword [eax]
    │││ │   0x10004e2d      push  eax
    │││ │   0x10004e2e      call  dword [edx+0x04]                     ; 4
    │││ │   0x10004e31      mov   ecx, dword [esi+0x30]
    │││ │   0x10004e34      test  ecx, ecx
    │││┌──< 0x10004e36      jz    0x10004e3e
    │││││   0x10004e38      push  esi
    │││││   0x10004e39      call  0x100054dd
    │││└──> 0x10004e3e      mov   eax, dword [ebp-0x04]
    │││┌──< 0x10004e41      jmp   0x100053c8
    │││││   0x10004e46      mov   ecx, dword [esi+0x14]
    │││││   0x10004e49      lea   eax, dword [esi+0x24]
    │││││   0x10004e4c      lea   ebx, dword [esi+0x18]
    │││││   0x10004e4f      push  esi
    │││││   0x10004e50      push  eax
    │││││   0x10004e51      push  ebx
    │││││   0x10004e52      call  0x10001af5
    │││││   0x10004e57      test  eax, eax
    │││││   0x10004e59      mov   dword [ebp-0x04], eax
   ┌──────< 0x10004e5c      jz    0x10004e86
   ││││││   0x10004e5e      push  0x10                                 ; 16
   ││││││   0x10004e60      mov   ecx, esi
   ││││││   0x10004e62      call  0x10004ca7
   ││││││   0x10004e67      mov   dword [ebp-0x20], eax
   ││││││   0x10004e6a      lea   ecx, dword [ebp-0x20]
   ││││││   0x10004e6d      call  0x10007caf
   ││││││   0x10004e72      mov   ebx, dword [ebp-0x04]
   ││││││   0x10004e75      mov   edx, dword [esi]
   ││││││   0x10004e77      push  0x00
   ││││││   0x10004e79      mov   ecx, esi
   ││││││   0x10004e7b      mov   eax, dword [ebx]
   ││││││   0x10004e7d      push  eax
   ││││││   0x10004e7e      invalid
   ││││││   0x10004e7f      push  edx
   ││││││   0x10004e80      add   al, 0xe9                             ; 233
   ││││││   0x10004e82      or    eax, dword [0xce8b0000]
    │││││   0x10004e88      call  0x100055aa
    │││││   0x10004e8d      test  eax, eax
    │││││   0x10004e8f      mov   dword [ebp-0x04], eax
    │││││   0x10004e92      jz    0x100053c0
    │││││   0x10004e98      mov   ebx, dword [ebx]
    │││││   0x10004e9a      mov   ecx, dword [esi+0x14]
    │││││   0x10004e9d      push  ebx
    │││││   0x10004e9e      call  0x10001e18
    │││││   0x10004ea3      mov   dword [ebp-0x24], eax
    │││││   0x10004ea6      lea   ecx, dword [ebp-0x24]
    │││││   0x10004ea9      jmp   0x10004e6d
    │││││   0x10004eab      mov   eax, dword [ebp+0x08]
    │││││   0x10004eae      dec   eax
    │││││   0x10004eaf      dec   eax
    │││││   0x10004eb0      jz    0x10004f6a
    │││││   0x10004eb6      sub   eax, 0x05
    │││││   0x10004eb9      jz    0x10004f39
    │││││   0x10004ebb      dec   eax
    │││││   0x10004ebc      dec   eax
    │││││   0x10004ebd      jz    0x10004f03
    │││││   0x10004ebf      sub   eax, 0x05
    │││││   0x10004ec2      jnz   0x10005090
    │││││   0x10004ec8      mov   ecx, dword [esi+0x18]
    │││││   0x10004ecb      push  0x00
    │││││   0x10004ecd      push  0x00
    │││││   0x10004ecf      push  0x3e1                                ; 993
    │││││   0x10004ed4      call  0x1000576f
    │││││   0x10004ed9      mov   ebx, eax
    │││││   0x10004edb      test  ebx, ebx
    │││││   0x10004edd      jz    0x100053c0
    │││││   0x10004ee3      mov   eax, dword [ebx]
    │││││   0x10004ee5      mov   edx, dword [esi]
    │││││   0x10004ee7      push  0x00
    │││││   0x10004ee9      push  eax
    │││││   0x10004eea      mov   ecx, esi
    │││││   0x10004eec      call  dword [edx+0x04]                     ; 4
    │││││   0x10004eef      push  0x10                                 ; 16
    │││││   0x10004ef1      mov   ecx, esi
    │││││   0x10004ef3      call  0x10004ca7
    │││││   0x10004ef8      mov   dword [ebp-0x28], eax
    │││││   0x10004efb      lea   ecx, dword [ebp-0x28]
    │││││   0x10004efe      jmp   0x1000538c
    │││││   0x10004f03      push  0x100373fc
    │││││   0x10004f08      mov   ecx, esi
    │││││   0x10004f0a      call  0x10003af6
    │││││   0x10004f0f      mov   ebx, eax
    │││││   0x10004f11      test  ebx, ebx
    │││││   0x10004f13      jz    0x100053c0
    │││││   0x10004f19      mov   eax, dword [ebx]
    │││││   0x10004f1b      mov   edx, dword [esi]
    │││││   0x10004f1d      push  0x00
    │││││   0x10004f1f      push  eax
    │││││   0x10004f20      mov   ecx, esi
    │││││   0x10004f22      call  dword [edx+0x04]                     ; 4
    │││││   0x10004f25      push  0x10                                 ; 16
    │││││   0x10004f27      mov   ecx, esi
    │││││   0x10004f29      call  0x10004ca7
    │││││   0x10004f2e      mov   dword [ebp-0x2c], eax
    │││││   0x10004f31      lea   ecx, dword [ebp-0x2c]
    │││││   0x10004f34      jmp   0x1000538c
    │││││   0x10004f39      mov   ecx, esi
    │││││   0x10004f3b      call  0x1000568d
    │││││   0x10004f40      mov   ebx, eax
    │││││   0x10004f42      test  ebx, ebx
    │││││   0x10004f44      jz    0x100053c0
    │││││   0x10004f4a      mov   eax, dword [ebx]
    │││││   0x10004f4c      mov   edx, dword [esi]
    │││││   0x10004f4e      push  0x00
    │││││   0x10004f50      push  eax
    │││││   0x10004f51      mov   ecx, esi
    │││││   0x10004f53      call  dword [edx+0x04]                     ; 4
    │││││   0x10004f56      push  0x10                                 ; 16
    │││││   0x10004f58      mov   ecx, esi
    │││││   0x10004f5a      call  0x10004ca7
    │││││   0x10004f5f      mov   dword [ebp-0x30], eax
    │││││   0x10004f62      lea   ecx, dword [ebp-0x30]
    │││││   0x10004f65      jmp   0x1000538c
    │││││   0x10004f6a      lea   eax, dword [esi+0x1c]
    │││││   0x10004f6d      mov   ecx, esi
    │││││   0x10004f6f      push  eax
    │││││   0x10004f70      call  0x10003af6
    │││││   0x10004f75      mov   ebx, eax
    │││││   0x10004f77      test  ebx, ebx
    │││││   0x10004f79      jz    0x100053c0
    │││││   0x10004f7f      invalid
    │││││   0x10004f80      add   ecx, dword [ebx+0x50006a16]
    │││││   0x10004f86      mov   ecx, esi
    │││││   0x10004f88      call  dword [edx+0x04]                     ; 4
    │││││   0x10004f8b      push  0x10                                 ; 16
    │││││   0x10004f8d      mov   ecx, esi
    │││││   0x10004f8f      call  0x10004ca7
    │││││   0x10004f94      mov   dword [ebp-0x34], eax
    │││││   0x10004f97      lea   ecx, dword [ebp-0x34]
    │││││   0x10004f9a      jmp   0x1000538c
    │││││   0x10004f9f      cmp   dword [ebp+0x08], 0x03
    │││││   0x10004fa3      jz    0x10005041
    │││││   0x10004fa9      cmp   dword [ebp+0x08], 0x06
    │││││   0x10004fad      jle   0x100053c0
    │││││   0x10004fb3      mov   eax, dword [ebp+0x08]
    │││││   0x10004fb6      cmp   eax, 0x08                            ; 8
    │││││   0x10004fb9      jle   0x10005052
    │││││   0x10004fbf      cmp   eax, 0x0a                            ; 0xa ; 10
    │││││   0x10004fc2      jz    0x1000500b
    │││││   0x10004fc4      cmp   eax, ecx
    │││││   0x10004fc6      jz    0x10004fd0
    │││││   0x10004fc8      cmp   eax, 0x10                            ; 16
    │││││   0x10004fcb      jmp   0x10005399
    │││││   0x10004fd0      mov   ecx, dword [esi+0x18]
    │││││   0x10004fd3      push  0x00
    │││││   0x10004fd5      push  0x00
    │││││   0x10004fd7      push  0x3e1                                ; 993
    │││││   0x10004fdc      call  0x1000576f
    │││││   0x10004fe1      mov   ebx, eax
    │││││   0x10004fe3      test  ebx, ebx
    │││││   0x10004fe5      jz    0x100053c0
    │││││   0x10004feb      mov   eax, dword [ebx]
    │││││   0x10004fed      mov   edx, dword [esi]
    │││││   0x10004fef      push  0x00
    │││││   0x10004ff1      push  eax
    │││││   0x10004ff2      mov   ecx, esi
    │││││   0x10004ff4      call  dword [edx+0x04]                     ; 4
    │││││   0x10004ff7      push  0x10                                 ; 16
    │││││   0x10004ff9      mov   ecx, esi
    │││││   0x10004ffb      call  0x10004ca7
    │││││   0x10005000      mov   dword [ebp-0x38], eax
    │││││   0x10005003      lea   ecx, dword [ebp-0x38]
    │││││   0x10005006      jmp   0x1000538c
    │││││   0x1000500b      push  0x100373fc
    │││││   0x10005010      mov   ecx, esi
    │││││   0x10005012      call  0x10003af6
    │││││   0x10005017      mov   ebx, eax
    │││││   0x10005019      test  ebx, ebx
    │││││   0x1000501b      jz    0x100053c0
    │││││   0x10005021      mov   eax, dword [ebx]
    │││││   0x10005023      mov   edx, dword [esi]
    │││││   0x10005025      push  0x00
    │││││   0x10005027      push  eax
    │││││   0x10005028      mov   ecx, esi
    │││││   0x1000502a      call  dword [edx+0x04]                     ; 4
    │││││   0x1000502d      push  0x10                                 ; 16
    │││││   0x1000502f      mov   ecx, esi
    │││││   0x10005031      call  0x10004ca7
    │││││   0x10005036      mov   dword [ebp-0x3c], eax
    │││││   0x10005039      lea   ecx, dword [ebp-0x3c]
    │││││   0x1000503c      jmp   0x1000538c
    │││││   0x10005041      cmp   dword [esi+0x2c], 0x00
    │││││   0x10005045      jnz   0x100053c0
    │││││   0x1000504b      mov   dword [ebp+0x08], 0x07
    │││││   0x10005052      mov   ecx, esi
    │││││   0x10005054      call  0x1000568d
    │││││   0x10005059      mov   ebx, eax
    │││││   0x1000505b      test  ebx, ebx
    │││││   0x1000505d      jz    0x100053c0
    │││││   0x10005063      mov   eax, dword [ebx]
    │││││   0x10005065      mov   edx, dword [esi]
    │││││   0x10005067      push  0x00
    │││││   0x10005069      push  eax
    │││││   0x1000506a      mov   ecx, esi
    │││││   0x1000506c      call  dword [edx+0x04]                     ; 4
    │││││   0x1000506f      push  0x10                                 ; 16
    │││││   0x10005071      mov   ecx, esi
    │││││   0x10005073      call  0x10004ca7
    │││││   0x10005078      mov   dword [ebp-0x40], eax
    │││││   0x1000507b      lea   ecx, dword [ebp-0x40]
    │││││   0x1000507e      invalid
    │││││   0x1000507f      invalid
    │││││   0x10005080      add   eax, dword [eax]
    │││││   0x10005082      add   byte [ebx-0x177cf7bb], cl
    │││││   0x10005088      pop   es
    │││││   0x10005089      jz    0x100050d2
    │││││   0x1000508b      sub   eax, 0x07
    │││││   0x1000508e      jz    0x10005097
    │││││   0x10005090      dec   eax
    │││││   0x10005091      dec   eax
    │││││   0x10005092      jmp   0x10005399
    │││││   0x10005097      mov   ecx, dword [esi+0x18]
    │││││   0x1000509a      push  0x00
    │││││   0x1000509c      push  0x00
    │││││   0x1000509e      push  0x3e1                                ; 993
    │││││   0x100050a3      call  0x1000576f
    │││││   0x100050a8      mov   ebx, eax
    │││││   0x100050aa      test  ebx, ebx
    │││││   0x100050ac      jz    0x100053c0
    │││││   0x100050b2      mov   eax, dword [ebx]
    │││││   0x100050b4      mov   edx, dword [esi]
    │││││   0x100050b6      push  0x00
    │││││   0x100050b8      push  eax
    │││││   0x100050b9      mov   ecx, esi
    │││││   0x100050bb      call  dword [edx+0x04]                     ; 4
    │││││   0x100050be      push  0x10                                 ; 16
    │││││   0x100050c0      mov   ecx, esi
    │││││   0x100050c2      call  0x10004ca7
    │││││   0x100050c7      mov   dword [ebp-0x44], eax
    │││││   0x100050ca      lea   ecx, dword [ebp-0x44]
    │││││   0x100050cd      jmp   0x1000538c
    │││││   0x100050d2      mov   ecx, esi
    │││││   0x100050d4      call  0x1000568d
    │││││   0x100050d9      mov   ebx, eax
    │││││   0x100050db      test  ebx, ebx
    │││││   0x100050dd      jz    0x100053c0
    │││││   0x100050e3      mov   eax, dword [ebx]
    │││││   0x100050e5      mov   edx, dword [esi]
    │││││   0x100050e7      push  0x00
    │││││   0x100050e9      push  eax
    │││││   0x100050ea      mov   ecx, esi
    │││││   0x100050ec      call  dword [edx+0x04]                     ; 4
    │││││   0x100050ef      push  0x10                                 ; 16
    │││││   0x100050f1      mov   ecx, esi
    │││││   0x100050f3      call  0x10004ca7
    │││││   0x100050f8      mov   dword [ebp-0x48], eax
    │││││   0x100050fb      lea   ecx, dword [ebp-0x48]
    │││││   0x100050fe      jmp   0x1000538c
    │││││   0x10005103      mov   eax, dword [ebp+0x08]
    │││││   0x10005106      sub   eax, ecx
    │││││   0x10005108      jnz   0x1000522e
    │││││   0x1000510e      mov   ecx, dword [esi+0x18]
    │││││   0x10005111      push  0x00
    │││││   0x10005113      push  0x00
    │││││   0x10005115      push  0x3e1                                ; 993
    │││││   0x1000511a      call  0x1000576f
    │││││   0x1000511f      mov   ebx, eax
    │││││   0x10005121      test  ebx, ebx
    │││││   0x10005123      jz    0x100053c0
    │││││   0x10005129      mov   eax, dword [ebx]
    │││││   0x1000512b      mov   edx, dword [esi]
    │││││   0x1000512d      push  0x00
    │││││   0x1000512f      push  eax
    │││││   0x10005130      mov   ecx, esi
    │││││   0x10005132      call  dword [edx+0x04]                     ; 4
    │││││   0x10005135      push  0x10                                 ; 16
    │││││   0x10005137      mov   ecx, esi
    │││││   0x10005139      call  0x10004ca7
    │││││   0x1000513e      mov   dword [ebp-0x4c], eax
    │││││   0x10005141      lea   ecx, dword [ebp-0x4c]
    │││││   0x10005144      jmp   0x1000538c
    │││││   0x10005149      mov   eax, dword [ebp+0x08]
    │││││   0x1000514c      sub   eax, ecx
    │││││   0x1000514e      jnz   0x1000522e
    │││││   0x10005154      mov   ecx, dword [esi+0x18]
    │││││   0x10005157      push  0x00
    │││││   0x10005159      push  0x00
    │││││   0x1000515b      push  0x3e1                                ; 993
    │││││   0x10005160      call  0x1000576f
    │││││   0x10005165      mov   ebx, eax
    │││││   0x10005167      test  ebx, ebx
    │││││   0x10005169      jz    0x100053c0
    │││││   0x1000516f      mov   eax, dword [ebx]
    │││││   0x10005171      mov   edx, dword [esi]
    │││││   0x10005173      push  0x00
    │││││   0x10005175      push  eax
    │││││   0x10005176      mov   ecx, esi
    │││││   0x10005178      call  dword [edx+0x04]                     ; 4
    │││││   0x1000517b      push  0x10                                 ; 16
    │││││   0x1000517d      mov   ecx, esi
    │││││   0x1000517f      invalid
    │││││   0x10005180      and   edi, ebx
    │││││   0x10005182      invalid
    │││││   0x10005183      dec   dword [ecx+0x4d8db045]
    │││││   0x10005189      mov   al, 0xe9                             ; 233
    │││││   0x1000518b      std
    │││││   0x1000518c      add   dword [eax], eax
    │││││   0x1000518e      add   byte [ebx+0xf0b087d], al
    │││││   0x10005194      mov   word [edi], fs
    │││││   0x10005196      add   al, byte [eax]
    │││││   0x10005198      add   byte [ebx-0x77cf7bb], cl
    │││││   0x1000519e      or    eax, 0xc13b507e
    │││││   0x100051a3      jz    0x100051b6
    │││││   0x100051a5      cmp   eax, 0x0f                            ; 0xf ; 15
    │││││   0x100051a8      jz    0x1000531b
    │││││   0x100051ae      cmp   eax, 0x10                            ; 16
    │││││   0x100051b1      jmp   0x10005310
    │││││   0x100051b6      mov   ecx, dword [esi+0x18]
    │││││   0x100051b9      push  0x00
    │││││   0x100051bb      push  0x00
    │││││   0x100051bd      push  0x3e1                                ; 993
    │││││   0x100051c2      call  0x1000576f
    │││││   0x100051c7      mov   ebx, eax
    │││││   0x100051c9      test  ebx, ebx
    │││││   0x100051cb      jz    0x1000534b
    │││││   0x100051d1      mov   eax, dword [ebx]
    │││││   0x100051d3      mov   edx, dword [esi]
    │││││   0x100051d5      push  0x00
    │││││   0x100051d7      push  eax
    │││││   0x100051d8      mov   ecx, esi
    │││││   0x100051da      call  dword [edx+0x04]                     ; 4
    │││││   0x100051dd      push  0x10                                 ; 16
    │││││   0x100051df      mov   ecx, esi
    │││││   0x100051e1      call  0x10004ca7
    │││││   0x100051e6      mov   dword [ebp-0x54], eax
    │││││   0x100051e9      lea   ecx, dword [ebp-0x54]
    │││││   0x100051ec      jmp   0x1000538c
    │││││   0x100051f1      push  0x100373fc
    │││││   0x100051f6      mov   ecx, esi
    │││││   0x100051f8      call  0x10003af6
    │││││   0x100051fd      mov   ebx, eax
    │││││   0x100051ff      test  ebx, ebx
    │││││   0x10005201      jz    0x100053c0
    │││││   0x10005207      mov   eax, dword [ebx]
    │││││   0x10005209      mov   edx, dword [esi]
    │││││   0x1000520b      push  0x00
    │││││   0x1000520d      push  eax
    │││││   0x1000520e      mov   ecx, esi
    │││││   0x10005210      call  dword [edx+0x04]                     ; 4
    │││││   0x10005213      push  0x10                                 ; 16
    │││││   0x10005215      mov   ecx, esi
    │││││   0x10005217      call  0x10004ca7
    │││││   0x1000521c      mov   dword [ebp-0x58], eax
    │││││   0x1000521f      lea   ecx, dword [ebp-0x58]
    │││││   0x10005222      jmp   0x1000538c
    │││││   0x10005227      mov   eax, dword [ebp+0x08]
    │││││   0x1000522a      sub   eax, ecx
    │││││   0x1000522c      jz    0x10005237
    │││││   0x1000522e      dec   eax
    │││││   0x1000522f      jz    0x10005286
    │││││   0x10005231      dec   eax
    │││││   0x10005232      jmp   0x10005399
    │││││   0x10005237      mov   ecx, dword [esi+0x18]
    │││││   0x1000523a      push  0x00

; --- xrefs to indirect-call address (code address) ---

; --- callers/xrefs to containing routine start candidate ---
fcn.10003464 0x1000349c [CALL] call fcn.10004ca7
fcn.100034e8 0x10003676 [CALL] call fcn.10004ca7
(nofunc) 0x10003745 [CALL] call fcn.10004ca7
fcn.100034e8 0x10003766 [CALL] call fcn.10004ca7
fcn.100034e8 0x10003787 [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CMutex::_destructor_void 0x100037a5 [CALL] call fcn.10004ca7
fcn.100034e8 0x100037c8 [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x100038fb [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x1000391c [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x10003956 [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x100039aa [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x100039be [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x100039cf [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x100039e0 [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x100039f1 [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x10003a02 [CALL] call fcn.10004ca7
sym.public:_void___thiscall_CExclusive::_destructor_void 0x10003a13 [CALL] call fcn.10004ca7
sym.public:_static_class_CResult_____cdecl_CDdeClass::GetDdeClass_class_CSmart_class_CDdeClass_______int 0x10003a37 [CALL] call fcn.10004ca7
fcn.10004ca7 0x10004d25 [CALL] call fcn.10004ca7
sym.public:_static_class_CResult_____cdecl_CResult::OutOfGlobalHeap_void 0x10004d73 [CALL] call fcn.10004ca7
(nofunc) 0x10004ded [CALL] call fcn.10004ca7
(nofunc) 0x10004e62 [CALL] call fcn.10004ca7
(nofunc) 0x10004ef3 [CALL] call fcn.10004ca7
(nofunc) 0x10004f29 [CALL] call fcn.10004ca7
(nofunc) 0x10004f5a [CALL] call fcn.10004ca7
(nofunc) 0x10004f8f [CALL] call fcn.10004ca7
(nofunc) 0x10004ffb [CALL] call fcn.10004ca7
(nofunc) 0x10005031 [CALL] call fcn.10004ca7
(nofunc) 0x10005073 [CALL] call fcn.10004ca7
(nofunc) 0x100050c2 [CALL] call fcn.10004ca7
(nofunc) 0x100050f3 [CALL] call fcn.10004ca7
(nofunc) 0x10005139 [CALL] call fcn.10004ca7
(nofunc) 0x1000517f [CALL] call fcn.10004ca7
(nofunc) 0x100051e1 [CALL] call fcn.10004ca7
(nofunc) 0x10005217 [CALL] call fcn.10004ca7
(nofunc) 0x10005262 [CALL] call fcn.10004ca7
(nofunc) 0x100052c4 [CALL] call fcn.10004ca7
(nofunc) 0x100052f5 [CALL] call fcn.10004ca7
(nofunc) 0x10005381 [CALL] call fcn.10004ca7
fcn.100056e0 0x10005739 [CALL] call fcn.10004ca7
(nofunc) 0x10005767 [CALL] call fcn.10004ca7
sym.public:_static_class_CResult_____cdecl_CResult::Limits_char_const 0x10007a33 [CALL] call fcn.10004ca7
fcn.10010388 0x100103b2 [CALL] call fcn.10004ca7
