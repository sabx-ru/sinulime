# Raw disassembly: MCVar 0x10004E2E resolution

Input: `/root/PL/PCU_old/H/mmc2/MCVar.dll`
Method: GNU objdump, PE32 i386, static only.

## Exact callsite

```asm
10004DD1  mov    ecx,DWORD PTR [esi+0x14]
10004DD4  lea    eax,[esi+0x24]
10004DD7  lea    ebx,[esi+0x18]
10004DDA  push   esi
10004DDB  push   eax
10004DDC  push   ebx
10004DDD  call   10001AF5
10004DE2  test   eax,eax
10004DE4  mov    DWORD PTR [ebp-0x4],eax
...
10004E22  mov    eax,DWORD PTR [ebp-0x4]
10004E25  mov    edx,DWORD PTR [esi]
10004E27  push   0x0
10004E29  mov    ecx,esi
10004E2B  mov    eax,DWORD PTR [eax]
10004E2D  push   eax
10004E2E  call   DWORD PTR [edx+0x4]
10004E31  mov    ecx,DWORD PTR [esi+0x30]
```

## Relevant vptr bytes and target

```asm
; vtable data from .rdata at 0x1002C3A0, little endian
1002C3A0  d3 10 00 10    ; slot +0 -> 0x100010D3
1002C3A4  d6 10 00 10    ; slot +4 -> 0x100010D6
1002C3A8  8a 7b 00 10    ; slot +8 -> 0x10007B8A

; vptr installation sites
10007B91  c7 06 a0 c3 02 10    mov DWORD PTR [esi],0x1002c3a0
10002F01  c7 06 a0 c3 02 10    mov DWORD PTR [esi],0x1002c3a0

; resolved slot +4
100010D6  c2 04 00             ret 0x4
```

The call is a local virtual result/variant operation. Its receiver is `ESI`; the first pushed argument is `*(CResult*)`, and the second is zero. For the vptr variant above, slot +4 is the `ret 4` stub at `0x100010D6`, not a transport/API call.

## Contextual repeated dispatches

The same sequence is repeated in nearby conversion branches:

```asm
10004E75  mov edx,[esi]
10004E79  mov ecx,esi
10004E7B  mov eax,[ebx]
10004E7D  push eax
10004E7E  call dword ptr [edx+4]

10004F19  mov eax,[ebx]
10004F1B  mov edx,[esi]
10004F1D  push 0
10004F1F  push eax
10004F20  mov ecx,esi
10004F22  call dword ptr [edx+4]

10004F4A  mov eax,[ebx]
10004F4C  mov edx,[esi]
10004F4E  push 0
10004F50  push eax
10004F51  mov ecx,esi
10004F53  call dword ptr [edx+4]
```

These are result/conversion dispatches, not a proven request submit edge. ReadVar’s strongest exact downstream boundary remains `0x1000BD47 -> 0x1000C532`; the subsequent transport/API edge is unresolved.
