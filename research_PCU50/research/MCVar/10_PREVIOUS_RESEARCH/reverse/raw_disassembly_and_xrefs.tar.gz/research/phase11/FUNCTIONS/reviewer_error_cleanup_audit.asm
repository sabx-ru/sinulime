/root/PL/PCU_old/H/mmc2/ncdde.exe
exact/base immediate candidates: []
/root/PL/PCU_old/H/mmc2/MCVar.dll
exact/base immediate candidates: []
VA 10007caf RVA 00007caf bytes 56 push esi
VA 10007cb0 RVA 00007cb0 bytes 8b31 mov esi, dword ptr [ecx]
VA 10007cb2 RVA 00007cb2 bytes 85f6 test esi, esi
VA 10007cb4 RVA 00007cb4 bytes 740e je 0x10007cc4
VA 10007cb6 RVA 00007cb6 bytes 8bce mov ecx, esi
VA 10007cb8 RVA 00007cb8 bytes e809000000 call 0x10007cc6
VA 10007cbd RVA 00007cbd bytes 56 push esi
VA 10007cbe RVA 00007cbe bytes e80ffd0000 call 0x100179d2
VA 10007cc3 RVA 00007cc3 bytes 59 pop ecx
VA 10007cc4 RVA 00007cc4 bytes 5e pop esi
VA 10007cc5 RVA 00007cc5 bytes c3 ret 
VA 10007cc6 RVA 00007cc6 bytes 56 push esi
VA 10007cc7 RVA 00007cc7 bytes 8bf1 mov esi, ecx
VA 10007cc9 RVA 00007cc9 bytes 8b4604 mov eax, dword ptr [esi + 4]
VA 10007ccc RVA 00007ccc bytes 85c0 test eax, eax
VA 10007cce RVA 00007cce bytes 740c je 0x10007cdc
VA 10007cd0 RVA 00007cd0 bytes 803800 cmp byte ptr [eax], 0
VA 10007cd3 RVA 00007cd3 bytes 7407 je 0x10007cdc
VA 10007cd5 RVA 00007cd5 bytes 50 push eax
VA 10007cd6 RVA 00007cd6 bytes e8f7fc0000 call 0x100179d2
VA 10007cdb RVA 00007cdb bytes 59 pop ecx
VA 10007cdc RVA 00007cdc bytes c7460430740310 mov dword ptr [esi + 4], 0x10037430
VA 10007ce3 RVA 00007ce3 bytes 5e pop esi
VA 10007ce4 RVA 00007ce4 bytes c3 ret 
VA 10007ce5 RVA 00007ce5 bytes 53 push ebx
VA 10007ce6 RVA 00007ce6 bytes 56 push esi
VA 10007ce7 RVA 00007ce7 bytes 8bf1 mov esi, ecx
VA 10007ce9 RVA 00007ce9 bytes 33db xor ebx, ebx
VA 10007ceb RVA 00007ceb bytes 8b4604 mov eax, dword ptr [esi + 4]
VA 10007cee RVA 00007cee bytes 85c0 test eax, eax
VA 10014cbe RVA 00014cbe bytes 56 push esi
VA 10014cbf RVA 00014cbf bytes 8bf1 mov esi, ecx
VA 10014cc1 RVA 00014cc1 bytes 8b4604 mov eax, dword ptr [esi + 4]
VA 10014cc4 RVA 00014cc4 bytes 85c0 test eax, eax
VA 10014cc6 RVA 00014cc6 bytes 7410 je 0x10014cd8
VA 10014cc8 RVA 00014cc8 bytes 8b4828 mov ecx, dword ptr [eax + 0x28]
VA 10014ccb RVA 00014ccb bytes e817000000 call 0x10014ce7
VA 10014cd0 RVA 00014cd0 bytes 8b4604 mov eax, dword ptr [esi + 4]
VA 10014cd3 RVA 00014cd3 bytes 8b0e mov ecx, dword ptr [esi]
VA 10014cd5 RVA 00014cd5 bytes 894824 mov dword ptr [eax + 0x24], ecx
VA 10014cd8 RVA 00014cd8 bytes 8b7604 mov esi, dword ptr [esi + 4]
VA 10014cdb RVA 00014cdb bytes 85f6 test esi, esi
VA 10014cdd RVA 00014cdd bytes 7406 je 0x10014ce5
VA 10014cdf RVA 00014cdf bytes 8b06 mov eax, dword ptr [esi]
VA 10014ce1 RVA 00014ce1 bytes 56 push esi
VA 10014ce2 RVA 00014ce2 bytes ff5008 call dword ptr [eax + 8]
VA 10014ce5 RVA 00014ce5 bytes 5e pop esi
VA 10014ce6 RVA 00014ce6 bytes c3 ret 
VA 10014ce7 RVA 00014ce7 bytes 56 push esi
VA 10014ce8 RVA 00014ce8 bytes 8bf1 mov esi, ecx
VA 10014cea RVA 00014cea bytes ff4e4c dec dword ptr [esi + 0x4c]
VA 10014ced RVA 00014ced bytes e801cbfeff call 0x100017f3
VA 10014cf2 RVA 00014cf2 bytes 833802 cmp dword ptr [eax], 2
VA 10014cf5 RVA 00014cf5 bytes 7404 je 0x10014cfb
VA 10014cf7 RVA 00014cf7 bytes 33c0 xor eax, eax
VA 10014cf9 RVA 00014cf9 bytes eb05 jmp 0x10014d00
VA 10014cfb RVA 00014cfb bytes 8b400c mov eax, dword ptr [eax + 0xc]
VA 10014cfe RVA 00014cfe bytes 8b00 mov eax, dword ptr [eax]
VA 10014d00 RVA 00014d00 bytes a820 test al, 0x20
VA 10014d02 RVA 00014d02 bytes 7427 je 0x10014d2b
VA 10014d04 RVA 00014d04 bytes 8b4638 mov eax, dword ptr [esi + 0x38]
VA 10014d07 RVA 00014d07 bytes 33c9 xor ecx, ecx
VA 10014d09 RVA 00014d09 bytes 85c0 test eax, eax
VA 10014d0b RVA 00014d0b bytes 7405 je 0x10014d12
VA 10014d0d RVA 00014d0d bytes 8b00 mov eax, dword ptr [eax]
VA 10014d0f RVA 00014d0f bytes 41 inc ecx
/root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/ncdde.exe
exact/base immediate candidates: []
/root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
exact/base immediate candidates: []
VA 10007dbd RVA 00007dbd bytes 56 push esi
VA 10007dbe RVA 00007dbe bytes 8b31 mov esi, dword ptr [ecx]
VA 10007dc0 RVA 00007dc0 bytes 85f6 test esi, esi
VA 10007dc2 RVA 00007dc2 bytes 740e je 0x10007dd2
VA 10007dc4 RVA 00007dc4 bytes 8bce mov ecx, esi
VA 10007dc6 RVA 00007dc6 bytes e809000000 call 0x10007dd4
VA 10007dcb RVA 00007dcb bytes 56 push esi
VA 10007dcc RVA 00007dcc bytes e80bfd0000 call 0x10017adc
VA 10007dd1 RVA 00007dd1 bytes 59 pop ecx
VA 10007dd2 RVA 00007dd2 bytes 5e pop esi
VA 10007dd3 RVA 00007dd3 bytes c3 ret 
VA 10007dd4 RVA 00007dd4 bytes 56 push esi
VA 10007dd5 RVA 00007dd5 bytes 8bf1 mov esi, ecx
VA 10007dd7 RVA 00007dd7 bytes 8b4604 mov eax, dword ptr [esi + 4]
VA 10007dda RVA 00007dda bytes 85c0 test eax, eax
VA 10007ddc RVA 00007ddc bytes 740c je 0x10007dea
VA 10007dde RVA 00007dde bytes 803800 cmp byte ptr [eax], 0
VA 10007de1 RVA 00007de1 bytes 7407 je 0x10007dea
VA 10007de3 RVA 00007de3 bytes 50 push eax
VA 10007de4 RVA 00007de4 bytes e8f3fc0000 call 0x10017adc
VA 10007de9 RVA 00007de9 bytes 59 pop ecx
VA 10007dea RVA 00007dea bytes c7460484840310 mov dword ptr [esi + 4], 0x10038484
VA 10007df1 RVA 00007df1 bytes 5e pop esi
VA 10007df2 RVA 00007df2 bytes c3 ret 
VA 10007df3 RVA 00007df3 bytes 53 push ebx
VA 10007df4 RVA 00007df4 bytes 56 push esi
VA 10007df5 RVA 00007df5 bytes 8bf1 mov esi, ecx
VA 10007df7 RVA 00007df7 bytes 33db xor ebx, ebx
VA 10007df9 RVA 00007df9 bytes 8b4604 mov eax, dword ptr [esi + 4]
VA 10007dfc RVA 00007dfc bytes 85c0 test eax, eax
VA 10007dfe RVA 00007dfe bytes 7441 je 0x10007e41