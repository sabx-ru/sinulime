
/root/PL/PCU_old/H/mmc2/MCVar.dll:     file format pei-i386


Disassembly of section .text:

10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>:
10004ca7:	55                   	push   ebp
10004ca8:	8b ec                	mov    ebp,esp
10004caa:	83 ec 6c             	sub    esp,0x6c
10004cad:	53                   	push   ebx
10004cae:	56                   	push   esi
10004caf:	ff 75 08             	push   DWORD PTR [ebp+0x8]
10004cb2:	8b f1                	mov    esi,ecx
10004cb4:	e8 51 07 00 00       	call   1000540a <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x617>
10004cb9:	50                   	push   eax
10004cba:	8b ce                	mov    ecx,esi
10004cbc:	ff 76 10             	push   DWORD PTR [esi+0x10]
10004cbf:	e8 46 07 00 00       	call   1000540a <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x617>
10004cc4:	50                   	push   eax
10004cc5:	56                   	push   esi
10004cc6:	8d 45 94             	lea    eax,[ebp-0x6c]
10004cc9:	68 88 09 03 10       	push   0x10030988
10004cce:	50                   	push   eax
10004ccf:	e8 6e 2d 00 00       	call   10007a42 <??0CSafeArrayDataBase@@QAE@GHH@Z+0x2b>
10004cd4:	8b 46 10             	mov    eax,DWORD PTR [esi+0x10]
10004cd7:	83 c4 14             	add    esp,0x14
10004cda:	6a 0e                	push   0xe
10004cdc:	59                   	pop    ecx
10004cdd:	3b c1                	cmp    eax,ecx
10004cdf:	0f 87 db 06 00 00    	ja     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004ce5:	ff 24 85 ce 53 00 10 	jmp    DWORD PTR [eax*4+0x100053ce]
10004cec:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10004cef:	48                   	dec    eax
10004cf0:	0f 84 50 01 00 00    	je     10004e46 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x53>
10004cf6:	83 e8 03             	sub    eax,0x3
10004cf9:	0f 84 d2 00 00 00    	je     10004dd1 <?DataTooLarge@CResult@@SAPAV1@XZ+0xc>
10004cff:	48                   	dec    eax
10004d00:	74 55                	je     10004d57 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x12d>
10004d02:	48                   	dec    eax
10004d03:	0f 85 b7 06 00 00    	jne    100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004d09:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004d0c:	8d 46 24             	lea    eax,[esi+0x24]
10004d0f:	8d 5e 18             	lea    ebx,[esi+0x18]
10004d12:	56                   	push   esi
10004d13:	50                   	push   eax
10004d14:	53                   	push   ebx
10004d15:	e8 db cd ff ff       	call   10001af5 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x50b>
10004d1a:	85 c0                	test   eax,eax
10004d1c:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
10004d1f:	74 11                	je     10004d32 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x108>
10004d21:	6a 10                	push   0x10
10004d23:	8b ce                	mov    ecx,esi
10004d25:	e8 7d ff ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004d2a:	89 45 f8             	mov    DWORD PTR [ebp-0x8],eax
10004d2d:	8d 4d f8             	lea    ecx,[ebp-0x8]
10004d30:	eb 4c                	jmp    10004d7e <?OutOfGlobalHeap@CResult@@SAPAV1@XZ+0x15>
10004d32:	8b ce                	mov    ecx,esi
10004d34:	e8 f1 ee ff ff       	call   10003c2a <?Set@CTlsMux@@QAEPAVCResult@@IPAX@Z+0x7d>
10004d39:	85 c0                	test   eax,eax
10004d3b:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
10004d3e:	0f 84 7c 06 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004d44:	8b 1b                	mov    ebx,DWORD PTR [ebx]
10004d46:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004d49:	53                   	push   ebx
10004d4a:	e8 c9 d0 ff ff       	call   10001e18 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x1e8>
10004d4f:	89 45 f4             	mov    DWORD PTR [ebp-0xc],eax
10004d52:	8d 4d f4             	lea    ecx,[ebp-0xc]
10004d55:	eb 27                	jmp    10004d7e <?OutOfGlobalHeap@CResult@@SAPAV1@XZ+0x15>
10004d57:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004d5a:	8d 46 24             	lea    eax,[esi+0x24]
10004d5d:	8d 5e 18             	lea    ebx,[esi+0x18]
10004d60:	56                   	push   esi
10004d61:	50                   	push   eax
10004d62:	53                   	push   ebx
10004d63:	e8 8d cd ff ff       	call   10001af5 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x50b>
10004d68:	85                 	test   eax,eax

10004d69 <?OutOfGlobalHeap@CResult@@SAPAV1@XZ>:
10004d69:	c0 89 45 fc 74 39 6a 	ror    BYTE PTR [ecx+0x3974fc45],0x6a
10004d70:	10 8b ce e8 2f ff    	adc    BYTE PTR [ebx-0xd01732],cl
10004d76:	ff                   	(bad)
10004d77:	ff 89 45 f0 8d 4d    	dec    DWORD PTR [ecx+0x4d8df045]
10004d7d:	f0 e8 2c 2f 00 00    	lock call 10007caf <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x31>
10004d83:	8b 5d fc             	mov    ebx,DWORD PTR [ebp-0x4]
10004d86:	8b 16                	mov    edx,DWORD PTR [esi]
10004d88:	6a 00                	push   0x0
10004d8a:	8b ce                	mov    ecx,esi
10004d8c:	8b 03                	mov    eax,DWORD PTR [ebx]
10004d8e:	50                   	push   eax
10004d8f:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004d92:	8b 4e 30             	mov    ecx,DWORD PTR [esi+0x30]
10004d95:	85 c9                	test   ecx,ecx

10004d97 <?DataConversion@CResult@@SAPAV1@XZ>:
10004d97:	0f 84 f4 05 00 00    	je     10005391 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x59e>
10004d9d:	56                   	push   esi
10004d9e:	e8 3a 07 00 00       	call   100054dd <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x6ea>
10004da3:	e9 e9 05 00 00       	jmp    10005391 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x59e>
10004da8:	8d 46 1c             	lea    eax,[esi+0x1c]
10004dab:	8b ce                	mov    ecx,esi
10004dad:	50                   	push   eax
10004dae:	e8 43 ed ff ff       	call   10003af6 <??0CDdeClass@@QAE@XZ+0x1a>
10004db3:	85 c0                	test   eax,eax
10004db5:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
10004db8:	0f 84 02 06 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004dbe:	8b 1b                	mov    ebx,DWORD PTR [ebx]
10004dc0:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004dc3:	53                   	push   ebx
10004dc4:	e8           	call   10001e18 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x1e8>

10004dc5 <?DataTooLarge@CResult@@SAPAV1@XZ>:
10004dc5:	4f                   	dec    edi
10004dc6:	d0 ff                	sar    bh,1
10004dc8:	ff 89 45 ec 8d 4d    	dec    DWORD PTR [ecx+0x4d8dec45]
10004dce:	ec                   	in     al,dx
10004dcf:	eb ad                	jmp    10004d7e <?OutOfGlobalHeap@CResult@@SAPAV1@XZ+0x15>
10004dd1:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004dd4:	8d 46 24             	lea    eax,[esi+0x24]
10004dd7:	8d 5e 18             	lea    ebx,[esi+0x18]
10004dda:	56                   	push   esi
10004ddb:	50                   	push   eax
10004ddc:	53                   	push   ebx
10004ddd:	e8 13 cd ff ff       	call   10001af5 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x50b>
10004de2:	85 c0                	test   eax,eax
10004de4:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
10004de7:	74 11                	je     10004dfa <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x7>
10004de9:	6a 10                	push   0x10
10004deb:	8b ce                	mov    ecx,esi
10004ded:	e8 b5 fe ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004df2:	89               	mov    DWORD PTR [ebp-0x18],eax

10004df3 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z>:
10004df3:	45                   	inc    ebp
10004df4:	e8 8d 4d e8 eb       	call   fbe89b86 <$R005D50+0xebe0fca6>
10004df9:	84 8b ce e8 c7 fc    	test   BYTE PTR [ebx-0x3381732],cl
10004dff:	ff                   	(bad)
10004e00:	ff 85 c0 89 45 fc    	inc    DWORD PTR [ebp-0x3ba7640]
10004e06:	0f 84 b4 05 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004e0c:	8b 1b                	mov    ebx,DWORD PTR [ebx]
10004e0e:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004e11:	53                   	push   ebx
10004e12:	e8 01 d0 ff ff       	call   10001e18 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x1e8>
10004e17:	8d 4d e4             	lea    ecx,[ebp-0x1c]
10004e1a:	89 45 e4             	mov    DWORD PTR [ebp-0x1c],eax
10004e1d:	e8 8d 2e 00 00       	call   10007caf <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x31>
10004e22:	8b 45 fc             	mov    eax,DWORD PTR [ebp-0x4]
10004e25:	8b 16                	mov    edx,DWORD PTR [esi]
10004e27:	6a 00                	push   0x0
10004e29:	8b ce                	mov    ecx,esi
10004e2b:	8b 00                	mov    eax,DWORD PTR [eax]
10004e2d:	50                   	push   eax
10004e2e:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004e31:	8b 4e 30             	mov    ecx,DWORD PTR [esi+0x30]
10004e34:	85 c9                	test   ecx,ecx
10004e36:	74 06                	je     10004e3e <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x4b>
10004e38:	56                   	push   esi
10004e39:	e8 9f 06 00 00       	call   100054dd <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x6ea>
10004e3e:	8b 45 fc             	mov    eax,DWORD PTR [ebp-0x4]
10004e41:	e9 82 05 00 00       	jmp    100053c8 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5d5>
10004e46:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004e49:	8d 46 24             	lea    eax,[esi+0x24]
10004e4c:	8d 5e 18             	lea    ebx,[esi+0x18]
10004e4f:	56                   	push   esi
10004e50:	50                   	push   eax
10004e51:	53                   	push   ebx
10004e52:	e8 9e cc ff ff       	call   10001af5 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x50b>
10004e57:	85 c0                	test   eax,eax
10004e59:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
10004e5c:	74 28                	je     10004e86 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x93>
10004e5e:	6a 10                	push   0x10
10004e60:	8b ce                	mov    ecx,esi
10004e62:	e8 40 fe ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004e67:	89 45 e0             	mov    DWORD PTR [ebp-0x20],eax
10004e6a:	8d 4d e0             	lea    ecx,[ebp-0x20]
10004e6d:	e8 3d 2e 00 00       	call   10007caf <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x31>
10004e72:	8b 5d fc             	mov    ebx,DWORD PTR [ebp-0x4]
10004e75:	8b 16                	mov    edx,DWORD PTR [esi]
10004e77:	6a 00                	push   0x0
10004e79:	8b ce                	mov    ecx,esi
10004e7b:	8b 03                	mov    eax,DWORD PTR [ebx]
10004e7d:	50                   	push   eax
10004e7e:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004e81:	e9 0b 05 00 00       	jmp    10005391 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x59e>
10004e86:	8b ce                	mov    ecx,esi
10004e88:	e8 1d 07 00 00       	call   100055aa <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x7b7>
10004e8d:	85 c0                	test   eax,eax
10004e8f:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
10004e92:	0f 84 28 05 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004e98:	8b 1b                	mov    ebx,DWORD PTR [ebx]
10004e9a:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004e9d:	53                   	push   ebx
10004e9e:	e8 75 cf ff ff       	call   10001e18 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x1e8>
10004ea3:	89 45 dc             	mov    DWORD PTR [ebp-0x24],eax
10004ea6:	8d 4d dc             	lea    ecx,[ebp-0x24]
10004ea9:	eb c2                	jmp    10004e6d <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x7a>
10004eab:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10004eae:	48                   	dec    eax
10004eaf:	48                   	dec    eax
10004eb0:	0f 84 b4 00 00 00    	je     10004f6a <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x177>
10004eb6:	83 e8 05             	sub    eax,0x5
10004eb9:	74 7e                	je     10004f39 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x146>
10004ebb:	48                   	dec    eax
10004ebc:	48                   	dec    eax
10004ebd:	74 44                	je     10004f03 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x110>
10004ebf:	83 e8 05             	sub    eax,0x5
10004ec2:	0f 85 c8 01 00 00    	jne    10005090 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x29d>
10004ec8:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
10004ecb:	6a 00                	push   0x0
10004ecd:	6a 00                	push   0x0
10004ecf:	68 e1 03 00 00       	push   0x3e1
10004ed4:	e8 96 08 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
10004ed9:	8b d8                	mov    ebx,eax
10004edb:	85 db                	test   ebx,ebx
10004edd:	0f 84 dd 04 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004ee3:	8b 03                	mov    eax,DWORD PTR [ebx]
10004ee5:	8b 16                	mov    edx,DWORD PTR [esi]
10004ee7:	6a 00                	push   0x0
10004ee9:	50                   	push   eax
10004eea:	8b ce                	mov    ecx,esi
10004eec:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004eef:	6a 10                	push   0x10
10004ef1:	8b ce                	mov    ecx,esi
10004ef3:	e8 af fd ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004ef8:	89 45 d8             	mov    DWORD PTR [ebp-0x28],eax
10004efb:	8d 4d d8             	lea    ecx,[ebp-0x28]
10004efe:	e9 89 04 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10004f03:	68 fc 73 03 10       	push   0x100373fc
10004f08:	8b ce                	mov    ecx,esi
10004f0a:	e8 e7 eb ff ff       	call   10003af6 <??0CDdeClass@@QAE@XZ+0x1a>
10004f0f:	8b d8                	mov    ebx,eax
10004f11:	85 db                	test   ebx,ebx
10004f13:	0f 84 a7 04 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004f19:	8b 03                	mov    eax,DWORD PTR [ebx]
10004f1b:	8b 16                	mov    edx,DWORD PTR [esi]
10004f1d:	6a 00                	push   0x0
10004f1f:	50                   	push   eax
10004f20:	8b ce                	mov    ecx,esi
10004f22:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004f25:	6a 10                	push   0x10
10004f27:	8b ce                	mov    ecx,esi
10004f29:	e8 79 fd ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004f2e:	89 45 d4             	mov    DWORD PTR [ebp-0x2c],eax
10004f31:	8d 4d d4             	lea    ecx,[ebp-0x2c]
10004f34:	e9 53 04 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10004f39:	8b ce                	mov    ecx,esi
10004f3b:	e8 4d 07 00 00       	call   1000568d <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x89a>
10004f40:	8b d8                	mov    ebx,eax
10004f42:	85 db                	test   ebx,ebx
10004f44:	0f 84 76 04 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004f4a:	8b 03                	mov    eax,DWORD PTR [ebx]
10004f4c:	8b 16                	mov    edx,DWORD PTR [esi]
10004f4e:	6a 00                	push   0x0
10004f50:	50                   	push   eax
10004f51:	8b ce                	mov    ecx,esi
10004f53:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004f56:	6a 10                	push   0x10
10004f58:	8b ce                	mov    ecx,esi
10004f5a:	e8 48 fd ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004f5f:	89 45 d0             	mov    DWORD PTR [ebp-0x30],eax
10004f62:	8d 4d d0             	lea    ecx,[ebp-0x30]
10004f65:	e9 22 04 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10004f6a:	8d 46 1c             	lea    eax,[esi+0x1c]
10004f6d:	8b ce                	mov    ecx,esi
10004f6f:	50                   	push   eax
10004f70:	e8 81 eb ff ff       	call   10003af6 <??0CDdeClass@@QAE@XZ+0x1a>
10004f75:	8b d8                	mov    ebx,eax
10004f77:	85 db                	test   ebx,ebx
10004f79:	0f 84 41 04 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004f7f:	8b 03                	mov    eax,DWORD PTR [ebx]
10004f81:	8b 16                	mov    edx,DWORD PTR [esi]
10004f83:	6a 00                	push   0x0
10004f85:	50                   	push   eax
10004f86:	8b ce                	mov    ecx,esi
10004f88:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004f8b:	6a 10                	push   0x10
10004f8d:	8b ce                	mov    ecx,esi
10004f8f:	e8 13 fd ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10004f94:	89 45 cc             	mov    DWORD PTR [ebp-0x34],eax
10004f97:	8d 4d cc             	lea    ecx,[ebp-0x34]
10004f9a:	e9 ed 03 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10004f9f:	83 7d 08 03          	cmp    DWORD PTR [ebp+0x8],0x3
10004fa3:	0f 84 98 00 00 00    	je     10005041 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x24e>
10004fa9:	83 7d 08 06          	cmp    DWORD PTR [ebp+0x8],0x6
10004fad:	0f 8e 0d 04 00 00    	jle    100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004fb3:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10004fb6:	83 f8 08             	cmp    eax,0x8
10004fb9:	0f 8e 93 00 00 00    	jle    10005052 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x25f>
10004fbf:	83 f8 0a             	cmp    eax,0xa
10004fc2:	74 47                	je     1000500b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x218>
10004fc4:	3b c1                	cmp    eax,ecx
10004fc6:	74 08                	je     10004fd0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x1dd>
10004fc8:	83 f8 10             	cmp    eax,0x10
10004fcb:	e9 c9 03 00 00       	jmp    10005399 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5a6>
10004fd0:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
10004fd3:	6a 00                	push   0x0
10004fd5:	6a 00                	push   0x0
10004fd7:	68 e1 03 00 00       	push   0x3e1
10004fdc:	e8 8e 07 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
10004fe1:	8b d8                	mov    ebx,eax
10004fe3:	85 db                	test   ebx,ebx
10004fe5:	0f 84 d5 03 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10004feb:	8b 03                	mov    eax,DWORD PTR [ebx]
10004fed:	8b 16                	mov    edx,DWORD PTR [esi]
10004fef:	6a 00                	push   0x0
10004ff1:	50                   	push   eax
10004ff2:	8b ce                	mov    ecx,esi
10004ff4:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004ff7:	6a 10                	push   0x10
10004ff9:	8b ce                	mov    ecx,esi
10004ffb:	e8 a7 fc ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10005000:	89 45 c8             	mov    DWORD PTR [ebp-0x38],eax
10005003:	8d 4d c8             	lea    ecx,[ebp-0x38]
10005006:	e9 81 03 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
1000500b:	68 fc 73 03 10       	push   0x100373fc
10005010:	8b ce                	mov    ecx,esi
10005012:	e8 df ea ff ff       	call   10003af6 <??0CDdeClass@@QAE@XZ+0x1a>
10005017:	8b d8                	mov    ebx,eax
10005019:	85 db                	test   ebx,ebx
1000501b:	0f 84 9f 03 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005021:	8b 03                	mov    eax,DWORD PTR [ebx]
10005023:	8b 16                	mov    edx,DWORD PTR [esi]
10005025:	6a 00                	push   0x0
10005027:	50                   	push   eax
10005028:	8b ce                	mov    ecx,esi
1000502a:	ff 52 04             	call   DWORD PTR [edx+0x4]
1000502d:	6a 10                	push   0x10
1000502f:	8b ce                	mov    ecx,esi
10005031:	e8 71 fc ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10005036:	89 45 c4             	mov    DWORD PTR [ebp-0x3c],eax
10005039:	8d 4d c4             	lea    ecx,[ebp-0x3c]
1000503c:	e9 4b 03 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005041:	83 7e 2c 00          	cmp    DWORD PTR [esi+0x2c],0x0
10005045:	0f 85 75 03 00 00    	jne    100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
1000504b:	c7 45 08 07 00 00 00 	mov    DWORD PTR [ebp+0x8],0x7
10005052:	8b ce                	mov    ecx,esi
10005054:	e8 34 06 00 00       	call   1000568d <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x89a>
10005059:	8b d8                	mov    ebx,eax
1000505b:	85 db                	test   ebx,ebx
1000505d:	0f 84 5d 03 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005063:	8b 03                	mov    eax,DWORD PTR [ebx]
10005065:	8b 16                	mov    edx,DWORD PTR [esi]
10005067:	6a 00                	push   0x0
10005069:	50                   	push   eax
1000506a:	8b ce                	mov    ecx,esi
1000506c:	ff 52 04             	call   DWORD PTR [edx+0x4]
1000506f:	6a 10                	push   0x10
10005071:	8b ce                	mov    ecx,esi
10005073:	e8 2f fc ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10005078:	89 45 c0             	mov    DWORD PTR [ebp-0x40],eax
1000507b:	8d 4d c0             	lea    ecx,[ebp-0x40]
1000507e:	e9 09 03 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005083:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10005086:	83 e8 07             	sub    eax,0x7
10005089:	74 47                	je     100050d2 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x2df>
1000508b:	83 e8 07             	sub    eax,0x7
1000508e:	74 07                	je     10005097 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x2a4>
10005090:	48                   	dec    eax
10005091:	48                   	dec    eax
10005092:	e9 02 03 00 00       	jmp    10005399 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5a6>
10005097:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
1000509a:	6a 00                	push   0x0
1000509c:	6a 00                	push   0x0
1000509e:	68 e1 03 00 00       	push   0x3e1
100050a3:	e8 c7 06 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
100050a8:	8b d8                	mov    ebx,eax
100050aa:	85 db                	test   ebx,ebx
100050ac:	0f 84 0e 03 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
100050b2:	8b 03                	mov    eax,DWORD PTR [ebx]
100050b4:	8b 16                	mov    edx,DWORD PTR [esi]
100050b6:	6a 00                	push   0x0
100050b8:	50                   	push   eax
100050b9:	8b ce                	mov    ecx,esi
100050bb:	ff 52 04             	call   DWORD PTR [edx+0x4]
100050be:	6a 10                	push   0x10
100050c0:	8b ce                	mov    ecx,esi
100050c2:	e8 e0 fb ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
100050c7:	89 45 bc             	mov    DWORD PTR [ebp-0x44],eax
100050ca:	8d 4d bc             	lea    ecx,[ebp-0x44]
100050cd:	e9 ba 02 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
100050d2:	8b ce                	mov    ecx,esi
100050d4:	e8 b4 05 00 00       	call   1000568d <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x89a>
100050d9:	8b d8                	mov    ebx,eax
100050db:	85 db                	test   ebx,ebx
100050dd:	0f 84 dd 02 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
100050e3:	8b 03                	mov    eax,DWORD PTR [ebx]
100050e5:	8b 16                	mov    edx,DWORD PTR [esi]
100050e7:	6a 00                	push   0x0
100050e9:	50                   	push   eax
100050ea:	8b ce                	mov    ecx,esi
100050ec:	ff 52 04             	call   DWORD PTR [edx+0x4]
100050ef:	6a 10                	push   0x10
100050f1:	8b ce                	mov    ecx,esi
100050f3:	e8 af fb ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
100050f8:	89 45 b8             	mov    DWORD PTR [ebp-0x48],eax
100050fb:	8d 4d b8             	lea    ecx,[ebp-0x48]
100050fe:	e9 89 02 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005103:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10005106:	2b c1                	sub    eax,ecx
10005108:	0f 85 20 01 00 00    	jne    1000522e <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x43b>
1000510e:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
10005111:	6a 00                	push   0x0
10005113:	6a 00                	push   0x0
10005115:	68 e1 03 00 00       	push   0x3e1
1000511a:	e8 50 06 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
1000511f:	8b d8                	mov    ebx,eax
10005121:	85 db                	test   ebx,ebx
10005123:	0f 84 97 02 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005129:	8b 03                	mov    eax,DWORD PTR [ebx]
1000512b:	8b 16                	mov    edx,DWORD PTR [esi]
1000512d:	6a 00                	push   0x0
1000512f:	50                   	push   eax
10005130:	8b ce                	mov    ecx,esi
10005132:	ff 52 04             	call   DWORD PTR [edx+0x4]
10005135:	6a 10                	push   0x10
10005137:	8b ce                	mov    ecx,esi
10005139:	e8 69 fb ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
1000513e:	89 45 b4             	mov    DWORD PTR [ebp-0x4c],eax
10005141:	8d 4d b4             	lea    ecx,[ebp-0x4c]
10005144:	e9 43 02 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005149:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
1000514c:	2b c1                	sub    eax,ecx
1000514e:	0f 85 da 00 00 00    	jne    1000522e <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x43b>
10005154:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
10005157:	6a 00                	push   0x0
10005159:	6a 00                	push   0x0
1000515b:	68 e1 03 00 00       	push   0x3e1
10005160:	e8 0a 06 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
10005165:	8b d8                	mov    ebx,eax
10005167:	85 db                	test   ebx,ebx
10005169:	0f 84 51 02 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
1000516f:	8b 03                	mov    eax,DWORD PTR [ebx]
10005171:	8b 16                	mov    edx,DWORD PTR [esi]
10005173:	6a 00                	push   0x0
10005175:	50                   	push   eax
10005176:	8b ce                	mov    ecx,esi
10005178:	ff 52 04             	call   DWORD PTR [edx+0x4]
1000517b:	6a 10                	push   0x10
1000517d:	8b ce                	mov    ecx,esi
1000517f:	e8 23 fb ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10005184:	89 45 b0             	mov    DWORD PTR [ebp-0x50],eax
10005187:	8d 4d b0             	lea    ecx,[ebp-0x50]
1000518a:	e9 fd 01 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
1000518f:	83 7d 08 0b          	cmp    DWORD PTR [ebp+0x8],0xb
10005193:	0f 8c 27 02 00 00    	jl     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005199:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
1000519c:	83 f8 0d             	cmp    eax,0xd
1000519f:	7e 50                	jle    100051f1 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x3fe>
100051a1:	3b c1                	cmp    eax,ecx
100051a3:	74 11                	je     100051b6 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x3c3>
100051a5:	83 f8 0f             	cmp    eax,0xf
100051a8:	0f 84 6d 01 00 00    	je     1000531b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x528>
100051ae:	83 f8 10             	cmp    eax,0x10
100051b1:	e9 5a 01 00 00       	jmp    10005310 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x51d>
100051b6:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
100051b9:	6a 00                	push   0x0
100051bb:	6a 00                	push   0x0
100051bd:	68 e1 03 00 00       	push   0x3e1
100051c2:	e8 a8 05 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
100051c7:	8b d8                	mov    ebx,eax
100051c9:	85 db                	test   ebx,ebx
100051cb:	0f 84 7a 01 00 00    	je     1000534b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x558>
100051d1:	8b 03                	mov    eax,DWORD PTR [ebx]
100051d3:	8b 16                	mov    edx,DWORD PTR [esi]
100051d5:	6a 00                	push   0x0
100051d7:	50                   	push   eax
100051d8:	8b ce                	mov    ecx,esi
100051da:	ff 52 04             	call   DWORD PTR [edx+0x4]
100051dd:	6a 10                	push   0x10
100051df:	8b ce                	mov    ecx,esi
100051e1:	e8 c1 fa ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
100051e6:	89 45 ac             	mov    DWORD PTR [ebp-0x54],eax
100051e9:	8d 4d ac             	lea    ecx,[ebp-0x54]
100051ec:	e9 9b 01 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
100051f1:	68 fc 73 03 10       	push   0x100373fc
100051f6:	8b ce                	mov    ecx,esi
100051f8:	e8 f9 e8 ff ff       	call   10003af6 <??0CDdeClass@@QAE@XZ+0x1a>
100051fd:	8b d8                	mov    ebx,eax
100051ff:	85 db                	test   ebx,ebx
10005201:	0f 84 b9 01 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005207:	8b 03                	mov    eax,DWORD PTR [ebx]
10005209:	8b 16                	mov    edx,DWORD PTR [esi]
1000520b:	6a 00                	push   0x0
1000520d:	50                   	push   eax
1000520e:	8b ce                	mov    ecx,esi
10005210:	ff 52 04             	call   DWORD PTR [edx+0x4]
10005213:	6a 10                	push   0x10
10005215:	8b ce                	mov    ecx,esi
10005217:	e8 8b fa ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
1000521c:	89 45 a8             	mov    DWORD PTR [ebp-0x58],eax
1000521f:	8d 4d a8             	lea    ecx,[ebp-0x58]
10005222:	e9 65 01 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005227:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
1000522a:	2b c1                	sub    eax,ecx
1000522c:	74 09                	je     10005237 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x444>
1000522e:	48                   	dec    eax
1000522f:	74 55                	je     10005286 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x493>
10005231:	48                   	dec    eax
10005232:	e9 62 01 00 00       	jmp    10005399 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5a6>
10005237:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
1000523a:	6a 00                	push   0x0
1000523c:	6a 00                	push   0x0
1000523e:	68 e1 03 00 00       	push   0x3e1
10005243:	e8 27 05 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
10005248:	8b d8                	mov    ebx,eax
1000524a:	85 db                	test   ebx,ebx
1000524c:	0f 84 6e 01 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005252:	8b 03                	mov    eax,DWORD PTR [ebx]
10005254:	8b 16                	mov    edx,DWORD PTR [esi]
10005256:	6a 00                	push   0x0
10005258:	50                   	push   eax
10005259:	8b ce                	mov    ecx,esi
1000525b:	ff 52 04             	call   DWORD PTR [edx+0x4]
1000525e:	6a 10                	push   0x10
10005260:	8b ce                	mov    ecx,esi
10005262:	e8 40 fa ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10005267:	89 45 a4             	mov    DWORD PTR [ebp-0x5c],eax
1000526a:	8d 4d a4             	lea    ecx,[ebp-0x5c]
1000526d:	e9 1a 01 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005272:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10005275:	83 e8 08             	sub    eax,0x8
10005278:	74 5a                	je     100052d4 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x4e1>
1000527a:	83 e8 06             	sub    eax,0x6
1000527d:	74 1a                	je     10005299 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x4a6>
1000527f:	48                   	dec    eax
10005280:	0f 85 89 00 00 00    	jne    1000530f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x51c>
10005286:	ff 76 18             	push   DWORD PTR [esi+0x18]
10005289:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
1000528c:	8d 5e 18             	lea    ebx,[esi+0x18]
1000528f:	e8 84 cb ff ff       	call   10001e18 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x1e8>
10005294:	e9 05 01 00 00       	jmp    1000539e <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5ab>
10005299:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
1000529c:	6a 00                	push   0x0
1000529e:	6a 00                	push   0x0
100052a0:	68 e1 03 00 00       	push   0x3e1
100052a5:	e8 c5 04 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
100052aa:	8b d8                	mov    ebx,eax
100052ac:	85 db                	test   ebx,ebx
100052ae:	0f 84 97 00 00 00    	je     1000534b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x558>
100052b4:	8b 03                	mov    eax,DWORD PTR [ebx]
100052b6:	8b 16                	mov    edx,DWORD PTR [esi]
100052b8:	6a 00                	push   0x0
100052ba:	50                   	push   eax
100052bb:	8b ce                	mov    ecx,esi
100052bd:	ff 52 04             	call   DWORD PTR [edx+0x4]
100052c0:	6a 10                	push   0x10
100052c2:	8b ce                	mov    ecx,esi
100052c4:	e8 de f9 ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
100052c9:	89 45 a0             	mov    DWORD PTR [ebp-0x60],eax
100052cc:	8d 4d a0             	lea    ecx,[ebp-0x60]
100052cf:	e9 b8 00 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
100052d4:	8b ce                	mov    ecx,esi
100052d6:	e8 b2 03 00 00       	call   1000568d <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x89a>
100052db:	8b d8                	mov    ebx,eax
100052dd:	85 db                	test   ebx,ebx
100052df:	0f 84 db 00 00 00    	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
100052e5:	8b 03                	mov    eax,DWORD PTR [ebx]
100052e7:	8b 16                	mov    edx,DWORD PTR [esi]
100052e9:	6a 00                	push   0x0
100052eb:	50                   	push   eax
100052ec:	8b ce                	mov    ecx,esi
100052ee:	ff 52 04             	call   DWORD PTR [edx+0x4]
100052f1:	6a 10                	push   0x10
100052f3:	8b ce                	mov    ecx,esi
100052f5:	e8 ad f9 ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
100052fa:	89 45 9c             	mov    DWORD PTR [ebp-0x64],eax
100052fd:	8d 4d 9c             	lea    ecx,[ebp-0x64]
10005300:	e9 87 00 00 00       	jmp    1000538c <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x599>
10005305:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
10005308:	2b c1                	sub    eax,ecx
1000530a:	74 4e                	je     1000535a <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x567>
1000530c:	48                   	dec    eax
1000530d:	74 0c                	je     1000531b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x528>
1000530f:	48                   	dec    eax
10005310:	0f 85 aa 00 00 00    	jne    100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005316:	8d 5e 18             	lea    ebx,[esi+0x18]
10005319:	eb 0e                	jmp    10005329 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x536>
1000531b:	ff 76 18             	push   DWORD PTR [esi+0x18]
1000531e:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10005321:	8d 5e 18             	lea    ebx,[esi+0x18]
10005324:	e8 ef ca ff ff       	call   10001e18 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x1e8>
10005329:	8b 0b                	mov    ecx,DWORD PTR [ebx]
1000532b:	85 c9                	test   ecx,ecx
1000532d:	74 09                	je     10005338 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x545>
1000532f:	53                   	push   ebx
10005330:	e8 d8 c2 ff ff       	call   1000160d <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x9f3>
10005335:	83 23 00             	and    DWORD PTR [ebx],0x0
10005338:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
1000533b:	8d 5e 14             	lea    ebx,[esi+0x14]
1000533e:	85 c9                	test   ecx,ecx
10005340:	74 09                	je     1000534b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x558>
10005342:	53                   	push   ebx
10005343:	e8 c5 c2 ff ff       	call   1000160d <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x9f3>
10005348:	83 23 00             	and    DWORD PTR [ebx],0x0
1000534b:	8b 4e 30             	mov    ecx,DWORD PTR [esi+0x30]
1000534e:	85 c9                	test   ecx,ecx
10005350:	74 6e                	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
10005352:	56                   	push   esi
10005353:	e8 85 01 00 00       	call   100054dd <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x6ea>
10005358:	eb 66                	jmp    100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
1000535a:	8b 4e 18             	mov    ecx,DWORD PTR [esi+0x18]
1000535d:	6a 00                	push   0x0
1000535f:	6a 00                	push   0x0
10005361:	68 e1 03 00 00       	push   0x3e1
10005366:	e8 04 04 00 00       	call   1000576f <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x97c>
1000536b:	8b d8                	mov    ebx,eax
1000536d:	85 db                	test   ebx,ebx
1000536f:	74 da                	je     1000534b <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x558>
10005371:	8b 03                	mov    eax,DWORD PTR [ebx]
10005373:	8b 16                	mov    edx,DWORD PTR [esi]
10005375:	6a 00                	push   0x0
10005377:	50                   	push   eax
10005378:	8b ce                	mov    ecx,esi
1000537a:	ff 52 04             	call   DWORD PTR [edx+0x4]
1000537d:	6a 10                	push   0x10
1000537f:	8b ce                	mov    ecx,esi
10005381:	e8 21 f9 ff ff       	call   10004ca7 <?StartPoke@CDdeAction@@IAEPAVCResult@@XZ+0x7d>
10005386:	89 45 98             	mov    DWORD PTR [ebp-0x68],eax
10005389:	8d 4d 98             	lea    ecx,[ebp-0x68]
1000538c:	e8 1e 29 00 00       	call   10007caf <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x31>
10005391:	8b c3                	mov    eax,ebx
10005393:	eb 33                	jmp    100053c8 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5d5>
10005395:	83 7d 08 10          	cmp    DWORD PTR [ebp+0x8],0x10
10005399:	75 25                	jne    100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
1000539b:	8d 5e 18             	lea    ebx,[esi+0x18]
1000539e:	8b 0b                	mov    ecx,DWORD PTR [ebx]
100053a0:	85 c9                	test   ecx,ecx
100053a2:	74 09                	je     100053ad <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5ba>
100053a4:	53                   	push   ebx
100053a5:	e8 63 c2 ff ff       	call   1000160d <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x9f3>
100053aa:	83 23 00             	and    DWORD PTR [ebx],0x0
100053ad:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
100053b0:	8d 5e 14             	lea    ebx,[esi+0x14]
100053b3:	85 c9                	test   ecx,ecx
100053b5:	74 09                	je     100053c0 <?GetNcddeBinaryData@CXVariant@@QAEPAUNCDDE_BINARY_HEADER@@PAXHPAH@Z+0x5cd>
100053b7:	53                   	push   ebx
100053b8:	e8 50 c2 ff ff       	call   1000160d <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x9f3>
100053bd:	83 23 00             	and    DWORD PTR [ebx],0x0
100053c0:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
100053c3:	89 46 10             	mov    DWORD PTR [esi+0x10],eax
100053c6:	33 c0                	xor    eax,eax
100053c8:	5e                   	pop    esi
100053c9:	5b                   	pop    ebx
100053ca:	c9                   	leave
100053cb:	c2 04 00             	ret    0x4
100053ce:	ec                   	in     al,dx
100053cf:	4c                   	dec    esp
