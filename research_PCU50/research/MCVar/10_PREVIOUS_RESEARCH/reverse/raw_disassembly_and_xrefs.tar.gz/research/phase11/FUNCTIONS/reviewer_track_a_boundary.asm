VA 1000bc30 RVA 0000bc30 bytes 55 push ebp
VA 1000bc31 RVA 0000bc31 bytes 8bec mov ebp, esp
VA 1000bc33 RVA 0000bc33 bytes 83ec3c sub esp, 0x3c
VA 1000bc36 RVA 0000bc36 bytes 8b4508 mov eax, dword ptr [ebp + 8]
VA 1000bc39 RVA 0000bc39 bytes 53 push ebx
VA 1000bc3a RVA 0000bc3a bytes 56 push esi
VA 1000bc3b RVA 0000bc3b bytes 57 push edi
VA 1000bc3c RVA 0000bc3c bytes 8d58f4 lea ebx, [eax - 0xc]
VA 1000bc3f RVA 0000bc3f bytes 8d4df4 lea ecx, [ebp - 0xc]
VA 1000bc42 RVA 0000bc42 bytes 53 push ebx
VA 1000bc43 RVA 0000bc43 bytes 6a0c push 0xc
VA 1000bc45 RVA 0000bc45 bytes e842900000 call 0x10014c8c
VA 1000bc4a RVA 0000bc4a bytes 53 push ebx
VA 1000bc4b RVA 0000bc4b bytes 8d45fc lea eax, [ebp - 4]
VA 1000bc70 RVA 0000bc70 bytes 7d0c jge 0x1000bc7e
VA 1000bc72 RVA 0000bc72 bytes 0c20 or al, 0x20
VA 1000bc74 RVA 0000bc74 bytes 668937 mov word ptr [edi], si
VA 1000bc77 RVA 0000bc77 bytes 897708 mov dword ptr [edi + 8], esi
VA 1000bc7a RVA 0000bc7a bytes 7427 je 0x1000bca3
VA 1000bc7c RVA 0000bc7c bytes 56 push esi
VA 1000bd40 RVA 0000bd40 bytes 45 inc ebp
VA 1000bd41 RVA 0000bd41 bytes d450 aam 0x50
VA 1000bd43 RVA 0000bd43 bytes 8d45d4 lea eax, [ebp - 0x2c]
VA 1000bd46 RVA 0000bd46 bytes 50 push eax
VA 1000bd47 RVA 0000bd47 bytes e8e6070000 call 0x1000c532
VA 1000bd4c RVA 0000bd4c bytes 8b4d08 mov ecx, dword ptr [ebp + 8]
VA 10004e10 RVA 00004e10 bytes 1453 adc al, 0x53
VA 10004e12 RVA 00004e12 bytes e801d0ffff call 0x10001e18
VA 10004e17 RVA 00004e17 bytes 8d4de4 lea ecx, [ebp - 0x1c]
VA 10004e1a RVA 00004e1a bytes 8945e4 mov dword ptr [ebp - 0x1c], eax
VA 10004e1d RVA 00004e1d bytes e88d2e0000 call 0x10007caf
VA 10004e22 RVA 00004e22 bytes 8b45fc mov eax, dword ptr [ebp - 4]
VA 10004e25 RVA 00004e25 bytes 8b16 mov edx, dword ptr [esi]
VA 10004e27 RVA 00004e27 bytes 6a00 push 0
VA 10004e29 RVA 00004e29 bytes 8bce mov ecx, esi
VA 10004e2b RVA 00004e2b bytes 8b00 mov eax, dword ptr [eax]
VA 10004e2d RVA 00004e2d bytes 50 push eax
VA 10004e2e RVA 00004e2e bytes ff5204 call dword ptr [edx + 4]
VA 10004e31 RVA 00004e31 bytes 8b4e30 mov ecx, dword ptr [esi + 0x30]
VA 1000c532 RVA 0000c532 bytes 55 push ebp
VA 1000c533 RVA 0000c533 bytes 8bec mov ebp, esp
VA 1000c535 RVA 0000c535 bytes 81ece8000000 sub esp, 0xe8
VA 1000c53b RVA 0000c53b bytes 53 push ebx
VA 1000c53c RVA 0000c53c bytes 56 push esi
VA 1000c53d RVA 0000c53d bytes 894dfc mov dword ptr [ebp - 4], ecx
VA 1000c540 RVA 0000c540 bytes 57 push edi
VA 1000c541 RVA 0000c541 bytes 6a08 push 8
VA 1000c543 RVA 0000c543 bytes 8d4d90 lea ecx, [ebp - 0x70]
VA 1000c546 RVA 0000c546 bytes e8e0080000 call 0x1000ce2b
VA 1000c54b RVA 0000c54b bytes 8b7d2c mov edi, dword ptr [ebp + 0x2c]
VA 1000c54e RVA 0000c54e bytes 6a00 push 0