; Fresh objdump of original PE section bytes via anonymous memfd; no original changed.
; Old MCVar.dll image base 0x10000000; .text VMA 0x10001000

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x1000bc30 --stop-address=0x1000bc4a <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

1000bc30 <.data+0xac30>:
1000bc30:	55                   	push   ebp
1000bc31:	8b ec                	mov    ebp,esp
1000bc33:	83 ec 3c             	sub    esp,0x3c
1000bc36:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
1000bc39:	53                   	push   ebx
1000bc3a:	56                   	push   esi
1000bc3b:	57                   	push   edi
1000bc3c:	8d 58 f4             	lea    ebx,[eax-0xc]
1000bc3f:	8d 4d f4             	lea    ecx,[ebp-0xc]
1000bc42:	53                   	push   ebx
1000bc43:	6a 0c                	push   0xc
1000bc45:	e8 42 90 00 00       	call   0x10014c8c

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x1000bdd9 --stop-address=0x1000bdea <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

1000bdd9 <.data+0xadd9>:
1000bdd9:	8d 4d f4             	lea    ecx,[ebp-0xc]
1000bddc:	e8 dd 8e 00 00       	call   0x10014cbe
1000bde1:	8b c6                	mov    eax,esi
1000bde3:	5f                   	pop    edi
1000bde4:	5e                   	pop    esi
1000bde5:	5b                   	pop    ebx
1000bde6:	c9                   	leave
1000bde7:	c2 18 00             	ret    0x18

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x10014c8c --stop-address=0x10014d00 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

10014c8c <.data+0x13c8c>:
10014c8c:	56                   	push   esi
10014c8d:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
10014c91:	57                   	push   edi
10014c92:	8b f9                	mov    edi,ecx
10014c94:	85 f6                	test   esi,esi
10014c96:	89 77 04             	mov    DWORD PTR [edi+0x4],esi
10014c99:	74 1c                	je     0x10014cb7
10014c9b:	8b 06                	mov    eax,DWORD PTR [esi]
10014c9d:	56                   	push   esi
10014c9e:	ff 50 04             	call   DWORD PTR [eax+0x4]
10014ca1:	8b 46 28             	mov    eax,DWORD PTR [esi+0x28]
10014ca4:	ff 40 4c             	inc    DWORD PTR [eax+0x4c]
10014ca7:	8b 46 24             	mov    eax,DWORD PTR [esi+0x24]
10014caa:	89 07                	mov    DWORD PTR [edi],eax
10014cac:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
10014cb0:	85 c0                	test   eax,eax
10014cb2:	74 03                	je     0x10014cb7
10014cb4:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
10014cb7:	8b c7                	mov    eax,edi
10014cb9:	5f                   	pop    edi
10014cba:	5e                   	pop    esi
10014cbb:	c2 08 00             	ret    0x8
10014cbe:	56                   	push   esi
10014cbf:	8b f1                	mov    esi,ecx
10014cc1:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10014cc4:	85 c0                	test   eax,eax
10014cc6:	74 10                	je     0x10014cd8
10014cc8:	8b 48 28             	mov    ecx,DWORD PTR [eax+0x28]
10014ccb:	e8 17 00 00 00       	call   0x10014ce7
10014cd0:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10014cd3:	8b 0e                	mov    ecx,DWORD PTR [esi]
10014cd5:	89 48 24             	mov    DWORD PTR [eax+0x24],ecx
10014cd8:	8b 76 04             	mov    esi,DWORD PTR [esi+0x4]
10014cdb:	85 f6                	test   esi,esi
10014cdd:	74 06                	je     0x10014ce5
10014cdf:	8b 06                	mov    eax,DWORD PTR [esi]
10014ce1:	56                   	push   esi
10014ce2:	ff 50 08             	call   DWORD PTR [eax+0x8]
10014ce5:	5e                   	pop    esi
10014ce6:	c3                   	ret
10014ce7:	56                   	push   esi
10014ce8:	8b f1                	mov    esi,ecx
10014cea:	ff 4e 4c             	dec    DWORD PTR [esi+0x4c]
10014ced:	e8 01 cb fe ff       	call   0x100017f3
10014cf2:	83 38 02             	cmp    DWORD PTR [eax],0x2
10014cf5:	74 04                	je     0x10014cfb
10014cf7:	33 c0                	xor    eax,eax
10014cf9:	eb 05                	jmp    0x10014d00
10014cfb:	8b 40 0c             	mov    eax,DWORD PTR [eax+0xc]
10014cfe:	8b 00                	mov    eax,DWORD PTR [eax]

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x10008ed5 --stop-address=0x10008efa <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

10008ed5 <.data+0x7ed5>:
10008ed5:	c7 46 04 30 c6 02 10 	mov    DWORD PTR [esi+0x4],0x1002c630
10008edc:	c7 46 08 e4 c5 02 10 	mov    DWORD PTR [esi+0x8],0x1002c5e4
10008ee3:	c7 46 0c bc c5 02 10 	mov    DWORD PTR [esi+0xc],0x1002c5bc
10008eea:	c7 46 10 94 c5 02 10 	mov    DWORD PTR [esi+0x10],0x1002c594
10008ef1:	c7 46 14 74 c5 02 10 	mov    DWORD PTR [esi+0x14],0x1002c574
10008ef8:	ff 15        	call   DWORD PTR ds:0x1002c19c

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x100098c5 --stop-address=0x10009930 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

100098c5 <.data+0x88c5>:
100098c5:	c7 46 04 cc c7 02 10 	mov    DWORD PTR [esi+0x4],0x1002c7cc
100098cc:	c7 46 08 80 c7 02 10 	mov    DWORD PTR [esi+0x8],0x1002c780
100098d3:	c7 46 0c 58 c7 02 10 	mov    DWORD PTR [esi+0xc],0x1002c758
100098da:	c7 46 10 30 c7 02 10 	mov    DWORD PTR [esi+0x10],0x1002c730
100098e1:	c7 46 14 10 c7 02 10 	mov    DWORD PTR [esi+0x14],0x1002c710
100098e8:	8b c6                	mov    eax,esi
100098ea:	5e                   	pop    esi
100098eb:	c2 04 00             	ret    0x4
100098ee:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
100098f2:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
100098f5:	50                   	push   eax
100098f6:	8b 08                	mov    ecx,DWORD PTR [eax]
100098f8:	ff 51 04             	call   DWORD PTR [ecx+0x4]
100098fb:	c2 04 00             	ret    0x4
100098fe:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
10009902:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
10009905:	50                   	push   eax
10009906:	8b 08                	mov    ecx,DWORD PTR [eax]
10009908:	ff 51 08             	call   DWORD PTR [ecx+0x8]
1000990b:	c2 04 00             	ret    0x4
1000990e:	55                   	push   ebp
1000990f:	8b ec                	mov    ebp,esp
10009911:	56                   	push   esi
10009912:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
10009915:	ff 75 10             	push   DWORD PTR [ebp+0x10]
10009918:	8b 46 18             	mov    eax,DWORD PTR [esi+0x18]
1000991b:	ff 75 0c             	push   DWORD PTR [ebp+0xc]
1000991e:	8b 08                	mov    ecx,DWORD PTR [eax]
10009920:	50                   	push   eax
10009921:	ff 11                	call   DWORD PTR [ecx]
10009923:	85 c0                	test   eax,eax
10009925:	7d 1f                	jge    0x10009946
10009927:	8b 0d 9c c6 02 10    	mov    ecx,DWORD PTR ds:0x1002c69c
1000992d:	03 ce                	add    ecx,esi
1000992f:	3b               	cmp    ecx,DWORD PTR [esi+0x18]

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x100099c3 --stop-address=0x100099e1 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

100099c3 <.data+0x89c3>:
100099c3:	83 6c 24 04 0c       	sub    DWORD PTR [esp+0x4],0xc
100099c8:	e9 df fd ff ff       	jmp    0x100097ac
100099cd:	83 6c 24 04 0c       	sub    DWORD PTR [esp+0x4],0xc
100099d2:	e9 9f fd ff ff       	jmp    0x10009776
100099d7:	83 6c 24 04 0c       	sub    DWORD PTR [esp+0x4],0xc
100099dc:	e9 a2 fd ff ff       	jmp    0x10009783

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x10009a59 --stop-address=0x10009a77 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

10009a59 <.data+0x8a59>:
10009a59:	83 6c 24 04 0c       	sub    DWORD PTR [esp+0x4],0xc
10009a5e:	e9 ab fe ff ff       	jmp    0x1000990e
10009a63:	83 6c 24 04 0c       	sub    DWORD PTR [esp+0x4],0xc
10009a68:	e9 81 fe ff ff       	jmp    0x100098ee
10009a6d:	83 6c 24 04 0c       	sub    DWORD PTR [esp+0x4],0xc
10009a72:	e9 87 fe ff ff       	jmp    0x100098fe

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x10009776 --stop-address=0x100097ac <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

10009776 <.data+0x8776>:
10009776:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
1000977a:	ff 40 18             	inc    DWORD PTR [eax+0x18]
1000977d:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
10009780:	c2 04 00             	ret    0x4
10009783:	56                   	push   esi
10009784:	8b 74 24 08          	mov    esi,DWORD PTR [esp+0x8]
10009788:	57                   	push   edi
10009789:	ff 4e 18             	dec    DWORD PTR [esi+0x18]
1000978c:	8b 7e 18             	mov    edi,DWORD PTR [esi+0x18]
1000978f:	85 ff                	test   edi,edi
10009791:	75 12                	jne    0x100097a5
10009793:	85 f6                	test   esi,esi
10009795:	74 0e                	je     0x100097a5
10009797:	8b ce                	mov    ecx,esi
10009799:	e8 82 fe ff ff       	call   0x10009620
1000979e:	56                   	push   esi
1000979f:	e8 2e e2 00 00       	call   0x100179d2
100097a4:	59                   	pop    ecx
100097a5:	8b c7                	mov    eax,edi
100097a7:	5f                   	pop    edi
100097a8:	5e                   	pop    esi
100097a9:	c2 04 00             	ret    0x4

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x10004e0c --stop-address=0x10004e46 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

10004e0c <.data+0x3e0c>:
10004e0c:	8b 1b                	mov    ebx,DWORD PTR [ebx]
10004e0e:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
10004e11:	53                   	push   ebx
10004e12:	e8 01 d0 ff ff       	call   0x10001e18
10004e17:	8d 4d e4             	lea    ecx,[ebp-0x1c]
10004e1a:	89 45 e4             	mov    DWORD PTR [ebp-0x1c],eax
10004e1d:	e8 8d 2e 00 00       	call   0x10007caf
10004e22:	8b 45 fc             	mov    eax,DWORD PTR [ebp-0x4]
10004e25:	8b 16                	mov    edx,DWORD PTR [esi]
10004e27:	6a 00                	push   0x0
10004e29:	8b ce                	mov    ecx,esi
10004e2b:	8b 00                	mov    eax,DWORD PTR [eax]
10004e2d:	50                   	push   eax
10004e2e:	ff 52 04             	call   DWORD PTR [edx+0x4]
10004e31:	8b 4e 30             	mov    ecx,DWORD PTR [esi+0x30]
10004e34:	85 c9                	test   ecx,ecx
10004e36:	74 06                	je     0x10004e3e
10004e38:	56                   	push   esi
10004e39:	e8 9f 06 00 00       	call   0x100054dd
10004e3e:	8b 45 fc             	mov    eax,DWORD PTR [ebp-0x4]
10004e41:	e9 82 05 00 00       	jmp    0x100053c8

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x1000e030 --stop-address=0x1000e065 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

1000e030 <.data+0xd030>:
1000e030:	fd                   	std
1000e031:	ff                   	(bad)
1000e032:	ff                   	jmp    (bad)
1000e033:	e8 47 68 ff ff       	call   0x1000487f
1000e038:	85 c0                	test   eax,eax
1000e03a:	0f 8c 5d 0c 00 00    	jl     0x1000ec9d
1000e040:	8d 45 10             	lea    eax,[ebp+0x10]
1000e043:	50                   	push   eax
1000e044:	8d 45 d0             	lea    eax,[ebp-0x30]
1000e047:	50                   	push   eax
1000e048:	8d 45 c8             	lea    eax,[ebp-0x38]
1000e04b:	50                   	push   eax
1000e04c:	e8 3c c8 ff ff       	call   0x1000a88d
1000e051:	83 c4 0c             	add    esp,0xc
1000e054:	85 c0                	test   eax,eax
1000e056:	0f 84 41 0c 00 00    	je     0x1000ec9d
1000e05c:	81 7d e4 bc 07 00 00 	cmp    DWORD PTR [ebp-0x1c],0x7bc
1000e063:	0f 8c        	jl     0x1000ec9d

; objdump -D -b binary -m i386 -Mintel --adjust-vma=0x10001000 --start-address=0x100148a0 --stop-address=0x100148c4 <original .text bytes>


/proc/self/fd/3:     file format binary


Disassembly of section .data:

100148a0 <.data+0x138a0>:
100148a0:	e9 23 03 00 00       	jmp    0x10014bc8
100148a5:	3d c0 c4 02 10       	cmp    eax,0x1002c4c0
100148aa:	0f 85 0e 03 00 00    	jne    0x10014bbe
100148b0:	8b 75 24             	mov    esi,DWORD PTR [ebp+0x24]
100148b3:	c7 45 08 a4 20 03 10 	mov    DWORD PTR [ebp+0x8],0x100320a4
100148ba:	f6 46 01 20          	test   BYTE PTR [esi+0x1],0x20
100148be:	0f 84 ee 02 00 00    	je     0x10014bb2


PCU_old/H/mmc2/MCVar.dll:     file format pei-i386

Contents of section .rdata:
 1002c5bc c3990010 cd990010 d7990010 61940010  ............a...
 1002c5cc 70940010 91940010 b1940010 30bc0010  p...........0...
 1002c5dc eabd0010                             ....            


PCU_old/H/mmc2/MCVar.dll:     file format pei-i386

Contents of section .rdata:
 1002c758 599a0010 639a0010 6d9a0010 61940010  Y...c...m...a...
 1002c768 70940010 91940010 b1940010 30bc0010  p...........0...
 1002c778 eabd0010                             ....            


PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll:     file format pei-i386


Disassembly of section .text:

10014dc8 <?MakeCB@CRequestID@@QAEPAVCResult@@KPAPAVCDdeAction@@PAUtagVARIANT@@11111@Z+0x406>:
10014dc8:	56                   	push   esi
10014dc9:	8b f1                	mov    esi,ecx
10014dcb:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10014dce:	85 c0                	test   eax,eax
10014dd0:	74 10                	je     10014de2 <?MakeCB@CRequestID@@QAEPAVCResult@@KPAPAVCDdeAction@@PAUtagVARIANT@@11111@Z+0x420>
10014dd2:	8b 48 28             	mov    ecx,DWORD PTR [eax+0x28]
10014dd5:	e8 17 00 00 00       	call   10014df1 <?MakeCB@CRequestID@@QAEPAVCResult@@KPAPAVCDdeAction@@PAUtagVARIANT@@11111@Z+0x42f>
10014dda:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10014ddd:	8b 0e                	mov    ecx,DWORD PTR [esi]
10014ddf:	89 48 24             	mov    DWORD PTR [eax+0x24],ecx
10014de2:	8b 76 04             	mov    esi,DWORD PTR [esi+0x4]
10014de5:	85 f6                	test   esi,esi
10014de7:	74 06                	je     10014def <?MakeCB@CRequestID@@QAEPAVCResult@@KPAPAVCDdeAction@@PAUtagVARIANT@@11111@Z+0x42d>
10014de9:	8b 06                	mov    eax,DWORD PTR [esi]
10014deb:	56                   	push   esi
10014dec:	ff 50 08             	call   DWORD PTR [eax+0x8]
10014def:	5e                   	pop    esi
10014df0:	c3                   	ret
