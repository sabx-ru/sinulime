
/root/PL/PCU_old/H/mmc2/MCVar.dll:     file format pei-i386


Disassembly of section .text:

1000bc74 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z>:
1000bc74:	66 89 37             	mov    WORD PTR [edi],si
1000bc77:	89 77 08             	mov    DWORD PTR [edi+0x8],esi
1000bc7a:	74 27                	je     1000bca3 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x2f>
1000bc7c:	56                   	push   esi
1000bc7d:	68 57 00 07 80       	push   0x80070057
1000bc82:	68 04 1f 03 10       	push   0x10031f04
1000bc87:	eb 0c                	jmp    1000bc95 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x21>
1000bc89:	6a 00                	push   0x0
1000bc8b:	68 03 40 00 80       	push   0x80004003
1000bc90:	68 c0 15 03 10       	push   0x100315c0
1000bc95:	8b cb                	mov    ecx,ebx
1000bc97:	e8 f7 f2 ff ff       	call   1000af93 <?Tim@@YAPBDXZ+0x24>
1000bc9c:	8b f0                	mov    esi,eax
1000bc9e:	e9 36 01 00 00       	jmp    1000bdd9 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x165>
1000bca3:	ff 75 14             	push   DWORD PTR [ebp+0x14]
1000bca6:	8d 45 c4             	lea    eax,[ebp-0x3c]
1000bca9:	8b cb                	mov    ecx,ebx
1000bcab:	66 c7 45 d4 0c 40    	mov    WORD PTR [ebp-0x2c],0x400c
1000bcb1:	89 45 dc             	mov    DWORD PTR [ebp-0x24],eax
1000bcb4:	66 c7 45 c4 08 00    	mov    WORD PTR [ebp-0x3c],0x8
1000bcba:	e8 ec fa ff ff       	call   1000b7ab <?Ms2Timer@@YAJK@Z+0xd1>
1000bcbf:	3b c6                	cmp    eax,esi
1000bcc1:	89 45 cc             	mov    DWORD PTR [ebp-0x34],eax
1000bcc4:	75 0a                	jne    1000bcd0 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x5c>
1000bcc6:	be 57 00 07 80       	mov    esi,0x80070057
1000bccb:	e9 f7 00 00 00       	jmp    1000bdc7 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x153>
1000bcd0:	66 89 75 e4          	mov    WORD PTR [ebp-0x1c],si
1000bcd4:	89 75 08             	mov    DWORD PTR [ebp+0x8],esi
1000bcd7:	e8 17 5b ff ff       	call   100017f3 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x80d>
1000bcdc:	83 38 02             	cmp    DWORD PTR [eax],0x2
1000bcdf:	74 04                	je     1000bce5 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x71>
1000bce1:	33 c0                	xor    eax,eax
1000bce3:	eb 05                	jmp    1000bcea <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x76>
1000bce5:	8b 40 0c             	mov    eax,DWORD PTR [eax+0xc]
1000bce8:	8b 00                	mov    eax,DWORD PTR [eax]
1000bcea:	a8 01                	test   al,0x1
1000bcec:	74 2d                	je     1000bd1b <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0xa7>
1000bcee:	8b 45 f8             	mov    eax,DWORD PTR [ebp-0x8]
1000bcf1:	3b c6                	cmp    eax,esi
1000bcf3:	74 08                	je     1000bcfd <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x89>
1000bcf5:	8b 40 28             	mov    eax,DWORD PTR [eax+0x28]
1000bcf8:	8b 78 4c             	mov    edi,DWORD PTR [eax+0x4c]
1000bcfb:	eb 03                	jmp    1000bd00 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x8c>
1000bcfd:	6a 63                	push   0x63
1000bcff:	5f                   	pop    edi
1000bd00:	e8 34 e2 ff ff       	call   10009f39 <??0CVar2@@QAE@XZ+0x35>
1000bd05:	50                   	push   eax
1000bd06:	ff 75 cc             	push   DWORD PTR [ebp-0x34]
1000bd09:	53                   	push   ebx
1000bd0a:	57                   	push   edi
1000bd0b:	68 dc 1e 03 10       	push   0x10031edc
1000bd10:	e8 9a e0 ff ff       	call   10009daf <??_E?$CList@PAVCTransactionID@@@@UAEPAXI@Z+0x1b>
1000bd15:	8b 7d 1c             	mov    edi,DWORD PTR [ebp+0x1c]
1000bd18:	83 c4 14             	add    esp,0x14
1000bd1b:	8d 45 e4             	lea    eax,[ebp-0x1c]
1000bd1e:	56                   	push   esi
1000bd1f:	50                   	push   eax
1000bd20:	56                   	push   esi
1000bd21:	56                   	push   esi
1000bd22:	56                   	push   esi
1000bd23:	56                   	push   esi
1000bd24:	57                   	push   edi
1000bd25:	8d 45 e4             	lea    eax,[ebp-0x1c]
1000bd28:	68 21 01 01 08       	push   0x8010121
1000bd2d:	50                   	push   eax
1000bd2e:	8d 45 08             	lea    eax,[ebp+0x8]
1000bd31:	50                   	push   eax
1000bd32:	56                   	push   esi
1000bd33:	56                   	push   esi
1000bd34:	8d 45 d4             	lea    eax,[ebp-0x2c]
1000bd37:	56                   	push   esi
1000bd38:	50                   	push   eax
1000bd39:	8d 45 d4             	lea    eax,[ebp-0x2c]
1000bd3c:	8b cb                	mov    ecx,ebx
1000bd3e:	50                   	push   eax
1000bd3f:	8d 45 d4             	lea    eax,[ebp-0x2c]
1000bd42:	50                   	push   eax
1000bd43:	8d 45 d4             	lea    eax,[ebp-0x2c]
1000bd46:	50                   	push   eax
1000bd47:	e8 e6 07 00 00       	call   1000c532 <?AddNcddeErrorInfo@CVar2@@QAEJJPAUtagVARIANT@@0@Z+0x527>
1000bd4c:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
1000bd4f:	8b f8                	mov    edi,eax
1000bd51:	3b fe                	cmp    edi,esi
1000bd53:	7c 1c                	jl     1000bd71 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0xfd>
1000bd55:	e8 33 f1 ff ff       	call   1000ae8d <?Trc@@YAXPBDZZ+0xde>
1000bd5a:	3b c6                	cmp    eax,esi
1000bd5c:	89 45 1c             	mov    DWORD PTR [ebp+0x1c],eax
1000bd5f:	74 04                	je     1000bd65 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0xf1>
1000bd61:	8b 38                	mov    edi,DWORD PTR [eax]
1000bd63:	eb 02                	jmp    1000bd67 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0xf3>
1000bd65:	33 ff                	xor    edi,edi
1000bd67:	8d 4d 1c             	lea    ecx,[ebp+0x1c]
1000bd6a:	e8 40 bf ff ff       	call   10007caf <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x31>
1000bd6f:	eb 0a                	jmp    1000bd7b <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x107>
1000bd71:	3b ce                	cmp    ecx,esi
1000bd73:	74 06                	je     1000bd7b <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x107>
1000bd75:	57                   	push   edi
1000bd76:	e8 9a 78 00 00       	call   10013615 <?FlushCyclics@CCyclicID@@IAEPAVCResult@@H@Z+0x896>
1000bd7b:	ff 75 08             	push   DWORD PTR [ebp+0x8]
1000bd7e:	e8 f0 f1 ff ff       	call   1000af73 <?Tim@@YAPBDXZ+0x4>
1000bd83:	f6 45 e5 20          	test   BYTE PTR [ebp-0x1b],0x20
1000bd87:	59                   	pop    ecx
1000bd88:	74 27                	je     1000bdb1 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x13d>
1000bd8a:	ff 75 ec             	push   DWORD PTR [ebp-0x14]
1000bd8d:	8d 4d 14             	lea    ecx,[ebp+0x14]
1000bd90:	89 75 14             	mov    DWORD PTR [ebp+0x14],esi
1000bd93:	89 75 18             	mov    DWORD PTR [ebp+0x18],esi
1000bd96:	e8 05 b7 00 00       	call   100174a0 <?ASSiteMap@CVar2@@KAPAGPAGAAUAS_ADR@1@@Z+0x96>
1000bd9b:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
1000bd9e:	39 75 14             	cmp    DWORD PTR [ebp+0x14],esi
1000bda1:	8b 40 0c             	mov    eax,DWORD PTR [eax+0xc]
1000bda4:	8b 38                	mov    edi,DWORD PTR [eax]
1000bda6:	74 09                	je     1000bdb1 <?ReadVar@CVar2@@UAGJUtagVARIANT@@0FPAU2@1111@Z+0x13d>
1000bda8:	ff 75 14             	push   DWORD PTR [ebp+0x14]
1000bdab:	ff 15 f4 c1 02 10    	call   DWORD PTR ds:0x1002c1f4
1000bdb1:	56                   	push   esi
1000bdb2:	56                   	push   esi
1000bdb3:	57                   	push   edi
1000bdb4:	8b cb                	mov    ecx,ebx
1000bdb6:	e8 50 f2 ff ff       	call   1000b00b <?qual2txt@@YAPBDF@Z+0x49>
1000bdbb:	8b f0                	mov    esi,eax
1000bdbd:	8d 45 e4             	lea    eax,[ebp-0x1c]
1000bdc0:	50                   	push   eax
1000bdc1:	ff 15 f0 c1 02 10    	call   DWORD PTR ds:0x1002c1f0
1000bdc7:	8b 3d f0 c1 02 10    	mov    edi,DWORD PTR ds:0x1002c1f0
1000bdcd:	8d 45 d4             	lea    eax,[ebp-0x2c]
1000bdd0:	50                   	push   eax
1000bdd1:	ff d7                	call   edi
1000bdd3:	8d 45 c4             	lea    eax,[ebp-0x3c]
1000bdd6:	50                   	push   eax
1000bdd7:	ff d7                	call   edi
1000bdd9:	8d 4d f4             	lea    ecx,[ebp-0xc]
1000bddc:	e8 dd 8e 00 00       	call   10014cbe <?MakeCB@CRequestID@@QAEPAVCResult@@KPAPAVCDdeAction@@PAUtagVARIANT@@11111@Z+0x406>
1000bde1:	8b c6                	mov    eax,esi
1000bde3:	5f                   	pop    edi
1000bde4:	5e                   	pop    esi
1000bde5:	5b                   	pop    ebx
1000bde6:	c9                   	leave
1000bde7:	c2 18 00             	ret    0x18
1000bdea:	55                   	push   ebp
1000bdeb:	8b ec                	mov    ebp,esp
1000bded:	83 ec 60             	sub    esp,0x60
1000bdf0:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
1000bdf3:	53                   	push   ebx
1000bdf4:	56                   	push   esi
1000bdf5:	57                   	push   edi
1000bdf6:	8d 58 f4             	lea    ebx,[eax-0xc]
1000bdf9:	8d 4d f0             	lea    ecx,[ebp-0x10]
1000bdfc:	53                   	push   ebx
1000bdfd:	6a 0d                	push   0xd
1000bdff:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
1000be02:	e8 85 8e 00 00       	call   10014c8c <?MakeCB@CRequestID@@QAEPAVCResult@@KPAPAVCDdeAction@@PAUtagVARIANT@@11111@Z+0x3d4>
1000be07:	53                   	push   ebx
1000be08:	8d 45 f8             	lea    eax,[ebp-0x8]
1000be0b:	68 64 1f 03 10       	push   0x10031f64
