# Phase 12 Track C annotated assembly anchors (H12-H17)

Addresses are VA in PE32 image base `0x10000000` for MCVar and `0x00400000` for ncdde. Comments describe only dataflow proven by the cited bytes.

## MCVar old ReadVar and relocated anchors

```asm
; /root/PL/research/logs_asmb/phase9_mcvar_readvar_focus.asm
; Source range 1000BC30..1000BDE7 in phase9_mcvar_readvar_focus.asm.
; Keep omitted addresses explicit: abbreviated lines below are not contiguous disassembly.
1000BD39  lea eax,[ebp-0x2c]
1000BD3C  mov ecx,ebx
1000BD3E  push eax
1000BD47  call 1000C532       ; substantive helper; return is compared below
1000BD4C  mov ecx,[ebp+0x08]
1000BD4F  mov edi,eax         ; helper return becomes local result
1000BD51  cmp edi,esi         ; signed compare with ESI (initialized in earlier body)
1000BD53  jl  1000BD71        ; alternate result path
1000BD55  call 1000AE8D
1000BD5A  cmp eax,esi
1000BD5C  mov [ebp+0x1c],eax
1000BD5F  je  1000BD65
1000BD61  mov edi,[eax]
1000BD67  lea ecx,[ebp+0x1c]
1000BD6A  call 10007CAF        ; symbol says DecodeError; bytes are cleanup-shaped
1000BD71  cmp ecx,esi
1000BD73  je  1000BD7B
1000BD75  push edi
1000BD76  call 10013615
1000BD7B  push [ebp+0x08]
1000BD7E  call 1000AF73
1000BD83  test byte [ebp-0x1b],0x20
1000BD87  je  1000BDB1
1000BD8A..1000BDA8  conditional optional-output setup/calls (see raw source lines 111-122)
1000BDB1..1000BDBB  quality-related path (see raw source lines 123-128)
1000BDBD..1000BDD7  cleanup/helper calls (see raw source lines 129-138)
1000BDD9  lea ecx,[ebp-0xc]
1000BDDC  call 10014CBE        ; scope cleanup, not proven request submission
1000BDE1  mov eax,esi
1000BDE7  ret 0x18
```

The new evidence identifies the matching request/helper boundary as `0x1000BE59 -> 0x1000C644`, cleanup equivalent `0x10014DC8`, and cleanup-shaped nominal decoder at `0x10007DBD`. No fixed relocation arithmetic is assumed.

## Why `0x10007CAF`/`0x10007DBD` are not accepted as error producers

```asm
; old 0x10007CAF; new is the same shape at 0x10007DBD
10007CAF  push esi
10007CB0  mov esi,[ecx]
10007CB2  test esi,esi
10007CB4  je  10007CC4
10007CB6  mov ecx,esi
10007CB8  call 10007CC6
10007CBD  push esi
10007CBE  call 100179D2        ; release/free
10007CC4  pop esi
10007CC5  ret
10007CC6  mov esi,ecx
10007CC9  mov eax,[esi+4]
10007CCC  test eax,eax
10007CCE  je  10007CDC
10007CD0  cmp byte [eax],0
10007CD3  je  10007CDC
10007CD5  push eax
10007CD6  call 100179D2        ; release/free string
10007CDC  mov [esi+4],0x10037430 ; reset pointer
10007CE4  ret
```

The instructions free/reset object state. They neither load nor construct `0x81000303` or `0x85000903`; arithmetic/lookup/propagation from an external producer remains possible.

## ncdde cache/state and per-item branches (independent side)

```asm
; /root/PL/research/phase11/FUNCTIONS/reviewer_track_b_focus.asm
004491C1  mov ecx,[0x48685c]
004491C7  mov edx,[0x4a6d04]
004491D3  mov edx,[0x4a6d08]
004491E2  mov edx,[0x4a6d0c]
00449224  mov esi,[eax*4+0x4a6cf8] ; selects internal state by 0/1/2 match

; ncdde producer loop / result codes
0044A612  cmp eax,-3
0044A615  je  0044A659
0044A617  cmp eax,-2
0044A61A  je  0044A663
0044A61C  test eax,eax
0044A61E  je  0044A659
0044A620  inc esi
0044A627  jl  0044A5F2             ; continue next item
0044A659  xor eax,eax              ; one terminal success path
0044A663  or eax,-1                ; distinct terminal failure
0044A67F  call 004012F8             ; forwarding path

; explicit byte/header mode selector and state values
0044AA29  cmp eax,3
0044AA37  mov word [0x486BD4],1
0044AA42  mov word [0x486BD4],2
0044AA4D  mov word [0x486BD4],0x64
0044AA8A  mov al,[0x486884]
0044AAA3  mov word [0x486BD6],dx
0044AAB4  inc al
0044AAB7  mov [0x486884],al
```

These ncdde branches prove local state selection/continuation only. They do not prove MCVar `CacheDevice`, HRESULT aggregation, or output quality semantics.
