; Phase 12 Track A evidence. Read-only disassembly excerpts; binaries untouched.
; Old -> new paired addresses where structurally equivalent.

; First proven boundary
; OLD 1000BD47: call 1000C532
; NEW 1000BE59: call 1000C644

; Helper prolog and Name/ServerHandles preparation
; OLD 1000C532 push ebp; mov ebp,esp; sub esp,0E8h
; OLD 1000C546 call 1000CE2B
; OLD 1000C56B call 10007E2F       ; Names lookup helper
; OLD 1000C578 call 10008A8E       ; object/error state helper
; OLD 1000C589 call 1000CE2B
; OLD 1000C5A9 call 10007E2F       ; ServerHandles lookup helper
; NEW 1000C644 push ebp; mov ebp,esp; sub esp,0E8h
; NEW 1000C658 call 1000CF3D
; NEW 1000C67D call 10007F3D       ; Names lookup helper
; NEW 1000C68A call 10008B9C       ; object/error state helper
; NEW 1000C69B call 1000CF3D
; NEW 1000C6BB call 10007F3D       ; ServerHandles lookup helper

; SAFEARRAY/per-item ascending loop (first loop)
; OLD 1000C60C call [1002C1B8]     ; element storage allocation/copy path
; OLD 1000C635 ... index/count tests
; OLD 1000C65F push element address
; OLD 1000C660 call [1002C1BC]
; OLD 1000C669 inc eax
; OLD 1000C670 jl 1000C635
; NEW 1000C71E call [1002D1B8]
; NEW 1000C747 ... index/count tests
; NEW 1000C771 push element address
; NEW 1000C772 call [1002D1BC]
; NEW 1000C77B inc eax
; NEW 1000C782 jl 1000C747

; Per-item keyed object/result lookup
; OLD 1000C7C3 mov ecx,ebx
; OLD 1000C7C3 call 10014E38
; OLD 1000C7C8 test eax,eax
; OLD 1000C7CC mov eax,[eax+08]
; NEW 1000C8D3 mov ecx,ebx
; NEW 1000C8D5 call 10014F42
; NEW 1000C8DA test eax,eax
; NEW 1000C8DE mov eax,[eax+08]

; Callback/result-shaped indirect operation. Concrete vptr/implementation unresolved.
; OLD 1000CA30 call dword ptr [eax+14h]
; NEW 1000CB42 call dword ptr [eax+14h]
; The surrounding code pushes explicit VARIANT/string/flag-related arguments
; and then enters a WriteVar-shaped path. This is not asserted to be DDE.

; Important negative evidence
; No direct PostMessageA/SendMessageA call is present in the above decoded chain.
; Do not use symbol label CDdeCon::PostMess at old 1000676F as a function entry:
; its decoded bytes are an interior/misaligned instruction sequence.
