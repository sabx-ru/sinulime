00448ac0 RVA 00048ac0 55 push ebp
00448ac1 RVA 00048ac1 8bec mov ebp, esp
00448ac3 RVA 00048ac3 6aff push -1
00448ac5 RVA 00048ac5 6868a94600 push 0x46a968
00448aca RVA 00048aca 64a100000000 mov eax, dword ptr fs:[0]
00448ad0 RVA 00048ad0 50 push eax
00448ad1 RVA 00048ad1 64892500000000 mov dword ptr fs:[0], esp
00448ad8 RVA 00048ad8 83ec58 sub esp, 0x58
00448adb RVA 00048adb 53 push ebx
00448adc RVA 00048adc 56 push esi
00448add RVA 00048add 83cbff or ebx, 0xffffffff
00448ae0 RVA 00048ae0 57 push edi
00448ae1 RVA 00048ae1 b90c000000 mov ecx, 0xc
00448ae6 RVA 00048ae6 8bc3 mov eax, ebx
00448ae8 RVA 00048ae8 8d7d9c lea edi, [ebp - 0x64]
00448aeb RVA 00048aeb 66895dcc mov word ptr [ebp - 0x34], bx
00448aef RVA 00048aef 8965f0 mov dword ptr [ebp - 0x10], esp
00448af2 RVA 00048af2 f3ab rep stosd dword ptr es:[edi], eax
00448af4 RVA 00048af4 8b7508 mov esi, dword ptr [ebp + 8]
00448af7 RVA 00048af7 33ff xor edi, edi
00448af9 RVA 00048af9 81fe90400000 cmp esi, 0x4090
00448aff RVA 00048aff 897dfc mov dword ptr [ebp - 4], edi
00448b02 RVA 00048b02 0f876f0d0000 ja 0x449877
00448b08 RVA 00048b08 0f84fc0a0000 je 0x44960a
00448b0e RVA 00048b0e 81fe22200000 cmp esi, 0x2022
00448b14 RVA 00048b14 0f8759060000 ja 0x449173
00448b1a RVA 00048b1a 0f84d1040000 je 0x448ff1
00449345 RVA 00049345 8b159c404800 mov edx, dword ptr [0x48409c]
0044934b RVA 0004934b 8b02 mov eax, dword ptr [edx]
0044934d RVA 0004934d b2ff mov dl, 0xff
0044934f RVA 0004934f 38502f cmp byte ptr [eax + 0x2f], dl
00449352 RVA 00049352 0f8504010000 jne 0x44945c
00449358 RVA 00049358 8b7919 mov edi, dword ptr [ecx + 0x19]
0044935b RVA 0004935b 38573f cmp byte ptr [edi + 0x3f], dl
0044935e RVA 0004935e 0f85f6000000 jne 0x44945a
00449364 RVA 00049364 f6411f04 test byte ptr [ecx + 0x1f], 4
00449368 RVA 00049368 0f85ec000000 jne 0x44945a
0044936e RVA 0004936e 833d8c40480001 cmp dword ptr [0x48408c], 1
00449375 RVA 00049375 0f85df000000 jne 0x44945a
0044937b RVA 0004937b 8d55e0 lea edx, [ebp - 0x20]
0044937e RVA 0004937e 6a01 push 1
00449380 RVA 00049380 52 push edx
00449381 RVA 00049381 8b1568684800 mov edx, dword ptr [0x486868]
00449387 RVA 00049387 83c004 add eax, 4
0044938a RVA 0004938a 52 push edx
0044938b RVA 0004938b 50 push eax
0044938c RVA 0004938c e8f690fbff call 0x402487
00449391 RVA 00049391 33ff xor edi, edi
00449393 RVA 00049393 8945ec mov dword ptr [ebp - 0x14], eax
00449396 RVA 00049396 3bc7 cmp eax, edi
00449398 RVA 00049398 0f84b7000000 je 0x449455
0044939e RVA 0004939e 8b1560684800 mov edx, dword ptr [0x486860]
004493a4 RVA 000493a4 a354684800 mov dword ptr [0x486854], eax
004493a9 RVA 000493a9 668b4836 mov cx, word ptr [eax + 0x36]
004493ad RVA 000493ad 66890d50684800 mov word ptr [0x486850], cx
004493b4 RVA 000493b4 8d4dd8 lea ecx, [ebp - 0x28]
004493b7 RVA 000493b7 895008 mov dword ptr [eax + 8], edx
004493ba RVA 000493ba e885d00100 call 0x466444
004493bf RVA 000493bf 8b45ec mov eax, dword ptr [ebp - 0x14]
004493c2 RVA 000493c2 56 push esi
004493c3 RVA 000493c3 6898404800 push 0x484098
004493c8 RVA 000493c8 c645fc08 mov byte ptr [ebp - 4], 8
004493cc RVA 000493cc c6407b01 mov byte ptr [eax + 0x7b], 1
004493d0 RVA 000493d0 8b4dec mov ecx, dword ptr [ebp - 0x14]
004493d3 RVA 000493d3 51 push ecx
004493d4 RVA 000493d4 e8d48dfbff call 0x4021ad
004493d9 RVA 000493d9 8b55ec mov edx, dword ptr [ebp - 0x14]
004493dc RVA 000493dc 83c40c add esp, 0xc
004493df RVA 000493df 8bf0 mov esi, eax
004493e1 RVA 000493e1 c6427b00 mov byte ptr [edx + 0x7b], 0
004493e5 RVA 000493e5 eb16 jmp 0x4493fd
004493e7 RVA 000493e7 8b450c mov eax, dword ptr [ebp + 0xc]
004493ea RVA 000493ea 8b4dec mov ecx, dword ptr [ebp - 0x14]
004493ed RVA 000493ed 8945dc mov dword ptr [ebp - 0x24], eax
004493f0 RVA 000493f0 b8fa934400 mov eax, 0x4493fa
004493f5 RVA 000493f5 c6417b00 mov byte ptr [ecx + 0x7b], 0
004493f9 RVA 000493f9 c3 ret 
004493fa RVA 000493fa 8b750c mov esi, dword ptr [ebp + 0xc]
004493fd RVA 000493fd c745fc00000000 mov dword ptr [ebp - 4], 0
00449404 RVA 00049404 e835d00100 call 0x46643e
00449409 RVA 00049409 8b55ec mov edx, dword ptr [ebp - 0x14]
0044940c RVA 0004940c 8b422a mov eax, dword ptr [edx + 0x2a]
0044940f RVA 0004940f 85c0 test eax, eax
00449411 RVA 00049411 7411 je 0x449424
00449413 RVA 00049413 50 push eax
00449414 RVA 00049414 6a00 push 0
00449416 RVA 00049416 6a00 push 0
00449418 RVA 00049418 6a00 push 0
0044941a RVA 0004941a 6a01 push 1
0044941c RVA 0004941c e88189fbff call 0x401da2
00449421 RVA 00049421 83c414 add esp, 0x14
00449424 RVA 00049424 668b45cc mov ax, word ptr [ebp - 0x34]
00449428 RVA 00049428 c745fcffffffff mov dword ptr [ebp - 4], 0xffffffff
0044942f RVA 0004942f 663dffff cmp ax, 0xffff
00449433 RVA 00049433 0f840afeffff je 0x449243
00449439 RVA 00049439 0fbfc0 movsx eax, ax
0044943c RVA 0004943c 8d0440 lea eax, [eax + eax*2]
0044943f RVA 0004943f 66ff0c45c4254800 dec word ptr [eax*2 + 0x4825c4]
00449447 RVA 00049447 66833c45c425480000 cmp word ptr [eax*2 + 0x4825c4], 0
00449450 RVA 00049450 e9fd040000 jmp 0x449952
00449455 RVA 00049455 8b4de8 mov ecx, dword ptr [ebp - 0x18]
00449458 RVA 00049458 eb02 jmp 0x44945c
0044945a RVA 0004945a 33ff xor edi, edi
0044945c RVA 0004945c 6848684800 push 0x486848
00449461 RVA 00049461 8d45ec lea eax, [ebp - 0x14]
00449464 RVA 00049464 6a01 push 1
00449466 RVA 00049466 50 push eax
00449467 RVA 00049467 e8d693fbff call 0x402842
0044946c RVA 0004946c 85c0 test eax, eax
0044946e RVA 0004946e 0f8cdf050000 jl 0x449a53
00449474 RVA 00049474 a002c64700 mov al, byte ptr [0x47c602]
00449479 RVA 00049479 84c0 test al, al
0044947b RVA 0004947b 743b je 0x4494b8
0044947d RVA 0004947d 8b55ec mov edx, dword ptr [ebp - 0x14]
00449480 RVA 00049480 8d4de4 lea ecx, [ebp - 0x1c]
00449483 RVA 00049483 51 push ecx
00449484 RVA 00049484 52 push edx
00449485 RVA 00049485 e84192fbff call 0x4026cb
0044948a RVA 0004948a 83c408 add esp, 8
0044948d RVA 0004948d 85c0 test eax, eax
0044948f RVA 0004948f 7427 je 0x4494b8
00449491 RVA 00049491 8b45e4 mov eax, dword ptr [ebp - 0x1c]
00449494 RVA 00049494 8b4dec mov ecx, dword ptr [ebp - 0x14]
00449497 RVA 00049497 50 push eax
00449498 RVA 00049498 57 push edi
00449499 RVA 00049499 6a04 push 4
0044949b RVA 0004949b 57 push edi
0044949c RVA 0004949c 51 push ecx
0044949d RVA 0004949d e80089fbff call 0x401da2
004494a2 RVA 000494a2 8b55ec mov edx, dword ptr [ebp - 0x14]
004494a5 RVA 000494a5 6848684800 push 0x486848
004494aa RVA 000494aa 52 push edx
004494ab RVA 000494ab e8da91fbff call 0x40268a
004494b0 RVA 000494b0 83c41c add esp, 0x1c
004494b3 RVA 000494b3 e99b050000 jmp 0x449a53
004494b8 RVA 000494b8 8b45ec mov eax, dword ptr [ebp - 0x14]
004494bb RVA 000494bb 3bc7 cmp eax, edi
004494bd RVA 000494bd a354684800 mov dword ptr [0x486854], eax
004494c2 RVA 000494c2 740d je 0x4494d1
004494c4 RVA 000494c4 668b4836 mov cx, word ptr [eax + 0x36]
004494c8 RVA 000494c8 66890d50684800 mov word ptr [0x486850], cx
004494cf RVA 000494cf eb07 jmp 0x4494d8
004494d1 RVA 000494d1 66893d50684800 mov word ptr [0x486850], di
004494d8 RVA 000494d8 8b1560684800 mov edx, dword ptr [0x486860]
004494de RVA 000494de 8d4dd0 lea ecx, [ebp - 0x30]
004494e1 RVA 000494e1 895008 mov dword ptr [eax + 8], edx
004494e4 RVA 000494e4 e85bcf0100 call 0x466444
004494e9 RVA 000494e9 8b45ec mov eax, dword ptr [ebp - 0x14]
004494ec RVA 000494ec c645fc0b mov byte ptr [ebp - 4], 0xb
004494f0 RVA 000494f0 8a4804 mov cl, byte ptr [eax + 4]
004494f3 RVA 000494f3 84c9 test cl, cl
004494f5 RVA 000494f5 7455 je 0x44954c
004494f7 RVA 000494f7 39782a cmp dword ptr [eax + 0x2a], edi
004494fa RVA 000494fa 7550 jne 0x44954c
004494fc RVA 000494fc c645fc00 mov byte ptr [ebp - 4], 0
00449500 RVA 00049500 e839cf0100 call 0x46643e
00449505 RVA 00049505 668b45cc mov ax, word ptr [ebp - 0x34]
00449509 RVA 00049509 895dfc mov dword ptr [ebp - 4], ebx
0044950c RVA 0004950c 663bc3 cmp ax, bx
0044950f RVA 0004950f 0f84ad020000 je 0x4497c2
00449515 RVA 00049515 0fbfc0 movsx eax, ax
00449518 RVA 00049518 8d0440 lea eax, [eax + eax*2]
0044951b RVA 0004951b 66ff0c45c4254800 dec word ptr [eax*2 + 0x4825c4]
00449523 RVA 00049523 66393c45c4254800 cmp word ptr [eax*2 + 0x4825c4], di
0044952b RVA 0004952b 0f8591020000 jne 0x4497c2
00449531 RVA 00049531 8d4dcc lea ecx, [ebp - 0x34]
00449534 RVA 00049534 e8ca86fbff call 0x401c03
00449539 RVA 00049539 8bc3 mov eax, ebx
0044953b RVA 0004953b 8b4df4 mov ecx, dword ptr [ebp - 0xc]
0044953e RVA 0004953e 64890d00000000 mov dword ptr fs:[0], ecx
00449545 RVA 00049545 5f pop edi
00449546 RVA 00049546 5e pop esi
00449547 RVA 00049547 5b pop ebx
00449548 RVA 00049548 8be5 mov esp, ebp
0044954a RVA 0004954a 5d pop ebp
0044954b RVA 0004954b c3 ret 
00449a9d RVA 00049a9d 8d4dcc lea ecx, [ebp - 0x34]
00449aa0 RVA 00049aa0 e85e81fbff call 0x401c03
00449aa5 RVA 00049aa5 8b4df4 mov ecx, dword ptr [ebp - 0xc]
00449aa8 RVA 00049aa8 5f pop edi
00449aa9 RVA 00049aa9 5e pop esi
00449aaa RVA 00049aaa 33c0 xor eax, eax
00449aac RVA 00049aac 64890d00000000 mov dword ptr fs:[0], ecx
00449ab3 RVA 00049ab3 5b pop ebx
00449ab4 RVA 00049ab4 8be5 mov esp, ebp
00449ab6 RVA 00049ab6 5d pop ebp
00449ab7 RVA 00049ab7 c3 ret 
0044aa10 RVA 0004aa10 188b5424143b sbb byte ptr [ebx + 0x3b142454], cl
0044aa16 RVA 0004aa16 d10f ror dword ptr [edi], 1
0044aa18 RVA 0004aa18 85b400000081ff test dword ptr [eax + eax - 0x7f0000], esi
0044aa1f RVA 0004aa1f 8813 mov byte ptr [ebx], dl
0044aa21 RVA 0004aa21 0000 add byte ptr [eax], al
0044aa23 RVA 0004aa23 0f8da8000000 jge 0x44aad1
0044aa29 RVA 0004aa29 83f803 cmp eax, 3
0044aa2c RVA 0004aa2c 8bf7 mov esi, edi
0044aa2e RVA 0004aa2e 7726 ja 0x44aa56
0044aa30 RVA 0004aa30 ff2485f8ab4400 jmp dword ptr [eax*4 + 0x44abf8]
0044aa37 RVA 0004aa37 66c705d46b48000100 mov word ptr [0x486bd4], 1
0044aa40 RVA 0004aa40 eb14 jmp 0x44aa56
0044aa42 RVA 0004aa42 66c705d46b48000200 mov word ptr [0x486bd4], 2
0044aa4b RVA 0004aa4b eb09 jmp 0x44aa56
0044aa4d RVA 0004aa4d 66c705d46b48006400 mov word ptr [0x486bd4], 0x64
0044aa56 RVA 0004aa56 8a44243c mov al, byte ptr [esp + 0x3c]
0044aa5a RVA 0004aa5a 84c0 test al, al
0044aa5c RVA 0004aa5c 7407 je 0x44aa65
0044aa5e RVA 0004aa5e 800dd56b480001 or byte ptr [0x486bd5], 1
0044aa65 RVA 0004aa65 8b442420 mov eax, dword ptr [esp + 0x20]
0044aa69 RVA 0004aa69 85c0 test eax, eax
0044aa6b RVA 0004aa6b 751d jne 0x44aa8a
0044aa6d RVA 0004aa6d 8b4c2440 mov ecx, dword ptr [esp + 0x40]
0044aa71 RVA 0004aa71 8b13 mov edx, dword ptr [ebx]
0044aa73 RVA 0004aa73 8d442420 lea eax, [esp + 0x20]
0044aa77 RVA 0004aa77 6a00 push 0
0044aa79 RVA 0004aa79 50 push eax
0044aa7a RVA 0004aa7a 8b442440 mov eax, dword ptr [esp + 0x40]
0044aa7e RVA 0004aa7e 6a03 push 3
0044aa80 RVA 0004aa80 51 push ecx
0044aa81 RVA 0004aa81 8b4818 mov ecx, dword ptr [eax + 0x18]
0044aa84 RVA 0004aa84 51 push ecx
0044aa85 RVA 0004aa85 8bcb mov ecx, ebx
0044aa87 RVA 0004aa87 ff5218 call dword ptr [edx + 0x18]
0044aa8a RVA 0004aa8a a084684800 mov al, byte ptr [0x486884]
0044aa8f RVA 0004aa8f 6633d2 xor dx, dx
0044aa92 RVA 0004aa92 660fb64c2420 movzx cx, byte ptr [esp + 0x20]
0044aa98 RVA 0004aa98 8ad0 mov dl, al
0044aa9a RVA 0004aa9a c1e208 shl edx, 8
0044aa9d RVA 0004aa9d 03d1 add edx, ecx
0044aa9f RVA 0004aa9f 8b4c2418 mov ecx, dword ptr [esp + 0x18]
0044aaa3 RVA 0004aaa3 668915d66b4800 mov word ptr [0x486bd6], dx
0044aaaa RVA 0004aaaa 8b542428 mov edx, dword ptr [esp + 0x28]
0044aaae RVA 0004aaae 2bd1 sub edx, ecx
0044aab0 RVA 0004aab0 8b4c2444 mov ecx, dword ptr [esp + 0x44]
0044aab4 RVA 0004aab4 fec0 inc al
0044aab6 RVA 0004aab6 42 inc edx
0044aab7 RVA 0004aab7 a284684800 mov byte ptr [0x486884], al
0044aabc RVA 0004aabc 8915d86b4800 mov dword ptr [0x486bd8], edx
0044aac2 RVA 0004aac2 8b11 mov edx, dword ptr [ecx]
0044aac4 RVA 0004aac4 8bc5 mov eax, ebp
0044aac6 RVA 0004aac6 2bc2 sub eax, edx
0044aac8 RVA 0004aac8 03c7 add eax, edi
0044aaca RVA 0004aaca a3dc6b4800 mov dword ptr [0x486bdc], eax
0044aacf RVA 0004aacf eb10 jmp 0x44aae1
0044aad1 RVA 0004aad1 81ff87130000 cmp edi, 0x1387
004012f8 RVA 000012f8 e9539a0400 jmp 0x44ad50
0040203b RVA 0000203b e9f0860400 jmp 0x44a730
00466f26 RVA 00066f26 ff251c636c00 jmp dword ptr [0x6c631c]
00466f56 RVA 00066f56 ff2538636c00 jmp dword ptr [0x6c6338]
PRODUCER THUNK 0x4021ad