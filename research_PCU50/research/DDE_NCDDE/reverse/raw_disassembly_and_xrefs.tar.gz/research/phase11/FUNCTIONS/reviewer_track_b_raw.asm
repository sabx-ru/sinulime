Input: /root/PL/PCU_old/H/mmc2/ncdde.exe; ImageBase=0x400000; Capstone x86-32; all addresses VA, RVA=VA-ImageBase.

RANGE VA 00448AC0..00448BD0 RVA 00048AC0 file offset 00048AC0
VA 00448AC0 RVA 00048AC0 bytes 55                        push ebp
VA 00448AC1 RVA 00048AC1 bytes 8b ec                     mov ebp, esp
VA 00448AC3 RVA 00048AC3 bytes 6a ff                     push -1
VA 00448AC5 RVA 00048AC5 bytes 68 68 a9 46 00            push 0x46a968
VA 00448ACA RVA 00048ACA bytes 64 a1 00 00 00 00         mov eax, dword ptr fs:[0]
VA 00448AD0 RVA 00048AD0 bytes 50                        push eax
VA 00448AD1 RVA 00048AD1 bytes 64 89 25 00 00 00 00      mov dword ptr fs:[0], esp
VA 00448AD8 RVA 00048AD8 bytes 83 ec 58                  sub esp, 0x58
VA 00448ADB RVA 00048ADB bytes 53                        push ebx
VA 00448ADC RVA 00048ADC bytes 56                        push esi
VA 00448ADD RVA 00048ADD bytes 83 cb ff                  or ebx, 0xffffffff
VA 00448AE0 RVA 00048AE0 bytes 57                        push edi
VA 00448AE1 RVA 00048AE1 bytes b9 0c 00 00 00            mov ecx, 0xc
VA 00448AE6 RVA 00048AE6 bytes 8b c3                     mov eax, ebx
VA 00448AE8 RVA 00048AE8 bytes 8d 7d 9c                  lea edi, [ebp - 0x64]
VA 00448AEB RVA 00048AEB bytes 66 89 5d cc               mov word ptr [ebp - 0x34], bx
VA 00448AEF RVA 00048AEF bytes 89 65 f0                  mov dword ptr [ebp - 0x10], esp
VA 00448AF2 RVA 00048AF2 bytes f3 ab                     rep stosd dword ptr es:[edi], eax
VA 00448AF4 RVA 00048AF4 bytes 8b 75 08                  mov esi, dword ptr [ebp + 8]
VA 00448AF7 RVA 00048AF7 bytes 33 ff                     xor edi, edi
VA 00448AF9 RVA 00048AF9 bytes 81 fe 90 40 00 00         cmp esi, 0x4090
VA 00448AFF RVA 00048AFF bytes 89 7d fc                  mov dword ptr [ebp - 4], edi
VA 00448B02 RVA 00048B02 bytes 0f 87 6f 0d 00 00         ja 0x449877
VA 00448B08 RVA 00048B08 bytes 0f 84 fc 0a 00 00         je 0x44960a
VA 00448B0E RVA 00048B0E bytes 81 fe 22 20 00 00         cmp esi, 0x2022
VA 00448B14 RVA 00048B14 bytes 0f 87 59 06 00 00         ja 0x449173
VA 00448B1A RVA 00048B1A bytes 0f 84 d1 04 00 00         je 0x448ff1
VA 00448B20 RVA 00048B20 bytes 8d 86 d0 ef ff ff         lea eax, [esi - 0x1030]
VA 00448B26 RVA 00048B26 bytes 83 f8 32                  cmp eax, 0x32
VA 00448B29 RVA 00048B29 bytes 0f 87 4a 0f 00 00         ja 0x449a79
VA 00448B2F RVA 00048B2F bytes 33 c9                     xor ecx, ecx
VA 00448B31 RVA 00048B31 bytes 8a 88 c8 9a 44 00         mov cl, byte ptr [eax + 0x449ac8]
VA 00448B37 RVA 00048B37 bytes ff 24 8d b8 9a 44 00      jmp dword ptr [ecx*4 + 0x449ab8]
VA 00448B3E RVA 00048B3E bytes a0 16 6d 4a 00            mov al, byte ptr [0x4a6d16]
VA 00448B43 RVA 00048B43 bytes 84 c0                     test al, al
VA 00448B45 RVA 00048B45 bytes 75 3f                     jne 0x448b86
VA 00448B47 RVA 00048B47 bytes 80 3d 02 c6 47 00 02      cmp byte ptr [0x47c602], 2
VA 00448B4E RVA 00048B4E bytes 76 20                     jbe 0x448b70
VA 00448B50 RVA 00048B50 bytes 8d 55 0c                  lea edx, [ebp + 0xc]
VA 00448B53 RVA 00048B53 bytes b9 b0 40 48 00            mov ecx, 0x4840b0
VA 00448B58 RVA 00048B58 bytes 52                        push edx
VA 00448B59 RVA 00048B59 bytes 68 74 af 47 00            push 0x47af74
VA 00448B5E RVA 00048B5E bytes e8 e5 96 fb ff            call 0x402248
VA 00448B63 RVA 00048B63 bytes 85 c0                     test eax, eax
VA 00448B65 RVA 00048B65 bytes 75 09                     jne 0x448b70
VA 00448B67 RVA 00048B67 bytes a0 74 68 48 00            mov al, byte ptr [0x486874]
VA 00448B6C RVA 00048B6C bytes 84 c0                     test al, al
VA 00448B6E RVA 00048B6E bytes 74 16                     je 0x448b86
VA 00448B70 RVA 00048B70 bytes a1 64 68 48 00            mov eax, dword ptr [0x486864]
VA 00448B75 RVA 00048B75 bytes 8b 0d 18 6d 4a 00         mov ecx, dword ptr [0x4a6d18]
VA 00448B7B RVA 00048B7B bytes 50                        push eax
VA 00448B7C RVA 00048B7C bytes 51                        push ecx
VA 00448B7D RVA 00048B7D bytes e8 a4 e3 01 00            call 0x466f26
VA 00448B82 RVA 00048B82 bytes 85 c0                     test eax, eax
VA 00448B84 RVA 00048B84 bytes 74 0c                     je 0x448b92
VA 00448B86 RVA 00048B86 bytes 66 39 5d cc               cmp word ptr [ebp - 0x34], bx
VA 00448B8A RVA 00048B8A bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 00448B8D RVA 00048B8D bytes e9 bc 02 00 00            jmp 0x448e4e
VA 00448B92 RVA 00048B92 bytes 83 7d 18 01               cmp dword ptr [ebp + 0x18], 1
VA 00448B96 RVA 00048B96 bytes 75 0c                     jne 0x448ba4
VA 00448B98 RVA 00048B98 bytes 66 39 5d cc               cmp word ptr [ebp - 0x34], bx
VA 00448B9C RVA 00048B9C bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 00448B9F RVA 00048B9F bytes e9 aa 02 00 00            jmp 0x448e4e
VA 00448BA4 RVA 00048BA4 bytes 80 3d 17 6d 4a 00 01      cmp byte ptr [0x4a6d17], 1
VA 00448BAB RVA 00048BAB bytes 75 29                     jne 0x448bd6
VA 00448BAD RVA 00048BAD bytes 8b 15 2c 6d 4a 00         mov edx, dword ptr [0x4a6d2c]
VA 00448BB3 RVA 00048BB3 bytes a1 68 68 48 00            mov eax, dword ptr [0x486868]
VA 00448BB8 RVA 00048BB8 bytes 8b 4a 04                  mov ecx, dword ptr [edx + 4]
VA 00448BBB RVA 00048BBB bytes 3b c8                     cmp ecx, eax
VA 00448BBD RVA 00048BBD bytes 74 0b                     je 0x448bca
VA 00448BBF RVA 00048BBF bytes 8b 0d 24 6d 4a 00         mov ecx, dword ptr [0x4a6d24]
VA 00448BC5 RVA 00048BC5 bytes 39 41 04                  cmp dword ptr [ecx + 4], eax
VA 00448BC8 RVA 00048BC8 bytes 75 11                     jne 0x448bdb
VA 00448BCA RVA 00048BCA bytes 66 39 5d cc               cmp word ptr [ebp - 0x34], bx

RANGE VA 00449160..004492D3 RVA 00049160 file offset 00049160
VA 00449160 RVA 00049160 bytes 8b 45 cc                  mov eax, dword ptr [ebp - 0x34]
VA 00449163 RVA 00049163 bytes c7 45 fc ff ff ff ff      mov dword ptr [ebp - 4], 0xffffffff
VA 0044916A RVA 0004916A bytes 66 3d ff ff               cmp ax, 0xffff
VA 0044916E RVA 0004916E bytes e9 c3 07 00 00            jmp 0x449936
VA 00449173 RVA 00049173 bytes 8b c6                     mov eax, esi
VA 00449175 RVA 00049175 bytes 2d b0 20 00 00            sub eax, 0x20b0
VA 0044917A RVA 0004917A bytes 0f 84 e5 00 00 00         je 0x449265
VA 00449180 RVA 00049180 bytes 83 e8 32                  sub eax, 0x32
VA 00449183 RVA 00049183 bytes 0f 84 cd 00 00 00         je 0x449256
VA 00449189 RVA 00049189 bytes 2d 6e 1f 00 00            sub eax, 0x1f6e
VA 0044918E RVA 0004918E bytes 0f 85 e5 08 00 00         jne 0x449a79
VA 00449194 RVA 00049194 bytes 80 3d e8 6c 4a 00 02      cmp byte ptr [0x4a6ce8], 2
VA 0044919B RVA 0004919B bytes 75 24                     jne 0x4491c1
VA 0044919D RVA 0004919D bytes 66 39 5d cc               cmp word ptr [ebp - 0x34], bx
VA 004491A1 RVA 000491A1 bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 004491A4 RVA 000491A4 bytes 74 08                     je 0x4491ae
VA 004491A6 RVA 000491A6 bytes 8d 4d cc                  lea ecx, [ebp - 0x34]
VA 004491A9 RVA 000491A9 bytes e8 01 8e fb ff            call 0x401faf
VA 004491AE RVA 000491AE bytes 8b c3                     mov eax, ebx
VA 004491B0 RVA 000491B0 bytes 8b 4d f4                  mov ecx, dword ptr [ebp - 0xc]
VA 004491B3 RVA 000491B3 bytes 64 89 0d 00 00 00 00      mov dword ptr fs:[0], ecx
VA 004491BA RVA 000491BA bytes 5f                        pop edi
VA 004491BB RVA 000491BB bytes 5e                        pop esi
VA 004491BC RVA 000491BC bytes 5b                        pop ebx
VA 004491BD RVA 000491BD bytes 8b e5                     mov esp, ebp
VA 004491BF RVA 000491BF bytes 5d                        pop ebp
VA 004491C0 RVA 000491C0 bytes c3                        ret 
VA 004491C1 RVA 000491C1 bytes 8b 0d 5c 68 48 00         mov ecx, dword ptr [0x48685c]
VA 004491C7 RVA 000491C7 bytes 8b 15 04 6d 4a 00         mov edx, dword ptr [0x4a6d04]
VA 004491CD RVA 000491CD bytes 33 c0                     xor eax, eax
VA 004491CF RVA 000491CF bytes 3b d1                     cmp edx, ecx
VA 004491D1 RVA 000491D1 bytes 74 51                     je 0x449224
VA 004491D3 RVA 000491D3 bytes 8b 15 08 6d 4a 00         mov edx, dword ptr [0x4a6d08]
VA 004491D9 RVA 000491D9 bytes b8 01 00 00 00            mov eax, 1
VA 004491DE RVA 000491DE bytes 3b d1                     cmp edx, ecx
VA 004491E0 RVA 000491E0 bytes 74 42                     je 0x449224
VA 004491E2 RVA 000491E2 bytes 8b 15 0c 6d 4a 00         mov edx, dword ptr [0x4a6d0c]
VA 004491E8 RVA 000491E8 bytes b8 02 00 00 00            mov eax, 2
VA 004491ED RVA 000491ED bytes 3b d1                     cmp edx, ecx
VA 004491EF RVA 000491EF bytes 74 33                     je 0x449224
VA 004491F1 RVA 000491F1 bytes a0 16 6d 4a 00            mov al, byte ptr [0x4a6d16]
VA 004491F6 RVA 000491F6 bytes 84 c0                     test al, al
VA 004491F8 RVA 000491F8 bytes 74 04                     je 0x4491fe
VA 004491FA RVA 000491FA bytes 33 f6                     xor esi, esi
VA 004491FC RVA 000491FC bytes eb 34                     jmp 0x449232
VA 004491FE RVA 000491FE bytes 83 3d d0 6c 4a 00 01      cmp dword ptr [0x4a6cd0], 1
VA 00449205 RVA 00049205 bytes 74 0d                     je 0x449214
VA 00449207 RVA 00049207 bytes 51                        push ecx
VA 00449208 RVA 00049208 bytes e8 9d 88 fb ff            call 0x401aaa
VA 0044920D RVA 0004920D bytes 83 c4 04                  add esp, 4
VA 00449210 RVA 00049210 bytes 8b f0                     mov esi, eax
VA 00449212 RVA 00049212 bytes eb 1e                     jmp 0x449232
VA 00449214 RVA 00049214 bytes 8b 4d 10                  mov ecx, dword ptr [ebp + 0x10]
VA 00449217 RVA 00049217 bytes 51                        push ecx
VA 00449218 RVA 00049218 bytes e8 12 95 fb ff            call 0x40272f
VA 0044921D RVA 0004921D bytes 83 c4 04                  add esp, 4
VA 00449220 RVA 00049220 bytes 8b f0                     mov esi, eax
VA 00449222 RVA 00049222 bytes eb 0e                     jmp 0x449232
VA 00449224 RVA 00049224 bytes 8b 34 85 f8 6c 4a 00      mov esi, dword ptr [eax*4 + 0x4a6cf8]
VA 0044922B RVA 0004922B bytes 89 3c 85 04 6d 4a 00      mov dword ptr [eax*4 + 0x4a6d04], edi
VA 00449232 RVA 00049232 bytes 66 39 5d cc               cmp word ptr [ebp - 0x34], bx
VA 00449236 RVA 00049236 bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 00449239 RVA 00049239 bytes 74 08                     je 0x449243
VA 0044923B RVA 0004923B bytes 8d 4d cc                  lea ecx, [ebp - 0x34]
VA 0044923E RVA 0004923E bytes e8 6c 8d fb ff            call 0x401faf
VA 00449243 RVA 00049243 bytes 8b c6                     mov eax, esi
VA 00449245 RVA 00049245 bytes 8b 4d f4                  mov ecx, dword ptr [ebp - 0xc]
VA 00449248 RVA 00049248 bytes 64 89 0d 00 00 00 00      mov dword ptr fs:[0], ecx
VA 0044924F RVA 0004924F bytes 5f                        pop edi
VA 00449250 RVA 00049250 bytes 5e                        pop esi
VA 00449251 RVA 00049251 bytes 5b                        pop ebx
VA 00449252 RVA 00049252 bytes 8b e5                     mov esp, ebp
VA 00449254 RVA 00049254 bytes 5d                        pop ebp
VA 00449255 RVA 00049255 bytes c3                        ret 
VA 00449256 RVA 00049256 bytes 8b 0d 6c 27 48 00         mov ecx, dword ptr [0x48276c]
VA 0044925C RVA 0004925C bytes e8 e0 7d fb ff            call 0x401041
VA 00449261 RVA 00049261 bytes 8b f0                     mov esi, eax
VA 00449263 RVA 00049263 bytes eb cd                     jmp 0x449232
VA 00449265 RVA 00049265 bytes a0 16 6d 4a 00            mov al, byte ptr [0x4a6d16]
VA 0044926A RVA 0004926A bytes 84 c0                     test al, al
VA 0044926C RVA 0004926C bytes 0f 85 e1 07 00 00         jne 0x449a53
VA 00449272 RVA 00049272 bytes 8b 75 0c                  mov esi, dword ptr [ebp + 0xc]
VA 00449275 RVA 00049275 bytes 83 fe 01                  cmp esi, 1
VA 00449278 RVA 00049278 bytes 74 59                     je 0x4492d3
VA 0044927A RVA 0004927A bytes 33 d2                     xor edx, edx
VA 0044927C RVA 0004927C bytes 66 8b 15 50 99 49 00      mov dx, word ptr [0x499950]
VA 00449283 RVA 00049283 bytes 3b f2                     cmp esi, edx
VA 00449285 RVA 00049285 bytes 74 4c                     je 0x4492d3
VA 00449287 RVA 00049287 bytes 83 fe 07                  cmp esi, 7
VA 0044928A RVA 0004928A bytes 75 3b                     jne 0x4492c7
VA 0044928C RVA 0004928C bytes a1 64 68 48 00            mov eax, dword ptr [0x486864]
VA 00449291 RVA 00049291 bytes 8b 0d 18 6d 4a 00         mov ecx, dword ptr [0x4a6d18]
VA 00449297 RVA 00049297 bytes 50                        push eax
VA 00449298 RVA 00049298 bytes 51                        push ecx
VA 00449299 RVA 00049299 bytes e8 88 dc 01 00            call 0x466f26
VA 0044929E RVA 0004929E bytes 85 c0                     test eax, eax
VA 004492A0 RVA 000492A0 bytes 0f 85 ad 07 00 00         jne 0x449a53
VA 004492A6 RVA 000492A6 bytes 8b 15 64 68 48 00         mov edx, dword ptr [0x486864]
VA 004492AC RVA 000492AC bytes a1 c0 6c 4a 00            mov eax, dword ptr [0x4a6cc0]
VA 004492B1 RVA 000492B1 bytes 57                        push edi
VA 004492B2 RVA 000492B2 bytes 56                        push esi
VA 004492B3 RVA 000492B3 bytes 52                        push edx
VA 004492B4 RVA 000492B4 bytes 57                        push edi
VA 004492B5 RVA 000492B5 bytes 6a 06                     push 6
VA 004492B7 RVA 000492B7 bytes 68 64 9c 47 00            push 0x479c64
VA 004492BC RVA 000492BC bytes 50                        push eax
VA 004492BD RVA 000492BD bytes e8 94 dc 01 00            call 0x466f56
VA 004492C2 RVA 000492C2 bytes e9 63 06 00 00            jmp 0x44992a
VA 004492C7 RVA 000492C7 bytes 6a 04                     push 4
VA 004492C9 RVA 000492C9 bytes e8 93 85 fb ff            call 0x401861
VA 004492CE RVA 000492CE bytes e9 54 06 00 00            jmp 0x449927

RANGE VA 00449880..00449A80 RVA 00049880 file offset 00049880
VA 00449880 RVA 00049880 bytes 00 00                     add byte ptr [eax], al
VA 00449882 RVA 00049882 bytes 0f 87 f1 01 00 00         ja 0x449a79
VA 00449888 RVA 00049888 bytes 33 c9                     xor ecx, ecx
VA 0044988A RVA 0004988A bytes 8a 88 14 9b 44 00         mov cl, byte ptr [eax + 0x449b14]
VA 00449890 RVA 00049890 bytes ff 24 8d fc 9a 44 00      jmp dword ptr [ecx*4 + 0x449afc]
VA 00449897 RVA 00049897 bytes a1 5c 68 48 00            mov eax, dword ptr [0x48685c]
VA 0044989C RVA 0004989C bytes 8b 0d 04 6d 4a 00         mov ecx, dword ptr [0x4a6d04]
VA 004498A2 RVA 000498A2 bytes 3b c8                     cmp ecx, eax
VA 004498A4 RVA 000498A4 bytes 75 06                     jne 0x4498ac
VA 004498A6 RVA 000498A6 bytes 89 3d 04 6d 4a 00         mov dword ptr [0x4a6d04], edi
VA 004498AC RVA 000498AC bytes 39 05 08 6d 4a 00         cmp dword ptr [0x4a6d08], eax
VA 004498B2 RVA 000498B2 bytes 75 06                     jne 0x4498ba
VA 004498B4 RVA 000498B4 bytes 89 3d 08 6d 4a 00         mov dword ptr [0x4a6d08], edi
VA 004498BA RVA 000498BA bytes 39 05 0c 6d 4a 00         cmp dword ptr [0x4a6d0c], eax
VA 004498C0 RVA 000498C0 bytes 75 06                     jne 0x4498c8
VA 004498C2 RVA 000498C2 bytes 89 3d 0c 6d 4a 00         mov dword ptr [0x4a6d0c], edi
VA 004498C8 RVA 000498C8 bytes 8a 0d 16 6d 4a 00         mov cl, byte ptr [0x4a6d16]
VA 004498CE RVA 000498CE bytes 84 c9                     test cl, cl
VA 004498D0 RVA 000498D0 bytes 75 10                     jne 0x4498e2
VA 004498D2 RVA 000498D2 bytes 83 3d d0 6c 4a 00 01      cmp dword ptr [0x4a6cd0], 1
VA 004498D9 RVA 000498D9 bytes 74 07                     je 0x4498e2
VA 004498DB RVA 000498DB bytes e8 25 77 fb ff            call 0x401005
VA 004498E0 RVA 000498E0 bytes eb 09                     jmp 0x4498eb
VA 004498E2 RVA 000498E2 bytes 50                        push eax
VA 004498E3 RVA 000498E3 bytes e8 6a 8e fb ff            call 0x402752
VA 004498E8 RVA 000498E8 bytes 83 c4 04                  add esp, 4
VA 004498EB RVA 000498EB bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 004498EE RVA 000498EE bytes 66 39 5d cc               cmp word ptr [ebp - 0x34], bx
VA 004498F2 RVA 000498F2 bytes 74 08                     je 0x4498fc
VA 004498F4 RVA 000498F4 bytes 8d 4d cc                  lea ecx, [ebp - 0x34]
VA 004498F7 RVA 000498F7 bytes e8 b3 86 fb ff            call 0x401faf
VA 004498FC RVA 000498FC bytes b8 01 00 00 00            mov eax, 1
VA 00449901 RVA 00049901 bytes 8b 4d f4                  mov ecx, dword ptr [ebp - 0xc]
VA 00449904 RVA 00049904 bytes 64 89 0d 00 00 00 00      mov dword ptr fs:[0], ecx
VA 0044990B RVA 0004990B bytes 5f                        pop edi
VA 0044990C RVA 0004990C bytes 5e                        pop esi
VA 0044990D RVA 0004990D bytes 5b                        pop ebx
VA 0044990E RVA 0004990E bytes 8b e5                     mov esp, ebp
VA 00449910 RVA 00049910 bytes 5d                        pop ebp
VA 00449911 RVA 00049911 bytes c3                        ret 
VA 00449912 RVA 00049912 bytes 83 3d d0 6c 4a 00 01      cmp dword ptr [0x4a6cd0], 1
VA 00449919 RVA 00049919 bytes 74 58                     je 0x449973
VA 0044991B RVA 0004991B bytes 8b 15 5c 68 48 00         mov edx, dword ptr [0x48685c]
VA 00449921 RVA 00049921 bytes 52                        push edx
VA 00449922 RVA 00049922 bytes e8 83 81 fb ff            call 0x401aaa
VA 00449927 RVA 00049927 bytes 83 c4 04                  add esp, 4
VA 0044992A RVA 0004992A bytes 8b f0                     mov esi, eax
VA 0044992C RVA 0004992C bytes 66 8b 45 cc               mov ax, word ptr [ebp - 0x34]
VA 00449930 RVA 00049930 bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 00449933 RVA 00049933 bytes 66 3b c3                  cmp ax, bx
VA 00449936 RVA 00049936 bytes 0f 84 07 f9 ff ff         je 0x449243
VA 0044993C RVA 0004993C bytes 0f bf c0                  movsx eax, ax
VA 0044993F RVA 0004993F bytes 8d 04 40                  lea eax, [eax + eax*2]
VA 00449942 RVA 00049942 bytes 66 ff 0c 45 c4 25 48 00   dec word ptr [eax*2 + 0x4825c4]
VA 0044994A RVA 0004994A bytes 66 39 3c 45 c4 25 48 00   cmp word ptr [eax*2 + 0x4825c4], di
VA 00449952 RVA 00049952 bytes 0f 85 eb f8 ff ff         jne 0x449243
VA 00449958 RVA 00049958 bytes 8d 4d cc                  lea ecx, [ebp - 0x34]
VA 0044995B RVA 0004995B bytes e8 a3 82 fb ff            call 0x401c03
VA 00449960 RVA 00049960 bytes 8b c6                     mov eax, esi
VA 00449962 RVA 00049962 bytes 8b 4d f4                  mov ecx, dword ptr [ebp - 0xc]
VA 00449965 RVA 00049965 bytes 64 89 0d 00 00 00 00      mov dword ptr fs:[0], ecx
VA 0044996C RVA 0004996C bytes 5f                        pop edi
VA 0044996D RVA 0004996D bytes 5e                        pop esi
VA 0044996E RVA 0004996E bytes 5b                        pop ebx
VA 0044996F RVA 0004996F bytes 8b e5                     mov esp, ebp
VA 00449971 RVA 00049971 bytes 5d                        pop ebp
VA 00449972 RVA 00049972 bytes c3                        ret 
VA 00449973 RVA 00049973 bytes 68 d0 42 48 00            push 0x4842d0
VA 00449978 RVA 00049978 bytes e8 d4 89 fb ff            call 0x402351
VA 0044997D RVA 0004997D bytes 83 c4 04                  add esp, 4
VA 00449980 RVA 00049980 bytes 8d 4d 9c                  lea ecx, [ebp - 0x64]
VA 00449983 RVA 00049983 bytes 8d 55 e8                  lea edx, [ebp - 0x18]
VA 00449986 RVA 00049986 bytes a3 60 68 48 00            mov dword ptr [0x486860], eax
VA 0044998B RVA 0004998B bytes 6a 01                     push 1
VA 0044998D RVA 0004998D bytes 51                        push ecx
VA 0044998E RVA 0004998E bytes 52                        push edx
VA 0044998F RVA 0004998F bytes 50                        push eax
VA 00449990 RVA 00049990 bytes b9 b0 40 48 00            mov ecx, 0x4840b0
VA 00449995 RVA 00049995 bytes e8 37 82 fb ff            call 0x401bd1
VA 0044999A RVA 0004999A bytes 85 c0                     test eax, eax
VA 0044999C RVA 0004999C bytes 75 53                     jne 0x4499f1
VA 0044999E RVA 0004999E bytes 6a 0a                     push 0xa
VA 004499A0 RVA 000499A0 bytes e8 68 8c fb ff            call 0x40260d
VA 004499A5 RVA 000499A5 bytes 8b f0                     mov esi, eax
VA 004499A7 RVA 000499A7 bytes 66 8b 45 cc               mov ax, word ptr [ebp - 0x34]
VA 004499AB RVA 000499AB bytes 83 c4 04                  add esp, 4
VA 004499AE RVA 000499AE bytes 66 3b c3                  cmp ax, bx
VA 004499B1 RVA 000499B1 bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 004499B4 RVA 000499B4 bytes 0f 84 89 f8 ff ff         je 0x449243
VA 004499BA RVA 000499BA bytes 0f bf c0                  movsx eax, ax
VA 004499BD RVA 000499BD bytes 8d 04 40                  lea eax, [eax + eax*2]
VA 004499C0 RVA 000499C0 bytes 66 ff 0c 45 c4 25 48 00   dec word ptr [eax*2 + 0x4825c4]
VA 004499C8 RVA 000499C8 bytes 66 39 3c 45 c4 25 48 00   cmp word ptr [eax*2 + 0x4825c4], di
VA 004499D0 RVA 000499D0 bytes 0f 85 6d f8 ff ff         jne 0x449243
VA 004499D6 RVA 000499D6 bytes 8d 4d cc                  lea ecx, [ebp - 0x34]
VA 004499D9 RVA 000499D9 bytes e8 25 82 fb ff            call 0x401c03
VA 004499DE RVA 000499DE bytes 8b c6                     mov eax, esi
VA 004499E0 RVA 000499E0 bytes 8b 4d f4                  mov ecx, dword ptr [ebp - 0xc]
VA 004499E3 RVA 000499E3 bytes 64 89 0d 00 00 00 00      mov dword ptr fs:[0], ecx
VA 004499EA RVA 000499EA bytes 5f                        pop edi
VA 004499EB RVA 000499EB bytes 5e                        pop esi
VA 004499EC RVA 000499EC bytes 5b                        pop ebx
VA 004499ED RVA 000499ED bytes 8b e5                     mov esp, ebp
VA 004499EF RVA 000499EF bytes 5d                        pop ebp
VA 004499F0 RVA 000499F0 bytes c3                        ret 
VA 004499F1 RVA 000499F1 bytes 8b 4d e8                  mov ecx, dword ptr [ebp - 0x18]
VA 004499F4 RVA 000499F4 bytes f6 41 1f 01               test byte ptr [ecx + 0x1f], 1
VA 004499F8 RVA 000499F8 bytes 75 0d                     jne 0x449a07
VA 004499FA RVA 000499FA bytes a1 2c 6d 4a 00            mov eax, dword ptr [0x4a6d2c]
VA 004499FF RVA 000499FF bytes 8b 40 04                  mov eax, dword ptr [eax + 4]
VA 00449A02 RVA 00049A02 bytes a3 68 68 48 00            mov dword ptr [0x486868], eax
VA 00449A07 RVA 00049A07 bytes 6a 02                     push 2
VA 00449A09 RVA 00049A09 bytes e8 99 88 fb ff            call 0x4022a7
VA 00449A0E RVA 00049A0E bytes 3b c7                     cmp eax, edi
VA 00449A10 RVA 00049A10 bytes 89 45 ec                  mov dword ptr [ebp - 0x14], eax
VA 00449A13 RVA 00049A13 bytes 74 3e                     je 0x449a53
VA 00449A15 RVA 00049A15 bytes 8b 15 60 68 48 00         mov edx, dword ptr [0x486860]
VA 00449A1B RVA 00049A1B bytes a3 54 68 48 00            mov dword ptr [0x486854], eax
VA 00449A20 RVA 00049A20 bytes 66 8b 48 36               mov cx, word ptr [eax + 0x36]
VA 00449A24 RVA 00049A24 bytes 56                        push esi
VA 00449A25 RVA 00049A25 bytes 66 89 0d 50 68 48 00      mov word ptr [0x486850], cx
VA 00449A2C RVA 00049A2C bytes 89 50 08                  mov dword ptr [eax + 8], edx
VA 00449A2F RVA 00049A2F bytes 8b 45 ec                  mov eax, dword ptr [ebp - 0x14]
VA 00449A32 RVA 00049A32 bytes 50                        push eax
VA 00449A33 RVA 00049A33 bytes e8 21 81 fb ff            call 0x401b59
VA 00449A38 RVA 00049A38 bytes 83 c4 08                  add esp, 8
VA 00449A3B RVA 00049A3B bytes e9 ea fe ff ff            jmp 0x44992a
VA 00449A40 RVA 00049A40 bytes 8b 0d 5c 68 48 00         mov ecx, dword ptr [0x48685c]
VA 00449A46 RVA 00049A46 bytes 6a 03                     push 3
VA 00449A48 RVA 00049A48 bytes 51                        push ecx
VA 00449A49 RVA 00049A49 bytes b9 a8 26 48 00            mov ecx, 0x4826a8
VA 00449A4E RVA 00049A4E bytes e8 e7 77 fb ff            call 0x40123a
VA 00449A53 RVA 00049A53 bytes 66 8b 45 cc               mov ax, word ptr [ebp - 0x34]
VA 00449A57 RVA 00049A57 bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx
VA 00449A5A RVA 00049A5A bytes 66 3b c3                  cmp ax, bx
VA 00449A5D RVA 00049A5D bytes 74 46                     je 0x449aa5
VA 00449A5F RVA 00049A5F bytes 0f bf c0                  movsx eax, ax
VA 00449A62 RVA 00049A62 bytes 8d 04 40                  lea eax, [eax + eax*2]
VA 00449A65 RVA 00049A65 bytes 66 ff 0c 45 c4 25 48 00   dec word ptr [eax*2 + 0x4825c4]
VA 00449A6D RVA 00049A6D bytes 66 39 3c 45 c4 25 48 00   cmp word ptr [eax*2 + 0x4825c4], di
VA 00449A75 RVA 00049A75 bytes 75 2e                     jne 0x449aa5
VA 00449A77 RVA 00049A77 bytes eb 24                     jmp 0x449a9d
VA 00449A79 RVA 00049A79 bytes 66 8b 45 cc               mov ax, word ptr [ebp - 0x34]
VA 00449A7D RVA 00049A7D bytes 89 5d fc                  mov dword ptr [ebp - 4], ebx

RANGE VA 0044A440..0044A730 RVA 0004A440 file offset 0004A440
VA 0044A440 RVA 0004A440 bytes 83 ec 10                  sub esp, 0x10
VA 0044A443 RVA 0004A443 bytes 53                        push ebx
VA 0044A444 RVA 0004A444 bytes 55                        push ebp
VA 0044A445 RVA 0004A445 bytes 8b 6c 24 1c               mov ebp, dword ptr [esp + 0x1c]
VA 0044A449 RVA 0004A449 bytes 56                        push esi
VA 0044A44A RVA 0004A44A bytes 57                        push edi
VA 0044A44B RVA 0004A44B bytes 8b 85 a6 00 00 00         mov eax, dword ptr [ebp + 0xa6]
VA 0044A451 RVA 0004A451 bytes 8b 08                     mov ecx, dword ptr [eax]
VA 0044A453 RVA 0004A453 bytes 8a 45 07                  mov al, byte ptr [ebp + 7]
VA 0044A456 RVA 0004A456 bytes 3c 02                     cmp al, 2
VA 0044A458 RVA 0004A458 bytes 8b 71 36                  mov esi, dword ptr [ecx + 0x36]
VA 0044A45B RVA 0004A45B bytes 75 54                     jne 0x44a4b1
VA 0044A45D RVA 0004A45D bytes 8b 55 1c                  mov edx, dword ptr [ebp + 0x1c]
VA 0044A460 RVA 0004A460 bytes a1 64 68 48 00            mov eax, dword ptr [0x486864]
VA 0044A465 RVA 0004A465 bytes 3b d0                     cmp edx, eax
VA 0044A467 RVA 0004A467 bytes 75 2b                     jne 0x44a494
VA 0044A469 RVA 0004A469 bytes 8b 45 20                  mov eax, dword ptr [ebp + 0x20]
VA 0044A46C RVA 0004A46C bytes 8b 0d 68 68 48 00         mov ecx, dword ptr [0x486868]
VA 0044A472 RVA 0004A472 bytes 3b c1                     cmp eax, ecx
VA 0044A474 RVA 0004A474 bytes 75 1e                     jne 0x44a494
VA 0044A476 RVA 0004A476 bytes 8b 4d 2e                  mov ecx, dword ptr [ebp + 0x2e]
VA 0044A479 RVA 0004A479 bytes a1 5c 68 48 00            mov eax, dword ptr [0x48685c]
VA 0044A47E RVA 0004A47E bytes 3b c8                     cmp ecx, eax
VA 0044A480 RVA 0004A480 bytes 75 12                     jne 0x44a494
VA 0044A482 RVA 0004A482 bytes 8b 85 80 00 00 00         mov eax, dword ptr [ebp + 0x80]
VA 0044A488 RVA 0004A488 bytes f7 d8                     neg eax
VA 0044A48A RVA 0004A48A bytes 1b c0                     sbb eax, eax
VA 0044A48C RVA 0004A48C bytes 23 c5                     and eax, ebp
VA 0044A48E RVA 0004A48E bytes 89 44 24 10               mov dword ptr [esp + 0x10], eax
VA 0044A492 RVA 0004A492 bytes eb 25                     jmp 0x44a4b9
VA 0044A494 RVA 0004A494 bytes 6a 02                     push 2
VA 0044A496 RVA 0004A496 bytes 8b ce                     mov ecx, esi
VA 0044A498 RVA 0004A498 bytes e8 0a 7e fb ff            call 0x4022a7
VA 0044A49D RVA 0004A49D bytes 85 c0                     test eax, eax
VA 0044A49F RVA 0004A49F bytes 89 44 24 10               mov dword ptr [esp + 0x10], eax
VA 0044A4A3 RVA 0004A4A3 bytes 74 14                     je 0x44a4b9
VA 0044A4A5 RVA 0004A4A5 bytes 8b d0                     mov edx, eax
VA 0044A4A7 RVA 0004A4A7 bytes 8b 82 80 00 00 00         mov eax, dword ptr [edx + 0x80]
VA 0044A4AD RVA 0004A4AD bytes 85 c0                     test eax, eax
VA 0044A4AF RVA 0004A4AF bytes 75 08                     jne 0x44a4b9
VA 0044A4B1 RVA 0004A4B1 bytes c7 44 24 10 00 00 00 00   mov dword ptr [esp + 0x10], 0
VA 0044A4B9 RVA 0004A4B9 bytes 8b 44 24 2c               mov eax, dword ptr [esp + 0x2c]
VA 0044A4BD RVA 0004A4BD bytes 8b 8d aa 00 00 00         mov ecx, dword ptr [ebp + 0xaa]
VA 0044A4C3 RVA 0004A4C3 bytes ba 01 00 00 00            mov edx, 1
VA 0044A4C8 RVA 0004A4C8 bytes c7 44 24 14 00 00 00 00   mov dword ptr [esp + 0x14], 0
VA 0044A4D0 RVA 0004A4D0 bytes 3b c2                     cmp eax, edx
VA 0044A4D2 RVA 0004A4D2 bytes 89 4c 24 18               mov dword ptr [esp + 0x18], ecx
VA 0044A4D6 RVA 0004A4D6 bytes 0f 84 fd 00 00 00         je 0x44a5d9
VA 0044A4DC RVA 0004A4DC bytes 3b ca                     cmp ecx, edx
VA 0044A4DE RVA 0004A4DE bytes 74 11                     je 0x44a4f1
VA 0044A4E0 RVA 0004A4E0 bytes 55                        push ebp
VA 0044A4E1 RVA 0004A4E1 bytes e8 80 6e fb ff            call 0x401366
VA 0044A4E6 RVA 0004A4E6 bytes 83 c4 04                  add esp, 4
VA 0044A4E9 RVA 0004A4E9 bytes 5f                        pop edi
VA 0044A4EA RVA 0004A4EA bytes 5e                        pop esi
VA 0044A4EB RVA 0004A4EB bytes 5d                        pop ebp
VA 0044A4EC RVA 0004A4EC bytes 5b                        pop ebx
VA 0044A4ED RVA 0004A4ED bytes 83 c4 10                  add esp, 0x10
VA 0044A4F0 RVA 0004A4F0 bytes c3                        ret 
VA 0044A4F1 RVA 0004A4F1 bytes f6 46 1f 01               test byte ptr [esi + 0x1f], 1
VA 0044A4F5 RVA 0004A4F5 bytes 0f 85 af 00 00 00         jne 0x44a5aa
VA 0044A4FB RVA 0004A4FB bytes 8b 85 a6 00 00 00         mov eax, dword ptr [ebp + 0xa6]
VA 0044A501 RVA 0004A501 bytes 83 cf ff                  or edi, 0xffffffff
VA 0044A504 RVA 0004A504 bytes 8b 08                     mov ecx, dword ptr [eax]
VA 0044A506 RVA 0004A506 bytes 8b 41 16                  mov eax, dword ptr [ecx + 0x16]
VA 0044A509 RVA 0004A509 bytes 3b c7                     cmp eax, edi
VA 0044A50B RVA 0004A50B bytes 75 15                     jne 0x44a522
VA 0044A50D RVA 0004A50D bytes 8b 51 06                  mov edx, dword ptr [ecx + 6]
VA 0044A510 RVA 0004A510 bytes 3b d7                     cmp edx, edi
VA 0044A512 RVA 0004A512 bytes 75 08                     jne 0x44a51c
VA 0044A514 RVA 0004A514 bytes 89 3d b8 6c 4a 00         mov dword ptr [0x4a6cb8], edi
VA 0044A51A RVA 0004A51A bytes eb 0f                     jmp 0x44a52b
VA 0044A51C RVA 0004A51C bytes 8b 41 0a                  mov eax, dword ptr [ecx + 0xa]
VA 0044A51F RVA 0004A51F bytes 2b c2                     sub eax, edx
VA 0044A521 RVA 0004A521 bytes 40                        inc eax
VA 0044A522 RVA 0004A522 bytes 3b c7                     cmp eax, edi
VA 0044A524 RVA 0004A524 bytes a3 b8 6c 4a 00            mov dword ptr [0x4a6cb8], eax
VA 0044A529 RVA 0004A529 bytes 75 2d                     jne 0x44a558
VA 0044A52B RVA 0004A52B bytes 8b 4e 19                  mov ecx, dword ptr [esi + 0x19]
VA 0044A52E RVA 0004A52E bytes 8b 41 26                  mov eax, dword ptr [ecx + 0x26]
VA 0044A531 RVA 0004A531 bytes 3b c7                     cmp eax, edi
VA 0044A533 RVA 0004A533 bytes 75 15                     jne 0x44a54a
VA 0044A535 RVA 0004A535 bytes 8b 51 16                  mov edx, dword ptr [ecx + 0x16]
VA 0044A538 RVA 0004A538 bytes 3b d7                     cmp edx, edi
VA 0044A53A RVA 0004A53A bytes 75 08                     jne 0x44a544
VA 0044A53C RVA 0004A53C bytes 89 3d b8 6c 4a 00         mov dword ptr [0x4a6cb8], edi
VA 0044A542 RVA 0004A542 bytes eb 0f                     jmp 0x44a553
VA 0044A544 RVA 0004A544 bytes 8b 41 1a                  mov eax, dword ptr [ecx + 0x1a]
VA 0044A547 RVA 0004A547 bytes 2b c2                     sub eax, edx
VA 0044A549 RVA 0004A549 bytes 40                        inc eax
VA 0044A54A RVA 0004A54A bytes 3b c7                     cmp eax, edi
VA 0044A54C RVA 0004A54C bytes a3 b8 6c 4a 00            mov dword ptr [0x4a6cb8], eax
VA 0044A551 RVA 0004A551 bytes 75 05                     jne 0x44a558
VA 0044A553 RVA 0004A553 bytes b8 01 00 00 00            mov eax, 1
VA 0044A558 RVA 0004A558 bytes 8b 4e 15                  mov ecx, dword ptr [esi + 0x15]
VA 0044A55B RVA 0004A55B bytes 49                        dec ecx
VA 0044A55C RVA 0004A55C bytes 74 2d                     je 0x44a58b
VA 0044A55E RVA 0004A55E bytes 83 e9 02                  sub ecx, 2
VA 0044A561 RVA 0004A561 bytes 75 3e                     jne 0x44a5a1
VA 0044A563 RVA 0004A563 bytes 83 f8 01                  cmp eax, 1
VA 0044A566 RVA 0004A566 bytes 74 11                     je 0x44a579
VA 0044A568 RVA 0004A568 bytes 55                        push ebp
VA 0044A569 RVA 0004A569 bytes e8 f8 6d fb ff            call 0x401366
VA 0044A56E RVA 0004A56E bytes 83 c4 04                  add esp, 4
VA 0044A571 RVA 0004A571 bytes 5f                        pop edi
VA 0044A572 RVA 0004A572 bytes 5e                        pop esi
VA 0044A573 RVA 0004A573 bytes 5d                        pop ebp
VA 0044A574 RVA 0004A574 bytes 5b                        pop ebx
VA 0044A575 RVA 0004A575 bytes 83 c4 10                  add esp, 0x10
VA 0044A578 RVA 0004A578 bytes c3                        ret 
VA 0044A579 RVA 0004A579 bytes 8b 54 24 2c               mov edx, dword ptr [esp + 0x2c]
VA 0044A57D RVA 0004A57D bytes 8b 46 09                  mov eax, dword ptr [esi + 9]
VA 0044A580 RVA 0004A580 bytes 8b 4e 11                  mov ecx, dword ptr [esi + 0x11]
VA 0044A583 RVA 0004A583 bytes 52                        push edx
VA 0044A584 RVA 0004A584 bytes 50                        push eax
VA 0044A585 RVA 0004A585 bytes 51                        push ecx
VA 0044A586 RVA 0004A586 bytes e9 ef 00 00 00            jmp 0x44a67a
VA 0044A58B RVA 0004A58B bytes 83 f8 01                  cmp eax, 1
VA 0044A58E RVA 0004A58E bytes 74 11                     je 0x44a5a1
VA 0044A590 RVA 0004A590 bytes 55                        push ebp
VA 0044A591 RVA 0004A591 bytes e8 d0 6d fb ff            call 0x401366
VA 0044A596 RVA 0004A596 bytes 83 c4 04                  add esp, 4
VA 0044A599 RVA 0004A599 bytes 5f                        pop edi
VA 0044A59A RVA 0004A59A bytes 5e                        pop esi
VA 0044A59B RVA 0004A59B bytes 5d                        pop ebp
VA 0044A59C RVA 0004A59C bytes 5b                        pop ebx
VA 0044A59D RVA 0004A59D bytes 83 c4 10                  add esp, 0x10
VA 0044A5A0 RVA 0004A5A0 bytes c3                        ret 
VA 0044A5A1 RVA 0004A5A1 bytes 8b 4c 24 18               mov ecx, dword ptr [esp + 0x18]
VA 0044A5A5 RVA 0004A5A5 bytes ba 01 00 00 00            mov edx, 1
VA 0044A5AA RVA 0004A5AA bytes 66 c7 05 d0 6b 48 00 14 00 mov word ptr [0x486bd0], 0x14
VA 0044A5B3 RVA 0004A5B3 bytes 66 89 15 d2 6b 48 00      mov word ptr [0x486bd2], dx
VA 0044A5BA RVA 0004A5BA bytes c7 05 e0 6b 48 00 f9 f8 f7 f6 mov dword ptr [0x486be0], 0xf6f7f8f9
VA 0044A5C4 RVA 0004A5C4 bytes 66 c7 05 d6 6b 48 00 00 00 mov word ptr [0x486bd6], 0
VA 0044A5CD RVA 0004A5CD bytes bf 03 00 00 00            mov edi, 3
VA 0044A5D2 RVA 0004A5D2 bytes b8 e4 6b 48 00            mov eax, 0x486be4
VA 0044A5D7 RVA 0004A5D7 bytes eb 07                     jmp 0x44a5e0
VA 0044A5D9 RVA 0004A5D9 bytes 8b fa                     mov edi, edx
VA 0044A5DB RVA 0004A5DB bytes b8 d0 6b 48 00            mov eax, 0x486bd0
VA 0044A5E0 RVA 0004A5E0 bytes 33 f6                     xor esi, esi
VA 0044A5E2 RVA 0004A5E2 bytes 89 44 24 24               mov dword ptr [esp + 0x24], eax
VA 0044A5E6 RVA 0004A5E6 bytes 85 c9                     test ecx, ecx
VA 0044A5E8 RVA 0004A5E8 bytes 89 54 24 1c               mov dword ptr [esp + 0x1c], edx
VA 0044A5EC RVA 0004A5EC bytes 7e 3f                     jle 0x44a62d
VA 0044A5EE RVA 0004A5EE bytes 8b 5c 24 28               mov ebx, dword ptr [esp + 0x28]
VA 0044A5F2 RVA 0004A5F2 bytes 8b 4c 24 2c               mov ecx, dword ptr [esp + 0x2c]
VA 0044A5F6 RVA 0004A5F6 bytes 57                        push edi
VA 0044A5F7 RVA 0004A5F7 bytes 8d 54 24 18               lea edx, [esp + 0x18]
VA 0044A5FB RVA 0004A5FB bytes 51                        push ecx
VA 0044A5FC RVA 0004A5FC bytes 8d 44 24 2c               lea eax, [esp + 0x2c]
VA 0044A600 RVA 0004A600 bytes 52                        push edx
VA 0044A601 RVA 0004A601 bytes 50                        push eax
VA 0044A602 RVA 0004A602 bytes 56                        push esi
VA 0044A603 RVA 0004A603 bytes 53                        push ebx
VA 0044A604 RVA 0004A604 bytes 8d 4c 24 34               lea ecx, [esp + 0x34]
VA 0044A608 RVA 0004A608 bytes 55                        push ebp
VA 0044A609 RVA 0004A609 bytes 51                        push ecx
VA 0044A60A RVA 0004A60A bytes e8 2c 7a fb ff            call 0x40203b
VA 0044A60F RVA 0004A60F bytes 83 c4 20                  add esp, 0x20
VA 0044A612 RVA 0004A612 bytes 83 f8 fd                  cmp eax, -3
VA 0044A615 RVA 0004A615 bytes 74 42                     je 0x44a659
VA 0044A617 RVA 0004A617 bytes 83 f8 fe                  cmp eax, -2
VA 0044A61A RVA 0004A61A bytes 74 47                     je 0x44a663
VA 0044A61C RVA 0004A61C bytes 85 c0                     test eax, eax
VA 0044A61E RVA 0004A61E bytes 74 39                     je 0x44a659
VA 0044A620 RVA 0004A620 bytes 8b 44 24 18               mov eax, dword ptr [esp + 0x18]
VA 0044A624 RVA 0004A624 bytes 46                        inc esi
VA 0044A625 RVA 0004A625 bytes 3b f0                     cmp esi, eax
VA 0044A627 RVA 0004A627 bytes 7c c9                     jl 0x44a5f2
VA 0044A629 RVA 0004A629 bytes 8b 44 24 24               mov eax, dword ptr [esp + 0x24]
VA 0044A62D RVA 0004A62D bytes 8b 4c 24 2c               mov ecx, dword ptr [esp + 0x2c]
VA 0044A631 RVA 0004A631 bytes 83 f9 01                  cmp ecx, 1
VA 0044A634 RVA 0004A634 bytes 75 0c                     jne 0x44a642
VA 0044A636 RVA 0004A636 bytes c6 00 00                  mov byte ptr [eax], 0
VA 0044A639 RVA 0004A639 bytes 8b 44 24 24               mov eax, dword ptr [esp + 0x24]
VA 0044A63D RVA 0004A63D bytes 40                        inc eax
VA 0044A63E RVA 0004A63E bytes 89 44 24 24               mov dword ptr [esp + 0x24], eax
VA 0044A642 RVA 0004A642 bytes 8b 54 24 10               mov edx, dword ptr [esp + 0x10]
VA 0044A646 RVA 0004A646 bytes 85 d2                     test edx, edx
VA 0044A648 RVA 0004A648 bytes 74 24                     je 0x44a66e
VA 0044A64A RVA 0004A64A bytes 8b 8a 80 00 00 00         mov ecx, dword ptr [edx + 0x80]
VA 0044A650 RVA 0004A650 bytes 68 d0 6b 48 00            push 0x486bd0
VA 0044A655 RVA 0004A655 bytes 8b 11                     mov edx, dword ptr [ecx]
VA 0044A657 RVA 0004A657 bytes ff 12                     call dword ptr [edx]
VA 0044A659 RVA 0004A659 bytes 5f                        pop edi
VA 0044A65A RVA 0004A65A bytes 5e                        pop esi
VA 0044A65B RVA 0004A65B bytes 5d                        pop ebp
VA 0044A65C RVA 0004A65C bytes 33 c0                     xor eax, eax
VA 0044A65E RVA 0004A65E bytes 5b                        pop ebx
VA 0044A65F RVA 0004A65F bytes 83 c4 10                  add esp, 0x10
VA 0044A662 RVA 0004A662 bytes c3                        ret 
VA 0044A663 RVA 0004A663 bytes 5f                        pop edi
VA 0044A664 RVA 0004A664 bytes 5e                        pop esi
VA 0044A665 RVA 0004A665 bytes 5d                        pop ebp
VA 0044A666 RVA 0004A666 bytes 83 c8 ff                  or eax, 0xffffffff
VA 0044A669 RVA 0004A669 bytes 5b                        pop ebx
VA 0044A66A RVA 0004A66A bytes 83 c4 10                  add esp, 0x10
VA 0044A66D RVA 0004A66D bytes c3                        ret 
VA 0044A66E RVA 0004A66E bytes 2d d0 6b 48 00            sub eax, 0x486bd0
VA 0044A673 RVA 0004A673 bytes 51                        push ecx
VA 0044A674 RVA 0004A674 bytes 50                        push eax
VA 0044A675 RVA 0004A675 bytes 68 d0 6b 48 00            push 0x486bd0
VA 0044A67A RVA 0004A67A bytes 8d 44 24 20               lea eax, [esp + 0x20]
VA 0044A67E RVA 0004A67E bytes 50                        push eax
VA 0044A67F RVA 0004A67F bytes 55                        push ebp
VA 0044A680 RVA 0004A680 bytes e8 73 6c fb ff            call 0x4012f8
VA 0044A685 RVA 0004A685 bytes 83 c4 14                  add esp, 0x14
VA 0044A688 RVA 0004A688 bytes 5f                        pop edi
VA 0044A689 RVA 0004A689 bytes 5e                        pop esi
VA 0044A68A RVA 0004A68A bytes 5d                        pop ebp
VA 0044A68B RVA 0004A68B bytes 5b                        pop ebx
VA 0044A68C RVA 0004A68C bytes 83 c4 10                  add esp, 0x10
VA 0044A68F RVA 0004A68F bytes c3                        ret 
VA 0044A690 RVA 0004A690 bytes cc                        int3 
VA 0044A691 RVA 0004A691 bytes cc                        int3 
VA 0044A692 RVA 0004A692 bytes cc                        int3 
VA 0044A693 RVA 0004A693 bytes cc                        int3 
VA 0044A694 RVA 0004A694 bytes cc                        int3 
VA 0044A695 RVA 0004A695 bytes cc                        int3 
VA 0044A696 RVA 0004A696 bytes cc                        int3 
VA 0044A697 RVA 0004A697 bytes cc                        int3 
VA 0044A698 RVA 0004A698 bytes cc                        int3 
VA 0044A699 RVA 0004A699 bytes cc                        int3 
VA 0044A69A RVA 0004A69A bytes cc                        int3 
VA 0044A69B RVA 0004A69B bytes cc                        int3 
VA 0044A69C RVA 0004A69C bytes cc                        int3 
VA 0044A69D RVA 0004A69D bytes cc                        int3 
VA 0044A69E RVA 0004A69E bytes cc                        int3 
VA 0044A69F RVA 0004A69F bytes cc                        int3 
VA 0044A6A0 RVA 0004A6A0 bytes cc                        int3 
VA 0044A6A1 RVA 0004A6A1 bytes cc                        int3 
VA 0044A6A2 RVA 0004A6A2 bytes cc                        int3 
VA 0044A6A3 RVA 0004A6A3 bytes cc                        int3 
VA 0044A6A4 RVA 0004A6A4 bytes cc                        int3 
VA 0044A6A5 RVA 0004A6A5 bytes cc                        int3 
VA 0044A6A6 RVA 0004A6A6 bytes cc                        int3 
VA 0044A6A7 RVA 0004A6A7 bytes cc                        int3 
VA 0044A6A8 RVA 0004A6A8 bytes cc                        int3 
VA 0044A6A9 RVA 0004A6A9 bytes cc                        int3 
VA 0044A6AA RVA 0004A6AA bytes cc                        int3 
VA 0044A6AB RVA 0004A6AB bytes cc                        int3 
VA 0044A6AC RVA 0004A6AC bytes cc                        int3 
VA 0044A6AD RVA 0004A6AD bytes cc                        int3 
VA 0044A6AE RVA 0004A6AE bytes cc                        int3 
VA 0044A6AF RVA 0004A6AF bytes cc                        int3 
VA 0044A6B0 RVA 0004A6B0 bytes cc                        int3 
VA 0044A6B1 RVA 0004A6B1 bytes cc                        int3 
VA 0044A6B2 RVA 0004A6B2 bytes cc                        int3 
VA 0044A6B3 RVA 0004A6B3 bytes cc                        int3 
VA 0044A6B4 RVA 0004A6B4 bytes cc                        int3 
VA 0044A6B5 RVA 0004A6B5 bytes cc                        int3 
VA 0044A6B6 RVA 0004A6B6 bytes cc                        int3 
VA 0044A6B7 RVA 0004A6B7 bytes cc                        int3 
VA 0044A6B8 RVA 0004A6B8 bytes cc                        int3 
VA 0044A6B9 RVA 0004A6B9 bytes cc                        int3 
VA 0044A6BA RVA 0004A6BA bytes cc                        int3 
VA 0044A6BB RVA 0004A6BB bytes cc                        int3 
VA 0044A6BC RVA 0004A6BC bytes cc                        int3 
VA 0044A6BD RVA 0004A6BD bytes cc                        int3 
VA 0044A6BE RVA 0004A6BE bytes cc                        int3 
VA 0044A6BF RVA 0004A6BF bytes cc                        int3 
VA 0044A6C0 RVA 0004A6C0 bytes cc                        int3 
VA 0044A6C1 RVA 0004A6C1 bytes cc                        int3 
VA 0044A6C2 RVA 0004A6C2 bytes cc                        int3 
VA 0044A6C3 RVA 0004A6C3 bytes cc                        int3 
VA 0044A6C4 RVA 0004A6C4 bytes cc                        int3 
VA 0044A6C5 RVA 0004A6C5 bytes cc                        int3 
VA 0044A6C6 RVA 0004A6C6 bytes cc                        int3 
VA 0044A6C7 RVA 0004A6C7 bytes cc                        int3 
VA 0044A6C8 RVA 0004A6C8 bytes cc                        int3 
VA 0044A6C9 RVA 0004A6C9 bytes cc                        int3 
VA 0044A6CA RVA 0004A6CA bytes cc                        int3 
VA 0044A6CB RVA 0004A6CB bytes cc                        int3 
VA 0044A6CC RVA 0004A6CC bytes cc                        int3 
VA 0044A6CD RVA 0004A6CD bytes cc                        int3 
VA 0044A6CE RVA 0004A6CE bytes cc                        int3 
VA 0044A6CF RVA 0004A6CF bytes cc                        int3 
VA 0044A6D0 RVA 0004A6D0 bytes cc                        int3 
VA 0044A6D1 RVA 0004A6D1 bytes cc                        int3 
VA 0044A6D2 RVA 0004A6D2 bytes cc                        int3 
VA 0044A6D3 RVA 0004A6D3 bytes cc                        int3 
VA 0044A6D4 RVA 0004A6D4 bytes cc                        int3 
VA 0044A6D5 RVA 0004A6D5 bytes cc                        int3 
VA 0044A6D6 RVA 0004A6D6 bytes cc                        int3 
VA 0044A6D7 RVA 0004A6D7 bytes cc                        int3 
VA 0044A6D8 RVA 0004A6D8 bytes cc                        int3 
VA 0044A6D9 RVA 0004A6D9 bytes cc                        int3 
VA 0044A6DA RVA 0004A6DA bytes cc                        int3 
VA 0044A6DB RVA 0004A6DB bytes cc                        int3 
VA 0044A6DC RVA 0004A6DC bytes cc                        int3 
VA 0044A6DD RVA 0004A6DD bytes cc                        int3 
VA 0044A6DE RVA 0004A6DE bytes cc                        int3 
VA 0044A6DF RVA 0004A6DF bytes cc                        int3 
VA 0044A6E0 RVA 0004A6E0 bytes cc                        int3 
VA 0044A6E1 RVA 0004A6E1 bytes cc                        int3 
VA 0044A6E2 RVA 0004A6E2 bytes cc                        int3 
VA 0044A6E3 RVA 0004A6E3 bytes cc                        int3 
VA 0044A6E4 RVA 0004A6E4 bytes cc                        int3 
VA 0044A6E5 RVA 0004A6E5 bytes cc                        int3 
VA 0044A6E6 RVA 0004A6E6 bytes cc                        int3 
VA 0044A6E7 RVA 0004A6E7 bytes cc                        int3 
VA 0044A6E8 RVA 0004A6E8 bytes cc                        int3 
VA 0044A6E9 RVA 0004A6E9 bytes cc                        int3 
VA 0044A6EA RVA 0004A6EA bytes cc                        int3 
VA 0044A6EB RVA 0004A6EB bytes cc                        int3 
VA 0044A6EC RVA 0004A6EC bytes cc                        int3 
VA 0044A6ED RVA 0004A6ED bytes cc                        int3 
VA 0044A6EE RVA 0004A6EE bytes cc                        int3 
VA 0044A6EF RVA 0004A6EF bytes cc                        int3 
VA 0044A6F0 RVA 0004A6F0 bytes cc                        int3 
VA 0044A6F1 RVA 0004A6F1 bytes cc                        int3 
VA 0044A6F2 RVA 0004A6F2 bytes cc                        int3 
VA 0044A6F3 RVA 0004A6F3 bytes cc                        int3 
VA 0044A6F4 RVA 0004A6F4 bytes cc                        int3 
VA 0044A6F5 RVA 0004A6F5 bytes cc                        int3 
VA 0044A6F6 RVA 0004A6F6 bytes cc                        int3 
VA 0044A6F7 RVA 0004A6F7 bytes cc                        int3 
VA 0044A6F8 RVA 0004A6F8 bytes cc                        int3 
VA 0044A6F9 RVA 0004A6F9 bytes cc                        int3 
VA 0044A6FA RVA 0004A6FA bytes cc                        int3 
VA 0044A6FB RVA 0004A6FB bytes cc                        int3 
VA 0044A6FC RVA 0004A6FC bytes cc                        int3 
VA 0044A6FD RVA 0004A6FD bytes cc                        int3 
VA 0044A6FE RVA 0004A6FE bytes cc                        int3 
VA 0044A6FF RVA 0004A6FF bytes cc                        int3 
VA 0044A700 RVA 0004A700 bytes cc                        int3 
VA 0044A701 RVA 0004A701 bytes cc                        int3 
VA 0044A702 RVA 0004A702 bytes cc                        int3 
VA 0044A703 RVA 0004A703 bytes cc                        int3 
VA 0044A704 RVA 0004A704 bytes cc                        int3 
VA 0044A705 RVA 0004A705 bytes cc                        int3 
VA 0044A706 RVA 0004A706 bytes cc                        int3 
VA 0044A707 RVA 0004A707 bytes cc                        int3 
VA 0044A708 RVA 0004A708 bytes cc                        int3 
VA 0044A709 RVA 0004A709 bytes cc                        int3 
VA 0044A70A RVA 0004A70A bytes cc                        int3 
VA 0044A70B RVA 0004A70B bytes cc                        int3 
VA 0044A70C RVA 0004A70C bytes cc                        int3 
VA 0044A70D RVA 0004A70D bytes cc                        int3 
VA 0044A70E RVA 0004A70E bytes cc                        int3 
VA 0044A70F RVA 0004A70F bytes cc                        int3 
VA 0044A710 RVA 0004A710 bytes cc                        int3 
VA 0044A711 RVA 0004A711 bytes cc                        int3 
VA 0044A712 RVA 0004A712 bytes cc                        int3 
VA 0044A713 RVA 0004A713 bytes cc                        int3 
VA 0044A714 RVA 0004A714 bytes cc                        int3 
VA 0044A715 RVA 0004A715 bytes cc                        int3 
VA 0044A716 RVA 0004A716 bytes cc                        int3 
VA 0044A717 RVA 0004A717 bytes cc                        int3 
VA 0044A718 RVA 0004A718 bytes cc                        int3 
VA 0044A719 RVA 0004A719 bytes cc                        int3 
VA 0044A71A RVA 0004A71A bytes cc                        int3 
VA 0044A71B RVA 0004A71B bytes cc                        int3 
VA 0044A71C RVA 0004A71C bytes cc                        int3 
VA 0044A71D RVA 0004A71D bytes cc                        int3 
VA 0044A71E RVA 0004A71E bytes cc                        int3 
VA 0044A71F RVA 0004A71F bytes cc                        int3 
VA 0044A720 RVA 0004A720 bytes cc                        int3 
VA 0044A721 RVA 0004A721 bytes cc                        int3 
VA 0044A722 RVA 0004A722 bytes cc                        int3 
VA 0044A723 RVA 0004A723 bytes cc                        int3 
VA 0044A724 RVA 0004A724 bytes cc                        int3 
VA 0044A725 RVA 0004A725 bytes cc                        int3 
VA 0044A726 RVA 0004A726 bytes cc                        int3 
VA 0044A727 RVA 0004A727 bytes cc                        int3 
VA 0044A728 RVA 0004A728 bytes cc                        int3 
VA 0044A729 RVA 0004A729 bytes cc                        int3 
VA 0044A72A RVA 0004A72A bytes cc                        int3 
VA 0044A72B RVA 0004A72B bytes cc                        int3 
VA 0044A72C RVA 0004A72C bytes cc                        int3 
VA 0044A72D RVA 0004A72D bytes cc                        int3 
VA 0044A72E RVA 0004A72E bytes cc                        int3 
VA 0044A72F RVA 0004A72F bytes cc                        int3 

RANGE VA 0044A730..0044AD50 RVA 0004A730 file offset 0004A730
VA 0044A730 RVA 0004A730 bytes 83 ec 20                  sub esp, 0x20
VA 0044A733 RVA 0004A733 bytes 8b 44 24 28               mov eax, dword ptr [esp + 0x28]
VA 0044A737 RVA 0004A737 bytes 53                        push ebx
VA 0044A738 RVA 0004A738 bytes 55                        push ebp
VA 0044A739 RVA 0004A739 bytes 56                        push esi
VA 0044A73A RVA 0004A73A bytes 8b 88 a6 00 00 00         mov ecx, dword ptr [eax + 0xa6]
VA 0044A740 RVA 0004A740 bytes 8b 44 24 3c               mov eax, dword ptr [esp + 0x3c]
VA 0044A744 RVA 0004A744 bytes 57                        push edi
VA 0044A745 RVA 0004A745 bytes 8b 14 81                  mov edx, dword ptr [ecx + eax*4]
VA 0044A748 RVA 0004A748 bytes 8b 4c 24 3c               mov ecx, dword ptr [esp + 0x3c]
VA 0044A74C RVA 0004A74C bytes 8b 5a 36                  mov ebx, dword ptr [edx + 0x36]
VA 0044A74F RVA 0004A74F bytes 8b 51 04                  mov edx, dword ptr [ecx + 4]
VA 0044A752 RVA 0004A752 bytes 8b 3c 82                  mov edi, dword ptr [edx + eax*4]
VA 0044A755 RVA 0004A755 bytes c7 44 24 1c 04 00 00 00   mov dword ptr [esp + 0x1c], 4
VA 0044A75D RVA 0004A75D bytes 83 c7 04                  add edi, 4
VA 0044A760 RVA 0004A760 bytes c7 44 24 20 00 00 00 00   mov dword ptr [esp + 0x20], 0
VA 0044A768 RVA 0004A768 bytes 89 7c 24 24               mov dword ptr [esp + 0x24], edi
VA 0044A76C RVA 0004A76C bytes 8a 47 2a                  mov al, byte ptr [edi + 0x2a]
VA 0044A76F RVA 0004A76F bytes 3c ff                     cmp al, 0xff
VA 0044A771 RVA 0004A771 bytes 75 08                     jne 0x44a77b
VA 0044A773 RVA 0004A773 bytes 8b 43 19                  mov eax, dword ptr [ebx + 0x19]
VA 0044A776 RVA 0004A776 bytes 8a 40 3e                  mov al, byte ptr [eax + 0x3e]
VA 0044A779 RVA 0004A779 bytes 3c ff                     cmp al, 0xff
VA 0044A77B RVA 0004A77B bytes 8b 4f 02                  mov ecx, dword ptr [edi + 2]
VA 0044A77E RVA 0004A77E bytes 0f 95 44 24 3c            setne byte ptr [esp + 0x3c]
VA 0044A783 RVA 0004A783 bytes 83 cd ff                  or ebp, 0xffffffff
VA 0044A786 RVA 0004A786 bytes 3b cd                     cmp ecx, ebp
VA 0044A788 RVA 0004A788 bytes 74 08                     je 0x44a792
VA 0044A78A RVA 0004A78A bytes 8b f1                     mov esi, ecx
VA 0044A78C RVA 0004A78C bytes 89 74 24 18               mov dword ptr [esp + 0x18], esi
VA 0044A790 RVA 0004A790 bytes eb 19                     jmp 0x44a7ab
VA 0044A792 RVA 0004A792 bytes 8b 53 19                  mov edx, dword ptr [ebx + 0x19]
VA 0044A795 RVA 0004A795 bytes 8b 42 16                  mov eax, dword ptr [edx + 0x16]
VA 0044A798 RVA 0004A798 bytes 3b c5                     cmp eax, ebp
VA 0044A79A RVA 0004A79A bytes 75 09                     jne 0x44a7a5
VA 0044A79C RVA 0004A79C bytes 8a 43 20                  mov al, byte ptr [ebx + 0x20]
VA 0044A79F RVA 0004A79F bytes c1 e8 05                  shr eax, 5
VA 0044A7A2 RVA 0004A7A2 bytes 83 e0 01                  and eax, 1
VA 0044A7A5 RVA 0004A7A5 bytes 89 44 24 18               mov dword ptr [esp + 0x18], eax
VA 0044A7A9 RVA 0004A7A9 bytes 8b f0                     mov esi, eax
VA 0044A7AB RVA 0004A7AB bytes 8b 47 12                  mov eax, dword ptr [edi + 0x12]
VA 0044A7AE RVA 0004A7AE bytes 3b c5                     cmp eax, ebp
VA 0044A7B0 RVA 0004A7B0 bytes 75 12                     jne 0x44a7c4
VA 0044A7B2 RVA 0004A7B2 bytes 3b cd                     cmp ecx, ebp
VA 0044A7B4 RVA 0004A7B4 bytes 75 08                     jne 0x44a7be
VA 0044A7B6 RVA 0004A7B6 bytes 89 2d b8 6c 4a 00         mov dword ptr [0x4a6cb8], ebp
VA 0044A7BC RVA 0004A7BC bytes eb 0f                     jmp 0x44a7cd
VA 0044A7BE RVA 0004A7BE bytes 8b 47 06                  mov eax, dword ptr [edi + 6]
VA 0044A7C1 RVA 0004A7C1 bytes 2b c1                     sub eax, ecx
VA 0044A7C3 RVA 0004A7C3 bytes 40                        inc eax
VA 0044A7C4 RVA 0004A7C4 bytes 3b c5                     cmp eax, ebp
VA 0044A7C6 RVA 0004A7C6 bytes a3 b8 6c 4a 00            mov dword ptr [0x4a6cb8], eax
VA 0044A7CB RVA 0004A7CB bytes 75 2d                     jne 0x44a7fa
VA 0044A7CD RVA 0004A7CD bytes 8b 4b 19                  mov ecx, dword ptr [ebx + 0x19]
VA 0044A7D0 RVA 0004A7D0 bytes 8b 41 26                  mov eax, dword ptr [ecx + 0x26]
VA 0044A7D3 RVA 0004A7D3 bytes 3b c5                     cmp eax, ebp
VA 0044A7D5 RVA 0004A7D5 bytes 75 15                     jne 0x44a7ec
VA 0044A7D7 RVA 0004A7D7 bytes 8b 51 16                  mov edx, dword ptr [ecx + 0x16]
VA 0044A7DA RVA 0004A7DA bytes 3b d5                     cmp edx, ebp
VA 0044A7DC RVA 0004A7DC bytes 75 08                     jne 0x44a7e6
VA 0044A7DE RVA 0004A7DE bytes 89 2d b8 6c 4a 00         mov dword ptr [0x4a6cb8], ebp
VA 0044A7E4 RVA 0004A7E4 bytes eb 0f                     jmp 0x44a7f5
VA 0044A7E6 RVA 0004A7E6 bytes 8b 41 1a                  mov eax, dword ptr [ecx + 0x1a]
VA 0044A7E9 RVA 0004A7E9 bytes 2b c2                     sub eax, edx
VA 0044A7EB RVA 0004A7EB bytes 40                        inc eax
VA 0044A7EC RVA 0004A7EC bytes 3b c5                     cmp eax, ebp
VA 0044A7EE RVA 0004A7EE bytes a3 b8 6c 4a 00            mov dword ptr [0x4a6cb8], eax
VA 0044A7F3 RVA 0004A7F3 bytes 75 05                     jne 0x44a7fa
VA 0044A7F5 RVA 0004A7F5 bytes b8 01 00 00 00            mov eax, 1
VA 0044A7FA RVA 0004A7FA bytes 8b 4c 24 44               mov ecx, dword ptr [esp + 0x44]
VA 0044A7FE RVA 0004A7FE bytes 8d 44 30 ff               lea eax, [eax + esi - 1]
VA 0044A802 RVA 0004A802 bytes 33 ff                     xor edi, edi
VA 0044A804 RVA 0004A804 bytes 3b f0                     cmp esi, eax
VA 0044A806 RVA 0004A806 bytes 8b 29                     mov ebp, dword ptr [ecx]
VA 0044A808 RVA 0004A808 bytes 89 44 24 28               mov dword ptr [esp + 0x28], eax
VA 0044A80C RVA 0004A80C bytes 89 74 24 14               mov dword ptr [esp + 0x14], esi
VA 0044A810 RVA 0004A810 bytes c6 44 24 13 00            mov byte ptr [esp + 0x13], 0
VA 0044A815 RVA 0004A815 bytes 0f 8f 4c 03 00 00         jg 0x44ab67
VA 0044A81B RVA 0004A81B bytes eb 04                     jmp 0x44a821
VA 0044A81D RVA 0004A81D bytes 8b 74 24 14               mov esi, dword ptr [esp + 0x14]
VA 0044A821 RVA 0004A821 bytes f6 05 cc 6c 4a 00 01      test byte ptr [0x4a6ccc], 1
VA 0044A828 RVA 0004A828 bytes 74 16                     je 0x44a840
VA 0044A82A RVA 0004A82A bytes 83 7c 24 4c 01            cmp dword ptr [esp + 0x4c], 1
VA 0044A82F RVA 0004A82F bytes 75 0f                     jne 0x44a840
VA 0044A831 RVA 0004A831 bytes 8b 54 24 24               mov edx, dword ptr [esp + 0x24]
VA 0044A835 RVA 0004A835 bytes 80 7a 2c 01               cmp byte ptr [edx + 0x2c], 1
VA 0044A839 RVA 0004A839 bytes 75 05                     jne 0x44a840
VA 0044A83B RVA 0004A83B bytes c6 45 00 7c               mov byte ptr [ebp], 0x7c
VA 0044A83F RVA 0004A83F bytes 45                        inc ebp
VA 0044A840 RVA 0004A840 bytes 8a 44 24 3c               mov al, byte ptr [esp + 0x3c]
VA 0044A844 RVA 0004A844 bytes 84 c0                     test al, al
VA 0044A846 RVA 0004A846 bytes 74 2f                     je 0x44a877
VA 0044A848 RVA 0004A848 bytes 81 ff 88 13 00 00         cmp edi, 0x1388
VA 0044A84E RVA 0004A84E bytes 7d 27                     jge 0x44a877
VA 0044A850 RVA 0004A850 bytes 83 7c 24 4c 01            cmp dword ptr [esp + 0x4c], 1
VA 0044A855 RVA 0004A855 bytes 75 1a                     jne 0x44a871
VA 0044A857 RVA 0004A857 bytes 8b 44 24 44               mov eax, dword ptr [esp + 0x44]
VA 0044A85B RVA 0004A85B bytes 56                        push esi
VA 0044A85C RVA 0004A85C bytes 68 fc af 47 00            push 0x47affc
VA 0044A861 RVA 0004A861 bytes 8b 08                     mov ecx, dword ptr [eax]
VA 0044A863 RVA 0004A863 bytes 51                        push ecx
VA 0044A864 RVA 0004A864 bytes ff 15 7c 61 6c 00         call dword ptr [0x6c617c]
VA 0044A86A RVA 0004A86A bytes 83 c4 0c                  add esp, 0xc
VA 0044A86D RVA 0004A86D bytes 03 e8                     add ebp, eax
VA 0044A86F RVA 0004A86F bytes eb 06                     jmp 0x44a877
VA 0044A871 RVA 0004A871 bytes 89 75 00                  mov dword ptr [ebp], esi
VA 0044A874 RVA 0004A874 bytes 83 c5 04                  add ebp, 4
VA 0044A877 RVA 0004A877 bytes a0 02 c6 47 00            mov al, byte ptr [0x47c602]
VA 0044A87C RVA 0004A87C bytes 84 c0                     test al, al
VA 0044A87E RVA 0004A87E bytes 74 59                     je 0x44a8d9
VA 0044A880 RVA 0004A880 bytes 8a 53 1f                  mov dl, byte ptr [ebx + 0x1f]
VA 0044A883 RVA 0004A883 bytes 80 e2 01                  and dl, 1
VA 0044A886 RVA 0004A886 bytes 80 fa 01                  cmp dl, 1
VA 0044A889 RVA 0004A889 bytes 75 4e                     jne 0x44a8d9
VA 0044A88B RVA 0004A88B bytes 8b 7c 24 38               mov edi, dword ptr [esp + 0x38]
VA 0044A88F RVA 0004A88F bytes 80 7f 07 02               cmp byte ptr [edi + 7], 2
VA 0044A893 RVA 0004A893 bytes 75 48                     jne 0x44a8dd
VA 0044A895 RVA 0004A895 bytes 8d 44 24 2c               lea eax, [esp + 0x2c]
VA 0044A899 RVA 0004A899 bytes 50                        push eax
VA 0044A89A RVA 0004A89A bytes 57                        push edi
VA 0044A89B RVA 0004A89B bytes e8 2b 7e fb ff            call 0x4026cb
VA 0044A8A0 RVA 0004A8A0 bytes 83 c4 08                  add esp, 8
VA 0044A8A3 RVA 0004A8A3 bytes 85 c0                     test eax, eax
VA 0044A8A5 RVA 0004A8A5 bytes 74 36                     je 0x44a8dd
VA 0044A8A7 RVA 0004A8A7 bytes 8b 4c 24 4c               mov ecx, dword ptr [esp + 0x4c]
VA 0044A8AB RVA 0004A8AB bytes 8b 13                     mov edx, dword ptr [ebx]
VA 0044A8AD RVA 0004A8AD bytes 49                        dec ecx
VA 0044A8AE RVA 0004A8AE bytes 8d 44 24 20               lea eax, [esp + 0x20]
VA 0044A8B2 RVA 0004A8B2 bytes f7 d9                     neg ecx
VA 0044A8B4 RVA 0004A8B4 bytes 1b c9                     sbb ecx, ecx
VA 0044A8B6 RVA 0004A8B6 bytes 6a 00                     push 0
VA 0044A8B8 RVA 0004A8B8 bytes 83 e1 02                  and ecx, 2
VA 0044A8BB RVA 0004A8BB bytes 50                        push eax
VA 0044A8BC RVA 0004A8BC bytes 8b 44 24 48               mov eax, dword ptr [esp + 0x48]
VA 0044A8C0 RVA 0004A8C0 bytes 41                        inc ecx
VA 0044A8C1 RVA 0004A8C1 bytes 51                        push ecx
VA 0044A8C2 RVA 0004A8C2 bytes 8b 4f 18                  mov ecx, dword ptr [edi + 0x18]
VA 0044A8C5 RVA 0004A8C5 bytes 50                        push eax
VA 0044A8C6 RVA 0004A8C6 bytes 51                        push ecx
VA 0044A8C7 RVA 0004A8C7 bytes 8b cb                     mov ecx, ebx
VA 0044A8C9 RVA 0004A8C9 bytes ff 52 18                  call dword ptr [edx + 0x18]
VA 0044A8CC RVA 0004A8CC bytes 8b 74 24 34               mov esi, dword ptr [esp + 0x34]
VA 0044A8D0 RVA 0004A8D0 bytes 89 44 24 1c               mov dword ptr [esp + 0x1c], eax
VA 0044A8D4 RVA 0004A8D4 bytes 83 cf ff                  or edi, 0xffffffff
VA 0044A8D7 RVA 0004A8D7 bytes eb 7a                     jmp 0x44a953
VA 0044A8D9 RVA 0004A8D9 bytes 8b 7c 24 38               mov edi, dword ptr [esp + 0x38]
VA 0044A8DD RVA 0004A8DD bytes 8b 4c 24 50               mov ecx, dword ptr [esp + 0x50]
VA 0044A8E1 RVA 0004A8E1 bytes 8d 44 24 1c               lea eax, [esp + 0x1c]
VA 0044A8E5 RVA 0004A8E5 bytes 8b 13                     mov edx, dword ptr [ebx]
VA 0044A8E7 RVA 0004A8E7 bytes 50                        push eax
VA 0044A8E8 RVA 0004A8E8 bytes 8b 44 24 44               mov eax, dword ptr [esp + 0x44]
VA 0044A8EC RVA 0004A8EC bytes 51                        push ecx
VA 0044A8ED RVA 0004A8ED bytes 8b 4f 18                  mov ecx, dword ptr [edi + 0x18]
VA 0044A8F0 RVA 0004A8F0 bytes 56                        push esi
VA 0044A8F1 RVA 0004A8F1 bytes 8b 74 24 40               mov esi, dword ptr [esp + 0x40]
VA 0044A8F5 RVA 0004A8F5 bytes 50                        push eax
VA 0044A8F6 RVA 0004A8F6 bytes 55                        push ebp
VA 0044A8F7 RVA 0004A8F7 bytes 51                        push ecx
VA 0044A8F8 RVA 0004A8F8 bytes 8b 06                     mov eax, dword ptr [esi]
VA 0044A8FA RVA 0004A8FA bytes 8b cb                     mov ecx, ebx
VA 0044A8FC RVA 0004A8FC bytes 50                        push eax
VA 0044A8FD RVA 0004A8FD bytes ff 52 1c                  call dword ptr [edx + 0x1c]
VA 0044A900 RVA 0004A900 bytes 8b f8                     mov edi, eax
VA 0044A902 RVA 0004A902 bytes 83 ff fd                  cmp edi, -3
VA 0044A905 RVA 0004A905 bytes 0f 84 ca 02 00 00         je 0x44abd5
VA 0044A90B RVA 0004A90B bytes 83 ff fe                  cmp edi, -2
VA 0044A90E RVA 0004A90E bytes 0f 84 b4 02 00 00         je 0x44abc8
VA 0044A914 RVA 0004A914 bytes 83 ff ff                  cmp edi, -1
VA 0044A917 RVA 0004A917 bytes 75 36                     jne 0x44a94f
VA 0044A919 RVA 0004A919 bytes 8b 44 24 38               mov eax, dword ptr [esp + 0x38]
VA 0044A91D RVA 0004A91D bytes 80 78 07 02               cmp byte ptr [eax + 7], 2
VA 0044A921 RVA 0004A921 bytes 0f 85 40 02 00 00         jne 0x44ab67
VA 0044A927 RVA 0004A927 bytes 8b 4c 24 4c               mov ecx, dword ptr [esp + 0x4c]
VA 0044A92B RVA 0004A92B bytes 8b 40 18                  mov eax, dword ptr [eax + 0x18]
VA 0044A92E RVA 0004A92E bytes 49                        dec ecx
VA 0044A92F RVA 0004A92F bytes 8b 13                     mov edx, dword ptr [ebx]
VA 0044A931 RVA 0004A931 bytes f7 d9                     neg ecx
VA 0044A933 RVA 0004A933 bytes 1b c9                     sbb ecx, ecx
VA 0044A935 RVA 0004A935 bytes 6a 00                     push 0
VA 0044A937 RVA 0004A937 bytes 83 e1 02                  and ecx, 2
VA 0044A93A RVA 0004A93A bytes 6a 00                     push 0
VA 0044A93C RVA 0004A93C bytes 41                        inc ecx
VA 0044A93D RVA 0004A93D bytes 51                        push ecx
VA 0044A93E RVA 0004A93E bytes 8b 4c 24 4c               mov ecx, dword ptr [esp + 0x4c]
VA 0044A942 RVA 0004A942 bytes 51                        push ecx
VA 0044A943 RVA 0004A943 bytes 50                        push eax
VA 0044A944 RVA 0004A944 bytes 8b cb                     mov ecx, ebx
VA 0044A946 RVA 0004A946 bytes ff 52 18                  call dword ptr [edx + 0x18]
VA 0044A949 RVA 0004A949 bytes 89 44 24 1c               mov dword ptr [esp + 0x1c], eax
VA 0044A94D RVA 0004A94D bytes eb 04                     jmp 0x44a953
VA 0044A94F RVA 0004A94F bytes 8b 44 24 1c               mov eax, dword ptr [esp + 0x1c]
VA 0044A953 RVA 0004A953 bytes 83 f8 01                  cmp eax, 1
VA 0044A956 RVA 0004A956 bytes c7 06 00 00 00 00         mov dword ptr [esi], 0
VA 0044A95C RVA 0004A95C bytes 75 20                     jne 0x44a97e
VA 0044A95E RVA 0004A95E bytes 84 43 1f                  test byte ptr [ebx + 0x1f], al
VA 0044A961 RVA 0004A961 bytes 75 1b                     jne 0x44a97e
VA 0044A963 RVA 0004A963 bytes 8b 4c 24 24               mov ecx, dword ptr [esp + 0x24]
VA 0044A967 RVA 0004A967 bytes 80 79 28 ff               cmp byte ptr [ecx + 0x28], 0xff
VA 0044A96B RVA 0004A96B bytes 75 09                     jne 0x44a976
VA 0044A96D RVA 0004A96D bytes 8b 53 19                  mov edx, dword ptr [ebx + 0x19]
VA 0044A970 RVA 0004A970 bytes 80 7a 3c ff               cmp byte ptr [edx + 0x3c], 0xff
VA 0044A974 RVA 0004A974 bytes 74 08                     je 0x44a97e
VA 0044A976 RVA 0004A976 bytes 8b 4c 24 18               mov ecx, dword ptr [esp + 0x18]
VA 0044A97A RVA 0004A97A bytes 89 4c 24 28               mov dword ptr [esp + 0x28], ecx
VA 0044A97E RVA 0004A97E bytes 81 ff 0f 27 00 00         cmp edi, 0x270f
VA 0044A984 RVA 0004A984 bytes 7e 21                     jle 0x44a9a7
VA 0044A986 RVA 0004A986 bytes 8a 4c 24 3c               mov cl, byte ptr [esp + 0x3c]
VA 0044A98A RVA 0004A98A bytes 81 ef 10 27 00 00         sub edi, 0x2710
VA 0044A990 RVA 0004A990 bytes 84 c9                     test cl, cl
VA 0044A992 RVA 0004A992 bytes 74 13                     je 0x44a9a7
VA 0044A994 RVA 0004A994 bytes 8b 54 24 38               mov edx, dword ptr [esp + 0x38]
VA 0044A998 RVA 0004A998 bytes 80 7a 07 02               cmp byte ptr [edx + 7], 2
VA 0044A99C RVA 0004A99C bytes 75 09                     jne 0x44a9a7
VA 0044A99E RVA 0004A99E bytes ff 44 24 14               inc dword ptr [esp + 0x14]
VA 0044A9A2 RVA 0004A9A2 bytes e9 a2 01 00 00            jmp 0x44ab49
VA 0044A9A7 RVA 0004A9A7 bytes 83 7c 24 4c 01            cmp dword ptr [esp + 0x4c], 1
VA 0044A9AC RVA 0004A9AC bytes 75 57                     jne 0x44aa05
VA 0044A9AE RVA 0004A9AE bytes 81 ff 87 13 00 00         cmp edi, 0x1387
VA 0044A9B4 RVA 0004A9B4 bytes 8d 87 78 ec ff ff         lea eax, [edi - 0x1388]
VA 0044A9BA RVA 0004A9BA bytes 7f 02                     jg 0x44a9be
VA 0044A9BC RVA 0004A9BC bytes 8b c7                     mov eax, edi
VA 0044A9BE RVA 0004A9BE bytes 8b 4c 24 14               mov ecx, dword ptr [esp + 0x14]
VA 0044A9C2 RVA 0004A9C2 bytes 8d 54 24 1c               lea edx, [esp + 0x1c]
VA 0044A9C6 RVA 0004A9C6 bytes 51                        push ecx
VA 0044A9C7 RVA 0004A9C7 bytes 8b 4c 24 44               mov ecx, dword ptr [esp + 0x44]
VA 0044A9CB RVA 0004A9CB bytes 52                        push edx
VA 0044A9CC RVA 0004A9CC bytes 8b 54 24 40               mov edx, dword ptr [esp + 0x40]
VA 0044A9D0 RVA 0004A9D0 bytes 6a 01                     push 1
VA 0044A9D2 RVA 0004A9D2 bytes 50                        push eax
VA 0044A9D3 RVA 0004A9D3 bytes 8b 44 24 34               mov eax, dword ptr [esp + 0x34]
VA 0044A9D7 RVA 0004A9D7 bytes 55                        push ebp
VA 0044A9D8 RVA 0004A9D8 bytes 50                        push eax
VA 0044A9D9 RVA 0004A9D9 bytes 51                        push ecx
VA 0044A9DA RVA 0004A9DA bytes 52                        push edx
VA 0044A9DB RVA 0004A9DB bytes e8 f7 6b fb ff            call 0x4015d7
VA 0044A9E0 RVA 0004A9E0 bytes 8b f0                     mov esi, eax
VA 0044A9E2 RVA 0004A9E2 bytes 83 c4 20                  add esp, 0x20
VA 0044A9E5 RVA 0004A9E5 bytes 85 f6                     test esi, esi
VA 0044A9E7 RVA 0004A9E7 bytes 0f 8d f4 00 00 00         jge 0x44aae1
VA 0044A9ED RVA 0004A9ED bytes 8b 44 24 38               mov eax, dword ptr [esp + 0x38]
VA 0044A9F1 RVA 0004A9F1 bytes 80 78 07 02               cmp byte ptr [eax + 7], 2
VA 0044A9F5 RVA 0004A9F5 bytes 0f 85 6c 01 00 00         jne 0x44ab67
VA 0044A9FB RVA 0004A9FB bytes be 01 00 00 00            mov esi, 1
VA 0044AA00 RVA 0004AA00 bytes e9 dc 00 00 00            jmp 0x44aae1
VA 0044AA05 RVA 0004AA05 bytes 85 ff                     test edi, edi
VA 0044AA07 RVA 0004AA07 bytes 0f 8c 64 01 00 00         jl 0x44ab71
VA 0044AA0D RVA 0004AA0D bytes 8b 4c 24 18               mov ecx, dword ptr [esp + 0x18]
VA 0044AA11 RVA 0004AA11 bytes 8b 54 24 14               mov edx, dword ptr [esp + 0x14]
VA 0044AA15 RVA 0004AA15 bytes 3b d1                     cmp edx, ecx
VA 0044AA17 RVA 0004AA17 bytes 0f 85 b4 00 00 00         jne 0x44aad1
VA 0044AA1D RVA 0004AA1D bytes 81 ff 88 13 00 00         cmp edi, 0x1388
VA 0044AA23 RVA 0004AA23 bytes 0f 8d a8 00 00 00         jge 0x44aad1
VA 0044AA29 RVA 0004AA29 bytes 83 f8 03                  cmp eax, 3
VA 0044AA2C RVA 0004AA2C bytes 8b f7                     mov esi, edi
VA 0044AA2E RVA 0004AA2E bytes 77 26                     ja 0x44aa56
VA 0044AA30 RVA 0004AA30 bytes ff 24 85 f8 ab 44 00      jmp dword ptr [eax*4 + 0x44abf8]
VA 0044AA37 RVA 0004AA37 bytes 66 c7 05 d4 6b 48 00 01 00 mov word ptr [0x486bd4], 1
VA 0044AA40 RVA 0004AA40 bytes eb 14                     jmp 0x44aa56
VA 0044AA42 RVA 0004AA42 bytes 66 c7 05 d4 6b 48 00 02 00 mov word ptr [0x486bd4], 2
VA 0044AA4B RVA 0004AA4B bytes eb 09                     jmp 0x44aa56
VA 0044AA4D RVA 0004AA4D bytes 66 c7 05 d4 6b 48 00 64 00 mov word ptr [0x486bd4], 0x64
VA 0044AA56 RVA 0004AA56 bytes 8a 44 24 3c               mov al, byte ptr [esp + 0x3c]
VA 0044AA5A RVA 0004AA5A bytes 84 c0                     test al, al
VA 0044AA5C RVA 0004AA5C bytes 74 07                     je 0x44aa65
VA 0044AA5E RVA 0004AA5E bytes 80 0d d5 6b 48 00 01      or byte ptr [0x486bd5], 1
VA 0044AA65 RVA 0004AA65 bytes 8b 44 24 20               mov eax, dword ptr [esp + 0x20]
VA 0044AA69 RVA 0004AA69 bytes 85 c0                     test eax, eax
VA 0044AA6B RVA 0004AA6B bytes 75 1d                     jne 0x44aa8a
VA 0044AA6D RVA 0004AA6D bytes 8b 4c 24 40               mov ecx, dword ptr [esp + 0x40]
VA 0044AA71 RVA 0004AA71 bytes 8b 13                     mov edx, dword ptr [ebx]
VA 0044AA73 RVA 0004AA73 bytes 8d 44 24 20               lea eax, [esp + 0x20]
VA 0044AA77 RVA 0004AA77 bytes 6a 00                     push 0
VA 0044AA79 RVA 0004AA79 bytes 50                        push eax
VA 0044AA7A RVA 0004AA7A bytes 8b 44 24 40               mov eax, dword ptr [esp + 0x40]
VA 0044AA7E RVA 0004AA7E bytes 6a 03                     push 3
VA 0044AA80 RVA 0004AA80 bytes 51                        push ecx
VA 0044AA81 RVA 0004AA81 bytes 8b 48 18                  mov ecx, dword ptr [eax + 0x18]
VA 0044AA84 RVA 0004AA84 bytes 51                        push ecx
VA 0044AA85 RVA 0004AA85 bytes 8b cb                     mov ecx, ebx
VA 0044AA87 RVA 0004AA87 bytes ff 52 18                  call dword ptr [edx + 0x18]
VA 0044AA8A RVA 0004AA8A bytes a0 84 68 48 00            mov al, byte ptr [0x486884]
VA 0044AA8F RVA 0004AA8F bytes 66 33 d2                  xor dx, dx
VA 0044AA92 RVA 0004AA92 bytes 66 0f b6 4c 24 20         movzx cx, byte ptr [esp + 0x20]
VA 0044AA98 RVA 0004AA98 bytes 8a d0                     mov dl, al
VA 0044AA9A RVA 0004AA9A bytes c1 e2 08                  shl edx, 8
VA 0044AA9D RVA 0004AA9D bytes 03 d1                     add edx, ecx
VA 0044AA9F RVA 0004AA9F bytes 8b 4c 24 18               mov ecx, dword ptr [esp + 0x18]
VA 0044AAA3 RVA 0004AAA3 bytes 66 89 15 d6 6b 48 00      mov word ptr [0x486bd6], dx
VA 0044AAAA RVA 0004AAAA bytes 8b 54 24 28               mov edx, dword ptr [esp + 0x28]
VA 0044AAAE RVA 0004AAAE bytes 2b d1                     sub edx, ecx
VA 0044AAB0 RVA 0004AAB0 bytes 8b 4c 24 44               mov ecx, dword ptr [esp + 0x44]
VA 0044AAB4 RVA 0004AAB4 bytes fe c0                     inc al
VA 0044AAB6 RVA 0004AAB6 bytes 42                        inc edx
VA 0044AAB7 RVA 0004AAB7 bytes a2 84 68 48 00            mov byte ptr [0x486884], al
VA 0044AABC RVA 0004AABC bytes 89 15 d8 6b 48 00         mov dword ptr [0x486bd8], edx
VA 0044AAC2 RVA 0004AAC2 bytes 8b 11                     mov edx, dword ptr [ecx]
VA 0044AAC4 RVA 0004AAC4 bytes 8b c5                     mov eax, ebp
VA 0044AAC6 RVA 0004AAC6 bytes 2b c2                     sub eax, edx
VA 0044AAC8 RVA 0004AAC8 bytes 03 c7                     add eax, edi
VA 0044AACA RVA 0004AACA bytes a3 dc 6b 48 00            mov dword ptr [0x486bdc], eax
VA 0044AACF RVA 0004AACF bytes eb 10                     jmp 0x44aae1
VA 0044AAD1 RVA 0004AAD1 bytes 81 ff 87 13 00 00         cmp edi, 0x1387
VA 0044AAD7 RVA 0004AAD7 bytes 8d b7 78 ec ff ff         lea esi, [edi - 0x1388]
VA 0044AADD RVA 0004AADD bytes 7f 02                     jg 0x44aae1
VA 0044AADF RVA 0004AADF bytes 8b f7                     mov esi, edi
VA 0044AAE1 RVA 0004AAE1 bytes 81 ff 87 13 00 00         cmp edi, 0x1387
VA 0044AAE7 RVA 0004AAE7 bytes 7e 0a                     jle 0x44aaf3
VA 0044AAE9 RVA 0004AAE9 bytes 8b 54 24 44               mov edx, dword ptr [esp + 0x44]
VA 0044AAED RVA 0004AAED bytes 03 f5                     add esi, ebp
VA 0044AAEF RVA 0004AAEF bytes 89 32                     mov dword ptr [edx], esi
VA 0044AAF1 RVA 0004AAF1 bytes eb 56                     jmp 0x44ab49
VA 0044AAF3 RVA 0004AAF3 bytes 8b 44 24 14               mov eax, dword ptr [esp + 0x14]
VA 0044AAF7 RVA 0004AAF7 bytes c6 44 24 13 01            mov byte ptr [esp + 0x13], 1
VA 0044AAFC RVA 0004AAFC bytes 40                        inc eax
VA 0044AAFD RVA 0004AAFD bytes 89 44 24 14               mov dword ptr [esp + 0x14], eax
VA 0044AB01 RVA 0004AB01 bytes 8b c6                     mov eax, esi
VA 0044AB03 RVA 0004AB03 bytes 2d d0 6b 48 00            sub eax, 0x486bd0
VA 0044AB08 RVA 0004AB08 bytes 03 c5                     add eax, ebp
VA 0044AB0A RVA 0004AB0A bytes 3d 00 02 00 00            cmp eax, 0x200
VA 0044AB0F RVA 0004AB0F bytes 7e 30                     jle 0x44ab41
VA 0044AB11 RVA 0004AB11 bytes 8b 4c 24 4c               mov ecx, dword ptr [esp + 0x4c]
VA 0044AB15 RVA 0004AB15 bytes 83 f9 01                  cmp ecx, 1
VA 0044AB18 RVA 0004AB18 bytes 74 27                     je 0x44ab41
VA 0044AB1A RVA 0004AB1A bytes 8b 74 24 48               mov esi, dword ptr [esp + 0x48]
VA 0044AB1E RVA 0004AB1E bytes 51                        push ecx
VA 0044AB1F RVA 0004AB1F bytes 8b 4c 24 3c               mov ecx, dword ptr [esp + 0x3c]
VA 0044AB23 RVA 0004AB23 bytes 50                        push eax
VA 0044AB24 RVA 0004AB24 bytes 68 d0 6b 48 00            push 0x486bd0
VA 0044AB29 RVA 0004AB29 bytes 56                        push esi
VA 0044AB2A RVA 0004AB2A bytes 51                        push ecx
VA 0044AB2B RVA 0004AB2B bytes e8 c8 67 fb ff            call 0x4012f8
VA 0044AB30 RVA 0004AB30 bytes 8b 54 24 58               mov edx, dword ptr [esp + 0x58]
VA 0044AB34 RVA 0004AB34 bytes 89 06                     mov dword ptr [esi], eax
VA 0044AB36 RVA 0004AB36 bytes 83 c4 14                  add esp, 0x14
VA 0044AB39 RVA 0004AB39 bytes c7 02 d0 6b 48 00         mov dword ptr [edx], 0x486bd0
VA 0044AB3F RVA 0004AB3F bytes eb 08                     jmp 0x44ab49
VA 0044AB41 RVA 0004AB41 bytes 8b 44 24 44               mov eax, dword ptr [esp + 0x44]
VA 0044AB45 RVA 0004AB45 bytes 03 f5                     add esi, ebp
VA 0044AB47 RVA 0004AB47 bytes 89 30                     mov dword ptr [eax], esi
VA 0044AB49 RVA 0004AB49 bytes 8b 4c 24 44               mov ecx, dword ptr [esp + 0x44]
VA 0044AB4D RVA 0004AB4D bytes 8b 54 24 14               mov edx, dword ptr [esp + 0x14]
VA 0044AB51 RVA 0004AB51 bytes 8b 44 24 28               mov eax, dword ptr [esp + 0x28]
VA 0044AB55 RVA 0004AB55 bytes 8b 29                     mov ebp, dword ptr [ecx]
VA 0044AB57 RVA 0004AB57 bytes 3b d0                     cmp edx, eax
VA 0044AB59 RVA 0004AB59 bytes 0f 8e be fc ff ff         jle 0x44a81d
VA 0044AB5F RVA 0004AB5F bytes 8a 44 24 13               mov al, byte ptr [esp + 0x13]
VA 0044AB63 RVA 0004AB63 bytes 84 c0                     test al, al
VA 0044AB65 RVA 0004AB65 bytes 75 54                     jne 0x44abbb
VA 0044AB67 RVA 0004AB67 bytes 5f                        pop edi
VA 0044AB68 RVA 0004AB68 bytes 5e                        pop esi
VA 0044AB69 RVA 0004AB69 bytes 5d                        pop ebp
VA 0044AB6A RVA 0004AB6A bytes 33 c0                     xor eax, eax
VA 0044AB6C RVA 0004AB6C bytes 5b                        pop ebx
VA 0044AB6D RVA 0004AB6D bytes 83 c4 20                  add esp, 0x20
VA 0044AB70 RVA 0004AB70 bytes c3                        ret 
VA 0044AB71 RVA 0004AB71 bytes a1 d0 6b 48 00            mov eax, dword ptr [0x486bd0]
VA 0044AB76 RVA 0004AB76 bytes 8b 4c 24 38               mov ecx, dword ptr [esp + 0x38]
VA 0044AB7A RVA 0004AB7A bytes 66 c7 05 d4 6b 48 00 ff ff mov word ptr [0x486bd4], 0xffff
VA 0044AB83 RVA 0004AB83 bytes 25 ff ff 00 00            and eax, 0xffff
VA 0044AB88 RVA 0004AB88 bytes 8b 51 2a                  mov edx, dword ptr [ecx + 0x2a]
VA 0044AB8B RVA 0004AB8B bytes 89 90 d0 6b 48 00         mov dword ptr [eax + 0x486bd0], edx
VA 0044AB91 RVA 0004AB91 bytes 8b 44 24 44               mov eax, dword ptr [esp + 0x44]
VA 0044AB95 RVA 0004AB95 bytes 66 83 05 d0 6b 48 00 04   add word ptr [0x486bd0], 4
VA 0044AB9D RVA 0004AB9D bytes 66 ff 05 d2 6b 48 00      inc word ptr [0x486bd2]
VA 0044ABA4 RVA 0004ABA4 bytes c7 05 d8 6b 48 00 00 00 00 00 mov dword ptr [0x486bd8], 0
VA 0044ABAE RVA 0004ABAE bytes c7 05 dc 6b 48 00 00 00 00 00 mov dword ptr [0x486bdc], 0
VA 0044ABB8 RVA 0004ABB8 bytes 83 00 04                  add dword ptr [eax], 4
VA 0044ABBB RVA 0004ABBB bytes 5f                        pop edi
VA 0044ABBC RVA 0004ABBC bytes 5e                        pop esi
VA 0044ABBD RVA 0004ABBD bytes 5d                        pop ebp
VA 0044ABBE RVA 0004ABBE bytes b8 01 00 00 00            mov eax, 1
VA 0044ABC3 RVA 0004ABC3 bytes 5b                        pop ebx
VA 0044ABC4 RVA 0004ABC4 bytes 83 c4 20                  add esp, 0x20
VA 0044ABC7 RVA 0004ABC7 bytes c3                        ret 
VA 0044ABC8 RVA 0004ABC8 bytes 5f                        pop edi
VA 0044ABC9 RVA 0004ABC9 bytes 5e                        pop esi
VA 0044ABCA RVA 0004ABCA bytes 5d                        pop ebp
VA 0044ABCB RVA 0004ABCB bytes b8 fe ff ff ff            mov eax, 0xfffffffe
VA 0044ABD0 RVA 0004ABD0 bytes 5b                        pop ebx
VA 0044ABD1 RVA 0004ABD1 bytes 83 c4 20                  add esp, 0x20
VA 0044ABD4 RVA 0004ABD4 bytes c3                        ret 
VA 0044ABD5 RVA 0004ABD5 bytes 8b 4c 24 38               mov ecx, dword ptr [esp + 0x38]
VA 0044ABD9 RVA 0004ABD9 bytes c7 06 00 00 00 00         mov dword ptr [esi], 0
VA 0044ABDF RVA 0004ABDF bytes 33 c0                     xor eax, eax
VA 0044ABE1 RVA 0004ABE1 bytes 5f                        pop edi
VA 0044ABE2 RVA 0004ABE2 bytes 8a 51 07                  mov dl, byte ptr [ecx + 7]
VA 0044ABE5 RVA 0004ABE5 bytes 5e                        pop esi
VA 0044ABE6 RVA 0004ABE6 bytes 80 fa 02                  cmp dl, 2
VA 0044ABE9 RVA 0004ABE9 bytes 5d                        pop ebp
VA 0044ABEA RVA 0004ABEA bytes 0f 95 c0                  setne al
VA 0044ABED RVA 0004ABED bytes 83 c0 fd                  add eax, -3
VA 0044ABF0 RVA 0004ABF0 bytes 5b                        pop ebx
VA 0044ABF1 RVA 0004ABF1 bytes 83 c4 20                  add esp, 0x20
VA 0044ABF4 RVA 0004ABF4 bytes c3                        ret 
VA 0044ABF5 RVA 0004ABF5 bytes 8d 49 00                  lea ecx, [ecx]
VA 0044ABF8 RVA 0004ABF8 bytes 37                        aaa 
VA 0044ABF9 RVA 0004ABF9 bytes aa                        stosb byte ptr es:[edi], al
VA 0044ABFA RVA 0004ABFA bytes 44                        inc esp
VA 0044ABFB RVA 0004ABFB bytes 00 4d aa                  add byte ptr [ebp - 0x56], cl
VA 0044ABFE RVA 0004ABFE bytes 44                        inc esp
VA 0044ABFF RVA 0004ABFF bytes 00 42 aa                  add byte ptr [edx - 0x56], al
VA 0044AC02 RVA 0004AC02 bytes 44                        inc esp
VA 0044AC03 RVA 0004AC03 bytes 00 4d aa                  add byte ptr [ebp - 0x56], cl
VA 0044AC06 RVA 0004AC06 bytes 44                        inc esp
VA 0044AC07 RVA 0004AC07 bytes 00 90 90 90 90 90         add byte ptr [eax - 0x6f6f6f70], dl
VA 0044AC0D RVA 0004AC0D bytes 90                        nop 
VA 0044AC0E RVA 0004AC0E bytes 90                        nop 
VA 0044AC0F RVA 0004AC0F bytes 90                        nop 
VA 0044AC10 RVA 0004AC10 bytes cc                        int3 
VA 0044AC11 RVA 0004AC11 bytes cc                        int3 
VA 0044AC12 RVA 0004AC12 bytes cc                        int3 
VA 0044AC13 RVA 0004AC13 bytes cc                        int3 
VA 0044AC14 RVA 0004AC14 bytes cc                        int3 
VA 0044AC15 RVA 0004AC15 bytes cc                        int3 
VA 0044AC16 RVA 0004AC16 bytes cc                        int3 
VA 0044AC17 RVA 0004AC17 bytes cc                        int3 
VA 0044AC18 RVA 0004AC18 bytes cc                        int3 
VA 0044AC19 RVA 0004AC19 bytes cc                        int3 
VA 0044AC1A RVA 0004AC1A bytes cc                        int3 
VA 0044AC1B RVA 0004AC1B bytes cc                        int3 
VA 0044AC1C RVA 0004AC1C bytes cc                        int3 
VA 0044AC1D RVA 0004AC1D bytes cc                        int3 
VA 0044AC1E RVA 0004AC1E bytes cc                        int3 
VA 0044AC1F RVA 0004AC1F bytes cc                        int3 
VA 0044AC20 RVA 0004AC20 bytes cc                        int3 
VA 0044AC21 RVA 0004AC21 bytes cc                        int3 
VA 0044AC22 RVA 0004AC22 bytes cc                        int3 
VA 0044AC23 RVA 0004AC23 bytes cc                        int3 
VA 0044AC24 RVA 0004AC24 bytes cc                        int3 
VA 0044AC25 RVA 0004AC25 bytes cc                        int3 
VA 0044AC26 RVA 0004AC26 bytes cc                        int3 
VA 0044AC27 RVA 0004AC27 bytes cc                        int3 
VA 0044AC28 RVA 0004AC28 bytes cc                        int3 
VA 0044AC29 RVA 0004AC29 bytes cc                        int3 
VA 0044AC2A RVA 0004AC2A bytes cc                        int3 
VA 0044AC2B RVA 0004AC2B bytes cc                        int3 
VA 0044AC2C RVA 0004AC2C bytes cc                        int3 
VA 0044AC2D RVA 0004AC2D bytes cc                        int3 
VA 0044AC2E RVA 0004AC2E bytes cc                        int3 
VA 0044AC2F RVA 0004AC2F bytes cc                        int3 
VA 0044AC30 RVA 0004AC30 bytes cc                        int3 
VA 0044AC31 RVA 0004AC31 bytes cc                        int3 
VA 0044AC32 RVA 0004AC32 bytes cc                        int3 
VA 0044AC33 RVA 0004AC33 bytes cc                        int3 
VA 0044AC34 RVA 0004AC34 bytes cc                        int3 
VA 0044AC35 RVA 0004AC35 bytes cc                        int3 
VA 0044AC36 RVA 0004AC36 bytes cc                        int3 
VA 0044AC37 RVA 0004AC37 bytes cc                        int3 
VA 0044AC38 RVA 0004AC38 bytes cc                        int3 
VA 0044AC39 RVA 0004AC39 bytes cc                        int3 
VA 0044AC3A RVA 0004AC3A bytes cc                        int3 
VA 0044AC3B RVA 0004AC3B bytes cc                        int3 
VA 0044AC3C RVA 0004AC3C bytes cc                        int3 
VA 0044AC3D RVA 0004AC3D bytes cc                        int3 
VA 0044AC3E RVA 0004AC3E bytes cc                        int3 
VA 0044AC3F RVA 0004AC3F bytes cc                        int3 
VA 0044AC40 RVA 0004AC40 bytes cc                        int3 
VA 0044AC41 RVA 0004AC41 bytes cc                        int3 
VA 0044AC42 RVA 0004AC42 bytes cc                        int3 
VA 0044AC43 RVA 0004AC43 bytes cc                        int3 
VA 0044AC44 RVA 0004AC44 bytes cc                        int3 
VA 0044AC45 RVA 0004AC45 bytes cc                        int3 
VA 0044AC46 RVA 0004AC46 bytes cc                        int3 
VA 0044AC47 RVA 0004AC47 bytes cc                        int3 
VA 0044AC48 RVA 0004AC48 bytes cc                        int3 
VA 0044AC49 RVA 0004AC49 bytes cc                        int3 
VA 0044AC4A RVA 0004AC4A bytes cc                        int3 
VA 0044AC4B RVA 0004AC4B bytes cc                        int3 
VA 0044AC4C RVA 0004AC4C bytes cc                        int3 
VA 0044AC4D RVA 0004AC4D bytes cc                        int3 
VA 0044AC4E RVA 0004AC4E bytes cc                        int3 
VA 0044AC4F RVA 0004AC4F bytes cc                        int3 
VA 0044AC50 RVA 0004AC50 bytes cc                        int3 
VA 0044AC51 RVA 0004AC51 bytes cc                        int3 
VA 0044AC52 RVA 0004AC52 bytes cc                        int3 
VA 0044AC53 RVA 0004AC53 bytes cc                        int3 
VA 0044AC54 RVA 0004AC54 bytes cc                        int3 
VA 0044AC55 RVA 0004AC55 bytes cc                        int3 
VA 0044AC56 RVA 0004AC56 bytes cc                        int3 
VA 0044AC57 RVA 0004AC57 bytes cc                        int3 
VA 0044AC58 RVA 0004AC58 bytes cc                        int3 
VA 0044AC59 RVA 0004AC59 bytes cc                        int3 
VA 0044AC5A RVA 0004AC5A bytes cc                        int3 
VA 0044AC5B RVA 0004AC5B bytes cc                        int3 
VA 0044AC5C RVA 0004AC5C bytes cc                        int3 
VA 0044AC5D RVA 0004AC5D bytes cc                        int3 
VA 0044AC5E RVA 0004AC5E bytes cc                        int3 
VA 0044AC5F RVA 0004AC5F bytes cc                        int3 
VA 0044AC60 RVA 0004AC60 bytes cc                        int3 
VA 0044AC61 RVA 0004AC61 bytes cc                        int3 
VA 0044AC62 RVA 0004AC62 bytes cc                        int3 
VA 0044AC63 RVA 0004AC63 bytes cc                        int3 
VA 0044AC64 RVA 0004AC64 bytes cc                        int3 
VA 0044AC65 RVA 0004AC65 bytes cc                        int3 
VA 0044AC66 RVA 0004AC66 bytes cc                        int3 
VA 0044AC67 RVA 0004AC67 bytes cc                        int3 
VA 0044AC68 RVA 0004AC68 bytes cc                        int3 
VA 0044AC69 RVA 0004AC69 bytes cc                        int3 
VA 0044AC6A RVA 0004AC6A bytes cc                        int3 
VA 0044AC6B RVA 0004AC6B bytes cc                        int3 
VA 0044AC6C RVA 0004AC6C bytes cc                        int3 
VA 0044AC6D RVA 0004AC6D bytes cc                        int3 
VA 0044AC6E RVA 0004AC6E bytes cc                        int3 
VA 0044AC6F RVA 0004AC6F bytes cc                        int3 
VA 0044AC70 RVA 0004AC70 bytes cc                        int3 
VA 0044AC71 RVA 0004AC71 bytes cc                        int3 
VA 0044AC72 RVA 0004AC72 bytes cc                        int3 
VA 0044AC73 RVA 0004AC73 bytes cc                        int3 
VA 0044AC74 RVA 0004AC74 bytes cc                        int3 
VA 0044AC75 RVA 0004AC75 bytes cc                        int3 
VA 0044AC76 RVA 0004AC76 bytes cc                        int3 
VA 0044AC77 RVA 0004AC77 bytes cc                        int3 
VA 0044AC78 RVA 0004AC78 bytes cc                        int3 
VA 0044AC79 RVA 0004AC79 bytes cc                        int3 
VA 0044AC7A RVA 0004AC7A bytes cc                        int3 
VA 0044AC7B RVA 0004AC7B bytes cc                        int3 
VA 0044AC7C RVA 0004AC7C bytes cc                        int3 
VA 0044AC7D RVA 0004AC7D bytes cc                        int3 
VA 0044AC7E RVA 0004AC7E bytes cc                        int3 
VA 0044AC7F RVA 0004AC7F bytes cc                        int3 
VA 0044AC80 RVA 0004AC80 bytes cc                        int3 
VA 0044AC81 RVA 0004AC81 bytes cc                        int3 
VA 0044AC82 RVA 0004AC82 bytes cc                        int3 
VA 0044AC83 RVA 0004AC83 bytes cc                        int3 
VA 0044AC84 RVA 0004AC84 bytes cc                        int3 
VA 0044AC85 RVA 0004AC85 bytes cc                        int3 
VA 0044AC86 RVA 0004AC86 bytes cc                        int3 
VA 0044AC87 RVA 0004AC87 bytes cc                        int3 
VA 0044AC88 RVA 0004AC88 bytes cc                        int3 
VA 0044AC89 RVA 0004AC89 bytes cc                        int3 
VA 0044AC8A RVA 0004AC8A bytes cc                        int3 
VA 0044AC8B RVA 0004AC8B bytes cc                        int3 
VA 0044AC8C RVA 0004AC8C bytes cc                        int3 
VA 0044AC8D RVA 0004AC8D bytes cc                        int3 
VA 0044AC8E RVA 0004AC8E bytes cc                        int3 
VA 0044AC8F RVA 0004AC8F bytes cc                        int3 
VA 0044AC90 RVA 0004AC90 bytes cc                        int3 
VA 0044AC91 RVA 0004AC91 bytes cc                        int3 
VA 0044AC92 RVA 0004AC92 bytes cc                        int3 
VA 0044AC93 RVA 0004AC93 bytes cc                        int3 
VA 0044AC94 RVA 0004AC94 bytes cc                        int3 
VA 0044AC95 RVA 0004AC95 bytes cc                        int3 
VA 0044AC96 RVA 0004AC96 bytes cc                        int3 
VA 0044AC97 RVA 0004AC97 bytes cc                        int3 
VA 0044AC98 RVA 0004AC98 bytes cc                        int3 
VA 0044AC99 RVA 0004AC99 bytes cc                        int3 
VA 0044AC9A RVA 0004AC9A bytes cc                        int3 
VA 0044AC9B RVA 0004AC9B bytes cc                        int3 
VA 0044AC9C RVA 0004AC9C bytes cc                        int3 
VA 0044AC9D RVA 0004AC9D bytes cc                        int3 
VA 0044AC9E RVA 0004AC9E bytes cc                        int3 
VA 0044AC9F RVA 0004AC9F bytes cc                        int3 
VA 0044ACA0 RVA 0004ACA0 bytes cc                        int3 
VA 0044ACA1 RVA 0004ACA1 bytes cc                        int3 
VA 0044ACA2 RVA 0004ACA2 bytes cc                        int3 
VA 0044ACA3 RVA 0004ACA3 bytes cc                        int3 
VA 0044ACA4 RVA 0004ACA4 bytes cc                        int3 
VA 0044ACA5 RVA 0004ACA5 bytes cc                        int3 
VA 0044ACA6 RVA 0004ACA6 bytes cc                        int3 
VA 0044ACA7 RVA 0004ACA7 bytes cc                        int3 
VA 0044ACA8 RVA 0004ACA8 bytes cc                        int3 
VA 0044ACA9 RVA 0004ACA9 bytes cc                        int3 
VA 0044ACAA RVA 0004ACAA bytes cc                        int3 
VA 0044ACAB RVA 0004ACAB bytes cc                        int3 
VA 0044ACAC RVA 0004ACAC bytes cc                        int3 
VA 0044ACAD RVA 0004ACAD bytes cc                        int3 
VA 0044ACAE RVA 0004ACAE bytes cc                        int3 
VA 0044ACAF RVA 0004ACAF bytes cc                        int3 
VA 0044ACB0 RVA 0004ACB0 bytes cc                        int3 
VA 0044ACB1 RVA 0004ACB1 bytes cc                        int3 
VA 0044ACB2 RVA 0004ACB2 bytes cc                        int3 
VA 0044ACB3 RVA 0004ACB3 bytes cc                        int3 
VA 0044ACB4 RVA 0004ACB4 bytes cc                        int3 
VA 0044ACB5 RVA 0004ACB5 bytes cc                        int3 
VA 0044ACB6 RVA 0004ACB6 bytes cc                        int3 
VA 0044ACB7 RVA 0004ACB7 bytes cc                        int3 
VA 0044ACB8 RVA 0004ACB8 bytes cc                        int3 
VA 0044ACB9 RVA 0004ACB9 bytes cc                        int3 
VA 0044ACBA RVA 0004ACBA bytes cc                        int3 
VA 0044ACBB RVA 0004ACBB bytes cc                        int3 
VA 0044ACBC RVA 0004ACBC bytes cc                        int3 
VA 0044ACBD RVA 0004ACBD bytes cc                        int3 
VA 0044ACBE RVA 0004ACBE bytes cc                        int3 
VA 0044ACBF RVA 0004ACBF bytes cc                        int3 
VA 0044ACC0 RVA 0004ACC0 bytes cc                        int3 
VA 0044ACC1 RVA 0004ACC1 bytes cc                        int3 
VA 0044ACC2 RVA 0004ACC2 bytes cc                        int3 
VA 0044ACC3 RVA 0004ACC3 bytes cc                        int3 
VA 0044ACC4 RVA 0004ACC4 bytes cc                        int3 
VA 0044ACC5 RVA 0004ACC5 bytes cc                        int3 
VA 0044ACC6 RVA 0004ACC6 bytes cc                        int3 
VA 0044ACC7 RVA 0004ACC7 bytes cc                        int3 
VA 0044ACC8 RVA 0004ACC8 bytes cc                        int3 
VA 0044ACC9 RVA 0004ACC9 bytes cc                        int3 
VA 0044ACCA RVA 0004ACCA bytes cc                        int3 
VA 0044ACCB RVA 0004ACCB bytes cc                        int3 
VA 0044ACCC RVA 0004ACCC bytes cc                        int3 
VA 0044ACCD RVA 0004ACCD bytes cc                        int3 
VA 0044ACCE RVA 0004ACCE bytes cc                        int3 
VA 0044ACCF RVA 0004ACCF bytes cc                        int3 
VA 0044ACD0 RVA 0004ACD0 bytes cc                        int3 
VA 0044ACD1 RVA 0004ACD1 bytes cc                        int3 
VA 0044ACD2 RVA 0004ACD2 bytes cc                        int3 
VA 0044ACD3 RVA 0004ACD3 bytes cc                        int3 
VA 0044ACD4 RVA 0004ACD4 bytes cc                        int3 
VA 0044ACD5 RVA 0004ACD5 bytes cc                        int3 
VA 0044ACD6 RVA 0004ACD6 bytes cc                        int3 
VA 0044ACD7 RVA 0004ACD7 bytes cc                        int3 
VA 0044ACD8 RVA 0004ACD8 bytes cc                        int3 
VA 0044ACD9 RVA 0004ACD9 bytes cc                        int3 
VA 0044ACDA RVA 0004ACDA bytes cc                        int3 
VA 0044ACDB RVA 0004ACDB bytes cc                        int3 
VA 0044ACDC RVA 0004ACDC bytes cc                        int3 
VA 0044ACDD RVA 0004ACDD bytes cc                        int3 
VA 0044ACDE RVA 0004ACDE bytes cc                        int3 
VA 0044ACDF RVA 0004ACDF bytes cc                        int3 
VA 0044ACE0 RVA 0004ACE0 bytes cc                        int3 
VA 0044ACE1 RVA 0004ACE1 bytes cc                        int3 
VA 0044ACE2 RVA 0004ACE2 bytes cc                        int3 
VA 0044ACE3 RVA 0004ACE3 bytes cc                        int3 
VA 0044ACE4 RVA 0004ACE4 bytes cc                        int3 
VA 0044ACE5 RVA 0004ACE5 bytes cc                        int3 
VA 0044ACE6 RVA 0004ACE6 bytes cc                        int3 
VA 0044ACE7 RVA 0004ACE7 bytes cc                        int3 
VA 0044ACE8 RVA 0004ACE8 bytes cc                        int3 
VA 0044ACE9 RVA 0004ACE9 bytes cc                        int3 
VA 0044ACEA RVA 0004ACEA bytes cc                        int3 
VA 0044ACEB RVA 0004ACEB bytes cc                        int3 
VA 0044ACEC RVA 0004ACEC bytes cc                        int3 
VA 0044ACED RVA 0004ACED bytes cc                        int3 
VA 0044ACEE RVA 0004ACEE bytes cc                        int3 
VA 0044ACEF RVA 0004ACEF bytes cc                        int3 
VA 0044ACF0 RVA 0004ACF0 bytes cc                        int3 
VA 0044ACF1 RVA 0004ACF1 bytes cc                        int3 
VA 0044ACF2 RVA 0004ACF2 bytes cc                        int3 
VA 0044ACF3 RVA 0004ACF3 bytes cc                        int3 
VA 0044ACF4 RVA 0004ACF4 bytes cc                        int3 
VA 0044ACF5 RVA 0004ACF5 bytes cc                        int3 
VA 0044ACF6 RVA 0004ACF6 bytes cc                        int3 
VA 0044ACF7 RVA 0004ACF7 bytes cc                        int3 
VA 0044ACF8 RVA 0004ACF8 bytes cc                        int3 
VA 0044ACF9 RVA 0004ACF9 bytes cc                        int3 
VA 0044ACFA RVA 0004ACFA bytes cc                        int3 
VA 0044ACFB RVA 0004ACFB bytes cc                        int3 
VA 0044ACFC RVA 0004ACFC bytes cc                        int3 
VA 0044ACFD RVA 0004ACFD bytes cc                        int3 
VA 0044ACFE RVA 0004ACFE bytes cc                        int3 
VA 0044ACFF RVA 0004ACFF bytes cc                        int3 
VA 0044AD00 RVA 0004AD00 bytes cc                        int3 
VA 0044AD01 RVA 0004AD01 bytes cc                        int3 
VA 0044AD02 RVA 0004AD02 bytes cc                        int3 
VA 0044AD03 RVA 0004AD03 bytes cc                        int3 
VA 0044AD04 RVA 0004AD04 bytes cc                        int3 
VA 0044AD05 RVA 0004AD05 bytes cc                        int3 
VA 0044AD06 RVA 0004AD06 bytes cc                        int3 
VA 0044AD07 RVA 0004AD07 bytes cc                        int3 
VA 0044AD08 RVA 0004AD08 bytes cc                        int3 
VA 0044AD09 RVA 0004AD09 bytes cc                        int3 
VA 0044AD0A RVA 0004AD0A bytes cc                        int3 
VA 0044AD0B RVA 0004AD0B bytes cc                        int3 
VA 0044AD0C RVA 0004AD0C bytes cc                        int3 
VA 0044AD0D RVA 0004AD0D bytes cc                        int3 
VA 0044AD0E RVA 0004AD0E bytes cc                        int3 
VA 0044AD0F RVA 0004AD0F bytes cc                        int3 
VA 0044AD10 RVA 0004AD10 bytes cc                        int3 
VA 0044AD11 RVA 0004AD11 bytes cc                        int3 
VA 0044AD12 RVA 0004AD12 bytes cc                        int3 
VA 0044AD13 RVA 0004AD13 bytes cc                        int3 
VA 0044AD14 RVA 0004AD14 bytes cc                        int3 
VA 0044AD15 RVA 0004AD15 bytes cc                        int3 
VA 0044AD16 RVA 0004AD16 bytes cc                        int3 
VA 0044AD17 RVA 0004AD17 bytes cc                        int3 
VA 0044AD18 RVA 0004AD18 bytes cc                        int3 
VA 0044AD19 RVA 0004AD19 bytes cc                        int3 
VA 0044AD1A RVA 0004AD1A bytes cc                        int3 
VA 0044AD1B RVA 0004AD1B bytes cc                        int3 
VA 0044AD1C RVA 0004AD1C bytes cc                        int3 
VA 0044AD1D RVA 0004AD1D bytes cc                        int3 
VA 0044AD1E RVA 0004AD1E bytes cc                        int3 
VA 0044AD1F RVA 0004AD1F bytes cc                        int3 
VA 0044AD20 RVA 0004AD20 bytes cc                        int3 
VA 0044AD21 RVA 0004AD21 bytes cc                        int3 
VA 0044AD22 RVA 0004AD22 bytes cc                        int3 
VA 0044AD23 RVA 0004AD23 bytes cc                        int3 
VA 0044AD24 RVA 0004AD24 bytes cc                        int3 
VA 0044AD25 RVA 0004AD25 bytes cc                        int3 
VA 0044AD26 RVA 0004AD26 bytes cc                        int3 
VA 0044AD27 RVA 0004AD27 bytes cc                        int3 
VA 0044AD28 RVA 0004AD28 bytes cc                        int3 
VA 0044AD29 RVA 0004AD29 bytes cc                        int3 
VA 0044AD2A RVA 0004AD2A bytes cc                        int3 
VA 0044AD2B RVA 0004AD2B bytes cc                        int3 
VA 0044AD2C RVA 0004AD2C bytes cc                        int3 
VA 0044AD2D RVA 0004AD2D bytes cc                        int3 
VA 0044AD2E RVA 0004AD2E bytes cc                        int3 
VA 0044AD2F RVA 0004AD2F bytes cc                        int3 
VA 0044AD30 RVA 0004AD30 bytes cc                        int3 
VA 0044AD31 RVA 0004AD31 bytes cc                        int3 
VA 0044AD32 RVA 0004AD32 bytes cc                        int3 
VA 0044AD33 RVA 0004AD33 bytes cc                        int3 
VA 0044AD34 RVA 0004AD34 bytes cc                        int3 
VA 0044AD35 RVA 0004AD35 bytes cc                        int3 
VA 0044AD36 RVA 0004AD36 bytes cc                        int3 
VA 0044AD37 RVA 0004AD37 bytes cc                        int3 
VA 0044AD38 RVA 0004AD38 bytes cc                        int3 
VA 0044AD39 RVA 0004AD39 bytes cc                        int3 
VA 0044AD3A RVA 0004AD3A bytes cc                        int3 
VA 0044AD3B RVA 0004AD3B bytes cc                        int3 
VA 0044AD3C RVA 0004AD3C bytes cc                        int3 
VA 0044AD3D RVA 0004AD3D bytes cc                        int3 
VA 0044AD3E RVA 0004AD3E bytes cc                        int3 
VA 0044AD3F RVA 0004AD3F bytes cc                        int3 
VA 0044AD40 RVA 0004AD40 bytes cc                        int3 
VA 0044AD41 RVA 0004AD41 bytes cc                        int3 
VA 0044AD42 RVA 0004AD42 bytes cc                        int3 
VA 0044AD43 RVA 0004AD43 bytes cc                        int3 
VA 0044AD44 RVA 0004AD44 bytes cc                        int3 
VA 0044AD45 RVA 0004AD45 bytes cc                        int3 
VA 0044AD46 RVA 0004AD46 bytes cc                        int3 
VA 0044AD47 RVA 0004AD47 bytes cc                        int3 
VA 0044AD48 RVA 0004AD48 bytes cc                        int3 
VA 0044AD49 RVA 0004AD49 bytes cc                        int3 
VA 0044AD4A RVA 0004AD4A bytes cc                        int3 
VA 0044AD4B RVA 0004AD4B bytes cc                        int3 
VA 0044AD4C RVA 0004AD4C bytes cc                        int3 
VA 0044AD4D RVA 0004AD4D bytes cc                        int3 
VA 0044AD4E RVA 0004AD4E bytes cc                        int3 
VA 0044AD4F RVA 0004AD4F bytes cc                        int3 

RANGE VA 0044AD50..0044AEA0 RVA 0004AD50 file offset 0004AD50
VA 0044AD50 RVA 0004AD50 bytes 83 ec 10                  sub esp, 0x10
VA 0044AD53 RVA 0004AD53 bytes 8b 44 24 14               mov eax, dword ptr [esp + 0x14]
VA 0044AD57 RVA 0004AD57 bytes 53                        push ebx
VA 0044AD58 RVA 0004AD58 bytes 55                        push ebp
VA 0044AD59 RVA 0004AD59 bytes 56                        push esi
VA 0044AD5A RVA 0004AD5A bytes 57                        push edi
VA 0044AD5B RVA 0004AD5B bytes 8b 7c 24 34               mov edi, dword ptr [esp + 0x34]
VA 0044AD5F RVA 0004AD5F bytes 83 ff 01                  cmp edi, 1
VA 0044AD62 RVA 0004AD62 bytes 75 0c                     jne 0x44ad70
VA 0044AD64 RVA 0004AD64 bytes 8d 88 8a 00 00 00         lea ecx, [eax + 0x8a]
VA 0044AD6A RVA 0004AD6A bytes 89 4c 24 34               mov dword ptr [esp + 0x34], ecx
VA 0044AD6E RVA 0004AD6E bytes eb 0a                     jmp 0x44ad7a
VA 0044AD70 RVA 0004AD70 bytes 8d 90 8e 00 00 00         lea edx, [eax + 0x8e]
VA 0044AD76 RVA 0004AD76 bytes 89 54 24 34               mov dword ptr [esp + 0x34], edx
VA 0044AD7A RVA 0004AD7A bytes 80 78 07 02               cmp byte ptr [eax + 7], 2
VA 0044AD7E RVA 0004AD7E bytes 75 29                     jne 0x44ada9
VA 0044AD80 RVA 0004AD80 bytes 8a 48 7b                  mov cl, byte ptr [eax + 0x7b]
VA 0044AD83 RVA 0004AD83 bytes 84 c9                     test cl, cl
VA 0044AD85 RVA 0004AD85 bytes 75 22                     jne 0x44ada9
VA 0044AD87 RVA 0004AD87 bytes 8b 80 a6 00 00 00         mov eax, dword ptr [eax + 0xa6]
VA 0044AD8D RVA 0004AD8D bytes 8b 00                     mov eax, dword ptr [eax]
VA 0044AD8F RVA 0004AD8F bytes 80 78 31 01               cmp byte ptr [eax + 0x31], 1
VA 0044AD93 RVA 0004AD93 bytes 74 14                     je 0x44ada9
VA 0044AD95 RVA 0004AD95 bytes 8b 48 36                  mov ecx, dword ptr [eax + 0x36]
VA 0044AD98 RVA 0004AD98 bytes f6 41 20 10               test byte ptr [ecx + 0x20], 0x10
VA 0044AD9C RVA 0004AD9C bytes 75 0b                     jne 0x44ada9
VA 0044AD9E RVA 0004AD9E bytes b9 01 00 00 00            mov ecx, 1
VA 0044ADA3 RVA 0004ADA3 bytes 89 4c 24 24               mov dword ptr [esp + 0x24], ecx
VA 0044ADA7 RVA 0004ADA7 bytes eb 0c                     jmp 0x44adb5
VA 0044ADA9 RVA 0004ADA9 bytes c7 44 24 24 00 00 00 00   mov dword ptr [esp + 0x24], 0
VA 0044ADB1 RVA 0004ADB1 bytes 8b 4c 24 24               mov ecx, dword ptr [esp + 0x24]
VA 0044ADB5 RVA 0004ADB5 bytes 8b 5c 24 28               mov ebx, dword ptr [esp + 0x28]
VA 0044ADB9 RVA 0004ADB9 bytes 8b 03                     mov eax, dword ptr [ebx]
VA 0044ADBB RVA 0004ADBB bytes 85 c0                     test eax, eax
VA 0044ADBD RVA 0004ADBD bytes 0f 85 87 00 00 00         jne 0x44ae4a
VA 0044ADC3 RVA 0004ADC3 bytes 85 c9                     test ecx, ecx
VA 0044ADC5 RVA 0004ADC5 bytes 74 39                     je 0x44ae00
VA 0044ADC7 RVA 0004ADC7 bytes 8b 54 24 34               mov edx, dword ptr [esp + 0x34]
VA 0044ADCB RVA 0004ADCB bytes 8b 02                     mov eax, dword ptr [edx]
VA 0044ADCD RVA 0004ADCD bytes 85 c0                     test eax, eax
VA 0044ADCF RVA 0004ADCF bytes 74 2f                     je 0x44ae00
VA 0044ADD1 RVA 0004ADD1 bytes 8b 6c 24 30               mov ebp, dword ptr [esp + 0x30]
VA 0044ADD5 RVA 0004ADD5 bytes 8b 74 24 2c               mov esi, dword ptr [esp + 0x2c]
VA 0044ADD9 RVA 0004ADD9 bytes 6a 00                     push 0
VA 0044ADDB RVA 0004ADDB bytes 55                        push ebp
VA 0044ADDC RVA 0004ADDC bytes 56                        push esi
VA 0044ADDD RVA 0004ADDD bytes 50                        push eax
VA 0044ADDE RVA 0004ADDE bytes e8 15 c2 01 00            call 0x466ff8
VA 0044ADE3 RVA 0004ADE3 bytes 85 c0                     test eax, eax
VA 0044ADE5 RVA 0004ADE5 bytes 89 03                     mov dword ptr [ebx], eax
VA 0044ADE7 RVA 0004ADE7 bytes 75 59                     jne 0x44ae42
VA 0044ADE9 RVA 0004ADE9 bytes 68 dc 00 00 00            push 0xdc
VA 0044ADEE RVA 0004ADEE bytes e8 a9 75 fb ff            call 0x40239c
VA 0044ADF3 RVA 0004ADF3 bytes 83 c4 04                  add esp, 4
VA 0044ADF6 RVA 0004ADF6 bytes 33 c0                     xor eax, eax
VA 0044ADF8 RVA 0004ADF8 bytes 5f                        pop edi
VA 0044ADF9 RVA 0004ADF9 bytes 5e                        pop esi
VA 0044ADFA RVA 0004ADFA bytes 5d                        pop ebp
VA 0044ADFB RVA 0004ADFB bytes 5b                        pop ebx
VA 0044ADFC RVA 0004ADFC bytes 83 c4 10                  add esp, 0x10
VA 0044ADFF RVA 0004ADFF bytes c3                        ret 
VA 0044AE00 RVA 0004AE00 bytes 8b 6c 24 30               mov ebp, dword ptr [esp + 0x30]
VA 0044AE04 RVA 0004AE04 bytes 33 c0                     xor eax, eax
VA 0044AE06 RVA 0004AE06 bytes 8b 74 24 2c               mov esi, dword ptr [esp + 0x2c]
VA 0044AE0A RVA 0004AE0A bytes 8b 15 c0 6c 4a 00         mov edx, dword ptr [0x4a6cc0]
VA 0044AE10 RVA 0004AE10 bytes 85 c9                     test ecx, ecx
VA 0044AE12 RVA 0004AE12 bytes 8b 0d 64 68 48 00         mov ecx, dword ptr [0x486864]
VA 0044AE18 RVA 0004AE18 bytes 0f 95 c0                  setne al
VA 0044AE1B RVA 0004AE1B bytes 50                        push eax
VA 0044AE1C RVA 0004AE1C bytes 57                        push edi
VA 0044AE1D RVA 0004AE1D bytes 51                        push ecx
VA 0044AE1E RVA 0004AE1E bytes 6a 00                     push 0
VA 0044AE20 RVA 0004AE20 bytes 55                        push ebp
VA 0044AE21 RVA 0004AE21 bytes 56                        push esi
VA 0044AE22 RVA 0004AE22 bytes 52                        push edx
VA 0044AE23 RVA 0004AE23 bytes e8 2e c1 01 00            call 0x466f56
VA 0044AE28 RVA 0004AE28 bytes 85 c0                     test eax, eax
VA 0044AE2A RVA 0004AE2A bytes 89 03                     mov dword ptr [ebx], eax
VA 0044AE2C RVA 0004AE2C bytes 75 14                     jne 0x44ae42
VA 0044AE2E RVA 0004AE2E bytes 6a 15                     push 0x15
VA 0044AE30 RVA 0004AE30 bytes e8 67 75 fb ff            call 0x40239c
VA 0044AE35 RVA 0004AE35 bytes 83 c4 04                  add esp, 4
VA 0044AE38 RVA 0004AE38 bytes 33 c0                     xor eax, eax
VA 0044AE3A RVA 0004AE3A bytes 5f                        pop edi
VA 0044AE3B RVA 0004AE3B bytes 5e                        pop esi
VA 0044AE3C RVA 0004AE3C bytes 5d                        pop ebp
VA 0044AE3D RVA 0004AE3D bytes 5b                        pop ebx
VA 0044AE3E RVA 0004AE3E bytes 83 c4 10                  add esp, 0x10
VA 0044AE41 RVA 0004AE41 bytes c3                        ret 
VA 0044AE42 RVA 0004AE42 bytes 89 2d 88 58 48 00         mov dword ptr [0x485888], ebp
VA 0044AE48 RVA 0004AE48 bytes eb 37                     jmp 0x44ae81
VA 0044AE4A RVA 0004AE4A bytes 8b 0d 88 58 48 00         mov ecx, dword ptr [0x485888]
VA 0044AE50 RVA 0004AE50 bytes 8b 6c 24 30               mov ebp, dword ptr [esp + 0x30]
VA 0044AE54 RVA 0004AE54 bytes 8b 74 24 2c               mov esi, dword ptr [esp + 0x2c]
VA 0044AE58 RVA 0004AE58 bytes 51                        push ecx
VA 0044AE59 RVA 0004AE59 bytes 55                        push ebp
VA 0044AE5A RVA 0004AE5A bytes 56                        push esi
VA 0044AE5B RVA 0004AE5B bytes 50                        push eax
VA 0044AE5C RVA 0004AE5C bytes e8 97 c1 01 00            call 0x466ff8
VA 0044AE61 RVA 0004AE61 bytes 85 c0                     test eax, eax
VA 0044AE63 RVA 0004AE63 bytes 89 03                     mov dword ptr [ebx], eax
VA 0044AE65 RVA 0004AE65 bytes 75 14                     jne 0x44ae7b
VA 0044AE67 RVA 0004AE67 bytes 6a 16                     push 0x16
VA 0044AE69 RVA 0004AE69 bytes e8 2e 75 fb ff            call 0x40239c
VA 0044AE6E RVA 0004AE6E bytes 83 c4 04                  add esp, 4
VA 0044AE71 RVA 0004AE71 bytes 33 c0                     xor eax, eax
VA 0044AE73 RVA 0004AE73 bytes 5f                        pop edi
VA 0044AE74 RVA 0004AE74 bytes 5e                        pop esi
VA 0044AE75 RVA 0004AE75 bytes 5d                        pop ebp
VA 0044AE76 RVA 0004AE76 bytes 5b                        pop ebx
VA 0044AE77 RVA 0004AE77 bytes 83 c4 10                  add esp, 0x10
VA 0044AE7A RVA 0004AE7A bytes c3                        ret 
VA 0044AE7B RVA 0004AE7B bytes 01 2d 88 58 48 00         add dword ptr [0x485888], ebp
VA 0044AE81 RVA 0004AE81 bytes a1 10 6d 4a 00            mov eax, dword ptr [0x4a6d10]
VA 0044AE86 RVA 0004AE86 bytes a8 10                     test al, 0x10
VA 0044AE88 RVA 0004AE88 bytes 0f 84 16 01 00 00         je 0x44afa4
VA 0044AE8E RVA 0004AE8E bytes a9 ff ff 00 00            test eax, 0xffff
VA 0044AE93 RVA 0004AE93 bytes 74 1d                     je 0x44aeb2
VA 0044AE95 RVA 0004AE95 bytes 8b 15 84 58 48 00         mov edx, dword ptr [0x485884]
VA 0044AE9B RVA 0004AE9B bytes a1 88 58 48 00            mov eax, dword ptr [0x485888]

RANGE VA 00466F20..00467010 RVA 00066F20 file offset 00066F20
VA 00466F20 RVA 00066F20 bytes ff 25 20 63 6c 00         jmp dword ptr [0x6c6320]
VA 00466F26 RVA 00066F26 bytes ff 25 1c 63 6c 00         jmp dword ptr [0x6c631c]
VA 00466F2C RVA 00066F2C bytes ff 25 18 63 6c 00         jmp dword ptr [0x6c6318]
VA 00466F32 RVA 00066F32 bytes ff 25 14 63 6c 00         jmp dword ptr [0x6c6314]
VA 00466F38 RVA 00066F38 bytes ff 25 64 63 6c 00         jmp dword ptr [0x6c6364]
VA 00466F3E RVA 00066F3E bytes ff 25 48 63 6c 00         jmp dword ptr [0x6c6348]
VA 00466F44 RVA 00066F44 bytes ff 25 44 63 6c 00         jmp dword ptr [0x6c6344]
VA 00466F4A RVA 00066F4A bytes ff 25 40 63 6c 00         jmp dword ptr [0x6c6340]
VA 00466F50 RVA 00066F50 bytes ff 25 3c 63 6c 00         jmp dword ptr [0x6c633c]
VA 00466F56 RVA 00066F56 bytes ff 25 38 63 6c 00         jmp dword ptr [0x6c6338]
VA 00466F5C RVA 00066F5C bytes ff 25 d8 62 6c 00         jmp dword ptr [0x6c62d8]
VA 00466F62 RVA 00066F62 bytes ff 25 7c 62 6c 00         jmp dword ptr [0x6c627c]
VA 00466F68 RVA 00066F68 bytes ff 25 80 62 6c 00         jmp dword ptr [0x6c6280]
VA 00466F6E RVA 00066F6E bytes ff 25 84 62 6c 00         jmp dword ptr [0x6c6284]
VA 00466F74 RVA 00066F74 bytes ff 25 88 62 6c 00         jmp dword ptr [0x6c6288]
VA 00466F7A RVA 00066F7A bytes ff 25 8c 62 6c 00         jmp dword ptr [0x6c628c]
VA 00466F80 RVA 00066F80 bytes ff 25 90 62 6c 00         jmp dword ptr [0x6c6290]
VA 00466F86 RVA 00066F86 bytes ff 25 94 62 6c 00         jmp dword ptr [0x6c6294]
VA 00466F8C RVA 00066F8C bytes ff 25 98 62 6c 00         jmp dword ptr [0x6c6298]
VA 00466F92 RVA 00066F92 bytes ff 25 9c 62 6c 00         jmp dword ptr [0x6c629c]
VA 00466F98 RVA 00066F98 bytes ff 25 a0 62 6c 00         jmp dword ptr [0x6c62a0]
VA 00466F9E RVA 00066F9E bytes ff 25 a4 62 6c 00         jmp dword ptr [0x6c62a4]
VA 00466FA4 RVA 00066FA4 bytes ff 25 a8 62 6c 00         jmp dword ptr [0x6c62a8]
VA 00466FAA RVA 00066FAA bytes ff 25 ac 62 6c 00         jmp dword ptr [0x6c62ac]
VA 00466FB0 RVA 00066FB0 bytes ff 25 b0 62 6c 00         jmp dword ptr [0x6c62b0]
VA 00466FB6 RVA 00066FB6 bytes ff 25 b4 62 6c 00         jmp dword ptr [0x6c62b4]
VA 00466FBC RVA 00066FBC bytes ff 25 b8 62 6c 00         jmp dword ptr [0x6c62b8]
VA 00466FC2 RVA 00066FC2 bytes ff 25 bc 62 6c 00         jmp dword ptr [0x6c62bc]
VA 00466FC8 RVA 00066FC8 bytes ff 25 c0 62 6c 00         jmp dword ptr [0x6c62c0]
VA 00466FCE RVA 00066FCE bytes ff 25 c4 62 6c 00         jmp dword ptr [0x6c62c4]
VA 00466FD4 RVA 00066FD4 bytes ff 25 c8 62 6c 00         jmp dword ptr [0x6c62c8]
VA 00466FDA RVA 00066FDA bytes ff 25 cc 62 6c 00         jmp dword ptr [0x6c62cc]
VA 00466FE0 RVA 00066FE0 bytes ff 25 d0 62 6c 00         jmp dword ptr [0x6c62d0]
VA 00466FE6 RVA 00066FE6 bytes ff 25 d4 62 6c 00         jmp dword ptr [0x6c62d4]
VA 00466FEC RVA 00066FEC bytes ff 25 4c 63 6c 00         jmp dword ptr [0x6c634c]
VA 00466FF2 RVA 00066FF2 bytes ff 25 dc 62 6c 00         jmp dword ptr [0x6c62dc]
VA 00466FF8 RVA 00066FF8 bytes ff 25 e0 62 6c 00         jmp dword ptr [0x6c62e0]
VA 00466FFE RVA 00066FFE bytes ff 25 e4 62 6c 00         jmp dword ptr [0x6c62e4]
VA 00467004 RVA 00067004 bytes ff 25 e8 62 6c 00         jmp dword ptr [0x6c62e8]
VA 0046700A RVA 0006700A bytes ff 25 ec 62 6c 00         jmp dword ptr [0x6c62ec]

IMPORTS relevant to handle/item comparison:
006C6284 USER32.dll!DdeNameService
006C628C USER32.dll!DdePostAdvise
006C6290 USER32.dll!DdeEnableCallback
006C6294 USER32.dll!DdeQueryConvInfo
006C6298 USER32.dll!DdeGetLastError
006C629C USER32.dll!DdeAbandonTransaction
006C62A0 USER32.dll!DdeSetUserHandle
006C62D8 USER32.dll!DdeQueryStringA
006C62DC USER32.dll!DdeUnaccessData
006C62E0 USER32.dll!DdeAddData
006C6310 USER32.dll!DdeAccessData
006C6318 USER32.dll!DdeKeepStringHandle
006C631C USER32.dll!DdeCmpStringHandles
006C6320 USER32.dll!DdeGetData
006C6328 USER32.dll!DdeInitializeA
006C632C USER32.dll!DdeCreateStringHandleA
006C6330 USER32.dll!DdeConnect
006C6334 USER32.dll!DdeClientTransaction
006C6338 USER32.dll!DdeCreateDataHandle
006C634C USER32.dll!DdeFreeDataHandle
006C6350 USER32.dll!DdeUninitialize
006C6354 USER32.dll!DdeFreeStringHandle
006C6364 USER32.dll!DdeDisconnect
DATA VA 00479C64 RVA 00079C64: 4e 63 64 64 65 00 00 00 43 6f 6d 70 72 65 73 73 00 00 00 00 46 54 28 4f 50 54 29 3a 20 70 6f 6c
DATA VA 00486BD0 RVA 00086BD0: 
