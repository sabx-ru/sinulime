; PCU_old MCVar.dll, PE32 image base 0x10000000
; Evidence extracted by GNU objdump and cross-checked with Rizin byte hits.

; Header construction candidate (NCDDE_BINARY_HEADER object in EBX)
10003df3:  push ebp
10003e07:  66 c7 03 14 00       mov WORD PTR [ebx],0x14 ; header size
10003e0c:  66 89 53 02          mov WORD PTR [ebx+2],dx ; DX=1
10003e10:  66 89 7b 06          mov WORD PTR [ebx+6],di ; EDI=0 (actual +6 store)
10003e14:  c7 43 10 f9 f8 f7 f6  mov DWORD PTR [ebx+0x10],0xf6f7f8f9

; Alternate header state in same construction/response state machine
10004627:  66 c7 43 04 64 00    mov WORD PTR [ebx+4],0x64
10004630:  66 c7 43 06 17 00    mov WORD PTR [ebx+6],0x17 ; literal, not increment
10004708:  66 c7 43 04 64 00    mov WORD PTR [ebx+4],0x64
1000470e:  66 c7 43 06 06 00    mov WORD PTR [ebx+6],0x6 ; literal, not increment

; Header read/validation
1000445f:  66 8b 43 06          mov ax,WORD PTR [ebx+6]
10004464:  3b 46 06             cmp eax,DWORD PTR [esi+6]
; The compare follows +4 comparison and precedes +0xc length comparison.

; New MCVar.dll corresponding header stores (base 0x10000000)
10003e4f:  66 89 7b 06          mov WORD PTR [ebx+6],di ; 0
1000466f:  66 c7 43 06 17 00    mov WORD PTR [ebx+6],0x17
1000474d:  66 c7 43 06 06 00    mov WORD PTR [ebx+6],0x6
1000449e:  66 8b 43 06          mov ax,WORD PTR [ebx+6]

; Incidental non-header-looking [base+6] store found by exhaustive byte scan
; old 0x100191d0 / new 0x100192e0: mov WORD PTR [esi+6],ax after division by 0x3c,
; inside CRT-like __mbsicmp-labelled region; object is not established as NCDDE header.
; Do not conflate this with the EBX header stores above.
