
/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00448ac0 <.text+0x47ac0>:
  448ac0:	55                   	push   ebp
  448ac1:	8b ec                	mov    ebp,esp
  448ac3:	6a ff                	push   0xffffffff
  448ac5:	68 68 a9 46 00       	push   0x46a968
  448aca:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  448ad0:	50                   	push   eax
  448ad1:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  448ad8:	83 ec 58             	sub    esp,0x58
  448adb:	53                   	push   ebx
  448adc:	56                   	push   esi
  448add:	83 cb ff             	or     ebx,0xffffffff
  448ae0:	57                   	push   edi
  448ae1:	b9 0c 00 00 00       	mov    ecx,0xc
  448ae6:	8b c3                	mov    eax,ebx
  448ae8:	8d 7d 9c             	lea    edi,[ebp-0x64]
  448aeb:	66 89 5d cc          	mov    WORD PTR [ebp-0x34],bx
  448aef:	89 65 f0             	mov    DWORD PTR [ebp-0x10],esp
  448af2:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  448af4:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
  448af7:	33 ff                	xor    edi,edi
  448af9:	81 fe 90 40 00 00    	cmp    esi,0x4090
  448aff:	89 7d fc             	mov    DWORD PTR [ebp-0x4],edi
  448b02:	0f 87 6f 0d 00 00    	ja     0x449877
  448b08:	0f 84 fc 0a 00 00    	je     0x44960a
  448b0e:	81 fe 22 20 00 00    	cmp    esi,0x2022
  448b14:	0f 87 59 06 00 00    	ja     0x449173
  448b1a:	0f 84 d1 04 00 00    	je     0x448ff1
  448b20:	8d 86 d0 ef ff ff    	lea    eax,[esi-0x1030]
  448b26:	83 f8 32             	cmp    eax,0x32
  448b29:	0f 87 4a 0f 00 00    	ja     0x449a79
  448b2f:	33 c9                	xor    ecx,ecx
  448b31:	8a 88 c8 9a 44 00    	mov    cl,BYTE PTR [eax+0x449ac8]
  448b37:	ff 24 8d b8 9a 44 00 	jmp    DWORD PTR [ecx*4+0x449ab8]
  448b3e:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  448b43:	84 c0                	test   al,al
  448b45:	75 3f                	jne    0x448b86
  448b47:	80 3d 02 c6 47 00 02 	cmp    BYTE PTR ds:0x47c602,0x2
  448b4e:	76 20                	jbe    0x448b70
  448b50:	8d 55 0c             	lea    edx,[ebp+0xc]
  448b53:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  448b58:	52                   	push   edx
  448b59:	68 74 af 47 00       	push   0x47af74
  448b5e:	e8 e5 96 fb ff       	call   0x402248
  448b63:	85 c0                	test   eax,eax
  448b65:	75 09                	jne    0x448b70
  448b67:	a0 74 68 48 00       	mov    al,ds:0x486874
  448b6c:	84 c0                	test   al,al
  448b6e:	74 16                	je     0x448b86
  448b70:	a1 64 68 48 00       	mov    eax,ds:0x486864
  448b75:	8b 0d 18 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d18
  448b7b:	50                   	push   eax
  448b7c:	51                   	push   ecx
  448b7d:	e8 a4 e3 01 00       	call   0x466f26
  448b82:	85 c0                	test   eax,eax
  448b84:	74 0c                	je     0x448b92
  448b86:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  448b8a:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  448b8d:	e9 bc 02 00 00       	jmp    0x448e4e
  448b92:	83 7d 18 01          	cmp    DWORD PTR [ebp+0x18],0x1
  448b96:	75 0c                	jne    0x448ba4
  448b98:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  448b9c:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  448b9f:	e9 aa 02 00 00       	jmp    0x448e4e
  448ba4:	80 3d 17 6d 4a 00 01 	cmp    BYTE PTR ds:0x4a6d17,0x1
  448bab:	75 29                	jne    0x448bd6
  448bad:	8b 15 2c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d2c
  448bb3:	a1 68 68 48 00       	mov    eax,ds:0x486868
  448bb8:	8b 4a 04             	mov    ecx,DWORD PTR [edx+0x4]
  448bbb:	3b c8                	cmp    ecx,eax
  448bbd:	74 0b                	je     0x448bca
  448bbf:	8b 0d 24 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d24
  448bc5:	39 41 04             	cmp    DWORD PTR [ecx+0x4],eax
  448bc8:	75 11                	jne    0x448bdb
  448bca:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  448bce:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  448bd1:	e9 78 02 00 00       	jmp    0x448e4e
  448bd6:	a1 68 68 48 00       	mov    eax,ds:0x486868
  448bdb:	8b 0d 6c 27 48 00    	mov    ecx,DWORD PTR ds:0x48276c
  448be1:	50                   	push   eax
  448be2:	e8 a2 9b fb ff       	call   0x402789
  448be7:	85 c0                	test   eax,eax
  448be9:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  448bec:	0f 85 fc 0c 00 00    	jne    0x4498ee
  448bf2:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  448bf6:	e9 53 02 00 00       	jmp    0x448e4e
  448bfb:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  448c00:	84 c0                	test   al,al
  448c02:	74 0c                	je     0x448c10
  448c04:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  448c08:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  448c0b:	e9 3e 02 00 00       	jmp    0x448e4e
  448c10:	83 3d d0 6c 4a 00 01 	cmp    DWORD PTR ds:0x4a6cd0,0x1
  448c17:	74 16                	je     0x448c2f
  448c19:	8b 15 5c 68 48 00    	mov    edx,DWORD PTR ds:0x48685c
  448c1f:	52                   	push   edx
  448c20:	e8 85 8e fb ff       	call   0x401aaa
  448c25:	83 c4 04             	add    esp,0x4
  448c28:	8b f0                	mov    esi,eax
  448c2a:	e9 03 06 00 00       	jmp    0x449232
  448c2f:	8b 5d 0c             	mov    ebx,DWORD PTR [ebp+0xc]
  448c32:	83 fb 01             	cmp    ebx,0x1
  448c35:	74 27                	je     0x448c5e
  448c37:	33 c0                	xor    eax,eax
  448c39:	66 a1 50 99 49 00    	mov    ax,ds:0x499950
  448c3f:	3b d8                	cmp    ebx,eax
  448c41:	74 1b                	je     0x448c5e
  448c43:	6a 0a                	push   0xa
  448c45:	e8 17 8c fb ff       	call   0x401861
  448c4a:	8b f0                	mov    esi,eax
  448c4c:	83 c8 ff             	or     eax,0xffffffff
  448c4f:	83 c4 04             	add    esp,0x4
  448c52:	66 39 45 cc          	cmp    WORD PTR [ebp-0x34],ax
  448c56:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  448c59:	e9 db 05 00 00       	jmp    0x449239
  448c5e:	66 81 3d ee 1a 48 00 	cmp    WORD PTR ds:0x481aee,0xd16
  448c65:	16 0d 
  448c67:	76 17                	jbe    0x448c80
  448c69:	6a 21                	push   0x21
  448c6b:	6a 04                	push   0x4
  448c6d:	6a 0a                	push   0xa
  448c6f:	6a 01                	push   0x1
  448c71:	6a 00                	push   0x0
  448c73:	e8 2a 91 fb ff       	call   0x401da2
  448c78:	83 c4 14             	add    esp,0x14
  448c7b:	e9 c4 01 00 00       	jmp    0x448e44
  448c80:	68 d0 42 48 00       	push   0x4842d0
  448c85:	e8 c7 96 fb ff       	call   0x402351
  448c8a:	83 c4 04             	add    esp,0x4
  448c8d:	8d 4d 9c             	lea    ecx,[ebp-0x64]
  448c90:	8d 55 e8             	lea    edx,[ebp-0x18]
  448c93:	a3 60 68 48 00       	mov    ds:0x486860,eax
  448c98:	6a 01                	push   0x1
  448c9a:	51                   	push   ecx
  448c9b:	52                   	push   edx
  448c9c:	50                   	push   eax
  448c9d:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  448ca2:	e8 2a 8f fb ff       	call   0x401bd1
  448ca7:	85 c0                	test   eax,eax
  448ca9:	75 1b                	jne    0x448cc6
  448cab:	6a 0a                	push   0xa
  448cad:	e8 5b 99 fb ff       	call   0x40260d
  448cb2:	8b f0                	mov    esi,eax
  448cb4:	83 c8 ff             	or     eax,0xffffffff
  448cb7:	83 c4 04             	add    esp,0x4
  448cba:	66 39 45 cc          	cmp    WORD PTR [ebp-0x34],ax
  448cbe:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  448cc1:	e9 73 05 00 00       	jmp    0x449239
  448cc6:	83 3d 8c 40 48 00 01 	cmp    DWORD PTR ds:0x48408c,0x1
  448ccd:	74 04                	je     0x448cd3
  448ccf:	6a 52                	push   0x52
  448cd1:	eb 98                	jmp    0x448c6b
  448cd3:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  448cd6:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  448cda:	75 0e                	jne    0x448cea
  448cdc:	a1 2c 6d 4a 00       	mov    eax,ds:0x4a6d2c
  448ce1:	8b 50 04             	mov    edx,DWORD PTR [eax+0x4]
  448ce4:	89 15 68 68 48 00    	mov    DWORD PTR ds:0x486868,edx
  448cea:	a1 9c 40 48 00       	mov    eax,ds:0x48409c
  448cef:	8d 55 e0             	lea    edx,[ebp-0x20]
  448cf2:	6a 01                	push   0x1
  448cf4:	52                   	push   edx
  448cf5:	8b 00                	mov    eax,DWORD PTR [eax]
  448cf7:	8b 15 68 68 48 00    	mov    edx,DWORD PTR ds:0x486868
  448cfd:	83 c0 04             	add    eax,0x4
  448d00:	52                   	push   edx
  448d01:	50                   	push   eax
  448d02:	e8 80 97 fb ff       	call   0x402487
  448d07:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  448d0a:	8b f8                	mov    edi,eax
  448d0c:	68 4c 68 48 00       	push   0x48684c
  448d11:	8d 45 ec             	lea    eax,[ebp-0x14]
  448d14:	6a 02                	push   0x2
  448d16:	50                   	push   eax
  448d17:	e8 26 9b fb ff       	call   0x402842
  448d1c:	8b f0                	mov    esi,eax
  448d1e:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  448d21:	85 c0                	test   eax,eax
  448d23:	a3 54 68 48 00       	mov    ds:0x486854,eax
  448d28:	74 0d                	je     0x448d37
  448d2a:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  448d2e:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  448d35:	eb 09                	jmp    0x448d40
  448d37:	66 c7 05 50 68 48 00 	mov    WORD PTR ds:0x486850,0x0
  448d3e:	00 00 
  448d40:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  448d46:	8d 4d d8             	lea    ecx,[ebp-0x28]
  448d49:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  448d4c:	e8 f3 d6 01 00       	call   0x466444
  448d51:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  448d54:	83 fe 01             	cmp    esi,0x1
  448d57:	c6 45 fc 02          	mov    BYTE PTR [ebp-0x4],0x2
  448d5b:	75 78                	jne    0x448dd5
  448d5d:	8a 48 05             	mov    cl,BYTE PTR [eax+0x5]
  448d60:	84 c9                	test   cl,cl
  448d62:	74 48                	je     0x448dac
  448d64:	8b 48 2e             	mov    ecx,DWORD PTR [eax+0x2e]
  448d67:	8b 15 5c 68 48 00    	mov    edx,DWORD PTR ds:0x48685c
  448d6d:	3b ca                	cmp    ecx,edx
  448d6f:	75 64                	jne    0x448dd5
  448d71:	8b 50 20             	mov    edx,DWORD PTR [eax+0x20]
  448d74:	8b 0d 68 68 48 00    	mov    ecx,DWORD PTR ds:0x486868
  448d7a:	3b d1                	cmp    edx,ecx
  448d7c:	75 57                	jne    0x448dd5
  448d7e:	8b 48 1c             	mov    ecx,DWORD PTR [eax+0x1c]
  448d81:	8b 15 64 68 48 00    	mov    edx,DWORD PTR ds:0x486864
  448d87:	3b ca                	cmp    ecx,edx
  448d89:	75 4a                	jne    0x448dd5
  448d8b:	6a 16                	push   0x16
  448d8d:	6a 04                	push   0x4
  448d8f:	6a 0a                	push   0xa
  448d91:	6a 01                	push   0x1
  448d93:	6a 00                	push   0x0
  448d95:	c7 05 64 68 48 00 00 	mov    DWORD PTR ds:0x486864,0x0
  448d9c:	00 00 00 
  448d9f:	e8 fe 8f fb ff       	call   0x401da2
  448da4:	83 c4 14             	add    esp,0x14
  448da7:	e9 8f 00 00 00       	jmp    0x448e3b
  448dac:	8b 15 5c 68 48 00    	mov    edx,DWORD PTR ds:0x48685c
  448db2:	52                   	push   edx
  448db3:	e8 f2 8c fb ff       	call   0x401aaa
  448db8:	83 c4 04             	add    esp,0x4
  448dbb:	8b f0                	mov    esi,eax
  448dbd:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  448dc1:	e8 78 d6 01 00       	call   0x46643e
  448dc6:	83 c8 ff             	or     eax,0xffffffff
  448dc9:	66 39 45 cc          	cmp    WORD PTR [ebp-0x34],ax
  448dcd:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  448dd0:	e9 64 04 00 00       	jmp    0x449239
  448dd5:	8b f3                	mov    esi,ebx
  448dd7:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  448dda:	4e                   	dec    esi
  448ddb:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
  448dde:	f7 de                	neg    esi
  448de0:	8b 11                	mov    edx,DWORD PTR [ecx]
  448de2:	6a 00                	push   0x0
  448de4:	1b f6                	sbb    esi,esi
  448de6:	6a 00                	push   0x0
  448de8:	83 e6 02             	and    esi,0x2
  448deb:	46                   	inc    esi
  448dec:	56                   	push   esi
  448ded:	6a 00                	push   0x0
  448def:	50                   	push   eax
  448df0:	ff 52 18             	call   DWORD PTR [edx+0x18]
  448df3:	83 f8 03             	cmp    eax,0x3
  448df6:	75 2b                	jne    0x448e23
  448df8:	33 c9                	xor    ecx,ecx
  448dfa:	66 8b 0d 50 99 49 00 	mov    cx,WORD PTR ds:0x499950
  448e01:	3b d9                	cmp    ebx,ecx
  448e03:	74 1e                	je     0x448e23
  448e05:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  448e08:	6a 11                	push   0x11
  448e0a:	6a 04                	push   0x4
  448e0c:	6a 0a                	push   0xa
  448e0e:	6a 01                	push   0x1
  448e10:	52                   	push   edx
  448e11:	e8 8c 8f fb ff       	call   0x401da2
  448e16:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  448e19:	83 c4 14             	add    esp,0x14
  448e1c:	68 4c 68 48 00       	push   0x48684c
  448e21:	eb 0f                	jmp    0x448e32
  448e23:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  448e26:	8b 48 2a             	mov    ecx,DWORD PTR [eax+0x2a]
  448e29:	85 c9                	test   ecx,ecx
  448e2b:	74 42                	je     0x448e6f
  448e2d:	68 4c 68 48 00       	push   0x48684c
  448e32:	50                   	push   eax
  448e33:	e8 52 98 fb ff       	call   0x40268a
  448e38:	83 c4 08             	add    esp,0x8
  448e3b:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  448e3f:	e8 fa d5 01 00       	call   0x46643e
  448e44:	83 c8 ff             	or     eax,0xffffffff
  448e47:	66 39 45 cc          	cmp    WORD PTR [ebp-0x34],ax
  448e4b:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  448e4e:	0f 84 51 0c 00 00    	je     0x449aa5
  448e54:	8d 4d cc             	lea    ecx,[ebp-0x34]
  448e57:	e8 53 91 fb ff       	call   0x401faf
  448e5c:	33 c0                	xor    eax,eax
  448e5e:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  448e61:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  448e68:	5f                   	pop    edi
  448e69:	5e                   	pop    esi
  448e6a:	5b                   	pop    ebx
  448e6b:	8b e5                	mov    esp,ebp
  448e6d:	5d                   	pop    ebp
  448e6e:	c3                   	ret
  448e6f:	85 ff                	test   edi,edi
  448e71:	74 73                	je     0x448ee6
  448e73:	57                   	push   edi
  448e74:	50                   	push   eax
  448e75:	e8 f7 97 fb ff       	call   0x402671
  448e7a:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  448e7d:	8b 4f 2a             	mov    ecx,DWORD PTR [edi+0x2a]
  448e80:	83 c4 08             	add    esp,0x8
  448e83:	89 4a 2a             	mov    DWORD PTR [edx+0x2a],ecx
  448e86:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  448e89:	c6 40 05 01          	mov    BYTE PTR [eax+0x5],0x1
  448e8d:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  448e91:	e8 a8 d5 01 00       	call   0x46643e
  448e96:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  448e9a:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  448ea1:	66 3d ff ff          	cmp    ax,0xffff
  448ea5:	0f 84 51 0a 00 00    	je     0x4498fc
  448eab:	0f bf c0             	movsx  eax,ax
  448eae:	8d 04 40             	lea    eax,[eax+eax*2]
  448eb1:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  448eb8:	00 
  448eb9:	66 83 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],0x0
  448ec0:	00 00 
  448ec2:	0f 85 34 0a 00 00    	jne    0x4498fc
  448ec8:	8d 4d cc             	lea    ecx,[ebp-0x34]
  448ecb:	e8 33 8d fb ff       	call   0x401c03
  448ed0:	b8 01 00 00 00       	mov    eax,0x1
  448ed5:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  448ed8:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  448edf:	5f                   	pop    edi
  448ee0:	5e                   	pop    esi
  448ee1:	5b                   	pop    ebx
  448ee2:	8b e5                	mov    esp,ebp
  448ee4:	5d                   	pop    ebp
  448ee5:	c3                   	ret
  448ee6:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  448ee9:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
  448eec:	50                   	push   eax
  448eed:	8b 11                	mov    edx,DWORD PTR [ecx]
  448eef:	ff 52 24             	call   DWORD PTR [edx+0x24]
  448ef2:	83 f8 ff             	cmp    eax,0xffffffff
  448ef5:	0f 84 86 00 00 00    	je     0x448f81
  448efb:	85 c0                	test   eax,eax
  448efd:	74 0d                	je     0x448f0c
  448eff:	83 f8 01             	cmp    eax,0x1
  448f02:	75 89                	jne    0x448e8d
  448f04:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  448f07:	88 41 05             	mov    BYTE PTR [ecx+0x5],al
  448f0a:	eb 81                	jmp    0x448e8d
  448f0c:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  448f0f:	c6 42 04 01          	mov    BYTE PTR [edx+0x4],0x1
  448f13:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
  448f16:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  448f19:	8a 48 27             	mov    cl,BYTE PTR [eax+0x27]
  448f1c:	8a 45 08             	mov    al,BYTE PTR [ebp+0x8]
  448f1f:	a8 01                	test   al,0x1
  448f21:	88 4a 32             	mov    BYTE PTR [edx+0x32],cl
  448f24:	0f 85 63 ff ff ff    	jne    0x448e8d
  448f2a:	a8 02                	test   al,0x2
  448f2c:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  448f30:	0f 85 5b ff ff ff    	jne    0x448e91
  448f36:	e8 03 d5 01 00       	call   0x46643e
  448f3b:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  448f3f:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  448f46:	66 3d ff ff          	cmp    ax,0xffff
  448f4a:	74 21                	je     0x448f6d
  448f4c:	0f bf c0             	movsx  eax,ax
  448f4f:	8d 04 40             	lea    eax,[eax+eax*2]
  448f52:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  448f59:	00 
  448f5a:	66 83 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],0x0
  448f61:	00 00 
  448f63:	75 08                	jne    0x448f6d
  448f65:	8d 4d cc             	lea    ecx,[ebp-0x34]
  448f68:	e8 96 8c fb ff       	call   0x401c03
  448f6d:	83 c8 ff             	or     eax,0xffffffff
  448f70:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  448f73:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  448f7a:	5f                   	pop    edi
  448f7b:	5e                   	pop    esi
  448f7c:	5b                   	pop    ebx
  448f7d:	8b e5                	mov    esp,ebp
  448f7f:	5d                   	pop    ebp
  448f80:	c3                   	ret
  448f81:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  448f84:	68 4c 68 48 00       	push   0x48684c
  448f89:	50                   	push   eax
  448f8a:	e8 fb 96 fb ff       	call   0x40268a
  448f8f:	83 c4 08             	add    esp,0x8
  448f92:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  448f96:	e8 a3 d4 01 00       	call   0x46643e
  448f9b:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  448f9f:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  448fa6:	66 3d ff ff          	cmp    ax,0xffff
  448faa:	0f 84 f5 0a 00 00    	je     0x449aa5
  448fb0:	0f bf c0             	movsx  eax,ax
  448fb3:	8d 04 40             	lea    eax,[eax+eax*2]
  448fb6:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  448fbd:	00 
  448fbe:	66 83 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],0x0
  448fc5:	00 00 
  448fc7:	e9 a9 0a 00 00       	jmp    0x449a75
  448fcc:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  448fcf:	8b 4d 0c             	mov    ecx,DWORD PTR [ebp+0xc]
  448fd2:	68 4c 68 48 00       	push   0x48684c
  448fd7:	52                   	push   edx
  448fd8:	89 4d dc             	mov    DWORD PTR [ebp-0x24],ecx
  448fdb:	e8 aa 96 fb ff       	call   0x40268a
  448fe0:	83 c4 08             	add    esp,0x8
  448fe3:	e8 50 d4 01 00       	call   0x466438
  448fe8:	6a 00                	push   0x0
  448fea:	6a 00                	push   0x0
  448fec:	e8 df da 01 00       	call   0x466ad0
  448ff1:	68 d0 42 48 00       	push   0x4842d0
  448ff6:	c6 05 6d 68 48 00 01 	mov    BYTE PTR ds:0x48686d,0x1
  448ffd:	e8 4f 93 fb ff       	call   0x402351
  449002:	83 c4 04             	add    esp,0x4
  449005:	32 db                	xor    bl,bl
  449007:	66 81 7d 14 ff ff    	cmp    WORD PTR [ebp+0x14],0xffff
  44900d:	a3 60 68 48 00       	mov    ds:0x486860,eax
  449012:	75 0c                	jne    0x449020
  449014:	8a 0d c8 6c 4a 00    	mov    cl,BYTE PTR ds:0x4a6cc8
  44901a:	84 c9                	test   cl,cl
  44901c:	74 02                	je     0x449020
  44901e:	b3 01                	mov    bl,0x1
  449020:	80 3d 76 68 48 00 01 	cmp    BYTE PTR ds:0x486876,0x1
  449027:	0f 85 87 00 00 00    	jne    0x4490b4
  44902d:	8b 0d 78 68 48 00    	mov    ecx,DWORD PTR ds:0x486878
  449033:	3b cf                	cmp    ecx,edi
  449035:	74 7d                	je     0x4490b4
  449037:	8b 51 1c             	mov    edx,DWORD PTR [ecx+0x1c]
  44903a:	8b 35 64 68 48 00    	mov    esi,DWORD PTR ds:0x486864
  449040:	3b d6                	cmp    edx,esi
  449042:	75 70                	jne    0x4490b4
  449044:	8b 51 20             	mov    edx,DWORD PTR [ecx+0x20]
  449047:	8b 35 68 68 48 00    	mov    esi,DWORD PTR ds:0x486868
  44904d:	3b d6                	cmp    edx,esi
  44904f:	74 11                	je     0x449062
  449051:	8b 91 a6 00 00 00    	mov    edx,DWORD PTR [ecx+0xa6]
  449057:	8b 12                	mov    edx,DWORD PTR [edx]
  449059:	8b 52 36             	mov    edx,DWORD PTR [edx+0x36]
  44905c:	f6 42 1f 01          	test   BYTE PTR [edx+0x1f],0x1
  449060:	75 52                	jne    0x4490b4
  449062:	3b cf                	cmp    ecx,edi
  449064:	89 4d ec             	mov    DWORD PTR [ebp-0x14],ecx
  449067:	89 0d 54 68 48 00    	mov    DWORD PTR ds:0x486854,ecx
  44906d:	74 0d                	je     0x44907c
  44906f:	66 8b 51 36          	mov    dx,WORD PTR [ecx+0x36]
  449073:	66 89 15 50 68 48 00 	mov    WORD PTR ds:0x486850,dx
  44907a:	eb 07                	jmp    0x449083
  44907c:	66 89 3d 50 68 48 00 	mov    WORD PTR ds:0x486850,di
  449083:	89 41 08             	mov    DWORD PTR [ecx+0x8],eax
  449086:	a1 78 68 48 00       	mov    eax,ds:0x486878
  44908b:	8b 48 20             	mov    ecx,DWORD PTR [eax+0x20]
  44908e:	a1 68 68 48 00       	mov    eax,ds:0x486868
  449093:	3b c8                	cmp    ecx,eax
  449095:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  449098:	74 09                	je     0x4490a3
  44909a:	8b 50 20             	mov    edx,DWORD PTR [eax+0x20]
  44909d:	89 15 68 68 48 00    	mov    DWORD PTR ds:0x486868,edx
  4490a3:	8b 4d 0c             	mov    ecx,DWORD PTR [ebp+0xc]
  4490a6:	8d 90 a2 00 00 00    	lea    edx,[eax+0xa2]
  4490ac:	51                   	push   ecx
  4490ad:	52                   	push   edx
  4490ae:	50                   	push   eax
  4490af:	e9 8a 00 00 00       	jmp    0x44913e
  4490b4:	8d 4d 9c             	lea    ecx,[ebp-0x64]
  4490b7:	6a 01                	push   0x1
  4490b9:	8d 55 e8             	lea    edx,[ebp-0x18]
  4490bc:	51                   	push   ecx
  4490bd:	52                   	push   edx
  4490be:	50                   	push   eax
  4490bf:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  4490c4:	e8 08 8b fb ff       	call   0x401bd1
  4490c9:	85 c0                	test   eax,eax
  4490cb:	75 0c                	jne    0x4490d9
  4490cd:	6a 0a                	push   0xa
  4490cf:	e8 39 95 fb ff       	call   0x40260d
  4490d4:	83 c4 04             	add    esp,0x4
  4490d7:	eb 6d                	jmp    0x449146
  4490d9:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  4490dc:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  4490e0:	75 0e                	jne    0x4490f0
  4490e2:	a1 2c 6d 4a 00       	mov    eax,ds:0x4a6d2c
  4490e7:	8b 50 04             	mov    edx,DWORD PTR [eax+0x4]
  4490ea:	89 15 68 68 48 00    	mov    DWORD PTR ds:0x486868,edx
  4490f0:	a1 9c 40 48 00       	mov    eax,ds:0x48409c
  4490f5:	8d 55 e0             	lea    edx,[ebp-0x20]
  4490f8:	6a 01                	push   0x1
  4490fa:	52                   	push   edx
  4490fb:	8b 00                	mov    eax,DWORD PTR [eax]
  4490fd:	8b 15 68 68 48 00    	mov    edx,DWORD PTR ds:0x486868
  449103:	83 c0 04             	add    eax,0x4
  449106:	52                   	push   edx
  449107:	50                   	push   eax
  449108:	e8 7a 93 fb ff       	call   0x402487
  44910d:	3b c7                	cmp    eax,edi
  44910f:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  449112:	75 04                	jne    0x449118
  449114:	33 f6                	xor    esi,esi
  449116:	eb 30                	jmp    0x449148
  449118:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  44911e:	a3 54 68 48 00       	mov    ds:0x486854,eax
  449123:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  449127:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  44912e:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  449131:	8b 45 0c             	mov    eax,DWORD PTR [ebp+0xc]
  449134:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  449137:	50                   	push   eax
  449138:	68 98 40 48 00       	push   0x484098
  44913d:	51                   	push   ecx
  44913e:	e8 6a 90 fb ff       	call   0x4021ad
  449143:	83 c4 0c             	add    esp,0xc
  449146:	8b f0                	mov    esi,eax
  449148:	80 fb 01             	cmp    bl,0x1
  44914b:	75 12                	jne    0x44915f
  44914d:	8b 15 64 68 48 00    	mov    edx,DWORD PTR ds:0x486864
  449153:	a1 c0 6c 4a 00       	mov    eax,ds:0x4a6cc0
  449158:	52                   	push   edx
  449159:	50                   	push   eax
  44915a:	e8 8b dd 01 00       	call   0x466eea
  44915f:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449163:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  44916a:	66 3d ff ff          	cmp    ax,0xffff
  44916e:	e9 c3 07 00 00       	jmp    0x449936
  449173:	8b c6                	mov    eax,esi
  449175:	2d b0 20 00 00       	sub    eax,0x20b0
  44917a:	0f 84 e5 00 00 00    	je     0x449265
  449180:	83 e8 32             	sub    eax,0x32
  449183:	0f 84 cd 00 00 00    	je     0x449256
  449189:	2d 6e 1f 00 00       	sub    eax,0x1f6e
  44918e:	0f 85 e5 08 00 00    	jne    0x449a79
  449194:	80 3d e8 6c 4a 00 02 	cmp    BYTE PTR ds:0x4a6ce8,0x2
  44919b:	75 24                	jne    0x4491c1
  44919d:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  4491a1:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  4491a4:	74 08                	je     0x4491ae
  4491a6:	8d 4d cc             	lea    ecx,[ebp-0x34]
  4491a9:	e8 01 8e fb ff       	call   0x401faf
  4491ae:	8b c3                	mov    eax,ebx
  4491b0:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4491b3:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4491ba:	5f                   	pop    edi
  4491bb:	5e                   	pop    esi
  4491bc:	5b                   	pop    ebx
  4491bd:	8b e5                	mov    esp,ebp
  4491bf:	5d                   	pop    ebp
  4491c0:	c3                   	ret
  4491c1:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  4491c7:	8b 15 04 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d04
  4491cd:	33 c0                	xor    eax,eax
  4491cf:	3b d1                	cmp    edx,ecx
  4491d1:	74 51                	je     0x449224
  4491d3:	8b 15 08 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d08
  4491d9:	b8 01 00 00 00       	mov    eax,0x1
  4491de:	3b d1                	cmp    edx,ecx
  4491e0:	74 42                	je     0x449224
  4491e2:	8b 15 0c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d0c
  4491e8:	b8 02 00 00 00       	mov    eax,0x2
  4491ed:	3b d1                	cmp    edx,ecx
  4491ef:	74 33                	je     0x449224
  4491f1:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  4491f6:	84 c0                	test   al,al
  4491f8:	74 04                	je     0x4491fe
  4491fa:	33 f6                	xor    esi,esi
  4491fc:	eb 34                	jmp    0x449232
  4491fe:	83 3d d0 6c 4a 00 01 	cmp    DWORD PTR ds:0x4a6cd0,0x1
  449205:	74 0d                	je     0x449214
  449207:	51                   	push   ecx
  449208:	e8 9d 88 fb ff       	call   0x401aaa
  44920d:	83 c4 04             	add    esp,0x4
  449210:	8b f0                	mov    esi,eax
  449212:	eb 1e                	jmp    0x449232
  449214:	8b 4d 10             	mov    ecx,DWORD PTR [ebp+0x10]
  449217:	51                   	push   ecx
  449218:	e8 12 95 fb ff       	call   0x40272f
  44921d:	83 c4 04             	add    esp,0x4
  449220:	8b f0                	mov    esi,eax
  449222:	eb 0e                	jmp    0x449232
  449224:	8b 34 85 f8 6c 4a 00 	mov    esi,DWORD PTR [eax*4+0x4a6cf8]
  44922b:	89 3c 85 04 6d 4a 00 	mov    DWORD PTR [eax*4+0x4a6d04],edi
  449232:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  449236:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  449239:	74 08                	je     0x449243
  44923b:	8d 4d cc             	lea    ecx,[ebp-0x34]
  44923e:	e8 6c 8d fb ff       	call   0x401faf
  449243:	8b c6                	mov    eax,esi
  449245:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  449248:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  44924f:	5f                   	pop    edi
  449250:	5e                   	pop    esi
  449251:	5b                   	pop    ebx
  449252:	8b e5                	mov    esp,ebp
  449254:	5d                   	pop    ebp
  449255:	c3                   	ret
  449256:	8b 0d 6c 27 48 00    	mov    ecx,DWORD PTR ds:0x48276c
  44925c:	e8 e0 7d fb ff       	call   0x401041
  449261:	8b f0                	mov    esi,eax
  449263:	eb cd                	jmp    0x449232
  449265:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  44926a:	84 c0                	test   al,al
  44926c:	0f 85 e1 07 00 00    	jne    0x449a53
  449272:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  449275:	83 fe 01             	cmp    esi,0x1
  449278:	74 59                	je     0x4492d3
  44927a:	33 d2                	xor    edx,edx
  44927c:	66 8b 15 50 99 49 00 	mov    dx,WORD PTR ds:0x499950
  449283:	3b f2                	cmp    esi,edx
  449285:	74 4c                	je     0x4492d3
  449287:	83 fe 07             	cmp    esi,0x7
  44928a:	75 3b                	jne    0x4492c7
  44928c:	a1 64 68 48 00       	mov    eax,ds:0x486864
  449291:	8b 0d 18 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d18
  449297:	50                   	push   eax
  449298:	51                   	push   ecx
  449299:	e8 88 dc 01 00       	call   0x466f26
  44929e:	85 c0                	test   eax,eax
  4492a0:	0f 85 ad 07 00 00    	jne    0x449a53
  4492a6:	8b 15 64 68 48 00    	mov    edx,DWORD PTR ds:0x486864
  4492ac:	a1 c0 6c 4a 00       	mov    eax,ds:0x4a6cc0
  4492b1:	57                   	push   edi
  4492b2:	56                   	push   esi
  4492b3:	52                   	push   edx
  4492b4:	57                   	push   edi
  4492b5:	6a 06                	push   0x6
  4492b7:	68 64 9c 47 00       	push   0x479c64
  4492bc:	50                   	push   eax
  4492bd:	e8 94 dc 01 00       	call   0x466f56
  4492c2:	e9 63 06 00 00       	jmp    0x44992a
  4492c7:	6a 04                	push   0x4
  4492c9:	e8 93 85 fb ff       	call   0x401861
  4492ce:	e9 54 06 00 00       	jmp    0x449927
  4492d3:	a1 d0 6c 4a 00       	mov    eax,ds:0x4a6cd0
  4492d8:	83 f8 01             	cmp    eax,0x1
  4492db:	74 1a                	je     0x4492f7
  4492dd:	83 f8 02             	cmp    eax,0x2
  4492e0:	75 09                	jne    0x4492eb
  4492e2:	a0 e8 6c 4a 00       	mov    al,ds:0x4a6ce8
  4492e7:	84 c0                	test   al,al
  4492e9:	75 0c                	jne    0x4492f7
  4492eb:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  4492f1:	51                   	push   ecx
  4492f2:	e9 2b 06 00 00       	jmp    0x449922
  4492f7:	68 d0 42 48 00       	push   0x4842d0
  4492fc:	e8 50 90 fb ff       	call   0x402351
  449301:	83 c4 04             	add    esp,0x4
  449304:	8d 55 9c             	lea    edx,[ebp-0x64]
  449307:	8d 4d e8             	lea    ecx,[ebp-0x18]
  44930a:	a3 60 68 48 00       	mov    ds:0x486860,eax
  44930f:	6a 01                	push   0x1
  449311:	52                   	push   edx
  449312:	51                   	push   ecx
  449313:	50                   	push   eax
  449314:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  449319:	e8 b3 88 fb ff       	call   0x401bd1
  44931e:	85 c0                	test   eax,eax
  449320:	75 0c                	jne    0x44932e
  449322:	6a 04                	push   0x4
  449324:	e8 e4 92 fb ff       	call   0x40260d
  449329:	e9 f9 05 00 00       	jmp    0x449927
  44932e:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449331:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  449335:	75 0e                	jne    0x449345
  449337:	8b 15 2c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d2c
  44933d:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  449340:	a3 68 68 48 00       	mov    ds:0x486868,eax
  449345:	8b 15 9c 40 48 00    	mov    edx,DWORD PTR ds:0x48409c
  44934b:	8b 02                	mov    eax,DWORD PTR [edx]
  44934d:	b2 ff                	mov    dl,0xff
  44934f:	38 50 2f             	cmp    BYTE PTR [eax+0x2f],dl
  449352:	0f 85 04 01 00 00    	jne    0x44945c
  449358:	8b 79 19             	mov    edi,DWORD PTR [ecx+0x19]
  44935b:	38 57 3f             	cmp    BYTE PTR [edi+0x3f],dl
  44935e:	0f 85 f6 00 00 00    	jne    0x44945a
  449364:	f6 41 1f 04          	test   BYTE PTR [ecx+0x1f],0x4
  449368:	0f 85 ec 00 00 00    	jne    0x44945a
  44936e:	83 3d 8c 40 48 00 01 	cmp    DWORD PTR ds:0x48408c,0x1
  449375:	0f 85 df 00 00 00    	jne    0x44945a
  44937b:	8d 55 e0             	lea    edx,[ebp-0x20]
  44937e:	6a 01                	push   0x1
