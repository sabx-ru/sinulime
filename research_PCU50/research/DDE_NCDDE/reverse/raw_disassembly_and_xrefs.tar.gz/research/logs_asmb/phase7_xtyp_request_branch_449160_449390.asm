
/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00449160 <.text+0x48160>:
  449160:	8b 45 cc             	mov    eax,DWORD PTR [ebp-0x34]
  449163:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  44916a:	66 3d ff ff          	cmp    ax,0xffff
  44916e:	e9 c3 07 00 00       	jmp    0x449936
  449173:	8b c6                	mov    eax,esi
  449175:	2d b0 20 00 00       	sub    eax,0x20b0
  44917a:	0f 84 e5 00 00 00    	je     0x449265
  449180:	83 e8 32             	sub    eax,0x32
  449183:	0f 84 cd 00 00 00    	je     0x449256
  449189:	2d 6e 1f 00 00       	sub    eax,0x1f6e
  44918e:	0f 85 e5 08 00 00    	jne    0x449a79
  449194:	80 3d e8 6c 4a 00 02 	cmp    BYTE PTR ds:0x4a6ce8,0x2
  44919b:	75 24                	jne    0x4491c1
  44919d:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  4491a1:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  4491a4:	74 08                	je     0x4491ae
  4491a6:	8d 4d cc             	lea    ecx,[ebp-0x34]
  4491a9:	e8 01 8e fb ff       	call   0x401faf
  4491ae:	8b c3                	mov    eax,ebx
  4491b0:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4491b3:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4491ba:	5f                   	pop    edi
  4491bb:	5e                   	pop    esi
  4491bc:	5b                   	pop    ebx
  4491bd:	8b e5                	mov    esp,ebp
  4491bf:	5d                   	pop    ebp
  4491c0:	c3                   	ret
  4491c1:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  4491c7:	8b 15 04 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d04
  4491cd:	33 c0                	xor    eax,eax
  4491cf:	3b d1                	cmp    edx,ecx
  4491d1:	74 51                	je     0x449224
  4491d3:	8b 15 08 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d08
  4491d9:	b8 01 00 00 00       	mov    eax,0x1
  4491de:	3b d1                	cmp    edx,ecx
  4491e0:	74 42                	je     0x449224
  4491e2:	8b 15 0c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d0c
  4491e8:	b8 02 00 00 00       	mov    eax,0x2
  4491ed:	3b d1                	cmp    edx,ecx
  4491ef:	74 33                	je     0x449224
  4491f1:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  4491f6:	84 c0                	test   al,al
  4491f8:	74 04                	je     0x4491fe
  4491fa:	33 f6                	xor    esi,esi
  4491fc:	eb 34                	jmp    0x449232
  4491fe:	83 3d d0 6c 4a 00 01 	cmp    DWORD PTR ds:0x4a6cd0,0x1
  449205:	74 0d                	je     0x449214
  449207:	51                   	push   ecx
  449208:	e8 9d 88 fb ff       	call   0x401aaa
  44920d:	83 c4 04             	add    esp,0x4
  449210:	8b f0                	mov    esi,eax
  449212:	eb 1e                	jmp    0x449232
  449214:	8b 4d 10             	mov    ecx,DWORD PTR [ebp+0x10]
  449217:	51                   	push   ecx
  449218:	e8 12 95 fb ff       	call   0x40272f
  44921d:	83 c4 04             	add    esp,0x4
  449220:	8b f0                	mov    esi,eax
  449222:	eb 0e                	jmp    0x449232
  449224:	8b 34 85 f8 6c 4a 00 	mov    esi,DWORD PTR [eax*4+0x4a6cf8]
  44922b:	89 3c 85 04 6d 4a 00 	mov    DWORD PTR [eax*4+0x4a6d04],edi
  449232:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  449236:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  449239:	74 08                	je     0x449243
  44923b:	8d 4d cc             	lea    ecx,[ebp-0x34]
  44923e:	e8 6c 8d fb ff       	call   0x401faf
  449243:	8b c6                	mov    eax,esi
  449245:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  449248:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  44924f:	5f                   	pop    edi
  449250:	5e                   	pop    esi
  449251:	5b                   	pop    ebx
  449252:	8b e5                	mov    esp,ebp
  449254:	5d                   	pop    ebp
  449255:	c3                   	ret
  449256:	8b 0d 6c 27 48 00    	mov    ecx,DWORD PTR ds:0x48276c
  44925c:	e8 e0 7d fb ff       	call   0x401041
  449261:	8b f0                	mov    esi,eax
  449263:	eb cd                	jmp    0x449232
  449265:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  44926a:	84 c0                	test   al,al
  44926c:	0f 85 e1 07 00 00    	jne    0x449a53
  449272:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  449275:	83 fe 01             	cmp    esi,0x1
  449278:	74 59                	je     0x4492d3
  44927a:	33 d2                	xor    edx,edx
  44927c:	66 8b 15 50 99 49 00 	mov    dx,WORD PTR ds:0x499950
  449283:	3b f2                	cmp    esi,edx
  449285:	74 4c                	je     0x4492d3
  449287:	83 fe 07             	cmp    esi,0x7
  44928a:	75 3b                	jne    0x4492c7
  44928c:	a1 64 68 48 00       	mov    eax,ds:0x486864
  449291:	8b 0d 18 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d18
  449297:	50                   	push   eax
  449298:	51                   	push   ecx
  449299:	e8 88 dc 01 00       	call   0x466f26
  44929e:	85 c0                	test   eax,eax
  4492a0:	0f 85 ad 07 00 00    	jne    0x449a53
  4492a6:	8b 15 64 68 48 00    	mov    edx,DWORD PTR ds:0x486864
  4492ac:	a1 c0 6c 4a 00       	mov    eax,ds:0x4a6cc0
  4492b1:	57                   	push   edi
  4492b2:	56                   	push   esi
  4492b3:	52                   	push   edx
  4492b4:	57                   	push   edi
  4492b5:	6a 06                	push   0x6
  4492b7:	68 64 9c 47 00       	push   0x479c64
  4492bc:	50                   	push   eax
  4492bd:	e8 94 dc 01 00       	call   0x466f56
  4492c2:	e9 63 06 00 00       	jmp    0x44992a
  4492c7:	6a 04                	push   0x4
  4492c9:	e8 93 85 fb ff       	call   0x401861
  4492ce:	e9 54 06 00 00       	jmp    0x449927
  4492d3:	a1 d0 6c 4a 00       	mov    eax,ds:0x4a6cd0
  4492d8:	83 f8 01             	cmp    eax,0x1
  4492db:	74 1a                	je     0x4492f7
  4492dd:	83 f8 02             	cmp    eax,0x2
  4492e0:	75 09                	jne    0x4492eb
  4492e2:	a0 e8 6c 4a 00       	mov    al,ds:0x4a6ce8
  4492e7:	84 c0                	test   al,al
  4492e9:	75 0c                	jne    0x4492f7
  4492eb:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  4492f1:	51                   	push   ecx
  4492f2:	e9 2b 06 00 00       	jmp    0x449922
  4492f7:	68 d0 42 48 00       	push   0x4842d0
  4492fc:	e8 50 90 fb ff       	call   0x402351
  449301:	83 c4 04             	add    esp,0x4
  449304:	8d 55 9c             	lea    edx,[ebp-0x64]
  449307:	8d 4d e8             	lea    ecx,[ebp-0x18]
  44930a:	a3 60 68 48 00       	mov    ds:0x486860,eax
  44930f:	6a 01                	push   0x1
  449311:	52                   	push   edx
  449312:	51                   	push   ecx
  449313:	50                   	push   eax
  449314:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  449319:	e8 b3 88 fb ff       	call   0x401bd1
  44931e:	85 c0                	test   eax,eax
  449320:	75 0c                	jne    0x44932e
  449322:	6a 04                	push   0x4
  449324:	e8 e4 92 fb ff       	call   0x40260d
  449329:	e9 f9 05 00 00       	jmp    0x449927
  44932e:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449331:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  449335:	75 0e                	jne    0x449345
  449337:	8b 15 2c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d2c
  44933d:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  449340:	a3 68 68 48 00       	mov    ds:0x486868,eax
  449345:	8b 15 9c 40 48 00    	mov    edx,DWORD PTR ds:0x48409c
  44934b:	8b 02                	mov    eax,DWORD PTR [edx]
  44934d:	b2 ff                	mov    dl,0xff
  44934f:	38 50 2f             	cmp    BYTE PTR [eax+0x2f],dl
  449352:	0f 85 04 01 00 00    	jne    0x44945c
  449358:	8b 79 19             	mov    edi,DWORD PTR [ecx+0x19]
  44935b:	38 57 3f             	cmp    BYTE PTR [edi+0x3f],dl
  44935e:	0f 85 f6 00 00 00    	jne    0x44945a
  449364:	f6 41 1f 04          	test   BYTE PTR [ecx+0x1f],0x4
  449368:	0f 85 ec 00 00 00    	jne    0x44945a
  44936e:	83 3d 8c 40 48 00 01 	cmp    DWORD PTR ds:0x48408c,0x1
  449375:	0f 85 df 00 00 00    	jne    0x44945a
  44937b:	8d 55 e0             	lea    edx,[ebp-0x20]
  44937e:	6a 01                	push   0x1
  449380:	52                   	push   edx
  449381:	8b 15 68 68 48 00    	mov    edx,DWORD PTR ds:0x486868
  449387:	83 c0 04             	add    eax,0x4
  44938a:	52                   	push   edx
  44938b:	50                   	push   eax
  44938c:	e8 f6 90 fb        	call   0x402487
