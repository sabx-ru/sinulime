
/root/PL/PCU_old/H/mmc2/dhserver.exe:     file format pei-i386


Disassembly of section .text:

004408e0 <.text+0x3f8e0>:
  4408e0:	ff 25 90 cc 49 00    	jmp    DWORD PTR ds:0x49cc90
  4408e6:	ff 25 8c cc 49 00    	jmp    DWORD PTR ds:0x49cc8c
  4408ec:	ff 25 88 cc 49 00    	jmp    DWORD PTR ds:0x49cc88
  4408f2:	ff 25 84 cc 49 00    	jmp    DWORD PTR ds:0x49cc84
  4408f8:	ff 25 80 cc 49 00    	jmp    DWORD PTR ds:0x49cc80
  4408fe:	ff 25 7c cc 49 00    	jmp    DWORD PTR ds:0x49cc7c
  440904:	ff 25 78 cc 49 00    	jmp    DWORD PTR ds:0x49cc78
  44090a:	ff 25 74 cc 49 00    	jmp    DWORD PTR ds:0x49cc74
  440910:	ff 25 70 cc 49 00    	jmp    DWORD PTR ds:0x49cc70
  440916:	ff 25 6c cc 49 00    	jmp    DWORD PTR ds:0x49cc6c
  44091c:	ff 25 68 cc 49 00    	jmp    DWORD PTR ds:0x49cc68
  440922:	ff 25 64 cc 49 00    	jmp    DWORD PTR ds:0x49cc64
  440928:	ff 25 60 cc 49 00    	jmp    DWORD PTR ds:0x49cc60
  44092e:	ff 25 5c cc 49 00    	jmp    DWORD PTR ds:0x49cc5c
  440934:	ff 25 58 cc 49 00    	jmp    DWORD PTR ds:0x49cc58
  44093a:	ff 25 54 cc 49 00    	jmp    DWORD PTR ds:0x49cc54
  440940:	ff 25 50 cc 49 00    	jmp    DWORD PTR ds:0x49cc50
  440946:	ff 25 4c cc 49 00    	jmp    DWORD PTR ds:0x49cc4c
  44094c:	ff 25 64 d2 49 00    	jmp    DWORD PTR ds:0x49d264
  440952:	ff 25 68 d2 49 00    	jmp    DWORD PTR ds:0x49d268
  440958:	ff 25 6c d2 49 00    	jmp    DWORD PTR ds:0x49d26c
  44095e:	ff 25 70 d2 49 00    	jmp    DWORD PTR ds:0x49d270
  440964:	ff 25 74 d2 49 00    	jmp    DWORD PTR ds:0x49d274
  44096a:	ff 25 84 d2 49 00    	jmp    DWORD PTR ds:0x49d284
  440970:	ff 25 80 d2 49 00    	jmp    DWORD PTR ds:0x49d280
  440976:	ff 25 7c d2 49 00    	jmp    DWORD PTR ds:0x49d27c
  44097c:	ff 25 78 d2 49 00    	jmp    DWORD PTR ds:0x49d278
  440982:	ff 25 5c d2 49 00    	jmp    DWORD PTR ds:0x49d25c
  440988:	ff 25 58 d2 49 00    	jmp    DWORD PTR ds:0x49d258
  44098e:	ff 25 54 d2 49 00    	jmp    DWORD PTR ds:0x49d254
  440994:	ff 25 50 d2 49 00    	jmp    DWORD PTR ds:0x49d250
  44099a:	ff 25 4c d2 49 00    	jmp    DWORD PTR ds:0x49d24c
  4409a0:	ff 25 48 d2 49 00    	jmp    DWORD PTR ds:0x49d248
  4409a6:	ff 25 44 d2 49 00    	jmp    DWORD PTR ds:0x49d244
  4409ac:	ff 25 40 d2 49 00    	jmp    DWORD PTR ds:0x49d240
  4409b2:	ff 25 3c d2 49 00    	jmp    DWORD PTR ds:0x49d23c
  4409b8:	ff 25 38 d2 49 00    	jmp    DWORD PTR ds:0x49d238
  4409be:	ff 25 34 d2 49 00    	jmp    DWORD PTR ds:0x49d234
  4409c4:	ff 25 30 d2 49 00    	jmp    DWORD PTR ds:0x49d230
  4409ca:	ff 25 2c d2 49 00    	jmp    DWORD PTR ds:0x49d22c
  4409d0:	ff 25 28 d2 49 00    	jmp    DWORD PTR ds:0x49d228
  4409d6:	ff 25 24 d2 49 00    	jmp    DWORD PTR ds:0x49d224
  4409dc:	ff 25 20 d2 49 00    	jmp    DWORD PTR ds:0x49d220
  4409e2:	ff 25 1c d2 49 00    	jmp    DWORD PTR ds:0x49d21c
  4409e8:	ff 25 18 d2 49 00    	jmp    DWORD PTR ds:0x49d218
  4409ee:	ff 25 14 d2 49 00    	jmp    DWORD PTR ds:0x49d214
  4409f4:	ff 25 10 d2 49 00    	jmp    DWORD PTR ds:0x49d210
  4409fa:	ff 25 0c d2 49 00    	jmp    DWORD PTR ds:0x49d20c
  440a00:	ff 25 08 d2 49 00    	jmp    DWORD PTR ds:0x49d208
  440a06:	ff 25 04 d2 49 00    	jmp    DWORD PTR ds:0x49d204
  440a0c:	ff 25 00 d2 49 00    	jmp    DWORD PTR ds:0x49d200
  440a12:	ff 25 fc d1 49 00    	jmp    DWORD PTR ds:0x49d1fc
  440a18:	ff 25 f8 d1 49 00    	jmp    DWORD PTR ds:0x49d1f8
  440a1e:	ff                   	.byte 0xff
  440a1f:	25                   	.byte 0x25
