
/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

0043cf20 <.text+0x3bf20>:
  43cf20:	cc                   	int3
  43cf21:	cc                   	int3
  43cf22:	cc                   	int3
  43cf23:	cc                   	int3
  43cf24:	cc                   	int3
  43cf25:	cc                   	int3
  43cf26:	cc                   	int3
  43cf27:	cc                   	int3
  43cf28:	cc                   	int3
  43cf29:	cc                   	int3
  43cf2a:	cc                   	int3
  43cf2b:	cc                   	int3
  43cf2c:	cc                   	int3
  43cf2d:	cc                   	int3
  43cf2e:	cc                   	int3
  43cf2f:	cc                   	int3
  43cf30:	cc                   	int3
  43cf31:	cc                   	int3
  43cf32:	cc                   	int3
  43cf33:	cc                   	int3
  43cf34:	cc                   	int3
  43cf35:	cc                   	int3
  43cf36:	cc                   	int3
  43cf37:	cc                   	int3
  43cf38:	cc                   	int3
  43cf39:	cc                   	int3
  43cf3a:	cc                   	int3
  43cf3b:	cc                   	int3
  43cf3c:	cc                   	int3
  43cf3d:	cc                   	int3
  43cf3e:	cc                   	int3
  43cf3f:	cc                   	int3
  43cf40:	cc                   	int3
  43cf41:	cc                   	int3
  43cf42:	cc                   	int3
  43cf43:	cc                   	int3
  43cf44:	cc                   	int3
  43cf45:	cc                   	int3
  43cf46:	cc                   	int3
  43cf47:	cc                   	int3
  43cf48:	cc                   	int3
  43cf49:	cc                   	int3
  43cf4a:	cc                   	int3
  43cf4b:	cc                   	int3
  43cf4c:	cc                   	int3
  43cf4d:	cc                   	int3
  43cf4e:	cc                   	int3
  43cf4f:	cc                   	int3
  43cf50:	55                   	push   ebp
  43cf51:	8b ec                	mov    ebp,esp
  43cf53:	6a ff                	push   0xffffffff
  43cf55:	68 02 a2 46 00       	push   0x46a202
  43cf5a:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43cf60:	50                   	push   eax
  43cf61:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43cf68:	83 ec 10             	sub    esp,0x10
  43cf6b:	53                   	push   ebx
  43cf6c:	56                   	push   esi
  43cf6d:	8b f1                	mov    esi,ecx
  43cf6f:	57                   	push   edi
  43cf70:	33 ff                	xor    edi,edi
  43cf72:	89 65 f0             	mov    DWORD PTR [ebp-0x10],esp
  43cf75:	8b 46 0d             	mov    eax,DWORD PTR [esi+0xd]
  43cf78:	3b c7                	cmp    eax,edi
  43cf7a:	74 0c                	je     0x43cf88
  43cf7c:	50                   	push   eax
  43cf7d:	e8 60 4a fc ff       	call   0x4019e2
  43cf82:	83 c4 04             	add    esp,0x4
  43cf85:	89 7e 0d             	mov    DWORD PTR [esi+0xd],edi
  43cf88:	8b 45 0c             	mov    eax,DWORD PTR [ebp+0xc]
  43cf8b:	3b c7                	cmp    eax,edi
  43cf8d:	74 28                	je     0x43cfb7
  43cf8f:	50                   	push   eax
  43cf90:	e8 d2 51 fc ff       	call   0x402167
  43cf95:	83 c4 04             	add    esp,0x4
  43cf98:	3b c7                	cmp    eax,edi
  43cf9a:	89 46 0d             	mov    DWORD PTR [esi+0xd],eax
  43cf9d:	75 18                	jne    0x43cfb7
  43cf9f:	b8 46 04 0c 01       	mov    eax,0x10c0446
  43cfa4:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  43cfa7:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43cfae:	5f                   	pop    edi
  43cfaf:	5e                   	pop    esi
  43cfb0:	5b                   	pop    ebx
  43cfb1:	8b e5                	mov    esp,ebp
  43cfb3:	5d                   	pop    ebp
  43cfb4:	c2 0c 00             	ret    0xc
  43cfb7:	57                   	push   edi
  43cfb8:	57                   	push   edi
  43cfb9:	57                   	push   edi
  43cfba:	57                   	push   edi
  43cfbb:	e8 38 57 fc ff       	call   0x4026f8
  43cfc0:	39 3d 64 2a 48 00    	cmp    DWORD PTR ds:0x482a64,edi
  43cfc6:	75 18                	jne    0x43cfe0
  43cfc8:	8b 45 10             	mov    eax,DWORD PTR [ebp+0x10]
  43cfcb:	8b 4e 0d             	mov    ecx,DWORD PTR [esi+0xd]
  43cfce:	8b 55 08             	mov    edx,DWORD PTR [ebp+0x8]
  43cfd1:	50                   	push   eax
  43cfd2:	51                   	push   ecx
  43cfd3:	52                   	push   edx
  43cfd4:	8b ce                	mov    ecx,esi
  43cfd6:	e8 ac 4a fc ff       	call   0x401a87
  43cfdb:	83 f8 01             	cmp    eax,0x1
  43cfde:	75 76                	jne    0x43d056
  43cfe0:	8d 4d e4             	lea    ecx,[ebp-0x1c]
  43cfe3:	e8 5c 94 02 00       	call   0x466444
  43cfe8:	89 7d fc             	mov    DWORD PTR [ebp-0x4],edi
  43cfeb:	6a 14                	push   0x14
  43cfed:	c6 45 fc 01          	mov    BYTE PTR [ebp-0x4],0x1
  43cff1:	e8 ee 93 02 00       	call   0x4663e4
  43cff6:	8b c8                	mov    ecx,eax
  43cff8:	83 c4 04             	add    esp,0x4
  43cffb:	89 4d 0c             	mov    DWORD PTR [ebp+0xc],ecx
  43cffe:	3b cf                	cmp    ecx,edi
  43d000:	c6 45 fc 02          	mov    BYTE PTR [ebp-0x4],0x2
  43d004:	74 12                	je     0x43d018
  43d006:	8b 45 10             	mov    eax,DWORD PTR [ebp+0x10]
  43d009:	8b 56 0d             	mov    edx,DWORD PTR [esi+0xd]
  43d00c:	50                   	push   eax
  43d00d:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
  43d010:	52                   	push   edx
  43d011:	50                   	push   eax
  43d012:	56                   	push   esi
  43d013:	e8 b1 4e fc ff       	call   0x401ec9
  43d018:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  43d01f:	e8 1a 94 02 00       	call   0x46643e
  43d024:	33 c0                	xor    eax,eax
  43d026:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  43d029:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d030:	5f                   	pop    edi
  43d031:	5e                   	pop    esi
  43d032:	5b                   	pop    ebx
  43d033:	8b e5                	mov    esp,ebp
  43d035:	5d                   	pop    ebp
  43d036:	c2 0c 00             	ret    0xc
  43d039:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  43d03c:	b8 45 d0 43 00       	mov    eax,0x43d045
  43d041:	89 4d e8             	mov    DWORD PTR [ebp-0x18],ecx
  43d044:	c3                   	ret
  43d045:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  43d04c:	e8 ed 93 02 00       	call   0x46643e
  43d051:	b8 28 04 0c 01       	mov    eax,0x10c0428
  43d056:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  43d059:	5f                   	pop    edi
  43d05a:	5e                   	pop    esi
  43d05b:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d062:	5b                   	pop    ebx
  43d063:	8b e5                	mov    esp,ebp
  43d065:	5d                   	pop    ebp
  43d066:	c2 0c 00             	ret    0xc
  43d069:	90                   	nop
  43d06a:	90                   	nop
  43d06b:	90                   	nop
  43d06c:	90                   	nop
  43d06d:	90                   	nop
  43d06e:	90                   	nop
  43d06f:	90                   	nop
  43d070:	cc                   	int3
  43d071:	cc                   	int3
  43d072:	cc                   	int3
  43d073:	cc                   	int3
  43d074:	cc                   	int3
  43d075:	cc                   	int3
  43d076:	cc                   	int3
  43d077:	cc                   	int3
  43d078:	cc                   	int3
  43d079:	cc                   	int3
  43d07a:	cc                   	int3
  43d07b:	cc                   	int3
  43d07c:	cc                   	int3
  43d07d:	cc                   	int3
  43d07e:	cc                   	int3
  43d07f:	cc                   	int3
  43d080:	cc                   	int3
  43d081:	cc                   	int3
  43d082:	cc                   	int3
  43d083:	cc                   	int3
  43d084:	cc                   	int3
  43d085:	cc                   	int3
  43d086:	cc                   	int3
  43d087:	cc                   	int3
  43d088:	cc                   	int3
  43d089:	cc                   	int3
  43d08a:	cc                   	int3
  43d08b:	cc                   	int3
  43d08c:	cc                   	int3
  43d08d:	cc                   	int3
  43d08e:	cc                   	int3
  43d08f:	cc                   	int3
  43d090:	cc                   	int3
  43d091:	cc                   	int3
  43d092:	cc                   	int3
  43d093:	cc                   	int3
  43d094:	cc                   	int3
  43d095:	cc                   	int3
  43d096:	cc                   	int3
  43d097:	cc                   	int3
  43d098:	cc                   	int3
  43d099:	cc                   	int3
  43d09a:	cc                   	int3
  43d09b:	cc                   	int3
  43d09c:	cc                   	int3
  43d09d:	cc                   	int3
  43d09e:	cc                   	int3
  43d09f:	cc                   	int3
  43d0a0:	cc                   	int3
  43d0a1:	cc                   	int3
  43d0a2:	cc                   	int3
  43d0a3:	cc                   	int3
  43d0a4:	cc                   	int3
  43d0a5:	cc                   	int3
  43d0a6:	cc                   	int3
  43d0a7:	cc                   	int3
  43d0a8:	cc                   	int3
  43d0a9:	cc                   	int3
  43d0aa:	cc                   	int3
  43d0ab:	cc                   	int3
  43d0ac:	cc                   	int3
  43d0ad:	cc                   	int3
  43d0ae:	cc                   	int3
  43d0af:	cc                   	int3
  43d0b0:	cc                   	int3
  43d0b1:	cc                   	int3
  43d0b2:	cc                   	int3
  43d0b3:	cc                   	int3
  43d0b4:	cc                   	int3
  43d0b5:	cc                   	int3
  43d0b6:	cc                   	int3
  43d0b7:	cc                   	int3
  43d0b8:	cc                   	int3
  43d0b9:	cc                   	int3
  43d0ba:	cc                   	int3
  43d0bb:	cc                   	int3
  43d0bc:	cc                   	int3
  43d0bd:	cc                   	int3
  43d0be:	cc                   	int3
  43d0bf:	cc                   	int3
  43d0c0:	51                   	push   ecx
  43d0c1:	53                   	push   ebx
  43d0c2:	8b 5c 24 0c          	mov    ebx,DWORD PTR [esp+0xc]
  43d0c6:	55                   	push   ebp
  43d0c7:	56                   	push   esi
  43d0c8:	85 db                	test   ebx,ebx
  43d0ca:	57                   	push   edi
  43d0cb:	8b f1                	mov    esi,ecx
  43d0cd:	75 04                	jne    0x43d0d3
  43d0cf:	33 ed                	xor    ebp,ebp
  43d0d1:	eb 0f                	jmp    0x43d0e2
  43d0d3:	8b fb                	mov    edi,ebx
  43d0d5:	83 c9 ff             	or     ecx,0xffffffff
  43d0d8:	33 c0                	xor    eax,eax
  43d0da:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  43d0dc:	f7 d1                	not    ecx
  43d0de:	49                   	dec    ecx
  43d0df:	8b e9                	mov    ebp,ecx
  43d0e1:	45                   	inc    ebp
  43d0e2:	8b 4c 24 20          	mov    ecx,DWORD PTR [esp+0x20]
  43d0e6:	8b 56 0d             	mov    edx,DWORD PTR [esi+0xd]
  43d0e9:	8d 44 24 10          	lea    eax,[esp+0x10]
  43d0ed:	8d 7e 04             	lea    edi,[esi+0x4]
  43d0f0:	50                   	push   eax
  43d0f1:	8b 46 09             	mov    eax,DWORD PTR [esi+0x9]
  43d0f4:	57                   	push   edi
  43d0f5:	51                   	push   ecx
  43d0f6:	8b 0d 44 2c 48 00    	mov    ecx,DWORD PTR ds:0x482c44
  43d0fc:	6a 01                	push   0x1
  43d0fe:	52                   	push   edx
  43d0ff:	50                   	push   eax
  43d100:	55                   	push   ebp
  43d101:	53                   	push   ebx
  43d102:	51                   	push   ecx
  43d103:	e8 b5 54 fc ff       	call   0x4025bd
  43d108:	89 44 24 3c          	mov    DWORD PTR [esp+0x3c],eax
  43d10c:	a0 10 6d 4a 00       	mov    al,ds:0x4a6d10
  43d111:	83 c4 24             	add    esp,0x24
  43d114:	a8 02                	test   al,0x2
  43d116:	74 30                	je     0x43d148
  43d118:	e8 09 55 fc ff       	call   0x402626
  43d11d:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  43d121:	8b 0f                	mov    ecx,DWORD PTR [edi]
  43d123:	50                   	push   eax
  43d124:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  43d128:	52                   	push   edx
  43d129:	8b 54 24 28          	mov    edx,DWORD PTR [esp+0x28]
  43d12d:	50                   	push   eax
  43d12e:	8b 46 0d             	mov    eax,DWORD PTR [esi+0xd]
  43d131:	51                   	push   ecx
  43d132:	8b 4e 09             	mov    ecx,DWORD PTR [esi+0x9]
  43d135:	52                   	push   edx
  43d136:	50                   	push   eax
  43d137:	51                   	push   ecx
  43d138:	55                   	push   ebp
  43d139:	53                   	push   ebx
  43d13a:	56                   	push   esi
  43d13b:	68 e8 a9 47 00       	push   0x47a9e8
  43d140:	e8 ae 46 fc ff       	call   0x4017f3
  43d145:	83 c4 2c             	add    esp,0x2c
  43d148:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  43d14c:	85 c0                	test   eax,eax
  43d14e:	75 11                	jne    0x43d161
  43d150:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  43d154:	5f                   	pop    edi
  43d155:	5e                   	pop    esi
  43d156:	5d                   	pop    ebp
  43d157:	0d 00 00 0c 01       	or     eax,0x10c0000
  43d15c:	5b                   	pop    ebx
  43d15d:	59                   	pop    ecx
  43d15e:	c2 0c 00             	ret    0xc
  43d161:	8b 17                	mov    edx,DWORD PTR [edi]
  43d163:	8b 46 09             	mov    eax,DWORD PTR [esi+0x9]
  43d166:	56                   	push   esi
  43d167:	52                   	push   edx
  43d168:	50                   	push   eax
  43d169:	e8 2a 9e 02 00       	call   0x466f98
  43d16e:	85 c0                	test   eax,eax
  43d170:	75 48                	jne    0x43d1ba
  43d172:	8b 0f                	mov    ecx,DWORD PTR [edi]
  43d174:	8b 56 09             	mov    edx,DWORD PTR [esi+0x9]
  43d177:	a1 44 2c 48 00       	mov    eax,ds:0x482c44
  43d17c:	51                   	push   ecx
  43d17d:	52                   	push   edx
  43d17e:	50                   	push   eax
  43d17f:	e8 0e 9e 02 00       	call   0x466f92
  43d184:	f6 05 10 6d 4a 00 02 	test   BYTE PTR ds:0x4a6d10,0x2
  43d18b:	74 15                	je     0x43d1a2
  43d18d:	8b 0f                	mov    ecx,DWORD PTR [edi]
  43d18f:	8b 56 09             	mov    edx,DWORD PTR [esi+0x9]
  43d192:	51                   	push   ecx
  43d193:	52                   	push   edx
  43d194:	56                   	push   esi
  43d195:	68 bc a9 47 00       	push   0x47a9bc
  43d19a:	e8 54 46 fc ff       	call   0x4017f3
  43d19f:	83 c4 10             	add    esp,0x10
  43d1a2:	a1 44 2c 48 00       	mov    eax,ds:0x482c44
  43d1a7:	50                   	push   eax
  43d1a8:	e8 df 9d 02 00       	call   0x466f8c
  43d1ad:	5f                   	pop    edi
  43d1ae:	5e                   	pop    esi
  43d1af:	5d                   	pop    ebp
  43d1b0:	0d 00 00 0c 01       	or     eax,0x10c0000
  43d1b5:	5b                   	pop    ebx
  43d1b6:	59                   	pop    ecx
  43d1b7:	c2 0c 00             	ret    0xc
  43d1ba:	5f                   	pop    edi
  43d1bb:	5e                   	pop    esi
  43d1bc:	5d                   	pop    ebp
  43d1bd:	33 c0                	xor    eax,eax
  43d1bf:	5b                   	pop    ebx
  43d1c0:	59                   	pop    ecx
  43d1c1:	c2 0c 00             	ret    0xc
  43d1c4:	90                   	nop
  43d1c5:	90                   	nop
  43d1c6:	90                   	nop
  43d1c7:	90                   	nop
  43d1c8:	90                   	nop
  43d1c9:	90                   	nop
  43d1ca:	90                   	nop
  43d1cb:	90                   	nop
  43d1cc:	90                   	nop
  43d1cd:	90                   	nop
  43d1ce:	90                   	nop
  43d1cf:	90                   	nop
  43d1d0:	cc                   	int3
  43d1d1:	cc                   	int3
  43d1d2:	cc                   	int3
  43d1d3:	cc                   	int3
  43d1d4:	cc                   	int3
  43d1d5:	cc                   	int3
  43d1d6:	cc                   	int3
  43d1d7:	cc                   	int3
  43d1d8:	cc                   	int3
  43d1d9:	cc                   	int3
  43d1da:	cc                   	int3
  43d1db:	cc                   	int3
  43d1dc:	cc                   	int3
  43d1dd:	cc                   	int3
  43d1de:	cc                   	int3
  43d1df:	cc                   	int3
  43d1e0:	cc                   	int3
  43d1e1:	cc                   	int3
  43d1e2:	cc                   	int3
  43d1e3:	cc                   	int3
  43d1e4:	cc                   	int3
  43d1e5:	cc                   	int3
  43d1e6:	cc                   	int3
  43d1e7:	cc                   	int3
  43d1e8:	cc                   	int3
  43d1e9:	cc                   	int3
  43d1ea:	cc                   	int3
  43d1eb:	cc                   	int3
  43d1ec:	cc                   	int3
  43d1ed:	cc                   	int3
  43d1ee:	cc                   	int3
  43d1ef:	cc                   	int3
  43d1f0:	cc                   	int3
  43d1f1:	cc                   	int3
  43d1f2:	cc                   	int3
  43d1f3:	cc                   	int3
  43d1f4:	cc                   	int3
  43d1f5:	cc                   	int3
  43d1f6:	cc                   	int3
  43d1f7:	cc                   	int3
  43d1f8:	cc                   	int3
  43d1f9:	cc                   	int3
  43d1fa:	cc                   	int3
  43d1fb:	cc                   	int3
  43d1fc:	cc                   	int3
  43d1fd:	cc                   	int3
  43d1fe:	cc                   	int3
  43d1ff:	cc                   	int3
  43d200:	cc                   	int3
  43d201:	cc                   	int3
  43d202:	cc                   	int3
  43d203:	cc                   	int3
  43d204:	cc                   	int3
  43d205:	cc                   	int3
  43d206:	cc                   	int3
  43d207:	cc                   	int3
  43d208:	cc                   	int3
  43d209:	cc                   	int3
  43d20a:	cc                   	int3
  43d20b:	cc                   	int3
  43d20c:	cc                   	int3
  43d20d:	cc                   	int3
  43d20e:	cc                   	int3
  43d20f:	cc                   	int3
  43d210:	cc                   	int3
  43d211:	cc                   	int3
  43d212:	cc                   	int3
  43d213:	cc                   	int3
  43d214:	cc                   	int3
  43d215:	cc                   	int3
  43d216:	cc                   	int3
  43d217:	cc                   	int3
  43d218:	cc                   	int3
  43d219:	cc                   	int3
  43d21a:	cc                   	int3
  43d21b:	cc                   	int3
  43d21c:	cc                   	int3
  43d21d:	cc                   	int3
  43d21e:	cc                   	int3
  43d21f:	cc                   	int3
  43d220:	a1 64 2a 48 00       	mov    eax,ds:0x482a64
  43d225:	56                   	push   esi
  43d226:	85 c0                	test   eax,eax
  43d228:	74 40                	je     0x43d26a
  43d22a:	a1 5c 2a 48 00       	mov    eax,ds:0x482a5c
  43d22f:	8b 70 08             	mov    esi,DWORD PTR [eax+0x8]
  43d232:	8b 4e 08             	mov    ecx,DWORD PTR [esi+0x8]
  43d235:	8b 56 0c             	mov    edx,DWORD PTR [esi+0xc]
  43d238:	8b 41 f8             	mov    eax,DWORD PTR [ecx-0x8]
  43d23b:	f7 d8                	neg    eax
  43d23d:	1b c0                	sbb    eax,eax
  43d23f:	23 c1                	and    eax,ecx
  43d241:	8b 4e 10             	mov    ecx,DWORD PTR [esi+0x10]
  43d244:	51                   	push   ecx
  43d245:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
  43d248:	52                   	push   edx
  43d249:	50                   	push   eax
  43d24a:	e8 38 48 fc ff       	call   0x401a87
  43d24f:	83 f8 01             	cmp    eax,0x1
  43d252:	74 16                	je     0x43d26a
  43d254:	85 f6                	test   esi,esi
  43d256:	74 09                	je     0x43d261
  43d258:	8b 06                	mov    eax,DWORD PTR [esi]
  43d25a:	6a 01                	push   0x1
  43d25c:	8b ce                	mov    ecx,esi
  43d25e:	ff 50 04             	call   DWORD PTR [eax+0x4]
  43d261:	a1 64 2a 48 00       	mov    eax,ds:0x482a64
  43d266:	85 c0                	test   eax,eax
  43d268:	75 c0                	jne    0x43d22a
  43d26a:	5e                   	pop    esi
  43d26b:	c2 10 00             	ret    0x10
  43d26e:	90                   	nop
  43d26f:	90                   	nop
  43d270:	cc                   	int3
  43d271:	cc                   	int3
  43d272:	cc                   	int3
  43d273:	cc                   	int3
  43d274:	cc                   	int3
  43d275:	cc                   	int3
  43d276:	cc                   	int3
  43d277:	cc                   	int3
  43d278:	cc                   	int3
  43d279:	cc                   	int3
  43d27a:	cc                   	int3
  43d27b:	cc                   	int3
  43d27c:	cc                   	int3
  43d27d:	cc                   	int3
  43d27e:	cc                   	int3
  43d27f:	cc                   	int3
  43d280:	cc                   	int3
  43d281:	cc                   	int3
  43d282:	cc                   	int3
  43d283:	cc                   	int3
  43d284:	cc                   	int3
  43d285:	cc                   	int3
  43d286:	cc                   	int3
  43d287:	cc                   	int3
  43d288:	cc                   	int3
  43d289:	cc                   	int3
  43d28a:	cc                   	int3
  43d28b:	cc                   	int3
  43d28c:	cc                   	int3
  43d28d:	cc                   	int3
  43d28e:	cc                   	int3
  43d28f:	cc                   	int3
  43d290:	6a ff                	push   0xffffffff
  43d292:	68 33 a2 46 00       	push   0x46a233
  43d297:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43d29d:	50                   	push   eax
  43d29e:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43d2a5:	51                   	push   ecx
  43d2a6:	56                   	push   esi
  43d2a7:	8b f1                	mov    esi,ecx
  43d2a9:	57                   	push   edi
  43d2aa:	89 74 24 08          	mov    DWORD PTR [esp+0x8],esi
  43d2ae:	c7 06 c8 ed 46 00    	mov    DWORD PTR [esi],0x46edc8
  43d2b4:	8d 7e 08             	lea    edi,[esi+0x8]
  43d2b7:	c7 44 24 14 00 00 00 	mov    DWORD PTR [esp+0x14],0x0
  43d2be:	00 
  43d2bf:	8b cf                	mov    ecx,edi
  43d2c1:	e8 06 91 02 00       	call   0x4663cc
  43d2c6:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  43d2ca:	c6 44 24 14 01       	mov    BYTE PTR [esp+0x14],0x1
  43d2cf:	89 46 04             	mov    DWORD PTR [esi+0x4],eax
  43d2d2:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  43d2d6:	85 c0                	test   eax,eax
  43d2d8:	c7 06 94 ee 46 00    	mov    DWORD PTR [esi],0x46ee94
  43d2de:	74 08                	je     0x43d2e8
  43d2e0:	50                   	push   eax
  43d2e1:	8b cf                	mov    ecx,edi
  43d2e3:	e8 08 91 02 00       	call   0x4663f0
  43d2e8:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  43d2ec:	8b 54 24 28          	mov    edx,DWORD PTR [esp+0x28]
  43d2f0:	89 4e 0c             	mov    DWORD PTR [esi+0xc],ecx
  43d2f3:	56                   	push   esi
  43d2f4:	b9 58 2a 48 00       	mov    ecx,0x482a58
  43d2f9:	89 56 10             	mov    DWORD PTR [esi+0x10],edx
  43d2fc:	e8 25 91 02 00       	call   0x466426
  43d301:	a1 50 2a 48 00       	mov    eax,ds:0x482a50
  43d306:	85 c0                	test   eax,eax
  43d308:	75 16                	jne    0x43d320
  43d30a:	68 f8 26 40 00       	push   0x4026f8
  43d30f:	6a 64                	push   0x64
  43d311:	6a 00                	push   0x0
  43d313:	6a 00                	push   0x0
  43d315:	ff 15 48 63 6c 00    	call   DWORD PTR ds:0x6c6348
  43d31b:	a3 50 2a 48 00       	mov    ds:0x482a50,eax
  43d320:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  43d324:	8b c6                	mov    eax,esi
  43d326:	5f                   	pop    edi
  43d327:	5e                   	pop    esi
  43d328:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d32f:	83 c4 10             	add    esp,0x10
  43d332:	c2 10 00             	ret    0x10
  43d335:	90                   	nop
  43d336:	90                   	nop
  43d337:	90                   	nop
  43d338:	90                   	nop
  43d339:	90                   	nop
  43d33a:	90                   	nop
  43d33b:	90                   	nop
  43d33c:	90                   	nop
  43d33d:	90                   	nop
  43d33e:	90                   	nop
  43d33f:	90                   	nop
  43d340:	cc                   	int3
  43d341:	cc                   	int3
  43d342:	cc                   	int3
  43d343:	cc                   	int3
  43d344:	cc                   	int3
  43d345:	cc                   	int3
  43d346:	cc                   	int3
  43d347:	cc                   	int3
  43d348:	cc                   	int3
  43d349:	cc                   	int3
  43d34a:	cc                   	int3
  43d34b:	cc                   	int3
  43d34c:	cc                   	int3
  43d34d:	cc                   	int3
  43d34e:	cc                   	int3
  43d34f:	cc                   	int3
  43d350:	cc                   	int3
  43d351:	cc                   	int3
  43d352:	cc                   	int3
  43d353:	cc                   	int3
  43d354:	cc                   	int3
  43d355:	cc                   	int3
  43d356:	cc                   	int3
  43d357:	cc                   	int3
  43d358:	cc                   	int3
  43d359:	cc                   	int3
  43d35a:	cc                   	int3
  43d35b:	cc                   	int3
  43d35c:	cc                   	int3
  43d35d:	cc                   	int3
  43d35e:	cc                   	int3
  43d35f:	cc                   	int3
  43d360:	cc                   	int3
  43d361:	cc                   	int3
  43d362:	cc                   	int3
  43d363:	cc                   	int3
  43d364:	cc                   	int3
  43d365:	cc                   	int3
  43d366:	cc                   	int3
  43d367:	cc                   	int3
  43d368:	cc                   	int3
  43d369:	cc                   	int3
  43d36a:	cc                   	int3
  43d36b:	cc                   	int3
  43d36c:	cc                   	int3
  43d36d:	cc                   	int3
  43d36e:	cc                   	int3
  43d36f:	cc                   	int3
  43d370:	56                   	push   esi
  43d371:	8b f1                	mov    esi,ecx
  43d373:	e8 a1 41 fc ff       	call   0x401519
  43d378:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  43d37d:	74 09                	je     0x43d388
  43d37f:	56                   	push   esi
  43d380:	e8 4d 90 02 00       	call   0x4663d2
  43d385:	83 c4 04             	add    esp,0x4
  43d388:	8b c6                	mov    eax,esi
  43d38a:	5e                   	pop    esi
  43d38b:	c2 04 00             	ret    0x4
  43d38e:	90                   	nop
  43d38f:	90                   	nop
  43d390:	cc                   	int3
  43d391:	cc                   	int3
  43d392:	cc                   	int3
  43d393:	cc                   	int3
  43d394:	cc                   	int3
  43d395:	cc                   	int3
  43d396:	cc                   	int3
  43d397:	cc                   	int3
  43d398:	cc                   	int3
  43d399:	cc                   	int3
  43d39a:	cc                   	int3
  43d39b:	cc                   	int3
  43d39c:	cc                   	int3
  43d39d:	cc                   	int3
  43d39e:	cc                   	int3
  43d39f:	cc                   	int3
  43d3a0:	6a ff                	push   0xffffffff
  43d3a2:	68 58 a2 46 00       	push   0x46a258
  43d3a7:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43d3ad:	50                   	push   eax
  43d3ae:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43d3b5:	51                   	push   ecx
  43d3b6:	56                   	push   esi
  43d3b7:	8b f1                	mov    esi,ecx
  43d3b9:	89 74 24 04          	mov    DWORD PTR [esp+0x4],esi
  43d3bd:	c7 06 94 ee 46 00    	mov    DWORD PTR [esi],0x46ee94
  43d3c3:	a1 64 2a 48 00       	mov    eax,ds:0x482a64
  43d3c8:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  43d3cf:	00 
  43d3d0:	83 f8 01             	cmp    eax,0x1
  43d3d3:	75 12                	jne    0x43d3e7
  43d3d5:	a1 50 2a 48 00       	mov    eax,ds:0x482a50
  43d3da:	85 c0                	test   eax,eax
  43d3dc:	74 09                	je     0x43d3e7
  43d3de:	50                   	push   eax
  43d3df:	6a 00                	push   0x0
  43d3e1:	ff 15 44 63 6c 00    	call   DWORD PTR ds:0x6c6344
  43d3e7:	8d 4e 08             	lea    ecx,[esi+0x8]
  43d3ea:	e8 d1 8f 02 00       	call   0x4663c0
  43d3ef:	8b 4c 24 08          	mov    ecx,DWORD PTR [esp+0x8]
  43d3f3:	c7 06 3c e0 46 00    	mov    DWORD PTR [esi],0x46e03c
  43d3f9:	5e                   	pop    esi
  43d3fa:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d401:	83 c4 10             	add    esp,0x10
  43d404:	c3                   	ret
  43d405:	90                   	nop
  43d406:	90                   	nop
  43d407:	90                   	nop
  43d408:	90                   	nop
  43d409:	90                   	nop
  43d40a:	90                   	nop
  43d40b:	90                   	nop
  43d40c:	90                   	nop
  43d40d:	90                   	nop
  43d40e:	90                   	nop
  43d40f:	90                   	nop
  43d410:	cc                   	int3
  43d411:	cc                   	int3
  43d412:	cc                   	int3
  43d413:	cc                   	int3
  43d414:	cc                   	int3
  43d415:	cc                   	int3
  43d416:	cc                   	int3
  43d417:	cc                   	int3
  43d418:	cc                   	int3
  43d419:	cc                   	int3
  43d41a:	cc                   	int3
  43d41b:	cc                   	int3
  43d41c:	cc                   	int3
  43d41d:	cc                   	int3
  43d41e:	cc                   	int3
  43d41f:	cc                   	int3
  43d420:	cc                   	int3
  43d421:	cc                   	int3
  43d422:	cc                   	int3
  43d423:	cc                   	int3
  43d424:	cc                   	int3
  43d425:	cc                   	int3
  43d426:	cc                   	int3
  43d427:	cc                   	int3
  43d428:	cc                   	int3
  43d429:	cc                   	int3
  43d42a:	cc                   	int3
  43d42b:	cc                   	int3
  43d42c:	cc                   	int3
  43d42d:	cc                   	int3
  43d42e:	cc                   	int3
  43d42f:	cc                   	int3
  43d430:	56                   	push   esi
  43d431:	8b 35 5c 2a 48 00    	mov    esi,DWORD PTR ds:0x482a5c
  43d437:	85 f6                	test   esi,esi
  43d439:	74 21                	je     0x43d45c
  43d43b:	57                   	push   edi
  43d43c:	8b 7c 24 0c          	mov    edi,DWORD PTR [esp+0xc]
  43d440:	8b c6                	mov    eax,esi
  43d442:	8b 36                	mov    esi,DWORD PTR [esi]
  43d444:	8b 48 08             	mov    ecx,DWORD PTR [eax+0x8]
  43d447:	39 79 04             	cmp    DWORD PTR [ecx+0x4],edi
  43d44a:	75 0b                	jne    0x43d457
  43d44c:	85 c9                	test   ecx,ecx
  43d44e:	74 07                	je     0x43d457
  43d450:	8b 01                	mov    eax,DWORD PTR [ecx]
  43d452:	6a 01                	push   0x1
  43d454:	ff 50 04             	call   DWORD PTR [eax+0x4]
  43d457:	85 f6                	test   esi,esi
  43d459:	75 e5                	jne    0x43d440
  43d45b:	5f                   	pop    edi
  43d45c:	5e                   	pop    esi
  43d45d:	c3                   	ret
  43d45e:	90                   	nop
  43d45f:	90                   	nop
  43d460:	cc                   	int3
  43d461:	cc                   	int3
  43d462:	cc                   	int3
  43d463:	cc                   	int3
  43d464:	cc                   	int3
  43d465:	cc                   	int3
  43d466:	cc                   	int3
  43d467:	cc                   	int3
  43d468:	cc                   	int3
  43d469:	cc                   	int3
  43d46a:	cc                   	int3
  43d46b:	cc                   	int3
  43d46c:	cc                   	int3
  43d46d:	cc                   	int3
  43d46e:	cc                   	int3
  43d46f:	cc                   	int3
  43d470:	83 ec 0c             	sub    esp,0xc
  43d473:	56                   	push   esi
  43d474:	57                   	push   edi
  43d475:	8b 7c 24 18          	mov    edi,DWORD PTR [esp+0x18]
  43d479:	8b f1                	mov    esi,ecx
  43d47b:	8a 07                	mov    al,BYTE PTR [edi]
  43d47d:	3c 4e                	cmp    al,0x4e
  43d47f:	74 2e                	je     0x43d4af
  43d481:	84 c0                	test   al,al
  43d483:	74 2a                	je     0x43d4af
  43d485:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  43d489:	83 f8 02             	cmp    eax,0x2
  43d48c:	50                   	push   eax
  43d48d:	72 18                	jb     0x43d4a7
  43d48f:	8d 44 24 0c          	lea    eax,[esp+0xc]
  43d493:	68 58 aa 47 00       	push   0x47aa58
  43d498:	50                   	push   eax
  43d499:	ff 15 7c 61 6c 00    	call   DWORD PTR ds:0x6c617c
  43d49f:	83 c4 0c             	add    esp,0xc
  43d4a2:	8d 4c 24 08          	lea    ecx,[esp+0x8]
  43d4a6:	51                   	push   ecx
  43d4a7:	57                   	push   edi
  43d4a8:	8b ce                	mov    ecx,esi
  43d4aa:	e8 d1 3d fc ff       	call   0x401280
  43d4af:	5f                   	pop    edi
  43d4b0:	5e                   	pop    esi
  43d4b1:	83 c4 0c             	add    esp,0xc
  43d4b4:	c2 08 00             	ret    0x8
  43d4b7:	90                   	nop
  43d4b8:	90                   	nop
  43d4b9:	90                   	nop
  43d4ba:	90                   	nop
  43d4bb:	90                   	nop
  43d4bc:	90                   	nop
  43d4bd:	90                   	nop
  43d4be:	90                   	nop
  43d4bf:	90                   	nop
  43d4c0:	cc                   	int3
  43d4c1:	cc                   	int3
  43d4c2:	cc                   	int3
  43d4c3:	cc                   	int3
  43d4c4:	cc                   	int3
  43d4c5:	cc                   	int3
  43d4c6:	cc                   	int3
  43d4c7:	cc                   	int3
  43d4c8:	cc                   	int3
  43d4c9:	cc                   	int3
  43d4ca:	cc                   	int3
  43d4cb:	cc                   	int3
  43d4cc:	cc                   	int3
  43d4cd:	cc                   	int3
  43d4ce:	cc                   	int3
  43d4cf:	cc                   	int3
  43d4d0:	cc                   	int3
  43d4d1:	cc                   	int3
  43d4d2:	cc                   	int3
  43d4d3:	cc                   	int3
  43d4d4:	cc                   	int3
  43d4d5:	cc                   	int3
  43d4d6:	cc                   	int3
  43d4d7:	cc                   	int3
  43d4d8:	cc                   	int3
  43d4d9:	cc                   	int3
  43d4da:	cc                   	int3
  43d4db:	cc                   	int3
  43d4dc:	cc                   	int3
  43d4dd:	cc                   	int3
  43d4de:	cc                   	int3
  43d4df:	cc                   	int3
  43d4e0:	55                   	push   ebp
  43d4e1:	8b ec                	mov    ebp,esp
  43d4e3:	6a ff                	push   0xffffffff
  43d4e5:	68 82 a2 46 00       	push   0x46a282
  43d4ea:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43d4f0:	50                   	push   eax
  43d4f1:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43d4f8:	81 ec f0 00 00 00    	sub    esp,0xf0
  43d4fe:	53                   	push   ebx
  43d4ff:	8b d9                	mov    ebx,ecx
  43d501:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  43d504:	56                   	push   esi
  43d505:	57                   	push   edi
  43d506:	8a 01                	mov    al,BYTE PTR [ecx]
  43d508:	89 65 f0             	mov    DWORD PTR [ebp-0x10],esp
  43d50b:	3c 41                	cmp    al,0x41
  43d50d:	74 08                	je     0x43d517
  43d50f:	3c 53                	cmp    al,0x53
  43d511:	0f 85 ec 00 00 00    	jne    0x43d603
  43d517:	8b 7d 0c             	mov    edi,DWORD PTR [ebp+0xc]
  43d51a:	83 ff 01             	cmp    edi,0x1
  43d51d:	74 10                	je     0x43d52f
  43d51f:	8a 43 34             	mov    al,BYTE PTR [ebx+0x34]
  43d522:	a8 03                	test   al,0x3
  43d524:	74 35                	je     0x43d55b
  43d526:	a8 04                	test   al,0x4
  43d528:	75 31                	jne    0x43d55b
  43d52a:	24 fa                	and    al,0xfa
  43d52c:	88 43 34             	mov    BYTE PTR [ebx+0x34],al
  43d52f:	8b 01                	mov    eax,DWORD PTR [ecx]
  43d531:	66 8b 49 04          	mov    cx,WORD PTR [ecx+0x4]
  43d535:	89 85 04 ff ff ff    	mov    DWORD PTR [ebp-0xfc],eax
  43d53b:	8b c7                	mov    eax,edi
  43d53d:	83 e8 00             	sub    eax,0x0
  43d540:	66 89 8d 08 ff ff ff 	mov    WORD PTR [ebp-0xf8],cx
  43d547:	74 3e                	je     0x43d587
  43d549:	48                   	dec    eax
  43d54a:	74 27                	je     0x43d573
  43d54c:	c6 85 04 ff ff ff 46 	mov    BYTE PTR [ebp-0xfc],0x46
  43d553:	8d 95 0a ff ff ff    	lea    edx,[ebp-0xf6]
  43d559:	eb 3e                	jmp    0x43d599
  43d55b:	24 fa                	and    al,0xfa
  43d55d:	88 43 34             	mov    BYTE PTR [ebx+0x34],al
  43d560:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  43d563:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d56a:	5f                   	pop    edi
  43d56b:	5e                   	pop    esi
  43d56c:	5b                   	pop    ebx
  43d56d:	8b e5                	mov    esp,ebp
  43d56f:	5d                   	pop    ebp
  43d570:	c2 08 00             	ret    0x8
  43d573:	c6 85 04 ff ff ff 42 	mov    BYTE PTR [ebp-0xfc],0x42
  43d57a:	8d 95 0a ff ff ff    	lea    edx,[ebp-0xf6]
  43d580:	bf 5c aa 47 00       	mov    edi,0x47aa5c
  43d585:	eb 12                	jmp    0x43d599
  43d587:	c6 85 04 ff ff ff 45 	mov    BYTE PTR [ebp-0xfc],0x45
  43d58e:	8d 95 0a ff ff ff    	lea    edx,[ebp-0xf6]
  43d594:	bf 18 6e 47 00       	mov    edi,0x476e18
  43d599:	83 c9 ff             	or     ecx,0xffffffff
  43d59c:	33 c0                	xor    eax,eax
  43d59e:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  43d5a0:	f7 d1                	not    ecx
  43d5a2:	2b f9                	sub    edi,ecx
  43d5a4:	8b c1                	mov    eax,ecx
  43d5a6:	8b f7                	mov    esi,edi
  43d5a8:	8b fa                	mov    edi,edx
  43d5aa:	c1 e9 02             	shr    ecx,0x2
  43d5ad:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  43d5af:	8b c8                	mov    ecx,eax
  43d5b1:	83 e1 03             	and    ecx,0x3
  43d5b4:	f3 a4                	rep movs BYTE PTR es:[edi],BYTE PTR ds:[esi]
  43d5b6:	8d 4d e8             	lea    ecx,[ebp-0x18]
  43d5b9:	e8 86 8e 02 00       	call   0x466444
  43d5be:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  43d5c5:	6a 1f                	push   0x1f
  43d5c7:	c6 45 fc 01          	mov    BYTE PTR [ebp-0x4],0x1
  43d5cb:	e8 14 8e 02 00       	call   0x4663e4
  43d5d0:	8b c8                	mov    ecx,eax
  43d5d2:	83 c4 04             	add    esp,0x4
  43d5d5:	89 4d 08             	mov    DWORD PTR [ebp+0x8],ecx
  43d5d8:	85 c9                	test   ecx,ecx
  43d5da:	c6 45 fc 02          	mov    BYTE PTR [ebp-0x4],0x2
  43d5de:	74 17                	je     0x43d5f7
  43d5e0:	8b 43 2c             	mov    eax,DWORD PTR [ebx+0x2c]
  43d5e3:	6a 00                	push   0x0
  43d5e5:	8d 95 04 ff ff ff    	lea    edx,[ebp-0xfc]
  43d5eb:	50                   	push   eax
  43d5ec:	8b 43 30             	mov    eax,DWORD PTR [ebx+0x30]
  43d5ef:	52                   	push   edx
  43d5f0:	53                   	push   ebx
  43d5f1:	50                   	push   eax
  43d5f2:	e8 e5 3f fc ff       	call   0x4015dc
  43d5f7:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  43d5fe:	e8 3b 8e 02 00       	call   0x46643e
  43d603:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  43d606:	5f                   	pop    edi
  43d607:	5e                   	pop    esi
  43d608:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d60f:	5b                   	pop    ebx
  43d610:	8b e5                	mov    esp,ebp
  43d612:	5d                   	pop    ebp
  43d613:	c2 08 00             	ret    0x8
  43d616:	8b 4d 0c             	mov    ecx,DWORD PTR [ebp+0xc]
  43d619:	b8 f7 d5 43 00       	mov    eax,0x43d5f7
  43d61e:	89 4d ec             	mov    DWORD PTR [ebp-0x14],ecx
  43d621:	c3                   	ret
  43d622:	90                   	nop
  43d623:	90                   	nop
  43d624:	90                   	nop
  43d625:	90                   	nop
  43d626:	90                   	nop
  43d627:	90                   	nop
  43d628:	90                   	nop
  43d629:	90                   	nop
  43d62a:	90                   	nop
  43d62b:	90                   	nop
  43d62c:	90                   	nop
  43d62d:	90                   	nop
  43d62e:	90                   	nop
  43d62f:	90                   	nop
  43d630:	cc                   	int3
  43d631:	cc                   	int3
  43d632:	cc                   	int3
  43d633:	cc                   	int3
  43d634:	cc                   	int3
  43d635:	cc                   	int3
  43d636:	cc                   	int3
  43d637:	cc                   	int3
  43d638:	cc                   	int3
  43d639:	cc                   	int3
  43d63a:	cc                   	int3
  43d63b:	cc                   	int3
  43d63c:	cc                   	int3
  43d63d:	cc                   	int3
  43d63e:	cc                   	int3
  43d63f:	cc                   	int3
  43d640:	cc                   	int3
  43d641:	cc                   	int3
  43d642:	cc                   	int3
  43d643:	cc                   	int3
  43d644:	cc                   	int3
  43d645:	cc                   	int3
  43d646:	cc                   	int3
  43d647:	cc                   	int3
  43d648:	cc                   	int3
  43d649:	cc                   	int3
  43d64a:	cc                   	int3
  43d64b:	cc                   	int3
  43d64c:	cc                   	int3
  43d64d:	cc                   	int3
  43d64e:	cc                   	int3
  43d64f:	cc                   	int3
  43d650:	cc                   	int3
  43d651:	cc                   	int3
  43d652:	cc                   	int3
  43d653:	cc                   	int3
  43d654:	cc                   	int3
  43d655:	cc                   	int3
  43d656:	cc                   	int3
  43d657:	cc                   	int3
  43d658:	cc                   	int3
  43d659:	cc                   	int3
  43d65a:	cc                   	int3
  43d65b:	cc                   	int3
  43d65c:	cc                   	int3
  43d65d:	cc                   	int3
  43d65e:	cc                   	int3
  43d65f:	cc                   	int3
  43d660:	cc                   	int3
  43d661:	cc                   	int3
  43d662:	cc                   	int3
  43d663:	cc                   	int3
  43d664:	cc                   	int3
  43d665:	cc                   	int3
  43d666:	cc                   	int3
  43d667:	cc                   	int3
  43d668:	cc                   	int3
  43d669:	cc                   	int3
  43d66a:	cc                   	int3
  43d66b:	cc                   	int3
  43d66c:	cc                   	int3
  43d66d:	cc                   	int3
  43d66e:	cc                   	int3
  43d66f:	cc                   	int3
  43d670:	cc                   	int3
  43d671:	cc                   	int3
  43d672:	cc                   	int3
  43d673:	cc                   	int3
  43d674:	cc                   	int3
  43d675:	cc                   	int3
  43d676:	cc                   	int3
  43d677:	cc                   	int3
  43d678:	cc                   	int3
  43d679:	cc                   	int3
  43d67a:	cc                   	int3
  43d67b:	cc                   	int3
  43d67c:	cc                   	int3
  43d67d:	cc                   	int3
  43d67e:	cc                   	int3
  43d67f:	cc                   	int3
  43d680:	cc                   	int3
  43d681:	cc                   	int3
  43d682:	cc                   	int3
  43d683:	cc                   	int3
  43d684:	cc                   	int3
  43d685:	cc                   	int3
  43d686:	cc                   	int3
  43d687:	cc                   	int3
  43d688:	cc                   	int3
  43d689:	cc                   	int3
  43d68a:	cc                   	int3
  43d68b:	cc                   	int3
  43d68c:	cc                   	int3
  43d68d:	cc                   	int3
  43d68e:	cc                   	int3
  43d68f:	cc                   	int3
  43d690:	6a ff                	push   0xffffffff
  43d692:	68 a8 a2 46 00       	push   0x46a2a8
  43d697:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43d69d:	50                   	push   eax
  43d69e:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43d6a5:	51                   	push   ecx
  43d6a6:	56                   	push   esi
  43d6a7:	8b f1                	mov    esi,ecx
  43d6a9:	57                   	push   edi
  43d6aa:	89 74 24 08          	mov    DWORD PTR [esp+0x8],esi
  43d6ae:	e8 92 44 fc ff       	call   0x401b45
  43d6b3:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  43d6b7:	8b 4c 24 20          	mov    ecx,DWORD PTR [esp+0x20]
  43d6bb:	89 46 09             	mov    DWORD PTR [esi+0x9],eax
  43d6be:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  43d6c2:	85 c0                	test   eax,eax
  43d6c4:	c7 44 24 14 00 00 00 	mov    DWORD PTR [esp+0x14],0x0
  43d6cb:	00 
  43d6cc:	c7 06 ac ee 46 00    	mov    DWORD PTR [esi],0x46eeac
  43d6d2:	89 4e 17             	mov    DWORD PTR [esi+0x17],ecx
  43d6d5:	8d 7e 11             	lea    edi,[esi+0x11]
  43d6d8:	75 05                	jne    0x43d6df
  43d6da:	c6 07 00             	mov    BYTE PTR [edi],0x0
  43d6dd:	eb 0e                	jmp    0x43d6ed
  43d6df:	8b 08                	mov    ecx,DWORD PTR [eax]
  43d6e1:	8b d7                	mov    edx,edi
  43d6e3:	89 0a                	mov    DWORD PTR [edx],ecx
  43d6e5:	66 8b 40 04          	mov    ax,WORD PTR [eax+0x4]
  43d6e9:	66 89 42 04          	mov    WORD PTR [edx+0x4],ax
  43d6ed:	8b 4c 24 28          	mov    ecx,DWORD PTR [esp+0x28]
  43d6f1:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  43d6f5:	68 90 40 00 00       	push   0x4090
  43d6fa:	51                   	push   ecx
  43d6fb:	52                   	push   edx
  43d6fc:	8b ce                	mov    ecx,esi
  43d6fe:	e8 15 49 fc ff       	call   0x402018
  43d703:	85 c0                	test   eax,eax
  43d705:	74 0f                	je     0x43d716
  43d707:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43d70a:	50                   	push   eax
  43d70b:	57                   	push   edi
  43d70c:	e8 00 41 fc ff       	call   0x401811
  43d711:	e8 1a 8f 02 00       	call   0x466630
  43d716:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  43d71a:	c6 46 08 01          	mov    BYTE PTR [esi+0x8],0x1
  43d71e:	8b c6                	mov    eax,esi
  43d720:	5f                   	pop    edi
  43d721:	5e                   	pop    esi
  43d722:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43d729:	83 c4 10             	add    esp,0x10
  43d72c:	c2 14 00             	ret    0x14
  43d72f:	90                   	nop
  43d730:	cc                   	int3
  43d731:	cc                   	int3
  43d732:	cc                   	int3
  43d733:	cc                   	int3
  43d734:	cc                   	int3
  43d735:	cc                   	int3
  43d736:	cc                   	int3
  43d737:	cc                   	int3
  43d738:	cc                   	int3
  43d739:	cc                   	int3
  43d73a:	cc                   	int3
  43d73b:	cc                   	int3
  43d73c:	cc                   	int3
  43d73d:	cc                   	int3
  43d73e:	cc                   	int3
  43d73f:	cc                   	int3
  43d740:	cc                   	int3
  43d741:	cc                   	int3
  43d742:	cc                   	int3
  43d743:	cc                   	int3
  43d744:	cc                   	int3
  43d745:	cc                   	int3
  43d746:	cc                   	int3
  43d747:	cc                   	int3
  43d748:	cc                   	int3
  43d749:	cc                   	int3
  43d74a:	cc                   	int3
  43d74b:	cc                   	int3
  43d74c:	cc                   	int3
  43d74d:	cc                   	int3
  43d74e:	cc                   	int3
  43d74f:	cc                   	int3
  43d750:	cc                   	int3
  43d751:	cc                   	int3
  43d752:	cc                   	int3
  43d753:	cc                   	int3
  43d754:	cc                   	int3
  43d755:	cc                   	int3
  43d756:	cc                   	int3
  43d757:	cc                   	int3
  43d758:	cc                   	int3
  43d759:	cc                   	int3
  43d75a:	cc                   	int3
  43d75b:	cc                   	int3
  43d75c:	cc                   	int3
  43d75d:	cc                   	int3
  43d75e:	cc                   	int3
  43d75f:	cc                   	int3
  43d760:	56                   	push   esi
  43d761:	8b f1                	mov    esi,ecx
  43d763:	e8 30 3c fc ff       	call   0x401398
  43d768:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  43d76d:	74 09                	je     0x43d778
  43d76f:	56                   	push   esi
  43d770:	e8 5d 8c 02 00       	call   0x4663d2
  43d775:	83 c4 04             	add    esp,0x4
  43d778:	8b c6                	mov    eax,esi
  43d77a:	5e                   	pop    esi
  43d77b:	c2 04 00             	ret    0x4
  43d77e:	90                   	nop
  43d77f:	90                   	nop
  43d780:	cc                   	int3
  43d781:	cc                   	int3
  43d782:	cc                   	int3
  43d783:	cc                   	int3
  43d784:	cc                   	int3
  43d785:	cc                   	int3
  43d786:	cc                   	int3
  43d787:	cc                   	int3
  43d788:	cc                   	int3
  43d789:	cc                   	int3
  43d78a:	cc                   	int3
  43d78b:	cc                   	int3
  43d78c:	cc                   	int3
  43d78d:	cc                   	int3
  43d78e:	cc                   	int3
  43d78f:	cc                   	int3
  43d790:	e9 7b 41 fc ff       	jmp    0x401910
  43d795:	90                   	nop
  43d796:	90                   	nop
  43d797:	90                   	nop
  43d798:	90                   	nop
  43d799:	90                   	nop
  43d79a:	90                   	nop
  43d79b:	90                   	nop
  43d79c:	90                   	nop
  43d79d:	90                   	nop
  43d79e:	90                   	nop
  43d79f:	90                   	nop
  43d7a0:	cc                   	int3
  43d7a1:	cc                   	int3
  43d7a2:	cc                   	int3
  43d7a3:	cc                   	int3
  43d7a4:	cc                   	int3
  43d7a5:	cc                   	int3
  43d7a6:	cc                   	int3
  43d7a7:	cc                   	int3
  43d7a8:	cc                   	int3
  43d7a9:	cc                   	int3
  43d7aa:	cc                   	int3
  43d7ab:	cc                   	int3
  43d7ac:	cc                   	int3
  43d7ad:	cc                   	int3
  43d7ae:	cc                   	int3
  43d7af:	cc                   	int3
  43d7b0:	81 ec dc 00 00 00    	sub    esp,0xdc
  43d7b6:	56                   	push   esi
  43d7b7:	8b f1                	mov    esi,ecx
  43d7b9:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [esp+0xf0]
  43d7c0:	57                   	push   edi
  43d7c1:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  43d7c4:	3b c1                	cmp    eax,ecx
  43d7c6:	0f 85 20 01 00 00    	jne    0x43d8ec
  43d7cc:	33 c0                	xor    eax,eax
  43d7ce:	c7 46 04 00 00 00 00 	mov    DWORD PTR [esi+0x4],0x0
  43d7d5:	8a 46 08             	mov    al,BYTE PTR [esi+0x8]
  43d7d8:	48                   	dec    eax
  43d7d9:	0f 84 84 00 00 00    	je     0x43d863
  43d7df:	83 e8 61             	sub    eax,0x61
  43d7e2:	0f 85 04 01 00 00    	jne    0x43d8ec
  43d7e8:	8b 84 24 e8 00 00 00 	mov    eax,DWORD PTR [esp+0xe8]
  43d7ef:	85 c0                	test   eax,eax
  43d7f1:	74 43                	je     0x43d836
  43d7f3:	6a 00                	push   0x0
  43d7f5:	8d 4c 24 0c          	lea    ecx,[esp+0xc]
  43d7f9:	68 dc 00 00 00       	push   0xdc
  43d7fe:	51                   	push   ecx
  43d7ff:	50                   	push   eax
  43d800:	e8 1b 97 02 00       	call   0x466f20
  43d805:	85 c0                	test   eax,eax
  43d807:	74 2d                	je     0x43d836
  43d809:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  43d80d:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43d810:	8d 46 11             	lea    eax,[esi+0x11]
  43d813:	52                   	push   edx
  43d814:	50                   	push   eax
  43d815:	e8 f7 3f fc ff       	call   0x401811
  43d81a:	85 f6                	test   esi,esi
  43d81c:	0f 84 ca 00 00 00    	je     0x43d8ec
  43d822:	8b 16                	mov    edx,DWORD PTR [esi]
  43d824:	6a 01                	push   0x1
  43d826:	8b ce                	mov    ecx,esi
  43d828:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43d82b:	5f                   	pop    edi
  43d82c:	5e                   	pop    esi
  43d82d:	81 c4 dc 00 00 00    	add    esp,0xdc
  43d833:	c2 14 00             	ret    0x14
  43d836:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43d839:	8d 46 11             	lea    eax,[esi+0x11]
  43d83c:	68 45 0e 0c 01       	push   0x10c0e45
  43d841:	50                   	push   eax
  43d842:	e8 ca 3f fc ff       	call   0x401811
  43d847:	85 f6                	test   esi,esi
  43d849:	0f 84 9d 00 00 00    	je     0x43d8ec
  43d84f:	8b 16                	mov    edx,DWORD PTR [esi]
  43d851:	6a 01                	push   0x1
  43d853:	8b ce                	mov    ecx,esi
  43d855:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43d858:	5f                   	pop    edi
  43d859:	5e                   	pop    esi
  43d85a:	81 c4 dc 00 00 00    	add    esp,0xdc
  43d860:	c2 14 00             	ret    0x14
  43d863:	8b 84 24 e8 00 00 00 	mov    eax,DWORD PTR [esp+0xe8]
  43d86a:	85 c0                	test   eax,eax
  43d86c:	74 26                	je     0x43d894
  43d86e:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43d871:	8d 46 11             	lea    eax,[esi+0x11]
  43d874:	6a 00                	push   0x0
  43d876:	50                   	push   eax
  43d877:	e8 95 3f fc ff       	call   0x401811
  43d87c:	85 f6                	test   esi,esi
  43d87e:	74 6c                	je     0x43d8ec
  43d880:	8b 16                	mov    edx,DWORD PTR [esi]
  43d882:	6a 01                	push   0x1
  43d884:	8b ce                	mov    ecx,esi
  43d886:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43d889:	5f                   	pop    edi
  43d88a:	5e                   	pop    esi
  43d88b:	81 c4 dc 00 00 00    	add    esp,0xdc
  43d891:	c2 14 00             	ret    0x14
  43d894:	0f be 46 11          	movsx  eax,BYTE PTR [esi+0x11]
  43d898:	8d 7e 11             	lea    edi,[esi+0x11]
  43d89b:	83 f8 53             	cmp    eax,0x53
  43d89e:	77 4c                	ja     0x43d8ec
  43d8a0:	33 c9                	xor    ecx,ecx
  43d8a2:	8a 88 04 d9 43 00    	mov    cl,BYTE PTR [eax+0x43d904]
  43d8a8:	ff 24 8d f8 d8 43 00 	jmp    DWORD PTR [ecx*4+0x43d8f8]
  43d8af:	68 b0 20 00 00       	push   0x20b0
  43d8b4:	68 6c a4 47 00       	push   0x47a46c
  43d8b9:	6a 00                	push   0x0
  43d8bb:	8b ce                	mov    ecx,esi
  43d8bd:	e8 56 47 fc ff       	call   0x402018
  43d8c2:	85 c0                	test   eax,eax
  43d8c4:	74 22                	je     0x43d8e8
  43d8c6:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43d8c9:	50                   	push   eax
  43d8ca:	57                   	push   edi
  43d8cb:	e8 41 3f fc ff       	call   0x401811
  43d8d0:	85 f6                	test   esi,esi
  43d8d2:	74 18                	je     0x43d8ec
  43d8d4:	8b 06                	mov    eax,DWORD PTR [esi]
  43d8d6:	6a 01                	push   0x1
  43d8d8:	8b ce                	mov    ecx,esi
  43d8da:	ff 50 04             	call   DWORD PTR [eax+0x4]
  43d8dd:	5f                   	pop    edi
  43d8de:	5e                   	pop    esi
  43d8df:	81 c4 dc 00 00 00    	add    esp,0xdc
  43d8e5:	c2 14 00             	ret    0x14
  43d8e8:	c6 46 08 62          	mov    BYTE PTR [esi+0x8],0x62
  43d8ec:	5f                   	pop    edi
  43d8ed:	5e                   	pop    esi
  43d8ee:	81 c4 dc 00 00 00    	add    esp,0xdc
  43d8f4:	c2 14 00             	ret    0x14
  43d8f7:	90                   	nop
  43d8f8:	47                   	inc    edi
  43d8f9:	d8 43 00             	fadd   DWORD PTR [ebx+0x0]
  43d8fc:	af                   	scas   eax,DWORD PTR es:[edi]
  43d8fd:	d8 43 00             	fadd   DWORD PTR [ebx+0x0]
  43d900:	ec                   	in     al,dx
  43d901:	d8 43 00             	fadd   DWORD PTR [ebx+0x0]
  43d904:	00 02                	add    BYTE PTR [edx],al
  43d906:	02 02                	add    al,BYTE PTR [edx]
  43d908:	02 02                	add    al,BYTE PTR [edx]
  43d90a:	02 02                	add    al,BYTE PTR [edx]
  43d90c:	02 02                	add    al,BYTE PTR [edx]
  43d90e:	02 02                	add    al,BYTE PTR [edx]
  43d910:	02 02                	add    al,BYTE PTR [edx]
  43d912:	02 02                	add    al,BYTE PTR [edx]
  43d914:	02 02                	add    al,BYTE PTR [edx]
  43d916:	02 02                	add    al,BYTE PTR [edx]
  43d918:	02 02                	add    al,BYTE PTR [edx]
  43d91a:	02 02                	add    al,BYTE PTR [edx]
  43d91c:	02 02                	add    al,BYTE PTR [edx]
  43d91e:	02 02                	add    al,BYTE PTR [edx]
  43d920:	02 02                	add    al,BYTE PTR [edx]
  43d922:	02 02                	add    al,BYTE PTR [edx]
  43d924:	02 02                	add    al,BYTE PTR [edx]
  43d926:	02 02                	add    al,BYTE PTR [edx]
  43d928:	02 02                	add    al,BYTE PTR [edx]
  43d92a:	02 02                	add    al,BYTE PTR [edx]
  43d92c:	02 02                	add    al,BYTE PTR [edx]
  43d92e:	02 02                	add    al,BYTE PTR [edx]
  43d930:	02 02                	add    al,BYTE PTR [edx]
  43d932:	02 02                	add    al,BYTE PTR [edx]
  43d934:	02 02                	add    al,BYTE PTR [edx]
  43d936:	02 02                	add    al,BYTE PTR [edx]
  43d938:	02 02                	add    al,BYTE PTR [edx]
  43d93a:	02 02                	add    al,BYTE PTR [edx]
  43d93c:	02 02                	add    al,BYTE PTR [edx]
  43d93e:	02 02                	add    al,BYTE PTR [edx]
  43d940:	02 02                	add    al,BYTE PTR [edx]
  43d942:	02 02                	add    al,BYTE PTR [edx]
  43d944:	02 01                	add    al,BYTE PTR [ecx]
  43d946:	02 02                	add    al,BYTE PTR [edx]
  43d948:	02 02                	add    al,BYTE PTR [edx]
  43d94a:	02 02                	add    al,BYTE PTR [edx]
  43d94c:	02 02                	add    al,BYTE PTR [edx]
  43d94e:	02 02                	add    al,BYTE PTR [edx]
  43d950:	02 02                	add    al,BYTE PTR [edx]
  43d952:	00 02                	add    BYTE PTR [edx],al
  43d954:	02 02                	add    al,BYTE PTR [edx]
  43d956:	02 01                	add    al,BYTE PTR [ecx]
  43d958:	90                   	nop
  43d959:	90                   	nop
  43d95a:	90                   	nop
  43d95b:	90                   	nop
  43d95c:	90                   	nop
  43d95d:	90                   	nop
  43d95e:	90                   	nop
  43d95f:	90                   	nop
  43d960:	cc                   	int3
  43d961:	cc                   	int3
  43d962:	cc                   	int3
  43d963:	cc                   	int3
  43d964:	cc                   	int3
  43d965:	cc                   	int3
  43d966:	cc                   	int3
  43d967:	cc                   	int3
  43d968:	cc                   	int3
  43d969:	cc                   	int3
  43d96a:	cc                   	int3
  43d96b:	cc                   	int3
  43d96c:	cc                   	int3
  43d96d:	cc                   	int3
  43d96e:	cc                   	int3
  43d96f:	cc                   	int3
  43d970:	cc                   	int3
  43d971:	cc                   	int3
  43d972:	cc                   	int3
  43d973:	cc                   	int3
  43d974:	cc                   	int3
  43d975:	cc                   	int3
  43d976:	cc                   	int3
  43d977:	cc                   	int3
  43d978:	cc                   	int3
  43d979:	cc                   	int3
  43d97a:	cc                   	int3
  43d97b:	cc                   	int3
  43d97c:	cc                   	int3
  43d97d:	cc                   	int3
  43d97e:	cc                   	int3
  43d97f:	cc                   	int3
  43d980:	cc                   	int3
  43d981:	cc                   	int3
  43d982:	cc                   	int3
  43d983:	cc                   	int3
  43d984:	cc                   	int3
  43d985:	cc                   	int3
  43d986:	cc                   	int3
  43d987:	cc                   	int3
  43d988:	cc                   	int3
  43d989:	cc                   	int3
  43d98a:	cc                   	int3
  43d98b:	cc                   	int3
  43d98c:	cc                   	int3
  43d98d:	cc                   	int3
  43d98e:	cc                   	int3
  43d98f:	cc                   	int3
  43d990:	cc                   	int3
  43d991:	cc                   	int3
  43d992:	cc                   	int3
  43d993:	cc                   	int3
  43d994:	cc                   	int3
  43d995:	cc                   	int3
  43d996:	cc                   	int3
  43d997:	cc                   	int3
  43d998:	cc                   	int3
  43d999:	cc                   	int3
  43d99a:	cc                   	int3
  43d99b:	cc                   	int3
  43d99c:	cc                   	int3
  43d99d:	cc                   	int3
  43d99e:	cc                   	int3
  43d99f:	cc                   	int3
  43d9a0:	cc                   	int3
  43d9a1:	cc                   	int3
  43d9a2:	cc                   	int3
  43d9a3:	cc                   	int3
  43d9a4:	cc                   	int3
  43d9a5:	cc                   	int3
  43d9a6:	cc                   	int3
  43d9a7:	cc                   	int3
  43d9a8:	cc                   	int3
  43d9a9:	cc                   	int3
  43d9aa:	cc                   	int3
  43d9ab:	cc                   	int3
  43d9ac:	cc                   	int3
  43d9ad:	cc                   	int3
  43d9ae:	cc                   	int3
  43d9af:	cc                   	int3
  43d9b0:	cc                   	int3
  43d9b1:	cc                   	int3
  43d9b2:	cc                   	int3
  43d9b3:	cc                   	int3
  43d9b4:	cc                   	int3
  43d9b5:	cc                   	int3
  43d9b6:	cc                   	int3
  43d9b7:	cc                   	int3
  43d9b8:	cc                   	int3
  43d9b9:	cc                   	int3
  43d9ba:	cc                   	int3
  43d9bb:	cc                   	int3
  43d9bc:	cc                   	int3
  43d9bd:	cc                   	int3
  43d9be:	cc                   	int3
  43d9bf:	cc                   	int3
  43d9c0:	cc                   	int3
  43d9c1:	cc                   	int3
  43d9c2:	cc                   	int3
  43d9c3:	cc                   	int3
  43d9c4:	cc                   	int3
  43d9c5:	cc                   	int3
  43d9c6:	cc                   	int3
  43d9c7:	cc                   	int3
  43d9c8:	cc                   	int3
  43d9c9:	cc                   	int3
  43d9ca:	cc                   	int3
  43d9cb:	cc                   	int3
  43d9cc:	cc                   	int3
  43d9cd:	cc                   	int3
  43d9ce:	cc                   	int3
  43d9cf:	cc                   	int3
  43d9d0:	6a ff                	push   0xffffffff
  43d9d2:	68 c8 a2 46 00       	push   0x46a2c8
  43d9d7:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43d9dd:	50                   	push   eax
  43d9de:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43d9e5:	51                   	push   ecx
  43d9e6:	56                   	push   esi
  43d9e7:	8b f1                	mov    esi,ecx
  43d9e9:	57                   	push   edi
  43d9ea:	89 74 24 08          	mov    DWORD PTR [esp+0x8],esi
  43d9ee:	e8 52 41 fc ff       	call   0x401b45
  43d9f3:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  43d9f7:	8b 4c 24 20          	mov    ecx,DWORD PTR [esp+0x20]
  43d9fb:	8b 54 24 28          	mov    edx,DWORD PTR [esp+0x28]
  43d9ff:	8d 7e 11             	lea    edi,[esi+0x11]
  43da02:	89 46 09             	mov    DWORD PTR [esi+0x9],eax
  43da05:	c7 06 c8 ee 46 00    	mov    DWORD PTR [esi],0x46eec8
  43da0b:	89 4e 17             	mov    DWORD PTR [esi+0x17],ecx
  43da0e:	8b 0a                	mov    ecx,DWORD PTR [edx]
  43da10:	8b c7                	mov    eax,edi
  43da12:	68 50 40 00 00       	push   0x4050
  43da17:	6a 00                	push   0x0
  43da19:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  43da20:	00 
  43da21:	89 08                	mov    DWORD PTR [eax],ecx
  43da23:	66 8b 52 04          	mov    dx,WORD PTR [edx+0x4]
  43da27:	8b ce                	mov    ecx,esi
  43da29:	66 89 50 04          	mov    WORD PTR [eax+0x4],dx
  43da2d:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  43da31:	50                   	push   eax
  43da32:	e8 e1 45 fc ff       	call   0x402018
  43da37:	85 c0                	test   eax,eax
  43da39:	74 0f                	je     0x43da4a
  43da3b:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43da3e:	50                   	push   eax
  43da3f:	57                   	push   edi
  43da40:	e8 cc 3d fc ff       	call   0x401811
  43da45:	e8 e6 8b 02 00       	call   0x466630
  43da4a:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  43da4e:	c6 46 08 01          	mov    BYTE PTR [esi+0x8],0x1
  43da52:	8b c6                	mov    eax,esi
  43da54:	5f                   	pop    edi
  43da55:	5e                   	pop    esi
  43da56:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43da5d:	83 c4 10             	add    esp,0x10
  43da60:	c2 10 00             	ret    0x10
  43da63:	90                   	nop
  43da64:	90                   	nop
  43da65:	90                   	nop
  43da66:	90                   	nop
  43da67:	90                   	nop
  43da68:	90                   	nop
  43da69:	90                   	nop
  43da6a:	90                   	nop
  43da6b:	90                   	nop
  43da6c:	90                   	nop
  43da6d:	90                   	nop
  43da6e:	90                   	nop
  43da6f:	90                   	nop
  43da70:	cc                   	int3
  43da71:	cc                   	int3
  43da72:	cc                   	int3
  43da73:	cc                   	int3
  43da74:	cc                   	int3
  43da75:	cc                   	int3
  43da76:	cc                   	int3
  43da77:	cc                   	int3
  43da78:	cc                   	int3
  43da79:	cc                   	int3
  43da7a:	cc                   	int3
  43da7b:	cc                   	int3
  43da7c:	cc                   	int3
  43da7d:	cc                   	int3
  43da7e:	cc                   	int3
  43da7f:	cc                   	int3
  43da80:	cc                   	int3
  43da81:	cc                   	int3
  43da82:	cc                   	int3
  43da83:	cc                   	int3
  43da84:	cc                   	int3
  43da85:	cc                   	int3
  43da86:	cc                   	int3
  43da87:	cc                   	int3
  43da88:	cc                   	int3
  43da89:	cc                   	int3
  43da8a:	cc                   	int3
  43da8b:	cc                   	int3
  43da8c:	cc                   	int3
  43da8d:	cc                   	int3
  43da8e:	cc                   	int3
  43da8f:	cc                   	int3
  43da90:	cc                   	int3
  43da91:	cc                   	int3
  43da92:	cc                   	int3
  43da93:	cc                   	int3
  43da94:	cc                   	int3
  43da95:	cc                   	int3
  43da96:	cc                   	int3
  43da97:	cc                   	int3
  43da98:	cc                   	int3
  43da99:	cc                   	int3
  43da9a:	cc                   	int3
  43da9b:	cc                   	int3
  43da9c:	cc                   	int3
  43da9d:	cc                   	int3
  43da9e:	cc                   	int3
  43da9f:	cc                   	int3
  43daa0:	56                   	push   esi
  43daa1:	8b f1                	mov    esi,ecx
  43daa3:	e8 d9 4a fc ff       	call   0x402581
  43daa8:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  43daad:	74 09                	je     0x43dab8
  43daaf:	56                   	push   esi
  43dab0:	e8 1d 89 02 00       	call   0x4663d2
  43dab5:	83 c4 04             	add    esp,0x4
  43dab8:	8b c6                	mov    eax,esi
  43daba:	5e                   	pop    esi
  43dabb:	c2 04 00             	ret    0x4
  43dabe:	90                   	nop
  43dabf:	90                   	nop
  43dac0:	cc                   	int3
  43dac1:	cc                   	int3
  43dac2:	cc                   	int3
  43dac3:	cc                   	int3
  43dac4:	cc                   	int3
  43dac5:	cc                   	int3
  43dac6:	cc                   	int3
  43dac7:	cc                   	int3
  43dac8:	cc                   	int3
  43dac9:	cc                   	int3
  43daca:	cc                   	int3
  43dacb:	cc                   	int3
  43dacc:	cc                   	int3
  43dacd:	cc                   	int3
  43dace:	cc                   	int3
  43dacf:	cc                   	int3
  43dad0:	e9 3b 3e fc ff       	jmp    0x401910
  43dad5:	90                   	nop
  43dad6:	90                   	nop
  43dad7:	90                   	nop
  43dad8:	90                   	nop
  43dad9:	90                   	nop
  43dada:	90                   	nop
  43dadb:	90                   	nop
  43dadc:	90                   	nop
  43dadd:	90                   	nop
  43dade:	90                   	nop
  43dadf:	90                   	nop
  43dae0:	cc                   	int3
  43dae1:	cc                   	int3
  43dae2:	cc                   	int3
  43dae3:	cc                   	int3
  43dae4:	cc                   	int3
  43dae5:	cc                   	int3
  43dae6:	cc                   	int3
  43dae7:	cc                   	int3
  43dae8:	cc                   	int3
  43dae9:	cc                   	int3
  43daea:	cc                   	int3
  43daeb:	cc                   	int3
  43daec:	cc                   	int3
  43daed:	cc                   	int3
  43daee:	cc                   	int3
  43daef:	cc                   	int3
  43daf0:	81 ec dc 00 00 00    	sub    esp,0xdc
  43daf6:	56                   	push   esi
  43daf7:	8b f1                	mov    esi,ecx
  43daf9:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [esp+0xf0]
  43db00:	57                   	push   edi
  43db01:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  43db04:	3b c1                	cmp    eax,ecx
  43db06:	0f 85 3e 01 00 00    	jne    0x43dc4a
  43db0c:	33 c0                	xor    eax,eax
  43db0e:	c7 46 04 00 00 00 00 	mov    DWORD PTR [esi+0x4],0x0
  43db15:	8a 46 08             	mov    al,BYTE PTR [esi+0x8]
  43db18:	48                   	dec    eax
  43db19:	0f 84 84 00 00 00    	je     0x43dba3
  43db1f:	83 e8 61             	sub    eax,0x61
  43db22:	0f 85 22 01 00 00    	jne    0x43dc4a
  43db28:	8b 84 24 e8 00 00 00 	mov    eax,DWORD PTR [esp+0xe8]
  43db2f:	85 c0                	test   eax,eax
  43db31:	74 43                	je     0x43db76
  43db33:	6a 00                	push   0x0
  43db35:	8d 4c 24 0c          	lea    ecx,[esp+0xc]
  43db39:	68 dc 00 00 00       	push   0xdc
  43db3e:	51                   	push   ecx
  43db3f:	50                   	push   eax
  43db40:	e8 db 93 02 00       	call   0x466f20
  43db45:	85 c0                	test   eax,eax
  43db47:	74 2d                	je     0x43db76
  43db49:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  43db4d:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43db50:	8d 46 11             	lea    eax,[esi+0x11]
  43db53:	52                   	push   edx
  43db54:	50                   	push   eax
  43db55:	e8 b7 3c fc ff       	call   0x401811
  43db5a:	85 f6                	test   esi,esi
  43db5c:	0f 84 e8 00 00 00    	je     0x43dc4a
  43db62:	8b 16                	mov    edx,DWORD PTR [esi]
  43db64:	6a 01                	push   0x1
  43db66:	8b ce                	mov    ecx,esi
  43db68:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43db6b:	5f                   	pop    edi
  43db6c:	5e                   	pop    esi
  43db6d:	81 c4 dc 00 00 00    	add    esp,0xdc
  43db73:	c2 14 00             	ret    0x14
  43db76:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43db79:	8d 46 11             	lea    eax,[esi+0x11]
  43db7c:	68 45 0e 0c 01       	push   0x10c0e45
  43db81:	50                   	push   eax
  43db82:	e8 8a 3c fc ff       	call   0x401811
  43db87:	85 f6                	test   esi,esi
  43db89:	0f 84 bb 00 00 00    	je     0x43dc4a
  43db8f:	8b 16                	mov    edx,DWORD PTR [esi]
  43db91:	6a 01                	push   0x1
  43db93:	8b ce                	mov    ecx,esi
  43db95:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43db98:	5f                   	pop    edi
  43db99:	5e                   	pop    esi
  43db9a:	81 c4 dc 00 00 00    	add    esp,0xdc
  43dba0:	c2 14 00             	ret    0x14
  43dba3:	8b 84 24 e8 00 00 00 	mov    eax,DWORD PTR [esp+0xe8]
  43dbaa:	85 c0                	test   eax,eax
  43dbac:	74 2a                	je     0x43dbd8
  43dbae:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43dbb1:	8d 46 11             	lea    eax,[esi+0x11]
  43dbb4:	6a 00                	push   0x0
  43dbb6:	50                   	push   eax
  43dbb7:	e8 55 3c fc ff       	call   0x401811
  43dbbc:	85 f6                	test   esi,esi
  43dbbe:	0f 84 86 00 00 00    	je     0x43dc4a
  43dbc4:	8b 16                	mov    edx,DWORD PTR [esi]
  43dbc6:	6a 01                	push   0x1
  43dbc8:	8b ce                	mov    ecx,esi
  43dbca:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43dbcd:	5f                   	pop    edi
  43dbce:	5e                   	pop    esi
  43dbcf:	81 c4 dc 00 00 00    	add    esp,0xdc
  43dbd5:	c2 14 00             	ret    0x14
  43dbd8:	8a 46 11             	mov    al,BYTE PTR [esi+0x11]
  43dbdb:	8d 7e 11             	lea    edi,[esi+0x11]
  43dbde:	3c 41                	cmp    al,0x41
  43dbe0:	74 2b                	je     0x43dc0d
  43dbe2:	3c 4e                	cmp    al,0x4e
  43dbe4:	74 0f                	je     0x43dbf5
  43dbe6:	3c 53                	cmp    al,0x53
  43dbe8:	74 23                	je     0x43dc0d
  43dbea:	5f                   	pop    edi
  43dbeb:	5e                   	pop    esi
  43dbec:	81 c4 dc 00 00 00    	add    esp,0xdc
  43dbf2:	c2 14 00             	ret    0x14
  43dbf5:	85 f6                	test   esi,esi
  43dbf7:	74 51                	je     0x43dc4a
  43dbf9:	8b 06                	mov    eax,DWORD PTR [esi]
  43dbfb:	6a 01                	push   0x1
  43dbfd:	8b ce                	mov    ecx,esi
  43dbff:	ff 50 04             	call   DWORD PTR [eax+0x4]
  43dc02:	5f                   	pop    edi
  43dc03:	5e                   	pop    esi
  43dc04:	81 c4 dc 00 00 00    	add    esp,0xdc
  43dc0a:	c2 14 00             	ret    0x14
  43dc0d:	68 b0 20 00 00       	push   0x20b0
  43dc12:	68 6c a4 47 00       	push   0x47a46c
  43dc17:	6a 00                	push   0x0
  43dc19:	8b ce                	mov    ecx,esi
  43dc1b:	e8 f8 43 fc ff       	call   0x402018
  43dc20:	85 c0                	test   eax,eax
  43dc22:	74 22                	je     0x43dc46
  43dc24:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43dc27:	50                   	push   eax
  43dc28:	57                   	push   edi
  43dc29:	e8 e3 3b fc ff       	call   0x401811
  43dc2e:	85 f6                	test   esi,esi
  43dc30:	74 18                	je     0x43dc4a
  43dc32:	8b 16                	mov    edx,DWORD PTR [esi]
  43dc34:	6a 01                	push   0x1
  43dc36:	8b ce                	mov    ecx,esi
  43dc38:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43dc3b:	5f                   	pop    edi
  43dc3c:	5e                   	pop    esi
  43dc3d:	81 c4 dc 00 00 00    	add    esp,0xdc
  43dc43:	c2 14 00             	ret    0x14
  43dc46:	c6 46 08 62          	mov    BYTE PTR [esi+0x8],0x62
  43dc4a:	5f                   	pop    edi
  43dc4b:	5e                   	pop    esi
  43dc4c:	81 c4 dc 00 00 00    	add    esp,0xdc
  43dc52:	c2 14 00             	ret    0x14
  43dc55:	90                   	nop
  43dc56:	90                   	nop
  43dc57:	90                   	nop
  43dc58:	90                   	nop
  43dc59:	90                   	nop
  43dc5a:	90                   	nop
  43dc5b:	90                   	nop
  43dc5c:	90                   	nop
  43dc5d:	90                   	nop
  43dc5e:	90                   	nop
  43dc5f:	90                   	nop
  43dc60:	cc                   	int3
  43dc61:	cc                   	int3
  43dc62:	cc                   	int3
  43dc63:	cc                   	int3
  43dc64:	cc                   	int3
  43dc65:	cc                   	int3
  43dc66:	cc                   	int3
  43dc67:	cc                   	int3
  43dc68:	cc                   	int3
  43dc69:	cc                   	int3
  43dc6a:	cc                   	int3
  43dc6b:	cc                   	int3
  43dc6c:	cc                   	int3
  43dc6d:	cc                   	int3
  43dc6e:	cc                   	int3
  43dc6f:	cc                   	int3
  43dc70:	cc                   	int3
  43dc71:	cc                   	int3
  43dc72:	cc                   	int3
  43dc73:	cc                   	int3
  43dc74:	cc                   	int3
  43dc75:	cc                   	int3
  43dc76:	cc                   	int3
  43dc77:	cc                   	int3
  43dc78:	cc                   	int3
  43dc79:	cc                   	int3
  43dc7a:	cc                   	int3
  43dc7b:	cc                   	int3
  43dc7c:	cc                   	int3
  43dc7d:	cc                   	int3
  43dc7e:	cc                   	int3
  43dc7f:	cc                   	int3
  43dc80:	cc                   	int3
  43dc81:	cc                   	int3
  43dc82:	cc                   	int3
  43dc83:	cc                   	int3
  43dc84:	cc                   	int3
  43dc85:	cc                   	int3
  43dc86:	cc                   	int3
  43dc87:	cc                   	int3
  43dc88:	cc                   	int3
  43dc89:	cc                   	int3
  43dc8a:	cc                   	int3
  43dc8b:	cc                   	int3
  43dc8c:	cc                   	int3
  43dc8d:	cc                   	int3
  43dc8e:	cc                   	int3
  43dc8f:	cc                   	int3
  43dc90:	cc                   	int3
  43dc91:	cc                   	int3
  43dc92:	cc                   	int3
  43dc93:	cc                   	int3
  43dc94:	cc                   	int3
  43dc95:	cc                   	int3
  43dc96:	cc                   	int3
  43dc97:	cc                   	int3
  43dc98:	cc                   	int3
  43dc99:	cc                   	int3
  43dc9a:	cc                   	int3
  43dc9b:	cc                   	int3
  43dc9c:	cc                   	int3
  43dc9d:	cc                   	int3
  43dc9e:	cc                   	int3
  43dc9f:	cc                   	int3
  43dca0:	cc                   	int3
  43dca1:	cc                   	int3
  43dca2:	cc                   	int3
  43dca3:	cc                   	int3
  43dca4:	cc                   	int3
  43dca5:	cc                   	int3
  43dca6:	cc                   	int3
  43dca7:	cc                   	int3
  43dca8:	cc                   	int3
  43dca9:	cc                   	int3
  43dcaa:	cc                   	int3
  43dcab:	cc                   	int3
  43dcac:	cc                   	int3
  43dcad:	cc                   	int3
  43dcae:	cc                   	int3
  43dcaf:	cc                   	int3
  43dcb0:	cc                   	int3
  43dcb1:	cc                   	int3
  43dcb2:	cc                   	int3
  43dcb3:	cc                   	int3
  43dcb4:	cc                   	int3
  43dcb5:	cc                   	int3
  43dcb6:	cc                   	int3
  43dcb7:	cc                   	int3
  43dcb8:	cc                   	int3
  43dcb9:	cc                   	int3
  43dcba:	cc                   	int3
  43dcbb:	cc                   	int3
  43dcbc:	cc                   	int3
  43dcbd:	cc                   	int3
  43dcbe:	cc                   	int3
  43dcbf:	cc                   	int3
  43dcc0:	6a ff                	push   0xffffffff
  43dcc2:	68 e8 a2 46 00       	push   0x46a2e8
  43dcc7:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43dccd:	50                   	push   eax
  43dcce:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43dcd5:	51                   	push   ecx
  43dcd6:	56                   	push   esi
  43dcd7:	8b f1                	mov    esi,ecx
  43dcd9:	89 74 24 04          	mov    DWORD PTR [esp+0x4],esi
  43dcdd:	e8 63 3e fc ff       	call   0x401b45
  43dce2:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  43dce6:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  43dcea:	8b 54 24 1c          	mov    edx,DWORD PTR [esp+0x1c]
  43dcee:	89 46 17             	mov    DWORD PTR [esi+0x17],eax
  43dcf1:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  43dcf5:	68 30 10 00 00       	push   0x1030
  43dcfa:	89 4e 1b             	mov    DWORD PTR [esi+0x1b],ecx
  43dcfd:	50                   	push   eax
  43dcfe:	6a 00                	push   0x0
  43dd00:	8b ce                	mov    ecx,esi
  43dd02:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  43dd09:	00 
  43dd0a:	c7 06 e4 ee 46 00    	mov    DWORD PTR [esi],0x46eee4
  43dd10:	89 56 09             	mov    DWORD PTR [esi+0x9],edx
  43dd13:	e8 00 43 fc ff       	call   0x402018
  43dd18:	85 c0                	test   eax,eax
  43dd1a:	74 16                	je     0x43dd32
  43dd1c:	50                   	push   eax
  43dd1d:	6a 00                	push   0x0
  43dd1f:	6a 00                	push   0x0
  43dd21:	6a 00                	push   0x0
  43dd23:	6a 00                	push   0x0
  43dd25:	e8 78 40 fc ff       	call   0x401da2
  43dd2a:	83 c4 14             	add    esp,0x14
  43dd2d:	e8 fe 88 02 00       	call   0x466630
  43dd32:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43dd35:	8b c6                	mov    eax,esi
  43dd37:	5e                   	pop    esi
  43dd38:	c7 41 35 01 00 00 00 	mov    DWORD PTR [ecx+0x35],0x1
  43dd3f:	8b 4c 24 04          	mov    ecx,DWORD PTR [esp+0x4]
  43dd43:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43dd4a:	83 c4 10             	add    esp,0x10
  43dd4d:	c2 10 00             	ret    0x10
  43dd50:	cc                   	int3
  43dd51:	cc                   	int3
  43dd52:	cc                   	int3
  43dd53:	cc                   	int3
  43dd54:	cc                   	int3
  43dd55:	cc                   	int3
  43dd56:	cc                   	int3
  43dd57:	cc                   	int3
  43dd58:	cc                   	int3
  43dd59:	cc                   	int3
  43dd5a:	cc                   	int3
  43dd5b:	cc                   	int3
  43dd5c:	cc                   	int3
  43dd5d:	cc                   	int3
  43dd5e:	cc                   	int3
  43dd5f:	cc                   	int3
  43dd60:	cc                   	int3
  43dd61:	cc                   	int3
  43dd62:	cc                   	int3
  43dd63:	cc                   	int3
  43dd64:	cc                   	int3
  43dd65:	cc                   	int3
  43dd66:	cc                   	int3
  43dd67:	cc                   	int3
  43dd68:	cc                   	int3
  43dd69:	cc                   	int3
  43dd6a:	cc                   	int3
  43dd6b:	cc                   	int3
  43dd6c:	cc                   	int3
  43dd6d:	cc                   	int3
  43dd6e:	cc                   	int3
  43dd6f:	cc                   	int3
  43dd70:	cc                   	int3
  43dd71:	cc                   	int3
  43dd72:	cc                   	int3
  43dd73:	cc                   	int3
  43dd74:	cc                   	int3
  43dd75:	cc                   	int3
  43dd76:	cc                   	int3
  43dd77:	cc                   	int3
  43dd78:	cc                   	int3
  43dd79:	cc                   	int3
  43dd7a:	cc                   	int3
  43dd7b:	cc                   	int3
  43dd7c:	cc                   	int3
  43dd7d:	cc                   	int3
  43dd7e:	cc                   	int3
  43dd7f:	cc                   	int3
  43dd80:	56                   	push   esi
  43dd81:	8b f1                	mov    esi,ecx
  43dd83:	e8 67 48 fc ff       	call   0x4025ef
  43dd88:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  43dd8d:	74 09                	je     0x43dd98
  43dd8f:	56                   	push   esi
  43dd90:	e8 3d 86 02 00       	call   0x4663d2
  43dd95:	83 c4 04             	add    esp,0x4
  43dd98:	8b c6                	mov    eax,esi
  43dd9a:	5e                   	pop    esi
  43dd9b:	c2 04 00             	ret    0x4
  43dd9e:	90                   	nop
  43dd9f:	90                   	nop
  43dda0:	cc                   	int3
  43dda1:	cc                   	int3
  43dda2:	cc                   	int3
  43dda3:	cc                   	int3
  43dda4:	cc                   	int3
  43dda5:	cc                   	int3
  43dda6:	cc                   	int3
  43dda7:	cc                   	int3
  43dda8:	cc                   	int3
  43dda9:	cc                   	int3
  43ddaa:	cc                   	int3
  43ddab:	cc                   	int3
  43ddac:	cc                   	int3
  43ddad:	cc                   	int3
  43ddae:	cc                   	int3
  43ddaf:	cc                   	int3
  43ddb0:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43ddb6:	6a ff                	push   0xffffffff
  43ddb8:	68 08 a3 46 00       	push   0x46a308
  43ddbd:	50                   	push   eax
  43ddbe:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43ddc5:	c7 01 e4 ee 46 00    	mov    DWORD PTR [ecx],0x46eee4
  43ddcb:	c7 44 24 08 ff ff ff 	mov    DWORD PTR [esp+0x8],0xffffffff
  43ddd2:	ff 
  43ddd3:	e8 38 3b fc ff       	call   0x401910
  43ddd8:	8b 4c 24 00          	mov    ecx,DWORD PTR [esp+0x0]
  43dddc:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43dde3:	83 c4 0c             	add    esp,0xc
  43dde6:	c3                   	ret
  43dde7:	90                   	nop
  43dde8:	90                   	nop
  43dde9:	90                   	nop
  43ddea:	90                   	nop
  43ddeb:	90                   	nop
  43ddec:	90                   	nop
  43dded:	90                   	nop
  43ddee:	90                   	nop
  43ddef:	90                   	nop
  43ddf0:	cc                   	int3
  43ddf1:	cc                   	int3
  43ddf2:	cc                   	int3
  43ddf3:	cc                   	int3
  43ddf4:	cc                   	int3
  43ddf5:	cc                   	int3
  43ddf6:	cc                   	int3
  43ddf7:	cc                   	int3
  43ddf8:	cc                   	int3
  43ddf9:	cc                   	int3
  43ddfa:	cc                   	int3
  43ddfb:	cc                   	int3
  43ddfc:	cc                   	int3
  43ddfd:	cc                   	int3
  43ddfe:	cc                   	int3
  43ddff:	cc                   	int3
  43de00:	81 ec 08 01 00 00    	sub    esp,0x108
  43de06:	53                   	push   ebx
  43de07:	55                   	push   ebp
  43de08:	56                   	push   esi
  43de09:	8b f1                	mov    esi,ecx
  43de0b:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [esp+0x124]
  43de12:	57                   	push   edi
  43de13:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  43de16:	3b c1                	cmp    eax,ecx
  43de18:	0f 85 be 01 00 00    	jne    0x43dfdc
  43de1e:	8a 46 08             	mov    al,BYTE PTR [esi+0x8]
  43de21:	c7 46 04 00 00 00 00 	mov    DWORD PTR [esi+0x4],0x0
  43de28:	84 c0                	test   al,al
  43de2a:	0f 84 88 00 00 00    	je     0x43deb8
  43de30:	3c 62                	cmp    al,0x62
  43de32:	0f 85 a4 01 00 00    	jne    0x43dfdc
  43de38:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [esp+0x11c]
  43de3f:	85 c0                	test   eax,eax
  43de41:	74 49                	je     0x43de8c
  43de43:	6a 00                	push   0x0
  43de45:	8d 4c 24 18          	lea    ecx,[esp+0x18]
  43de49:	68 dc 00 00 00       	push   0xdc
  43de4e:	51                   	push   ecx
  43de4f:	50                   	push   eax
  43de50:	e8 cb 90 02 00       	call   0x466f20
  43de55:	85 c0                	test   eax,eax
  43de57:	74 33                	je     0x43de8c
  43de59:	8d 54 24 10          	lea    edx,[esp+0x10]
  43de5d:	8d 44 24 10          	lea    eax,[esp+0x10]
  43de61:	52                   	push   edx
  43de62:	50                   	push   eax
  43de63:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  43de67:	68 a8 6d 47 00       	push   0x476da8
  43de6c:	51                   	push   ecx
  43de6d:	ff 15 50 61 6c 00    	call   DWORD PTR ds:0x6c6150
  43de73:	83 c4 10             	add    esp,0x10
  43de76:	83 f8 01             	cmp    eax,0x1
  43de79:	75 11                	jne    0x43de8c
  43de7b:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  43de7f:	8b 46 1b             	mov    eax,DWORD PTR [esi+0x1b]
  43de82:	52                   	push   edx
  43de83:	6a 00                	push   0x0
  43de85:	6a 00                	push   0x0
  43de87:	6a 00                	push   0x0
  43de89:	50                   	push   eax
  43de8a:	eb 0c                	jmp    0x43de98
  43de8c:	8b 4e 1b             	mov    ecx,DWORD PTR [esi+0x1b]
  43de8f:	6a 45                	push   0x45
  43de91:	6a 0e                	push   0xe
  43de93:	6a 09                	push   0x9
  43de95:	6a 01                	push   0x1
  43de97:	51                   	push   ecx
  43de98:	e8 05 3f fc ff       	call   0x401da2
  43de9d:	8b 56 1b             	mov    edx,DWORD PTR [esi+0x1b]
  43dea0:	83 c4 14             	add    esp,0x14
  43dea3:	52                   	push   edx
  43dea4:	e8 08 3a fc ff       	call   0x4018b1
  43dea9:	c6 46 08 63          	mov    BYTE PTR [esi+0x8],0x63
  43dead:	8b 76 17             	mov    esi,DWORD PTR [esi+0x17]
  43deb0:	83 c4 04             	add    esp,0x4
  43deb3:	e9 d9 00 00 00       	jmp    0x43df91
  43deb8:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [esp+0x11c]
  43debf:	85 c0                	test   eax,eax
  43dec1:	74 57                	je     0x43df1a
  43dec3:	8b 4e 0d             	mov    ecx,DWORD PTR [esi+0xd]
  43dec6:	8b 15 44 2c 48 00    	mov    edx,DWORD PTR ds:0x482c44
  43decc:	51                   	push   ecx
  43decd:	52                   	push   edx
  43dece:	e8 d3 3a fc ff       	call   0x4019a6
  43ded3:	8b 3d 4c 68 48 00    	mov    edi,DWORD PTR ds:0x48684c
  43ded9:	83 c4 08             	add    esp,0x8
  43dedc:	85 ff                	test   edi,edi
  43dede:	8b d8                	mov    ebx,eax
  43dee0:	74 38                	je     0x43df1a
  43dee2:	8b 2d b4 61 6c 00    	mov    ebp,DWORD PTR ds:0x6c61b4
  43dee8:	8b 4f 1c             	mov    ecx,DWORD PTR [edi+0x1c]
  43deeb:	8b 15 c0 6c 4a 00    	mov    edx,DWORD PTR ds:0x4a6cc0
  43def1:	6a 00                	push   0x0
  43def3:	8d 44 24 18          	lea    eax,[esp+0x18]
  43def7:	68 00 01 00 00       	push   0x100
  43defc:	50                   	push   eax
  43defd:	51                   	push   ecx
  43defe:	52                   	push   edx
  43deff:	e8 58 90 02 00       	call   0x466f5c
  43df04:	8d 44 24 14          	lea    eax,[esp+0x14]
  43df08:	53                   	push   ebx
  43df09:	50                   	push   eax
  43df0a:	ff d5                	call   ebp
  43df0c:	83 c4 08             	add    esp,0x8
  43df0f:	85 c0                	test   eax,eax
  43df11:	74 50                	je     0x43df63
  43df13:	8b 7f 0c             	mov    edi,DWORD PTR [edi+0xc]
  43df16:	85 ff                	test   edi,edi
  43df18:	75 ce                	jne    0x43dee8
  43df1a:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43df1d:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [esp+0x11c]
  43df24:	85 c0                	test   eax,eax
  43df26:	c7 41 35 02 00 00 00 	mov    DWORD PTR [ecx+0x35],0x2
  43df2d:	0f 85 89 00 00 00    	jne    0x43dfbc
  43df33:	68 b0 20 00 00       	push   0x20b0
  43df38:	68 6c a4 47 00       	push   0x47a46c
  43df3d:	6a 00                	push   0x0
  43df3f:	8b ce                	mov    ecx,esi
  43df41:	e8 d2 40 fc ff       	call   0x402018
  43df46:	85 c0                	test   eax,eax
  43df48:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  43df4c:	74 5d                	je     0x43dfab
  43df4e:	8b 56 1b             	mov    edx,DWORD PTR [esi+0x1b]
  43df51:	50                   	push   eax
  43df52:	6a 00                	push   0x0
  43df54:	6a 00                	push   0x0
  43df56:	6a 00                	push   0x0
  43df58:	52                   	push   edx
  43df59:	e8 44 3e fc ff       	call   0x401da2
  43df5e:	83 c4 14             	add    esp,0x14
  43df61:	eb 59                	jmp    0x43dfbc
  43df63:	85 ff                	test   edi,edi
  43df65:	74 b3                	je     0x43df1a
  43df67:	8b 46 17             	mov    eax,DWORD PTR [esi+0x17]
  43df6a:	85 c0                	test   eax,eax
  43df6c:	74 05                	je     0x43df73
  43df6e:	83 c0 04             	add    eax,0x4
  43df71:	eb 02                	jmp    0x43df75
  43df73:	33 c0                	xor    eax,eax
  43df75:	89 87 80 00 00 00    	mov    DWORD PTR [edi+0x80],eax
  43df7b:	8b 4e 1b             	mov    ecx,DWORD PTR [esi+0x1b]
  43df7e:	51                   	push   ecx
  43df7f:	e8 2d 39 fc ff       	call   0x4018b1
  43df84:	8b 56 17             	mov    edx,DWORD PTR [esi+0x17]
  43df87:	83 c4 04             	add    esp,0x4
  43df8a:	c7 42 35 03 00 00 00 	mov    DWORD PTR [edx+0x35],0x3
  43df91:	85 f6                	test   esi,esi
  43df93:	74 47                	je     0x43dfdc
  43df95:	8b 06                	mov    eax,DWORD PTR [esi]
  43df97:	6a 01                	push   0x1
  43df99:	8b ce                	mov    ecx,esi
  43df9b:	ff 50 04             	call   DWORD PTR [eax+0x4]
  43df9e:	5f                   	pop    edi
  43df9f:	5e                   	pop    esi
  43dfa0:	5d                   	pop    ebp
  43dfa1:	5b                   	pop    ebx
  43dfa2:	81 c4 08 01 00 00    	add    esp,0x108
  43dfa8:	c2 14 00             	ret    0x14
  43dfab:	c6 46 08 62          	mov    BYTE PTR [esi+0x8],0x62
  43dfaf:	5f                   	pop    edi
  43dfb0:	5e                   	pop    esi
  43dfb1:	5d                   	pop    ebp
  43dfb2:	5b                   	pop    ebx
  43dfb3:	81 c4 08 01 00 00    	add    esp,0x108
  43dfb9:	c2 14 00             	ret    0x14
  43dfbc:	8b 46 1b             	mov    eax,DWORD PTR [esi+0x1b]
  43dfbf:	50                   	push   eax
  43dfc0:	e8 ec 38 fc ff       	call   0x4018b1
  43dfc5:	c6 46 08 63          	mov    BYTE PTR [esi+0x8],0x63
  43dfc9:	8b 76 17             	mov    esi,DWORD PTR [esi+0x17]
  43dfcc:	83 c4 04             	add    esp,0x4
  43dfcf:	85 f6                	test   esi,esi
  43dfd1:	74 09                	je     0x43dfdc
  43dfd3:	8b 16                	mov    edx,DWORD PTR [esi]
  43dfd5:	6a 01                	push   0x1
  43dfd7:	8b ce                	mov    ecx,esi
  43dfd9:	ff 52 04             	call   DWORD PTR [edx+0x4]
  43dfdc:	5f                   	pop    edi
  43dfdd:	5e                   	pop    esi
  43dfde:	5d                   	pop    ebp
  43dfdf:	5b                   	pop    ebx
  43dfe0:	81 c4 08 01 00 00    	add    esp,0x108
  43dfe6:	c2 14 00             	ret    0x14
  43dfe9:	90                   	nop
  43dfea:	90                   	nop
  43dfeb:	90                   	nop
  43dfec:	90                   	nop
  43dfed:	90                   	nop
  43dfee:	90                   	nop
  43dfef:	90                   	nop
  43dff0:	cc                   	int3
  43dff1:	cc                   	int3
  43dff2:	cc                   	int3
  43dff3:	cc                   	int3
  43dff4:	cc                   	int3
  43dff5:	cc                   	int3
  43dff6:	cc                   	int3
  43dff7:	cc                   	int3
  43dff8:	cc                   	int3
  43dff9:	cc                   	int3
  43dffa:	cc                   	int3
  43dffb:	cc                   	int3
  43dffc:	cc                   	int3
  43dffd:	cc                   	int3
  43dffe:	cc                   	int3
  43dfff:	cc                   	int3
  43e000:	cc                   	int3
  43e001:	cc                   	int3
  43e002:	cc                   	int3
  43e003:	cc                   	int3
  43e004:	cc                   	int3
  43e005:	cc                   	int3
  43e006:	cc                   	int3
  43e007:	cc                   	int3
  43e008:	cc                   	int3
  43e009:	cc                   	int3
  43e00a:	cc                   	int3
  43e00b:	cc                   	int3
  43e00c:	cc                   	int3
  43e00d:	cc                   	int3
  43e00e:	cc                   	int3
  43e00f:	cc                   	int3
  43e010:	cc                   	int3
  43e011:	cc                   	int3
  43e012:	cc                   	int3
  43e013:	cc                   	int3
  43e014:	cc                   	int3
  43e015:	cc                   	int3
  43e016:	cc                   	int3
  43e017:	cc                   	int3
  43e018:	cc                   	int3
  43e019:	cc                   	int3
  43e01a:	cc                   	int3
  43e01b:	cc                   	int3
  43e01c:	cc                   	int3
  43e01d:	cc                   	int3
  43e01e:	cc                   	int3
  43e01f:	cc                   	int3
  43e020:	cc                   	int3
  43e021:	cc                   	int3
  43e022:	cc                   	int3
  43e023:	cc                   	int3
  43e024:	cc                   	int3
  43e025:	cc                   	int3
  43e026:	cc                   	int3
  43e027:	cc                   	int3
  43e028:	cc                   	int3
  43e029:	cc                   	int3
  43e02a:	cc                   	int3
  43e02b:	cc                   	int3
  43e02c:	cc                   	int3
  43e02d:	cc                   	int3
  43e02e:	cc                   	int3
  43e02f:	cc                   	int3
  43e030:	cc                   	int3
  43e031:	cc                   	int3
  43e032:	cc                   	int3
  43e033:	cc                   	int3
  43e034:	cc                   	int3
  43e035:	cc                   	int3
  43e036:	cc                   	int3
  43e037:	cc                   	int3
  43e038:	cc                   	int3
  43e039:	cc                   	int3
  43e03a:	cc                   	int3
  43e03b:	cc                   	int3
  43e03c:	cc                   	int3
  43e03d:	cc                   	int3
  43e03e:	cc                   	int3
  43e03f:	cc                   	int3
  43e040:	cc                   	int3
  43e041:	cc                   	int3
  43e042:	cc                   	int3
  43e043:	cc                   	int3
  43e044:	cc                   	int3
  43e045:	cc                   	int3
  43e046:	cc                   	int3
  43e047:	cc                   	int3
  43e048:	cc                   	int3
  43e049:	cc                   	int3
  43e04a:	cc                   	int3
  43e04b:	cc                   	int3
  43e04c:	cc                   	int3
  43e04d:	cc                   	int3
  43e04e:	cc                   	int3
  43e04f:	cc                   	int3
  43e050:	cc                   	int3
  43e051:	cc                   	int3
  43e052:	cc                   	int3
  43e053:	cc                   	int3
  43e054:	cc                   	int3
  43e055:	cc                   	int3
  43e056:	cc                   	int3
  43e057:	cc                   	int3
  43e058:	cc                   	int3
  43e059:	cc                   	int3
  43e05a:	cc                   	int3
  43e05b:	cc                   	int3
  43e05c:	cc                   	int3
  43e05d:	cc                   	int3
  43e05e:	cc                   	int3
  43e05f:	cc                   	int3
  43e060:	cc                   	int3
  43e061:	cc                   	int3
  43e062:	cc                   	int3
  43e063:	cc                   	int3
  43e064:	cc                   	int3
  43e065:	cc                   	int3
  43e066:	cc                   	int3
  43e067:	cc                   	int3
  43e068:	cc                   	int3
  43e069:	cc                   	int3
  43e06a:	cc                   	int3
  43e06b:	cc                   	int3
  43e06c:	cc                   	int3
  43e06d:	cc                   	int3
  43e06e:	cc                   	int3
  43e06f:	cc                   	int3
  43e070:	6a ff                	push   0xffffffff
  43e072:	68 28 a3 46 00       	push   0x46a328
  43e077:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  43e07d:	50                   	push   eax
  43e07e:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  43e085:	51                   	push   ecx
  43e086:	56                   	push   esi
  43e087:	8b f1                	mov    esi,ecx
  43e089:	89 74 24 04          	mov    DWORD PTR [esp+0x4],esi
  43e08d:	e8 b3 3a fc ff       	call   0x401b45
  43e092:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  43e096:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  43e09a:	8b 54 24 1c          	mov    edx,DWORD PTR [esp+0x1c]
  43e09e:	89 46 17             	mov    DWORD PTR [esi+0x17],eax
  43e0a1:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  43e0a5:	68 40 80 00 00       	push   0x8040
  43e0aa:	89 4e 1b             	mov    DWORD PTR [esi+0x1b],ecx
  43e0ad:	50                   	push   eax
  43e0ae:	6a 00                	push   0x0
  43e0b0:	8b ce                	mov    ecx,esi
  43e0b2:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  43e0b9:	00 
  43e0ba:	c7 06 00 ef 46 00    	mov    DWORD PTR [esi],0x46ef00
  43e0c0:	89 56 09             	mov    DWORD PTR [esi+0x9],edx
  43e0c3:	e8 50 3f fc ff       	call   0x402018
  43e0c8:	85 c0                	test   eax,eax
  43e0ca:	74 16                	je     0x43e0e2
  43e0cc:	50                   	push   eax
  43e0cd:	6a 00                	push   0x0
  43e0cf:	6a 00                	push   0x0
  43e0d1:	6a 00                	push   0x0
  43e0d3:	6a 00                	push   0x0
  43e0d5:	e8 c8 3c fc ff       	call   0x401da2
  43e0da:	83 c4 14             	add    esp,0x14
  43e0dd:	e8 4e 85 02 00       	call   0x466630
  43e0e2:	8b 4e 17             	mov    ecx,DWORD PTR [esi+0x17]
  43e0e5:	8b c6                	mov    eax,esi
  43e0e7:	5e                   	pop    esi
  43e0e8:	c7 41 35 04 00 00 00 	mov    DWORD PTR [ecx+0x35],0x4
  43e0ef:	8b 4c 24 04          	mov    ecx,DWORD PTR [esp+0x4]
  43e0f3:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  43e0fa:	83 c4 10             	add    esp,0x10
  43e0fd:	c2 10 00             	ret    0x10
  43e100:	cc                   	int3
  43e101:	cc                   	int3
  43e102:	cc                   	int3
  43e103:	cc                   	int3
  43e104:	cc                   	int3
  43e105:	cc                   	int3
  43e106:	cc                   	int3
  43e107:	cc                   	int3
  43e108:	cc                   	int3
  43e109:	cc                   	int3
  43e10a:	cc                   	int3
  43e10b:	cc                   	int3
  43e10c:	cc                   	int3
  43e10d:	cc                   	int3
  43e10e:	cc                   	int3
  43e10f:	cc                   	int3
  43e110:	cc                   	int3
  43e111:	cc                   	int3
  43e112:	cc                   	int3
  43e113:	cc                   	int3
  43e114:	cc                   	int3
  43e115:	cc                   	int3
  43e116:	cc                   	int3
  43e117:	cc                   	int3
  43e118:	cc                   	int3
  43e119:	cc                   	int3
  43e11a:	cc                   	int3
  43e11b:	cc                   	int3
  43e11c:	cc                   	int3
  43e11d:	cc                   	int3
  43e11e:	cc                   	int3
  43e11f:	cc                   	int3
