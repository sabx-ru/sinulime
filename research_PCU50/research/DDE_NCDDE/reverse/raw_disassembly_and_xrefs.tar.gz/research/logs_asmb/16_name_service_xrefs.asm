40a76e:	8b 4d 50             	mov    ecx,DWORD PTR [ebp+0x50]
  40a771:	83 c4 04             	add    esp,0x4
  40a774:	6a 01                	push   0x1
  40a776:	56                   	push   esi
  40a777:	e8 a4 87 ff ff       	call   0x402f20
  40a77c:	8b 13                	mov    edx,DWORD PTR [ebx]
  40a77e:	50                   	push   eax
  40a77f:	52                   	push   edx
  40a780:	e8 f9 75 02 00       	call   0x431d7e
  40a785:	68 c8 00 00 00       	push   0xc8
  40a78a:	e8 b1 44 00 00       	call   0x40ec40
  40a78f:	6a 0c                	push   0xc
  40a791:	e8 1d af 02 00       	call   0x4356b3
  40a796:	83 c4 08             	add    esp,0x8
  40a799:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  40a79d:	3b c6                	cmp    eax,esi
  40a79f:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x10
--
  40a7fe:	33 c0                	xor    eax,eax
  40a800:	89 45 58             	mov    DWORD PTR [ebp+0x58],eax
  40a803:	8b 03                	mov    eax,DWORD PTR [ebx]
  40a805:	68 ec 03 00 00       	push   0x3ec
  40a80a:	68 1c 77 45 00       	push   0x45771c
  40a80f:	50                   	push   eax
  40a810:	c6 84 24 ec 06 00 00 	mov    BYTE PTR [esp+0x6ec],0xe
  40a817:	0e 
  40a818:	e8 e9 74 02 00       	call   0x431d06
  40a81d:	8b 4d 58             	mov    ecx,DWORD PTR [ebp+0x58]
  40a820:	89 85 88 02 00 00    	mov    DWORD PTR [ebp+0x288],eax
  40a826:	e8 f5 86 ff ff       	call   0x402f20
  40a82b:	8b 4d 54             	mov    ecx,DWORD PTR [ebp+0x54]
  40a82e:	8b f0                	mov    esi,eax
  40a830:	e8 eb 86 ff ff       	call   0x402f20
  40a835:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  40a837:	6a 00                	push   0x0
  40a839:	56                   	push   esi
  40a83a:	50                   	push   eax
  40a83b:	51                   	push   ecx
  40a83c:	89 44 24 20          	mov    DWORD PTR [esp+0x20],eax
  40a840:	89 4c 24 24          	mov    DWORD PTR [esp+0x24],ecx
  40a844:	e8 f9 74 02 00       	call   0x431d42
  40a849:	8b f8                	mov    edi,eax
  40a84b:	85 ff                	test   edi,edi
  40a84d:	74 43                	je     0x40a892
  40a84f:	6a 30                	push   0x30
  40a851:	e8 5d ae 02 00       	call   0x4356b3
  40a856:	83 c4 04             	add    esp,0x4
  40a859:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40a85d:	85 c0                	test   eax,eax
--
  40a88c:	57                   	push   edi
  40a88d:	e8 d4 74 02 00       	call   0x431d66
  40a892:	33 ff                	xor    edi,edi
  40a894:	8b 03                	mov    eax,DWORD PTR [ebx]
  40a896:	68 ec 03 00 00       	push   0x3ec
  40a89b:	68 10 77 45 00       	push   0x457710
  40a8a0:	50                   	push   eax
  40a8a1:	89 7d 5c             	mov    DWORD PTR [ebp+0x5c],edi
  40a8a4:	e8 5d 74 02 00       	call   0x431d06
  40a8a9:	68 38 74 45 00       	push   0x457438
  40a8ae:	8d 94 24 fc 00 00 00 	lea    edx,[esp+0xfc]
  40a8b5:	68 00 01 00 00       	push   0x100
  40a8ba:	89 45 0c             	mov    DWORD PTR [ebp+0xc],eax
  40a8bd:	52                   	push   edx
  40a8be:	89 2d 24 cb 45 00    	mov    DWORD PTR ds:0x45cb24,ebp
  40a8c4:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  40a8c6:	68 18 74 45 00       	push   0x457418