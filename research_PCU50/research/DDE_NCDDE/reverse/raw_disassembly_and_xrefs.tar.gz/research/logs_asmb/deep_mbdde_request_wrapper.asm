
mbdde.exe:     file format pei-i386


Disassembly of section .text:

0040bd00 <.text+0xad00>:
  40bd00:	75 1c                	jne    0x40bd1e
  40bd02:	84 c9                	test   cl,cl
  40bd04:	74 14                	je     0x40bd1a
  40bd06:	8a 50 01             	mov    dl,BYTE PTR [eax+0x1]
  40bd09:	8a ca                	mov    cl,dl
  40bd0b:	3a 57 01             	cmp    dl,BYTE PTR [edi+0x1]
  40bd0e:	75 0e                	jne    0x40bd1e
  40bd10:	83 c0 02             	add    eax,0x2
  40bd13:	83 c7 02             	add    edi,0x2
  40bd16:	84 c9                	test   cl,cl
  40bd18:	75 e0                	jne    0x40bcfa
  40bd1a:	33 c0                	xor    eax,eax
  40bd1c:	eb 05                	jmp    0x40bd23
  40bd1e:	1b c0                	sbb    eax,eax
  40bd20:	83 d8 ff             	sbb    eax,0xffffffff
  40bd23:	3b c3                	cmp    eax,ebx
  40bd25:	0f 84 a5 03 00 00    	je     0x40c0d0
  40bd2b:	eb 02                	jmp    0x40bd2f
  40bd2d:	33 db                	xor    ebx,ebx
  40bd2f:	39 5c 24 14          	cmp    DWORD PTR [esp+0x14],ebx
  40bd33:	0f 84 97 03 00 00    	je     0x40c0d0
  40bd39:	6a 10                	push   0x10
  40bd3b:	e8 73 99 02 00       	call   0x4356b3
  40bd40:	83 c4 04             	add    esp,0x4
  40bd43:	3b c3                	cmp    eax,ebx
  40bd45:	74 11                	je     0x40bd58
  40bd47:	89 58 04             	mov    DWORD PTR [eax+0x4],ebx
  40bd4a:	89 58 08             	mov    DWORD PTR [eax+0x8],ebx
  40bd4d:	89 58 0c             	mov    DWORD PTR [eax+0xc],ebx
  40bd50:	c7 00 48 a9 44 00    	mov    DWORD PTR [eax],0x44a948
  40bd56:	8b d8                	mov    ebx,eax
  40bd58:	68 90 75 45 00       	push   0x457590
  40bd5d:	8d 4c 24 2c          	lea    ecx,[esp+0x2c]
  40bd61:	c6 84 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],0x45
  40bd68:	45 
  40bd69:	e8 e2 92 02 00       	call   0x435050
  40bd6e:	bf 9c a6 44 00       	mov    edi,0x44a69c
  40bd73:	89 7c 24 24          	mov    DWORD PTR [esp+0x24],edi
  40bd77:	8d 44 24 2c          	lea    eax,[esp+0x2c]
  40bd7b:	8d 4c 24 30          	lea    ecx,[esp+0x30]
  40bd7f:	f7 d8                	neg    eax
  40bd81:	1b c0                	sbb    eax,eax
  40bd83:	68 ac 75 45 00       	push   0x4575ac
  40bd88:	23 c1                	and    eax,ecx
  40bd8a:	8d 94 24 1c 02 00 00 	lea    edx,[esp+0x21c]
  40bd91:	68 00 01 00 00       	push   0x100
  40bd96:	52                   	push   edx
  40bd97:	8b 00                	mov    eax,DWORD PTR [eax]
  40bd99:	68 44 75 45 00       	push   0x457544
  40bd9e:	56                   	push   esi
  40bd9f:	50                   	push   eax
  40bda0:	c6 84 24 f8 06 00 00 	mov    BYTE PTR [esp+0x6f8],0x46
  40bda7:	46 
  40bda8:	e8 d3 3c 01 00       	call   0x41fa80
  40bdad:	83 c4 18             	add    esp,0x18
  40bdb0:	8d 4c 24 50          	lea    ecx,[esp+0x50]
  40bdb4:	68 80 75 45 00       	push   0x457580
  40bdb9:	e8 ad 93 02 00       	call   0x43516b
  40bdbe:	8d 84 24 18 02 00 00 	lea    eax,[esp+0x218]
  40bdc5:	8d 4c 24 50          	lea    ecx,[esp+0x50]
  40bdc9:	50                   	push   eax
  40bdca:	e8 ef 95 02 00       	call   0x4353be
  40bdcf:	8d 8c 24 18 02 00 00 	lea    ecx,[esp+0x218]
  40bdd6:	51                   	push   ecx
  40bdd7:	8d 4c 24 2c          	lea    ecx,[esp+0x2c]
  40bddb:	e8 de 95 02 00       	call   0x4353be
  40bde0:	8d 94 24 18 02 00 00 	lea    edx,[esp+0x218]
  40bde7:	8d 4c 24 20          	lea    ecx,[esp+0x20]
  40bdeb:	52                   	push   edx
  40bdec:	c6 84 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],0x47
  40bdf3:	47 
  40bdf4:	e8 57 92 02 00       	call   0x435050
  40bdf9:	89 7c 24 1c          	mov    DWORD PTR [esp+0x1c],edi
  40bdfd:	8d 44 24 1c          	lea    eax,[esp+0x1c]
  40be01:	8d 4c 24 20          	lea    ecx,[esp+0x20]
  40be05:	f7 d8                	neg    eax
  40be07:	1b c0                	sbb    eax,eax
  40be09:	8d 54 24 28          	lea    edx,[esp+0x28]
  40be0d:	23 c1                	and    eax,ecx
  40be0f:	8d 4c 24 24          	lea    ecx,[esp+0x24]
  40be13:	f7 d9                	neg    ecx
  40be15:	8b 00                	mov    eax,DWORD PTR [eax]
  40be17:	68 ac 75 45 00       	push   0x4575ac
  40be1c:	1b c9                	sbb    ecx,ecx
  40be1e:	68 00 01 00 00       	push   0x100
  40be23:	23 ca                	and    ecx,edx
  40be25:	8d 94 24 20 02 00 00 	lea    edx,[esp+0x220]
  40be2c:	52                   	push   edx
  40be2d:	50                   	push   eax
  40be2e:	8b 09                	mov    ecx,DWORD PTR [ecx]
  40be30:	68 88 75 45 00       	push   0x457588
  40be35:	51                   	push   ecx
  40be36:	c6 84 24 f8 06 00 00 	mov    BYTE PTR [esp+0x6f8],0x48
  40be3d:	48 
  40be3e:	e8 3d 3c 01 00       	call   0x41fa80
  40be43:	83 c4 18             	add    esp,0x18
  40be46:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  40be4a:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  40be4e:	8d 44 24 20          	lea    eax,[esp+0x20]
  40be52:	f7 d9                	neg    ecx
  40be54:	1b c9                	sbb    ecx,ecx
  40be56:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x49
  40be5d:	49 
  40be5e:	23 c8                	and    ecx,eax
  40be60:	e8 7d 91 02 00       	call   0x434fe2
  40be65:	8d 8c 24 18 02 00 00 	lea    ecx,[esp+0x218]
  40be6c:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x46
  40be73:	46 
  40be74:	51                   	push   ecx
  40be75:	8d 8c 24 80 00 00 00 	lea    ecx,[esp+0x80]
  40be7c:	e8 ea 92 02 00       	call   0x43516b
  40be81:	8b fe                	mov    edi,esi
  40be83:	83 c9 ff             	or     ecx,0xffffffff
  40be86:	33 c0                	xor    eax,eax
  40be88:	68 e0 21 00 00       	push   0x21e0
  40be8d:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  40be8f:	f7 d1                	not    ecx
  40be91:	49                   	dec    ecx
  40be92:	8d 74 0e 01          	lea    esi,[esi+ecx*1+0x1]
  40be96:	e8 18 98 02 00       	call   0x4356b3
  40be9b:	83 c4 04             	add    esp,0x4
  40be9e:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40bea2:	85 c0                	test   eax,eax
  40bea4:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x4a
  40beab:	4a 
  40beac:	74 20                	je     0x40bece
  40beae:	8d 54 24 78          	lea    edx,[esp+0x78]
  40beb2:	8d 4c 24 4c          	lea    ecx,[esp+0x4c]
  40beb6:	52                   	push   edx
  40beb7:	8d 54 24 60          	lea    edx,[esp+0x60]
  40bebb:	51                   	push   ecx
  40bebc:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  40bebf:	52                   	push   edx
  40bec0:	8b 55 48             	mov    edx,DWORD PTR [ebp+0x48]
  40bec3:	51                   	push   ecx
  40bec4:	52                   	push   edx
  40bec5:	8b c8                	mov    ecx,eax
  40bec7:	e8 a4 4c 00 00       	call   0x410b70
  40becc:	eb 02                	jmp    0x40bed0
  40bece:	33 c0                	xor    eax,eax
  40bed0:	89 43 04             	mov    DWORD PTR [ebx+0x4],eax
  40bed3:	8b 40 2c             	mov    eax,DWORD PTR [eax+0x2c]
  40bed6:	89 43 0c             	mov    DWORD PTR [ebx+0xc],eax
  40bed9:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
  40bedc:	68 ec 03 00 00       	push   0x3ec
  40bee1:	68 28 75 45 00       	push   0x457528
  40bee6:	50                   	push   eax
  40bee7:	c6 84 24 ec 06 00 00 	mov    BYTE PTR [esp+0x6ec],0x46
  40beee:	46 
  40beef:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  40bef6:	00 
  40bef7:	e8 0a 5e 02 00       	call   0x431d06
  40befc:	8b f8                	mov    edi,eax
  40befe:	85 ff                	test   edi,edi
  40bf00:	0f 84 91 00 00 00    	je     0x40bf97
  40bf06:	8b 53 0c             	mov    edx,DWORD PTR [ebx+0xc]
  40bf09:	8d 4c 24 34          	lea    ecx,[esp+0x34]
  40bf0d:	51                   	push   ecx
  40bf0e:	68 10 27 00 00       	push   0x2710
  40bf13:	68 b0 20 00 00       	push   0x20b0
  40bf18:	6a 01                	push   0x1
  40bf1a:	57                   	push   edi
  40bf1b:	52                   	push   edx
  40bf1c:	6a 00                	push   0x0
  40bf1e:	6a 00                	push   0x0
  40bf20:	e8 bb 05 00 00       	call   0x40c4e0
  40bf25:	83 c4 20             	add    esp,0x20
  40bf28:	85 c0                	test   eax,eax
  40bf2a:	74 6b                	je     0x40bf97
  40bf2c:	6a 00                	push   0x0
  40bf2e:	8d 8c 24 fc 01 00 00 	lea    ecx,[esp+0x1fc]
  40bf35:	6a 1e                	push   0x1e
  40bf37:	51                   	push   ecx
  40bf38:	50                   	push   eax
  40bf39:	e8 3a 5e 02 00       	call   0x431d78
  40bf3e:	85 c0                	test   eax,eax
  40bf40:	74 55                	je     0x40bf97
  40bf42:	8d 54 24 10          	lea    edx,[esp+0x10]
  40bf46:	8d 44 24 10          	lea    eax,[esp+0x10]
  40bf4a:	52                   	push   edx
  40bf4b:	50                   	push   eax
  40bf4c:	8d 8c 24 00 02 00 00 	lea    ecx,[esp+0x200]
  40bf53:	68 18 75 45 00       	push   0x457518
  40bf58:	51                   	push   ecx
  40bf59:	e8 03 54 01 00       	call   0x421361
  40bf5e:	83 c4 10             	add    esp,0x10
  40bf61:	83 f8 01             	cmp    eax,0x1
  40bf64:	75 31                	jne    0x40bf97
  40bf66:	a1 f8 ca 45 00       	mov    eax,ds:0x45caf8
  40bf6b:	8b 48 0c             	mov    ecx,DWORD PTR [eax+0xc]
  40bf6e:	85 c9                	test   ecx,ecx
  40bf70:	74 25                	je     0x40bf97
  40bf72:	8b 40 04             	mov    eax,DWORD PTR [eax+0x4]
  40bf75:	85 c0                	test   eax,eax
  40bf77:	74 1e                	je     0x40bf97
  40bf79:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  40bf7d:	8b c8                	mov    ecx,eax
  40bf7f:	8b 00                	mov    eax,DWORD PTR [eax]
  40bf81:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  40bf84:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  40bf87:	85 c9                	test   ecx,ecx
  40bf89:	74 08                	je     0x40bf93
  40bf8b:	3b 91 20 09 00 00    	cmp    edx,DWORD PTR [ecx+0x920]
  40bf91:	74 56                	je     0x40bfe9
  40bf93:	85 c0                	test   eax,eax
  40bf95:	75 e6                	jne    0x40bf7d
  40bf97:	83 7c 24 10 ff       	cmp    DWORD PTR [esp+0x10],0xffffffff
  40bf9c:	74 62                	je     0x40c000
  40bf9e:	68 30 09 00 00       	push   0x930
  40bfa3:	e8 0b 97 02 00       	call   0x4356b3
  40bfa8:	83 c4 04             	add    esp,0x4
  40bfab:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40bfaf:	85 c0                	test   eax,eax
  40bfb1:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x4b
  40bfb8:	4b 
  40bfb9:	74 38                	je     0x40bff3
  40bfbb:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  40bfbf:	8d 4c 24 78          	lea    ecx,[esp+0x78]
  40bfc3:	52                   	push   edx
  40bfc4:	51                   	push   ecx
  40bfc5:	8d 54 24 54          	lea    edx,[esp+0x54]
  40bfc9:	8d 4c 24 6c          	lea    ecx,[esp+0x6c]
  40bfcd:	52                   	push   edx
  40bfce:	8b 53 04             	mov    edx,DWORD PTR [ebx+0x4]
  40bfd1:	51                   	push   ecx
  40bfd2:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  40bfd5:	52                   	push   edx
  40bfd6:	8b 55 44             	mov    edx,DWORD PTR [ebp+0x44]
  40bfd9:	51                   	push   ecx
  40bfda:	8b 4d 48             	mov    ecx,DWORD PTR [ebp+0x48]
  40bfdd:	52                   	push   edx
  40bfde:	51                   	push   ecx
  40bfdf:	55                   	push   ebp
  40bfe0:	8b c8                	mov    ecx,eax
  40bfe2:	e8 29 62 00 00       	call   0x412210
  40bfe7:	eb 0c                	jmp    0x40bff5
  40bfe9:	c7 44 24 10 ff ff ff 	mov    DWORD PTR [esp+0x10],0xffffffff
  40bff0:	ff 
  40bff1:	eb 0d                	jmp    0x40c000
  40bff3:	33 c0                	xor    eax,eax
  40bff5:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x46
  40bffc:	46 
  40bffd:	89 43 08             	mov    DWORD PTR [ebx+0x8],eax
  40c000:	85 ff                	test   edi,edi
  40c002:	74 0a                	je     0x40c00e
  40c004:	8b 55 08             	mov    edx,DWORD PTR [ebp+0x8]
  40c007:	57                   	push   edi
  40c008:	52                   	push   edx
  40c009:	e8 fe 5c 02 00       	call   0x431d0c
  40c00e:	8b 0d f8 ca 45 00    	mov    ecx,DWORD PTR ds:0x45caf8
  40c014:	53                   	push   ebx
  40c015:	e8 7c 7f 02 00       	call   0x433f96
  40c01a:	8d 44 24 24          	lea    eax,[esp+0x24]
  40c01e:	8d 4c 24 28          	lea    ecx,[esp+0x28]
  40c022:	f7 d8                	neg    eax
  40c024:	1b c0                	sbb    eax,eax
  40c026:	68 ac 75 45 00       	push   0x4575ac
  40c02b:	23 c1                	and    eax,ecx
  40c02d:	8d 94 24 1c 02 00 00 	lea    edx,[esp+0x21c]
  40c034:	68 00 01 00 00       	push   0x100
  40c039:	52                   	push   edx
  40c03a:	8b 00                	mov    eax,DWORD PTR [eax]
  40c03c:	68 48 c2 45 00       	push   0x45c248
  40c041:	68 cc 76 45 00       	push   0x4576cc
  40c046:	50                   	push   eax
  40c047:	e8 34 3a 01 00       	call   0x41fa80
  40c04c:	6a 04                	push   0x4
  40c04e:	8d 84 24 34 02 00 00 	lea    eax,[esp+0x234]
  40c055:	68 c4 76 45 00       	push   0x4576c4
  40c05a:	50                   	push   eax
  40c05b:	e8 a0 58 01 00       	call   0x421900
  40c060:	83 c4 24             	add    esp,0x24
  40c063:	85 c0                	test   eax,eax
  40c065:	75 0a                	jne    0x40c071
  40c067:	8b 43 08             	mov    eax,DWORD PTR [ebx+0x8]
  40c06a:	85 c0                	test   eax,eax
  40c06c:	74 03                	je     0x40c071
  40c06e:	89 5d 20             	mov    DWORD PTR [ebp+0x20],ebx
  40c071:	8d 4c 24 24          	lea    ecx,[esp+0x24]
  40c075:	8d 54 24 28          	lea    edx,[esp+0x28]
  40c079:	f7 d9                	neg    ecx
  40c07b:	1b c9                	sbb    ecx,ecx
  40c07d:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x4c
  40c084:	4c 
  40c085:	23 ca                	and    ecx,edx
  40c087:	e8 56 8f 02 00       	call   0x434fe2
  40c08c:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x44
  40c093:	44 
  40c094:	bf 48 c2 45 00       	mov    edi,0x45c248
  40c099:	8b c6                	mov    eax,esi
  40c09b:	8a 10                	mov    dl,BYTE PTR [eax]
  40c09d:	8a 1f                	mov    bl,BYTE PTR [edi]
  40c09f:	8a ca                	mov    cl,dl
  40c0a1:	3a d3                	cmp    dl,bl
  40c0a3:	75 1e                	jne    0x40c0c3
  40c0a5:	84 c9                	test   cl,cl
  40c0a7:	74 16                	je     0x40c0bf
  40c0a9:	8a 50 01             	mov    dl,BYTE PTR [eax+0x1]
  40c0ac:	8a 5f 01             	mov    bl,BYTE PTR [edi+0x1]
  40c0af:	8a ca                	mov    cl,dl
  40c0b1:	3a d3                	cmp    dl,bl
  40c0b3:	75 0e                	jne    0x40c0c3
  40c0b5:	83 c0 02             	add    eax,0x2
  40c0b8:	83 c7 02             	add    edi,0x2
  40c0bb:	84 c9                	test   cl,cl
  40c0bd:	75 dc                	jne    0x40c09b
  40c0bf:	33 c0                	xor    eax,eax
  40c0c1:	eb 05                	jmp    0x40c0c8
  40c0c3:	1b c0                	sbb    eax,eax
  40c0c5:	83 d8 ff             	sbb    eax,0xffffffff
  40c0c8:	85 c0                	test   eax,eax
  40c0ca:	0f 85 5d fc ff ff    	jne    0x40bd2d
  40c0d0:	8d 4c 24 2c          	lea    ecx,[esp+0x2c]
  40c0d4:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x4d
  40c0db:	4d 
  40c0dc:	f7 d9                	neg    ecx
  40c0de:	1b c9                	sbb    ecx,ecx
  40c0e0:	8d 44 24 30          	lea    eax,[esp+0x30]
  40c0e4:	e9 0c 01 00 00       	jmp    0x40c1f5
  40c0e9:	6a 10                	push   0x10
  40c0eb:	e8 c3 95 02 00       	call   0x4356b3
  40c0f0:	83 c4 04             	add    esp,0x4
  40c0f3:	3b c7                	cmp    eax,edi
  40c0f5:	74 13                	je     0x40c10a
  40c0f7:	c7 00 48 a9 44 00    	mov    DWORD PTR [eax],0x44a948
  40c0fd:	89 78 04             	mov    DWORD PTR [eax+0x4],edi
  40c100:	89 78 08             	mov    DWORD PTR [eax+0x8],edi
  40c103:	89 78 0c             	mov    DWORD PTR [eax+0xc],edi
  40c106:	8b f0                	mov    esi,eax
  40c108:	eb 02                	jmp    0x40c10c
  40c10a:	33 f6                	xor    esi,esi
  40c10c:	68 48 c2 45 00       	push   0x45c248
  40c111:	8d 4c 24 24          	lea    ecx,[esp+0x24]
  40c115:	c6 84 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],0x4e
  40c11c:	4e 
  40c11d:	e8 2e 8f 02 00       	call   0x435050
  40c122:	c7 44 24 1c 9c a6 44 	mov    DWORD PTR [esp+0x1c],0x44a69c
  40c129:	00 
  40c12a:	b3 4f                	mov    bl,0x4f
  40c12c:	68 e0 21 00 00       	push   0x21e0
  40c131:	88 9c 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],bl
  40c138:	e8 76 95 02 00       	call   0x4356b3
  40c13d:	83 c4 04             	add    esp,0x4
  40c140:	89 44 24 34          	mov    DWORD PTR [esp+0x34],eax
  40c144:	3b c7                	cmp    eax,edi
  40c146:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x50
  40c14d:	50 
  40c14e:	74 20                	je     0x40c170
  40c150:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  40c154:	8d 54 24 4c          	lea    edx,[esp+0x4c]
  40c158:	51                   	push   ecx
  40c159:	8d 4c 24 60          	lea    ecx,[esp+0x60]
  40c15d:	52                   	push   edx
  40c15e:	8b 55 08             	mov    edx,DWORD PTR [ebp+0x8]
  40c161:	51                   	push   ecx
  40c162:	8b 4d 48             	mov    ecx,DWORD PTR [ebp+0x48]
  40c165:	52                   	push   edx
  40c166:	51                   	push   ecx
  40c167:	8b c8                	mov    ecx,eax
  40c169:	e8 02 4a 00 00       	call   0x410b70
  40c16e:	eb 02                	jmp    0x40c172
  40c170:	33 c0                	xor    eax,eax
  40c172:	89 46 04             	mov    DWORD PTR [esi+0x4],eax
  40c175:	8b 40 2c             	mov    eax,DWORD PTR [eax+0x2c]
  40c178:	68 30 09 00 00       	push   0x930
  40c17d:	88 9c 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],bl
  40c184:	89 46 0c             	mov    DWORD PTR [esi+0xc],eax
  40c187:	e8 27 95 02 00       	call   0x4356b3
  40c18c:	83 c4 04             	add    esp,0x4
  40c18f:	89 44 24 34          	mov    DWORD PTR [esp+0x34],eax
  40c193:	3b c7                	cmp    eax,edi
  40c195:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x51
  40c19c:	51 
  40c19d:	74 2a                	je     0x40c1c9
  40c19f:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  40c1a3:	57                   	push   edi
  40c1a4:	52                   	push   edx
  40c1a5:	8d 4c 24 54          	lea    ecx,[esp+0x54]
  40c1a9:	8d 54 24 6c          	lea    edx,[esp+0x6c]
  40c1ad:	51                   	push   ecx
  40c1ae:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
  40c1b1:	52                   	push   edx
  40c1b2:	8b 55 08             	mov    edx,DWORD PTR [ebp+0x8]
  40c1b5:	51                   	push   ecx
  40c1b6:	8b 4d 44             	mov    ecx,DWORD PTR [ebp+0x44]
  40c1b9:	52                   	push   edx
  40c1ba:	8b 55 48             	mov    edx,DWORD PTR [ebp+0x48]
  40c1bd:	51                   	push   ecx
  40c1be:	52                   	push   edx
  40c1bf:	55                   	push   ebp
  40c1c0:	8b c8                	mov    ecx,eax
  40c1c2:	e8 49 60 00 00       	call   0x412210
  40c1c7:	eb 02                	jmp    0x40c1cb
  40c1c9:	33 c0                	xor    eax,eax
  40c1cb:	89 46 08             	mov    DWORD PTR [esi+0x8],eax
  40c1ce:	8b 0d f8 ca 45 00    	mov    ecx,DWORD PTR ds:0x45caf8
  40c1d4:	56                   	push   esi
  40c1d5:	88 9c 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],bl
  40c1dc:	e8 b5 7d 02 00       	call   0x433f96
  40c1e1:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  40c1e5:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x52
  40c1ec:	52 
  40c1ed:	f7 d9                	neg    ecx
  40c1ef:	1b c9                	sbb    ecx,ecx
  40c1f1:	8d 44 24 20          	lea    eax,[esp+0x20]
  40c1f5:	23 c8                	and    ecx,eax
  40c1f7:	e8 e6 8d 02 00       	call   0x434fe2
  40c1fc:	8b 4d 60             	mov    ecx,DWORD PTR [ebp+0x60]
  40c1ff:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x1b
  40c206:	1b 
  40c207:	85 c9                	test   ecx,ecx
  40c209:	74 05                	je     0x40c210
  40c20b:	e8 50 42 00 00       	call   0x410460
  40c210:	8d 4c 24 70          	lea    ecx,[esp+0x70]
  40c214:	8d 54 24 74          	lea    edx,[esp+0x74]
  40c218:	f7 d9                	neg    ecx
  40c21a:	1b c9                	sbb    ecx,ecx
  40c21c:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x53
  40c223:	53 
  40c224:	23 ca                	and    ecx,edx
  40c226:	e8 b7 8d 02 00       	call   0x434fe2
  40c22b:	8d 4c 24 78          	lea    ecx,[esp+0x78]
  40c22f:	8d 44 24 7c          	lea    eax,[esp+0x7c]
  40c233:	f7 d9                	neg    ecx
  40c235:	1b c9                	sbb    ecx,ecx
  40c237:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x54
  40c23e:	54 
  40c23f:	23 c8                	and    ecx,eax
  40c241:	e8 9c 8d 02 00       	call   0x434fe2
  40c246:	8d 4c 24 64          	lea    ecx,[esp+0x64]
  40c24a:	8d 54 24 68          	lea    edx,[esp+0x68]
  40c24e:	f7 d9                	neg    ecx
  40c250:	1b c9                	sbb    ecx,ecx
  40c252:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x55
  40c259:	55 
  40c25a:	23 ca                	and    ecx,edx
  40c25c:	e8 81 8d 02 00       	call   0x434fe2
  40c261:	8d 8c 24 98 00 00 00 	lea    ecx,[esp+0x98]
  40c268:	8d 84 24 9c 00 00 00 	lea    eax,[esp+0x9c]
  40c26f:	f7 d9                	neg    ecx
  40c271:	1b c9                	sbb    ecx,ecx
  40c273:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x56
  40c27a:	56 
  40c27b:	23 c8                	and    ecx,eax
  40c27d:	e8 60 8d 02 00       	call   0x434fe2
  40c282:	8d 4c 24 44          	lea    ecx,[esp+0x44]
  40c286:	8d 54 24 48          	lea    edx,[esp+0x48]
  40c28a:	f7 d9                	neg    ecx
  40c28c:	1b c9                	sbb    ecx,ecx
  40c28e:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x57
  40c295:	57 
  40c296:	23 ca                	and    ecx,edx
  40c298:	e8 45 8d 02 00       	call   0x434fe2
  40c29d:	8d 4c 24 4c          	lea    ecx,[esp+0x4c]
  40c2a1:	8d 44 24 50          	lea    eax,[esp+0x50]
  40c2a5:	f7 d9                	neg    ecx
  40c2a7:	1b c9                	sbb    ecx,ecx
  40c2a9:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x58
  40c2b0:	58 
  40c2b1:	23 c8                	and    ecx,eax
  40c2b3:	e8 2a 8d 02 00       	call   0x434fe2
  40c2b8:	8d 4c 24 5c          	lea    ecx,[esp+0x5c]
  40c2bc:	8d 54 24 60          	lea    edx,[esp+0x60]
  40c2c0:	f7 d9                	neg    ecx
  40c2c2:	1b c9                	sbb    ecx,ecx
  40c2c4:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x59
  40c2cb:	59 
  40c2cc:	23 ca                	and    ecx,edx
  40c2ce:	e8 0f 8d 02 00       	call   0x434fe2
  40c2d3:	8d 8c 24 90 00 00 00 	lea    ecx,[esp+0x90]
  40c2da:	8d 84 24 94 00 00 00 	lea    eax,[esp+0x94]
  40c2e1:	f7 d9                	neg    ecx
  40c2e3:	1b c9                	sbb    ecx,ecx
  40c2e5:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x5a
  40c2ec:	5a 
  40c2ed:	23 c8                	and    ecx,eax
  40c2ef:	e8 ee 8c 02 00       	call   0x434fe2
  40c2f4:	8d 8c 24 80 00 00 00 	lea    ecx,[esp+0x80]
  40c2fb:	8d 94 24 84 00 00 00 	lea    edx,[esp+0x84]
  40c302:	f7 d9                	neg    ecx
  40c304:	1b c9                	sbb    ecx,ecx
  40c306:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x5b
  40c30d:	5b 
  40c30e:	23 ca                	and    ecx,edx
  40c310:	e8 cd 8c 02 00       	call   0x434fe2
  40c315:	8d 8c 24 88 00 00 00 	lea    ecx,[esp+0x88]
  40c31c:	8d 84 24 8c 00 00 00 	lea    eax,[esp+0x8c]
  40c323:	f7 d9                	neg    ecx
  40c325:	1b c9                	sbb    ecx,ecx
  40c327:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x5c
  40c32e:	5c 
  40c32f:	23 c8                	and    ecx,eax
  40c331:	e8 ac 8c 02 00       	call   0x434fe2
  40c336:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x5
  40c33d:	05 
  40c33e:	a1 20 75 45 00       	mov    eax,ds:0x457520
  40c343:	89 2d cc c5 45 00    	mov    DWORD PTR ds:0x45c5cc,ebp
  40c349:	85 c0                	test   eax,eax
  40c34b:	74 26                	je     0x40c373
  40c34d:	8d 04 80             	lea    eax,[eax+eax*4]
  40c350:	8d 04 80             	lea    eax,[eax+eax*4]
  40c353:	8d 0c 80             	lea    ecx,[eax+eax*4]
  40c356:	c1 e1 03             	shl    ecx,0x3
  40c359:	51                   	push   ecx
  40c35a:	55                   	push   ebp
  40c35b:	68 e0 9e 40 00       	push   0x409ee0
  40c360:	b9 a0 cc 45 00       	mov    ecx,0x45cca0
  40c365:	e8 16 2c 01 00       	call   0x41ef80
  40c36a:	8b cd                	mov    ecx,ebp
  40c36c:	e8 8f db ff ff       	call   0x409f00
  40c371:	eb 07                	jmp    0x40c37a
  40c373:	8b cd                	mov    ecx,ebp
  40c375:	e8 f6 dc ff ff       	call   0x40a070
  40c37a:	8b 8c 24 d8 06 00 00 	mov    ecx,DWORD PTR [esp+0x6d8]
  40c381:	5f                   	pop    edi
  40c382:	8b c5                	mov    eax,ebp
  40c384:	5e                   	pop    esi
  40c385:	5d                   	pop    ebp
  40c386:	5b                   	pop    ebx
  40c387:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  40c38e:	81 c4 d4 06 00 00    	add    esp,0x6d4
  40c394:	c2 08 00             	ret    0x8
  40c397:	90                   	nop
  40c398:	90                   	nop
  40c399:	90                   	nop
  40c39a:	90                   	nop
  40c39b:	90                   	nop
  40c39c:	90                   	nop
  40c39d:	90                   	nop
  40c39e:	90                   	nop
  40c39f:	90                   	nop
  40c3a0:	56                   	push   esi
  40c3a1:	8b f1                	mov    esi,ecx
  40c3a3:	e8 a8 05 00 00       	call   0x40c950
  40c3a8:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  40c3ad:	74 09                	je     0x40c3b8
  40c3af:	56                   	push   esi
  40c3b0:	e8 27 93 02 00       	call   0x4356dc
  40c3b5:	83 c4 04             	add    esp,0x4
  40c3b8:	8b c6                	mov    eax,esi
  40c3ba:	5e                   	pop    esi
  40c3bb:	c2 04 00             	ret    0x4
  40c3be:	90                   	nop
  40c3bf:	90                   	nop
  40c3c0:	56                   	push   esi
  40c3c1:	8b f1                	mov    esi,ecx
  40c3c3:	e8 38 00 00 00       	call   0x40c400
  40c3c8:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  40c3cd:	74 09                	je     0x40c3d8
  40c3cf:	56                   	push   esi
  40c3d0:	e8 07 93 02 00       	call   0x4356dc
  40c3d5:	83 c4 04             	add    esp,0x4
  40c3d8:	8b c6                	mov    eax,esi
  40c3da:	5e                   	pop    esi
  40c3db:	c2 04 00             	ret    0x4
  40c3de:	90                   	nop
  40c3df:	90                   	nop
  40c3e0:	56                   	push   esi
  40c3e1:	8b f1                	mov    esi,ecx
  40c3e3:	e8 e8 00 00 00       	call   0x40c4d0
  40c3e8:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  40c3ed:	74 09                	je     0x40c3f8
  40c3ef:	56                   	push   esi
  40c3f0:	e8 e7 92 02 00       	call   0x4356dc
  40c3f5:	83 c4 04             	add    esp,0x4
  40c3f8:	8b c6                	mov    eax,esi
  40c3fa:	5e                   	pop    esi
  40c3fb:	c2 04 00             	ret    0x4
  40c3fe:	90                   	nop
  40c3ff:	90                   	nop
  40c400:	6a ff                	push   0xffffffff
  40c402:	68 86 69 44 00       	push   0x446986
  40c407:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  40c40d:	50                   	push   eax
  40c40e:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  40c415:	83 ec 08             	sub    esp,0x8
  40c418:	55                   	push   ebp
  40c419:	56                   	push   esi
  40c41a:	8b f1                	mov    esi,ecx
  40c41c:	57                   	push   edi
  40c41d:	89 74 24 0c          	mov    DWORD PTR [esp+0xc],esi
  40c421:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  40c428:	00 
  40c429:	8d 46 24             	lea    eax,[esi+0x24]
  40c42c:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  40c430:	85 c0                	test   eax,eax
  40c432:	c6 44 24 1c 03       	mov    BYTE PTR [esp+0x1c],0x3
  40c437:	74 05                	je     0x40c43e
  40c439:	8d 48 04             	lea    ecx,[eax+0x4]
  40c43c:	eb 02                	jmp    0x40c440
  40c43e:	33 c9                	xor    ecx,ecx
  40c440:	e8 9d 8b 02 00       	call   0x434fe2
  40c445:	8d 46 1c             	lea    eax,[esi+0x1c]
  40c448:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  40c44c:	85 c0                	test   eax,eax
  40c44e:	c6 44 24 1c 04       	mov    BYTE PTR [esp+0x1c],0x4
  40c453:	74 05                	je     0x40c45a
  40c455:	8d 48 04             	lea    ecx,[eax+0x4]
  40c458:	eb 02                	jmp    0x40c45c
  40c45a:	33 c9                	xor    ecx,ecx
  40c45c:	e8 81 8b 02 00       	call   0x434fe2
  40c461:	83 c6 08             	add    esi,0x8
  40c464:	89 74 24 10          	mov    DWORD PTR [esp+0x10],esi
  40c468:	c7 06 f0 a8 44 00    	mov    DWORD PTR [esi],0x44a8f0
  40c46e:	8b 6e 08             	mov    ebp,DWORD PTR [esi+0x8]
  40c471:	33 ff                	xor    edi,edi
  40c473:	85 ed                	test   ebp,ebp
  40c475:	c6 44 24 1c 05       	mov    BYTE PTR [esp+0x1c],0x5
  40c47a:	7e 20                	jle    0x40c49c
  40c47c:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  40c47f:	8b 0c b8             	mov    ecx,DWORD PTR [eax+edi*4]
  40c482:	85 c9                	test   ecx,ecx
  40c484:	74 11                	je     0x40c497
  40c486:	8b 11                	mov    edx,DWORD PTR [ecx]
  40c488:	6a 01                	push   0x1
  40c48a:	ff 52 04             	call   DWORD PTR [edx+0x4]
  40c48d:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  40c490:	c7 04 b8 00 00 00 00 	mov    DWORD PTR [eax+edi*4],0x0
  40c497:	47                   	inc    edi
  40c498:	3b fd                	cmp    edi,ebp
  40c49a:	7c e0                	jl     0x40c47c
  40c49c:	55                   	push   ebp
  40c49d:	6a 00                	push   0x0
  40c49f:	8b ce                	mov    ecx,esi
  40c4a1:	e8 d3 78 02 00       	call   0x433d79
  40c4a6:	8b ce                	mov    ecx,esi
  40c4a8:	c6 44 24 1c 00       	mov    BYTE PTR [esp+0x1c],0x0
  40c4ad:	e8 1d 76 02 00       	call   0x433acf
  40c4b2:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  40c4b6:	5f                   	pop    edi
  40c4b7:	5e                   	pop    esi
  40c4b8:	5d                   	pop    ebp
  40c4b9:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  40c4c0:	83 c4 14             	add    esp,0x14
  40c4c3:	c3                   	ret
  40c4c4:	90                   	nop
  40c4c5:	90                   	nop
  40c4c6:	90                   	nop
  40c4c7:	90                   	nop
  40c4c8:	90                   	nop
  40c4c9:	90                   	nop
  40c4ca:	90                   	nop
  40c4cb:	90                   	nop
  40c4cc:	90                   	nop
  40c4cd:	90                   	nop
  40c4ce:	90                   	nop
  40c4cf:	90                   	nop
  40c4d0:	e9 4d 73 02 00       	jmp    0x433822
  40c4d5:	90                   	nop
  40c4d6:	90                   	nop
  40c4d7:	90                   	nop
  40c4d8:	90                   	nop
  40c4d9:	90                   	nop
  40c4da:	90                   	nop
  40c4db:	90                   	nop
  40c4dc:	90                   	nop
  40c4dd:	90                   	nop
  40c4de:	90                   	nop
  40c4df:	90                   	nop
  40c4e0:	83 ec 28             	sub    esp,0x28
  40c4e3:	53                   	push   ebx
  40c4e4:	8b 5c 24 38          	mov    ebx,DWORD PTR [esp+0x38]
  40c4e8:	55                   	push   ebp
  40c4e9:	56                   	push   esi
  40c4ea:	85 db                	test   ebx,ebx
  40c4ec:	57                   	push   edi
  40c4ed:	75 0e                	jne    0x40c4fd
  40c4ef:	a1 24 cb 45 00       	mov    eax,ds:0x45cb24
  40c4f4:	8b 48 5c             	mov    ecx,DWORD PTR [eax+0x5c]
  40c4f7:	89 4c 24 44          	mov    DWORD PTR [esp+0x44],ecx
  40c4fb:	8b d9                	mov    ebx,ecx
  40c4fd:	8b 44 24 58          	mov    eax,DWORD PTR [esp+0x58]
  40c501:	85 c0                	test   eax,eax
  40c503:	75 08                	jne    0x40c50d
  40c505:	8d 54 24 18          	lea    edx,[esp+0x18]
  40c509:	89 54 24 58          	mov    DWORD PTR [esp+0x58],edx
  40c50d:	8b 44 24 50          	mov    eax,DWORD PTR [esp+0x50]
  40c511:	3d 90 40 00 00       	cmp    eax,0x4090
  40c516:	74 0e                	je     0x40c526
  40c518:	3d b0 20 00 00       	cmp    eax,0x20b0
  40c51d:	74 07                	je     0x40c526
  40c51f:	8b eb                	mov    ebp,ebx
  40c521:	e9 a0 00 00 00       	jmp    0x40c5c6
  40c526:	a1 0c cb 45 00       	mov    eax,ds:0x45cb0c
  40c52b:	85 c0                	test   eax,eax
  40c52d:	74 1a                	je     0x40c549
  40c52f:	8b c8                	mov    ecx,eax
  40c531:	8b 00                	mov    eax,DWORD PTR [eax]
  40c533:	8b 71 08             	mov    esi,DWORD PTR [ecx+0x8]
  40c536:	39 1e                	cmp    DWORD PTR [esi],ebx
  40c538:	74 0b                	je     0x40c545
  40c53a:	85 c0                	test   eax,eax
  40c53c:	75 f1                	jne    0x40c52f
  40c53e:	8b eb                	mov    ebp,ebx
  40c540:	e9 81 00 00 00       	jmp    0x40c5c6
  40c545:	85 f6                	test   esi,esi
  40c547:	75 04                	jne    0x40c54d
  40c549:	8b eb                	mov    ebp,ebx
  40c54b:	eb 79                	jmp    0x40c5c6
  40c54d:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  40c550:	85 c0                	test   eax,eax
  40c552:	75 1e                	jne    0x40c572
  40c554:	8b 46 10             	mov    eax,DWORD PTR [esi+0x10]
  40c557:	8b 4e 08             	mov    ecx,DWORD PTR [esi+0x8]
  40c55a:	8b 56 04             	mov    edx,DWORD PTR [esi+0x4]
  40c55d:	40                   	inc    eax
  40c55e:	89 46 10             	mov    DWORD PTR [esi+0x10],eax
  40c561:	8b 46 0c             	mov    eax,DWORD PTR [esi+0xc]
  40c564:	6a 00                	push   0x0
  40c566:	50                   	push   eax
  40c567:	51                   	push   ecx
  40c568:	52                   	push   edx
  40c569:	e8 d4 57 02 00       	call   0x431d42
  40c56e:	8b e8                	mov    ebp,eax
  40c570:	eb 54                	jmp    0x40c5c6
  40c572:	8b 46 1c             	mov    eax,DWORD PTR [esi+0x1c]
  40c575:	33 d2                	xor    edx,edx
  40c577:	8b 48 04             	mov    ecx,DWORD PTR [eax+0x4]
  40c57a:	8b 78 08             	mov    edi,DWORD PTR [eax+0x8]
  40c57d:	3b ca                	cmp    ecx,edx
  40c57f:	89 4e 1c             	mov    DWORD PTR [esi+0x1c],ecx
  40c582:	74 04                	je     0x40c588
  40c584:	89 11                	mov    DWORD PTR [ecx],edx
  40c586:	eb 03                	jmp    0x40c58b
  40c588:	89 56 18             	mov    DWORD PTR [esi+0x18],edx
  40c58b:	8b 4e 24             	mov    ecx,DWORD PTR [esi+0x24]
  40c58e:	89 08                	mov    DWORD PTR [eax],ecx
  40c590:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  40c593:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  40c596:	48                   	dec    eax
  40c597:	89 46 20             	mov    DWORD PTR [esi+0x20],eax
  40c59a:	75 28                	jne    0x40c5c4
  40c59c:	8b 46 18             	mov    eax,DWORD PTR [esi+0x18]
  40c59f:	3b c2                	cmp    eax,edx
  40c5a1:	74 06                	je     0x40c5a9
  40c5a3:	8b 00                	mov    eax,DWORD PTR [eax]
  40c5a5:	3b c2                	cmp    eax,edx
  40c5a7:	75 fa                	jne    0x40c5a3
  40c5a9:	8b 4e 28             	mov    ecx,DWORD PTR [esi+0x28]
  40c5ac:	89 56 20             	mov    DWORD PTR [esi+0x20],edx
  40c5af:	89 56 24             	mov    DWORD PTR [esi+0x24],edx
  40c5b2:	89 56 1c             	mov    DWORD PTR [esi+0x1c],edx
  40c5b5:	89 56 18             	mov    DWORD PTR [esi+0x18],edx
  40c5b8:	e8 ca 78 02 00       	call   0x433e87
  40c5bd:	c7 46 28 00 00 00 00 	mov    DWORD PTR [esi+0x28],0x0
  40c5c4:	8b ef                	mov    ebp,edi
  40c5c6:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  40c5cd:	00 
  40c5ce:	8b 54 24 58          	mov    edx,DWORD PTR [esp+0x58]
  40c5d2:	8b 74 24 54          	mov    esi,DWORD PTR [esp+0x54]
  40c5d6:	8b 44 24 50          	mov    eax,DWORD PTR [esp+0x50]
  40c5da:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  40c5de:	52                   	push   edx
  40c5df:	8b 54 24 4c          	mov    edx,DWORD PTR [esp+0x4c]
  40c5e3:	56                   	push   esi
  40c5e4:	50                   	push   eax
  40c5e5:	8b 44 24 4c          	mov    eax,DWORD PTR [esp+0x4c]
  40c5e9:	51                   	push   ecx
  40c5ea:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  40c5ee:	52                   	push   edx
  40c5ef:	55                   	push   ebp
  40c5f0:	50                   	push   eax
  40c5f1:	51                   	push   ecx
  40c5f2:	e8 45 57 02 00       	call   0x431d3c
  40c5f7:	8b f8                	mov    edi,eax
  40c5f9:	85 ff                	test   edi,edi
  40c5fb:	89 7c 24 14          	mov    DWORD PTR [esp+0x14],edi
  40c5ff:	0f 85 2e 01 00 00    	jne    0x40c733
  40c605:	3b eb                	cmp    ebp,ebx
  40c607:	0f 84 9b 00 00 00    	je     0x40c6a8
  40c60d:	a1 0c cb 45 00       	mov    eax,ds:0x45cb0c
  40c612:	85 c0                	test   eax,eax
  40c614:	0f 84 8e 00 00 00    	je     0x40c6a8
  40c61a:	8b c8                	mov    ecx,eax
  40c61c:	8b 00                	mov    eax,DWORD PTR [eax]
  40c61e:	8b 71 08             	mov    esi,DWORD PTR [ecx+0x8]
  40c621:	39 1e                	cmp    DWORD PTR [esi],ebx
  40c623:	74 06                	je     0x40c62b
  40c625:	85 c0                	test   eax,eax
  40c627:	75 f1                	jne    0x40c61a
  40c629:	eb 7d                	jmp    0x40c6a8
  40c62b:	85 f6                	test   esi,esi
  40c62d:	74 79                	je     0x40c6a8
  40c62f:	8b 46 24             	mov    eax,DWORD PTR [esi+0x24]
  40c632:	8b 5e 18             	mov    ebx,DWORD PTR [esi+0x18]
  40c635:	85 c0                	test   eax,eax
  40c637:	75 30                	jne    0x40c669
  40c639:	8b 56 2c             	mov    edx,DWORD PTR [esi+0x2c]
  40c63c:	6a 0c                	push   0xc
  40c63e:	8d 46 28             	lea    eax,[esi+0x28]
  40c641:	52                   	push   edx
  40c642:	50                   	push   eax
  40c643:	e8 1f 78 02 00       	call   0x433e67
  40c648:	8b 4e 2c             	mov    ecx,DWORD PTR [esi+0x2c]
  40c64b:	83 c0 04             	add    eax,0x4
  40c64e:	8d 14 49             	lea    edx,[ecx+ecx*2]
  40c651:	49                   	dec    ecx
  40c652:	85 c9                	test   ecx,ecx
  40c654:	8d 44 90 f4          	lea    eax,[eax+edx*4-0xc]
  40c658:	7c 0f                	jl     0x40c669
  40c65a:	41                   	inc    ecx
  40c65b:	8b 56 24             	mov    edx,DWORD PTR [esi+0x24]
  40c65e:	89 10                	mov    DWORD PTR [eax],edx
  40c660:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  40c663:	83 e8 0c             	sub    eax,0xc
  40c666:	49                   	dec    ecx
  40c667:	75 f2                	jne    0x40c65b
  40c669:	8b 7e 24             	mov    edi,DWORD PTR [esi+0x24]
  40c66c:	6a 01                	push   0x1
  40c66e:	8b 07                	mov    eax,DWORD PTR [edi]
  40c670:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  40c673:	c7 47 04 00 00 00 00 	mov    DWORD PTR [edi+0x4],0x0
  40c67a:	89 1f                	mov    DWORD PTR [edi],ebx
  40c67c:	8b 4e 20             	mov    ecx,DWORD PTR [esi+0x20]
  40c67f:	8d 5f 08             	lea    ebx,[edi+0x8]
  40c682:	41                   	inc    ecx
  40c683:	53                   	push   ebx
  40c684:	89 4e 20             	mov    DWORD PTR [esi+0x20],ecx
  40c687:	e8 94 28 00 00       	call   0x40ef20
  40c68c:	89 2b                	mov    DWORD PTR [ebx],ebp
  40c68e:	8b 46 18             	mov    eax,DWORD PTR [esi+0x18]
  40c691:	85 c0                	test   eax,eax
  40c693:	74 05                	je     0x40c69a
  40c695:	89 78 04             	mov    DWORD PTR [eax+0x4],edi
  40c698:	eb 03                	jmp    0x40c69d
  40c69a:	89 7e 1c             	mov    DWORD PTR [esi+0x1c],edi
  40c69d:	8b 5c 24 44          	mov    ebx,DWORD PTR [esp+0x44]
  40c6a1:	89 7e 18             	mov    DWORD PTR [esi+0x18],edi
  40c6a4:	8b 7c 24 14          	mov    edi,DWORD PTR [esp+0x14]
  40c6a8:	8b 0d 28 cb 45 00    	mov    ecx,DWORD PTR ds:0x45cb28
  40c6ae:	51                   	push   ecx
  40c6af:	e8 e8 56 02 00       	call   0x431d9c
  40c6b4:	05 ff bf ff ff       	add    eax,0xffffbfff
  40c6b9:	83 f8 0b             	cmp    eax,0xb
  40c6bc:	77 5a                	ja     0x40c718
  40c6be:	33 d2                	xor    edx,edx
  40c6c0:	8a 90 58 c7 40 00    	mov    dl,BYTE PTR [eax+0x40c758]
  40c6c6:	ff 24 95 50 c7 40 00 	jmp    DWORD PTR [edx*4+0x40c750]
  40c6cd:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
  40c6d1:	83 fe 05             	cmp    esi,0x5
  40c6d4:	7c 34                	jl     0x40c70a
  40c6d6:	6a 01                	push   0x1
  40c6d8:	6a 00                	push   0x0
  40c6da:	6a 00                	push   0x0
  40c6dc:	8d 44 24 28          	lea    eax,[esp+0x28]
  40c6e0:	6a 00                	push   0x0
  40c6e2:	50                   	push   eax
  40c6e3:	ff 15 ec a5 44 00    	call   DWORD PTR ds:0x44a5ec
  40c6e9:	85 c0                	test   eax,eax
  40c6eb:	74 1d                	je     0x40c70a
  40c6ed:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  40c6f1:	51                   	push   ecx
  40c6f2:	ff 15 f0 a5 44 00    	call   DWORD PTR ds:0x44a5f0
  40c6f8:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  40c6fc:	52                   	push   edx
  40c6fd:	ff 15 f4 a5 44 00    	call   DWORD PTR ds:0x44a5f4
  40c703:	83 7c 24 20 12       	cmp    DWORD PTR [esp+0x20],0x12
  40c708:	74 0e                	je     0x40c718
  40c70a:	46                   	inc    esi
  40c70b:	83 fe 14             	cmp    esi,0x14
  40c70e:	89 74 24 10          	mov    DWORD PTR [esp+0x10],esi
  40c712:	0f 8c b6 fe ff ff    	jl     0x40c5ce
  40c718:	83 7c 24 54 ff       	cmp    DWORD PTR [esp+0x54],0xffffffff
  40c71d:	75 0a                	jne    0x40c729
  40c71f:	8b 54 24 58          	mov    edx,DWORD PTR [esp+0x58]
  40c723:	c7 02 00 00 00 00    	mov    DWORD PTR [edx],0x0
  40c729:	8b c7                	mov    eax,edi
  40c72b:	5f                   	pop    edi
  40c72c:	5e                   	pop    esi
  40c72d:	5d                   	pop    ebp
  40c72e:	5b                   	pop    ebx
  40c72f:	83 c4 28             	add    esp,0x28
  40c732:	c3                   	ret
  40c733:	83 fe ff             	cmp    esi,0xffffffff
  40c736:	75 f1                	jne    0x40c729
  40c738:	8b 44 24 58          	mov    eax,DWORD PTR [esp+0x58]
  40c73c:	53                   	push   ebx
  40c73d:	8b 08                	mov    ecx,DWORD PTR [eax]
  40c73f:	51                   	push   ecx
  40c740:	55                   	push   ebp
  40c741:	e8 3e 56 02 00       	call   0x431d84
  40c746:	8b c7                	mov    eax,edi
  40c748:	5f                   	pop    edi
  40c749:	5e                   	pop    esi
  40c74a:	5d                   	pop    ebp
  40c74b:	5b                   	pop    ebx
  40c74c:	83 c4 28             	add    esp,0x28
  40c74f:	c3                   	ret
  40c750:	cd c6                	int    0xc6
  40c752:	40                   	inc    eax
  40c753:	00 18                	add    BYTE PTR [eax],bl
  40c755:	c7 40 00 00 01 01 01 	mov    DWORD PTR [eax+0x0],0x1010100
  40c75c:	01 01                	add    DWORD PTR [ecx],eax
	...
