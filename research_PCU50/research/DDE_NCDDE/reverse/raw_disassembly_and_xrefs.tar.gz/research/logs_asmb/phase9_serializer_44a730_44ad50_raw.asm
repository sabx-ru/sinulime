
PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

0044a730 <.text+0x49730>:
  44a730:	83 ec 20             	sub    esp,0x20
  44a733:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  44a737:	53                   	push   ebx
  44a738:	55                   	push   ebp
  44a739:	56                   	push   esi
  44a73a:	8b 88 a6 00 00 00    	mov    ecx,DWORD PTR [eax+0xa6]
  44a740:	8b 44 24 3c          	mov    eax,DWORD PTR [esp+0x3c]
  44a744:	57                   	push   edi
  44a745:	8b 14 81             	mov    edx,DWORD PTR [ecx+eax*4]
  44a748:	8b 4c 24 3c          	mov    ecx,DWORD PTR [esp+0x3c]
  44a74c:	8b 5a 36             	mov    ebx,DWORD PTR [edx+0x36]
  44a74f:	8b 51 04             	mov    edx,DWORD PTR [ecx+0x4]
  44a752:	8b 3c 82             	mov    edi,DWORD PTR [edx+eax*4]
  44a755:	c7 44 24 1c 04 00 00 	mov    DWORD PTR [esp+0x1c],0x4
  44a75c:	00 
  44a75d:	83 c7 04             	add    edi,0x4
  44a760:	c7 44 24 20 00 00 00 	mov    DWORD PTR [esp+0x20],0x0
  44a767:	00 
  44a768:	89 7c 24 24          	mov    DWORD PTR [esp+0x24],edi
  44a76c:	8a 47 2a             	mov    al,BYTE PTR [edi+0x2a]
  44a76f:	3c ff                	cmp    al,0xff
  44a771:	75 08                	jne    0x44a77b
  44a773:	8b 43 19             	mov    eax,DWORD PTR [ebx+0x19]
  44a776:	8a 40 3e             	mov    al,BYTE PTR [eax+0x3e]
  44a779:	3c ff                	cmp    al,0xff
  44a77b:	8b 4f 02             	mov    ecx,DWORD PTR [edi+0x2]
  44a77e:	0f 95 44 24 3c       	setne  BYTE PTR [esp+0x3c]
  44a783:	83 cd ff             	or     ebp,0xffffffff
  44a786:	3b cd                	cmp    ecx,ebp
  44a788:	74 08                	je     0x44a792
  44a78a:	8b f1                	mov    esi,ecx
  44a78c:	89 74 24 18          	mov    DWORD PTR [esp+0x18],esi
  44a790:	eb 19                	jmp    0x44a7ab
  44a792:	8b 53 19             	mov    edx,DWORD PTR [ebx+0x19]
  44a795:	8b 42 16             	mov    eax,DWORD PTR [edx+0x16]
  44a798:	3b c5                	cmp    eax,ebp
  44a79a:	75 09                	jne    0x44a7a5
  44a79c:	8a 43 20             	mov    al,BYTE PTR [ebx+0x20]
  44a79f:	c1 e8 05             	shr    eax,0x5
  44a7a2:	83 e0 01             	and    eax,0x1
  44a7a5:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  44a7a9:	8b f0                	mov    esi,eax
  44a7ab:	8b 47 12             	mov    eax,DWORD PTR [edi+0x12]
  44a7ae:	3b c5                	cmp    eax,ebp
  44a7b0:	75 12                	jne    0x44a7c4
  44a7b2:	3b cd                	cmp    ecx,ebp
  44a7b4:	75 08                	jne    0x44a7be
  44a7b6:	89 2d b8 6c 4a 00    	mov    DWORD PTR ds:0x4a6cb8,ebp
  44a7bc:	eb 0f                	jmp    0x44a7cd
  44a7be:	8b 47 06             	mov    eax,DWORD PTR [edi+0x6]
  44a7c1:	2b c1                	sub    eax,ecx
  44a7c3:	40                   	inc    eax
  44a7c4:	3b c5                	cmp    eax,ebp
  44a7c6:	a3 b8 6c 4a 00       	mov    ds:0x4a6cb8,eax
  44a7cb:	75 2d                	jne    0x44a7fa
  44a7cd:	8b 4b 19             	mov    ecx,DWORD PTR [ebx+0x19]
  44a7d0:	8b 41 26             	mov    eax,DWORD PTR [ecx+0x26]
  44a7d3:	3b c5                	cmp    eax,ebp
  44a7d5:	75 15                	jne    0x44a7ec
  44a7d7:	8b 51 16             	mov    edx,DWORD PTR [ecx+0x16]
  44a7da:	3b d5                	cmp    edx,ebp
  44a7dc:	75 08                	jne    0x44a7e6
  44a7de:	89 2d b8 6c 4a 00    	mov    DWORD PTR ds:0x4a6cb8,ebp
  44a7e4:	eb 0f                	jmp    0x44a7f5
  44a7e6:	8b 41 1a             	mov    eax,DWORD PTR [ecx+0x1a]
  44a7e9:	2b c2                	sub    eax,edx
  44a7eb:	40                   	inc    eax
  44a7ec:	3b c5                	cmp    eax,ebp
  44a7ee:	a3 b8 6c 4a 00       	mov    ds:0x4a6cb8,eax
  44a7f3:	75 05                	jne    0x44a7fa
  44a7f5:	b8 01 00 00 00       	mov    eax,0x1
  44a7fa:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44a7fe:	8d 44 30 ff          	lea    eax,[eax+esi*1-0x1]
  44a802:	33 ff                	xor    edi,edi
  44a804:	3b f0                	cmp    esi,eax
  44a806:	8b 29                	mov    ebp,DWORD PTR [ecx]
  44a808:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  44a80c:	89 74 24 14          	mov    DWORD PTR [esp+0x14],esi
  44a810:	c6 44 24 13 00       	mov    BYTE PTR [esp+0x13],0x0
  44a815:	0f 8f 4c 03 00 00    	jg     0x44ab67
  44a81b:	eb 04                	jmp    0x44a821
  44a81d:	8b 74 24 14          	mov    esi,DWORD PTR [esp+0x14]
  44a821:	f6 05 cc 6c 4a 00 01 	test   BYTE PTR ds:0x4a6ccc,0x1
  44a828:	74 16                	je     0x44a840
  44a82a:	83 7c 24 4c 01       	cmp    DWORD PTR [esp+0x4c],0x1
  44a82f:	75 0f                	jne    0x44a840
  44a831:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  44a835:	80 7a 2c 01          	cmp    BYTE PTR [edx+0x2c],0x1
  44a839:	75 05                	jne    0x44a840
  44a83b:	c6 45 00 7c          	mov    BYTE PTR [ebp+0x0],0x7c
  44a83f:	45                   	inc    ebp
  44a840:	8a 44 24 3c          	mov    al,BYTE PTR [esp+0x3c]
  44a844:	84 c0                	test   al,al
  44a846:	74 2f                	je     0x44a877
  44a848:	81 ff 88 13 00 00    	cmp    edi,0x1388
  44a84e:	7d 27                	jge    0x44a877
  44a850:	83 7c 24 4c 01       	cmp    DWORD PTR [esp+0x4c],0x1
  44a855:	75 1a                	jne    0x44a871
  44a857:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44a85b:	56                   	push   esi
  44a85c:	68 fc af 47 00       	push   0x47affc
  44a861:	8b 08                	mov    ecx,DWORD PTR [eax]
  44a863:	51                   	push   ecx
  44a864:	ff 15 7c 61 6c 00    	call   DWORD PTR ds:0x6c617c
  44a86a:	83 c4 0c             	add    esp,0xc
  44a86d:	03 e8                	add    ebp,eax
  44a86f:	eb 06                	jmp    0x44a877
  44a871:	89 75 00             	mov    DWORD PTR [ebp+0x0],esi
  44a874:	83 c5 04             	add    ebp,0x4
  44a877:	a0 02 c6 47 00       	mov    al,ds:0x47c602
  44a87c:	84 c0                	test   al,al
  44a87e:	74 59                	je     0x44a8d9
  44a880:	8a 53 1f             	mov    dl,BYTE PTR [ebx+0x1f]
  44a883:	80 e2 01             	and    dl,0x1
  44a886:	80 fa 01             	cmp    dl,0x1
  44a889:	75 4e                	jne    0x44a8d9
  44a88b:	8b 7c 24 38          	mov    edi,DWORD PTR [esp+0x38]
  44a88f:	80 7f 07 02          	cmp    BYTE PTR [edi+0x7],0x2
  44a893:	75 48                	jne    0x44a8dd
  44a895:	8d 44 24 2c          	lea    eax,[esp+0x2c]
  44a899:	50                   	push   eax
  44a89a:	57                   	push   edi
  44a89b:	e8 2b 7e fb ff       	call   0x4026cb
  44a8a0:	83 c4 08             	add    esp,0x8
  44a8a3:	85 c0                	test   eax,eax
  44a8a5:	74 36                	je     0x44a8dd
  44a8a7:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44a8ab:	8b 13                	mov    edx,DWORD PTR [ebx]
  44a8ad:	49                   	dec    ecx
  44a8ae:	8d 44 24 20          	lea    eax,[esp+0x20]
  44a8b2:	f7 d9                	neg    ecx
  44a8b4:	1b c9                	sbb    ecx,ecx
  44a8b6:	6a 00                	push   0x0
  44a8b8:	83 e1 02             	and    ecx,0x2
  44a8bb:	50                   	push   eax
  44a8bc:	8b 44 24 48          	mov    eax,DWORD PTR [esp+0x48]
  44a8c0:	41                   	inc    ecx
  44a8c1:	51                   	push   ecx
  44a8c2:	8b 4f 18             	mov    ecx,DWORD PTR [edi+0x18]
  44a8c5:	50                   	push   eax
  44a8c6:	51                   	push   ecx
  44a8c7:	8b cb                	mov    ecx,ebx
  44a8c9:	ff 52 18             	call   DWORD PTR [edx+0x18]
  44a8cc:	8b 74 24 34          	mov    esi,DWORD PTR [esp+0x34]
  44a8d0:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  44a8d4:	83 cf ff             	or     edi,0xffffffff
  44a8d7:	eb 7a                	jmp    0x44a953
  44a8d9:	8b 7c 24 38          	mov    edi,DWORD PTR [esp+0x38]
  44a8dd:	8b 4c 24 50          	mov    ecx,DWORD PTR [esp+0x50]
  44a8e1:	8d 44 24 1c          	lea    eax,[esp+0x1c]
  44a8e5:	8b 13                	mov    edx,DWORD PTR [ebx]
  44a8e7:	50                   	push   eax
  44a8e8:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44a8ec:	51                   	push   ecx
  44a8ed:	8b 4f 18             	mov    ecx,DWORD PTR [edi+0x18]
  44a8f0:	56                   	push   esi
  44a8f1:	8b 74 24 40          	mov    esi,DWORD PTR [esp+0x40]
  44a8f5:	50                   	push   eax
  44a8f6:	55                   	push   ebp
  44a8f7:	51                   	push   ecx
  44a8f8:	8b 06                	mov    eax,DWORD PTR [esi]
  44a8fa:	8b cb                	mov    ecx,ebx
  44a8fc:	50                   	push   eax
  44a8fd:	ff 52 1c             	call   DWORD PTR [edx+0x1c]
  44a900:	8b f8                	mov    edi,eax
  44a902:	83 ff fd             	cmp    edi,0xfffffffd
  44a905:	0f 84 ca 02 00 00    	je     0x44abd5
  44a90b:	83 ff fe             	cmp    edi,0xfffffffe
  44a90e:	0f 84 b4 02 00 00    	je     0x44abc8
  44a914:	83 ff ff             	cmp    edi,0xffffffff
  44a917:	75 36                	jne    0x44a94f
  44a919:	8b 44 24 38          	mov    eax,DWORD PTR [esp+0x38]
  44a91d:	80 78 07 02          	cmp    BYTE PTR [eax+0x7],0x2
  44a921:	0f 85 40 02 00 00    	jne    0x44ab67
  44a927:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44a92b:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
  44a92e:	49                   	dec    ecx
  44a92f:	8b 13                	mov    edx,DWORD PTR [ebx]
  44a931:	f7 d9                	neg    ecx
  44a933:	1b c9                	sbb    ecx,ecx
  44a935:	6a 00                	push   0x0
  44a937:	83 e1 02             	and    ecx,0x2
  44a93a:	6a 00                	push   0x0
  44a93c:	41                   	inc    ecx
  44a93d:	51                   	push   ecx
  44a93e:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44a942:	51                   	push   ecx
  44a943:	50                   	push   eax
  44a944:	8b cb                	mov    ecx,ebx
  44a946:	ff 52 18             	call   DWORD PTR [edx+0x18]
  44a949:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  44a94d:	eb 04                	jmp    0x44a953
  44a94f:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  44a953:	83 f8 01             	cmp    eax,0x1
  44a956:	c7 06 00 00 00 00    	mov    DWORD PTR [esi],0x0
  44a95c:	75 20                	jne    0x44a97e
  44a95e:	84 43 1f             	test   BYTE PTR [ebx+0x1f],al
  44a961:	75 1b                	jne    0x44a97e
  44a963:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  44a967:	80 79 28 ff          	cmp    BYTE PTR [ecx+0x28],0xff
  44a96b:	75 09                	jne    0x44a976
  44a96d:	8b 53 19             	mov    edx,DWORD PTR [ebx+0x19]
  44a970:	80 7a 3c ff          	cmp    BYTE PTR [edx+0x3c],0xff
  44a974:	74 08                	je     0x44a97e
  44a976:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44a97a:	89 4c 24 28          	mov    DWORD PTR [esp+0x28],ecx
  44a97e:	81 ff 0f 27 00 00    	cmp    edi,0x270f
  44a984:	7e 21                	jle    0x44a9a7
  44a986:	8a 4c 24 3c          	mov    cl,BYTE PTR [esp+0x3c]
  44a98a:	81 ef 10 27 00 00    	sub    edi,0x2710
  44a990:	84 c9                	test   cl,cl
  44a992:	74 13                	je     0x44a9a7
  44a994:	8b 54 24 38          	mov    edx,DWORD PTR [esp+0x38]
  44a998:	80 7a 07 02          	cmp    BYTE PTR [edx+0x7],0x2
  44a99c:	75 09                	jne    0x44a9a7
  44a99e:	ff 44 24 14          	inc    DWORD PTR [esp+0x14]
  44a9a2:	e9 a2 01 00 00       	jmp    0x44ab49
  44a9a7:	83 7c 24 4c 01       	cmp    DWORD PTR [esp+0x4c],0x1
  44a9ac:	75 57                	jne    0x44aa05
  44a9ae:	81 ff 87 13 00 00    	cmp    edi,0x1387
  44a9b4:	8d 87 78 ec ff ff    	lea    eax,[edi-0x1388]
  44a9ba:	7f 02                	jg     0x44a9be
  44a9bc:	8b c7                	mov    eax,edi
  44a9be:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  44a9c2:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  44a9c6:	51                   	push   ecx
  44a9c7:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44a9cb:	52                   	push   edx
  44a9cc:	8b 54 24 40          	mov    edx,DWORD PTR [esp+0x40]
  44a9d0:	6a 01                	push   0x1
  44a9d2:	50                   	push   eax
  44a9d3:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  44a9d7:	55                   	push   ebp
  44a9d8:	50                   	push   eax
  44a9d9:	51                   	push   ecx
  44a9da:	52                   	push   edx
  44a9db:	e8 f7 6b fb ff       	call   0x4015d7
  44a9e0:	8b f0                	mov    esi,eax
  44a9e2:	83 c4 20             	add    esp,0x20
  44a9e5:	85 f6                	test   esi,esi
  44a9e7:	0f 8d f4 00 00 00    	jge    0x44aae1
  44a9ed:	8b 44 24 38          	mov    eax,DWORD PTR [esp+0x38]
  44a9f1:	80 78 07 02          	cmp    BYTE PTR [eax+0x7],0x2
  44a9f5:	0f 85 6c 01 00 00    	jne    0x44ab67
  44a9fb:	be 01 00 00 00       	mov    esi,0x1
  44aa00:	e9 dc 00 00 00       	jmp    0x44aae1
  44aa05:	85 ff                	test   edi,edi
  44aa07:	0f 8c 64 01 00 00    	jl     0x44ab71
  44aa0d:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44aa11:	8b 54 24 14          	mov    edx,DWORD PTR [esp+0x14]
  44aa15:	3b d1                	cmp    edx,ecx
  44aa17:	0f 85 b4 00 00 00    	jne    0x44aad1
  44aa1d:	81 ff 88 13 00 00    	cmp    edi,0x1388
  44aa23:	0f 8d a8 00 00 00    	jge    0x44aad1
  44aa29:	83 f8 03             	cmp    eax,0x3
  44aa2c:	8b f7                	mov    esi,edi
  44aa2e:	77 26                	ja     0x44aa56
  44aa30:	ff 24 85 f8 ab 44 00 	jmp    DWORD PTR [eax*4+0x44abf8]
  44aa37:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0x1
  44aa3e:	01 00 
  44aa40:	eb 14                	jmp    0x44aa56
  44aa42:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0x2
  44aa49:	02 00 
  44aa4b:	eb 09                	jmp    0x44aa56
  44aa4d:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0x64
  44aa54:	64 00 
  44aa56:	8a 44 24 3c          	mov    al,BYTE PTR [esp+0x3c]
  44aa5a:	84 c0                	test   al,al
  44aa5c:	74 07                	je     0x44aa65
  44aa5e:	80 0d d5 6b 48 00 01 	or     BYTE PTR ds:0x486bd5,0x1
  44aa65:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  44aa69:	85 c0                	test   eax,eax
  44aa6b:	75 1d                	jne    0x44aa8a
  44aa6d:	8b 4c 24 40          	mov    ecx,DWORD PTR [esp+0x40]
  44aa71:	8b 13                	mov    edx,DWORD PTR [ebx]
  44aa73:	8d 44 24 20          	lea    eax,[esp+0x20]
  44aa77:	6a 00                	push   0x0
  44aa79:	50                   	push   eax
  44aa7a:	8b 44 24 40          	mov    eax,DWORD PTR [esp+0x40]
  44aa7e:	6a 03                	push   0x3
  44aa80:	51                   	push   ecx
  44aa81:	8b 48 18             	mov    ecx,DWORD PTR [eax+0x18]
  44aa84:	51                   	push   ecx
  44aa85:	8b cb                	mov    ecx,ebx
  44aa87:	ff 52 18             	call   DWORD PTR [edx+0x18]
  44aa8a:	a0 84 68 48 00       	mov    al,ds:0x486884
  44aa8f:	66 33 d2             	xor    dx,dx
  44aa92:	66 0f b6 4c 24 20    	movzx  cx,BYTE PTR [esp+0x20]
  44aa98:	8a d0                	mov    dl,al
  44aa9a:	c1 e2 08             	shl    edx,0x8
  44aa9d:	03 d1                	add    edx,ecx
  44aa9f:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44aaa3:	66 89 15 d6 6b 48 00 	mov    WORD PTR ds:0x486bd6,dx
  44aaaa:	8b 54 24 28          	mov    edx,DWORD PTR [esp+0x28]
  44aaae:	2b d1                	sub    edx,ecx
  44aab0:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44aab4:	fe c0                	inc    al
  44aab6:	42                   	inc    edx
  44aab7:	a2 84 68 48 00       	mov    ds:0x486884,al
  44aabc:	89 15 d8 6b 48 00    	mov    DWORD PTR ds:0x486bd8,edx
  44aac2:	8b 11                	mov    edx,DWORD PTR [ecx]
  44aac4:	8b c5                	mov    eax,ebp
  44aac6:	2b c2                	sub    eax,edx
  44aac8:	03 c7                	add    eax,edi
  44aaca:	a3 dc 6b 48 00       	mov    ds:0x486bdc,eax
  44aacf:	eb 10                	jmp    0x44aae1
  44aad1:	81 ff 87 13 00 00    	cmp    edi,0x1387
  44aad7:	8d b7 78 ec ff ff    	lea    esi,[edi-0x1388]
  44aadd:	7f 02                	jg     0x44aae1
  44aadf:	8b f7                	mov    esi,edi
  44aae1:	81 ff 87 13 00 00    	cmp    edi,0x1387
  44aae7:	7e 0a                	jle    0x44aaf3
  44aae9:	8b 54 24 44          	mov    edx,DWORD PTR [esp+0x44]
  44aaed:	03 f5                	add    esi,ebp
  44aaef:	89 32                	mov    DWORD PTR [edx],esi
  44aaf1:	eb 56                	jmp    0x44ab49
  44aaf3:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  44aaf7:	c6 44 24 13 01       	mov    BYTE PTR [esp+0x13],0x1
  44aafc:	40                   	inc    eax
  44aafd:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  44ab01:	8b c6                	mov    eax,esi
  44ab03:	2d d0 6b 48 00       	sub    eax,0x486bd0
  44ab08:	03 c5                	add    eax,ebp
  44ab0a:	3d 00 02 00 00       	cmp    eax,0x200
  44ab0f:	7e 30                	jle    0x44ab41
  44ab11:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44ab15:	83 f9 01             	cmp    ecx,0x1
  44ab18:	74 27                	je     0x44ab41
  44ab1a:	8b 74 24 48          	mov    esi,DWORD PTR [esp+0x48]
  44ab1e:	51                   	push   ecx
  44ab1f:	8b 4c 24 3c          	mov    ecx,DWORD PTR [esp+0x3c]
  44ab23:	50                   	push   eax
  44ab24:	68 d0 6b 48 00       	push   0x486bd0
  44ab29:	56                   	push   esi
  44ab2a:	51                   	push   ecx
  44ab2b:	e8 c8 67 fb ff       	call   0x4012f8
  44ab30:	8b 54 24 58          	mov    edx,DWORD PTR [esp+0x58]
  44ab34:	89 06                	mov    DWORD PTR [esi],eax
  44ab36:	83 c4 14             	add    esp,0x14
  44ab39:	c7 02 d0 6b 48 00    	mov    DWORD PTR [edx],0x486bd0
  44ab3f:	eb 08                	jmp    0x44ab49
  44ab41:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44ab45:	03 f5                	add    esi,ebp
  44ab47:	89 30                	mov    DWORD PTR [eax],esi
  44ab49:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44ab4d:	8b 54 24 14          	mov    edx,DWORD PTR [esp+0x14]
  44ab51:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  44ab55:	8b 29                	mov    ebp,DWORD PTR [ecx]
  44ab57:	3b d0                	cmp    edx,eax
  44ab59:	0f 8e be fc ff ff    	jle    0x44a81d
  44ab5f:	8a 44 24 13          	mov    al,BYTE PTR [esp+0x13]
  44ab63:	84 c0                	test   al,al
  44ab65:	75 54                	jne    0x44abbb
  44ab67:	5f                   	pop    edi
  44ab68:	5e                   	pop    esi
  44ab69:	5d                   	pop    ebp
  44ab6a:	33 c0                	xor    eax,eax
  44ab6c:	5b                   	pop    ebx
  44ab6d:	83 c4 20             	add    esp,0x20
  44ab70:	c3                   	ret
  44ab71:	a1 d0 6b 48 00       	mov    eax,ds:0x486bd0
  44ab76:	8b 4c 24 38          	mov    ecx,DWORD PTR [esp+0x38]
  44ab7a:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0xffff
  44ab81:	ff ff 
  44ab83:	25 ff ff 00 00       	and    eax,0xffff
  44ab88:	8b 51 2a             	mov    edx,DWORD PTR [ecx+0x2a]
  44ab8b:	89 90 d0 6b 48 00    	mov    DWORD PTR [eax+0x486bd0],edx
  44ab91:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44ab95:	66 83 05 d0 6b 48 00 	add    WORD PTR ds:0x486bd0,0x4
  44ab9c:	04 
  44ab9d:	66 ff 05 d2 6b 48 00 	inc    WORD PTR ds:0x486bd2
  44aba4:	c7 05 d8 6b 48 00 00 	mov    DWORD PTR ds:0x486bd8,0x0
  44abab:	00 00 00 
  44abae:	c7 05 dc 6b 48 00 00 	mov    DWORD PTR ds:0x486bdc,0x0
  44abb5:	00 00 00 
  44abb8:	83 00 04             	add    DWORD PTR [eax],0x4
  44abbb:	5f                   	pop    edi
  44abbc:	5e                   	pop    esi
  44abbd:	5d                   	pop    ebp
  44abbe:	b8 01 00 00 00       	mov    eax,0x1
  44abc3:	5b                   	pop    ebx
  44abc4:	83 c4 20             	add    esp,0x20
  44abc7:	c3                   	ret
  44abc8:	5f                   	pop    edi
  44abc9:	5e                   	pop    esi
  44abca:	5d                   	pop    ebp
  44abcb:	b8 fe ff ff ff       	mov    eax,0xfffffffe
  44abd0:	5b                   	pop    ebx
  44abd1:	83 c4 20             	add    esp,0x20
  44abd4:	c3                   	ret
  44abd5:	8b 4c 24 38          	mov    ecx,DWORD PTR [esp+0x38]
  44abd9:	c7 06 00 00 00 00    	mov    DWORD PTR [esi],0x0
  44abdf:	33 c0                	xor    eax,eax
  44abe1:	5f                   	pop    edi
  44abe2:	8a 51 07             	mov    dl,BYTE PTR [ecx+0x7]
  44abe5:	5e                   	pop    esi
  44abe6:	80 fa 02             	cmp    dl,0x2
  44abe9:	5d                   	pop    ebp
  44abea:	0f 95 c0             	setne  al
  44abed:	83 c0 fd             	add    eax,0xfffffffd
  44abf0:	5b                   	pop    ebx
  44abf1:	83 c4 20             	add    esp,0x20
  44abf4:	c3                   	ret
  44abf5:	8d 49 00             	lea    ecx,[ecx+0x0]
  44abf8:	37                   	aaa
  44abf9:	aa                   	stos   BYTE PTR es:[edi],al
  44abfa:	44                   	inc    esp
  44abfb:	00 4d aa             	add    BYTE PTR [ebp-0x56],cl
  44abfe:	44                   	inc    esp
  44abff:	00 42 aa             	add    BYTE PTR [edx-0x56],al
  44ac02:	44                   	inc    esp
  44ac03:	00 4d aa             	add    BYTE PTR [ebp-0x56],cl
  44ac06:	44                   	inc    esp
  44ac07:	00 90 90 90 90 90    	add    BYTE PTR [eax-0x6f6f6f70],dl
  44ac0d:	90                   	nop
  44ac0e:	90                   	nop
  44ac0f:	90                   	nop
  44ac10:	cc                   	int3
  44ac11:	cc                   	int3
  44ac12:	cc                   	int3
  44ac13:	cc                   	int3
  44ac14:	cc                   	int3
  44ac15:	cc                   	int3
  44ac16:	cc                   	int3
  44ac17:	cc                   	int3
  44ac18:	cc                   	int3
  44ac19:	cc                   	int3
  44ac1a:	cc                   	int3
  44ac1b:	cc                   	int3
  44ac1c:	cc                   	int3
  44ac1d:	cc                   	int3
  44ac1e:	cc                   	int3
  44ac1f:	cc                   	int3
  44ac20:	cc                   	int3
  44ac21:	cc                   	int3
  44ac22:	cc                   	int3
  44ac23:	cc                   	int3
  44ac24:	cc                   	int3
  44ac25:	cc                   	int3
  44ac26:	cc                   	int3
  44ac27:	cc                   	int3
  44ac28:	cc                   	int3
  44ac29:	cc                   	int3
  44ac2a:	cc                   	int3
  44ac2b:	cc                   	int3
  44ac2c:	cc                   	int3
  44ac2d:	cc                   	int3
  44ac2e:	cc                   	int3
  44ac2f:	cc                   	int3
  44ac30:	cc                   	int3
  44ac31:	cc                   	int3
  44ac32:	cc                   	int3
  44ac33:	cc                   	int3
  44ac34:	cc                   	int3
  44ac35:	cc                   	int3
  44ac36:	cc                   	int3
  44ac37:	cc                   	int3
  44ac38:	cc                   	int3
  44ac39:	cc                   	int3
  44ac3a:	cc                   	int3
  44ac3b:	cc                   	int3
  44ac3c:	cc                   	int3
  44ac3d:	cc                   	int3
  44ac3e:	cc                   	int3
  44ac3f:	cc                   	int3
  44ac40:	cc                   	int3
  44ac41:	cc                   	int3
  44ac42:	cc                   	int3
  44ac43:	cc                   	int3
  44ac44:	cc                   	int3
  44ac45:	cc                   	int3
  44ac46:	cc                   	int3
  44ac47:	cc                   	int3
  44ac48:	cc                   	int3
  44ac49:	cc                   	int3
  44ac4a:	cc                   	int3
  44ac4b:	cc                   	int3
  44ac4c:	cc                   	int3
  44ac4d:	cc                   	int3
  44ac4e:	cc                   	int3
  44ac4f:	cc                   	int3
  44ac50:	cc                   	int3
  44ac51:	cc                   	int3
  44ac52:	cc                   	int3
  44ac53:	cc                   	int3
  44ac54:	cc                   	int3
  44ac55:	cc                   	int3
  44ac56:	cc                   	int3
  44ac57:	cc                   	int3
  44ac58:	cc                   	int3
  44ac59:	cc                   	int3
  44ac5a:	cc                   	int3
  44ac5b:	cc                   	int3
  44ac5c:	cc                   	int3
  44ac5d:	cc                   	int3
  44ac5e:	cc                   	int3
  44ac5f:	cc                   	int3
  44ac60:	cc                   	int3
  44ac61:	cc                   	int3
  44ac62:	cc                   	int3
  44ac63:	cc                   	int3
  44ac64:	cc                   	int3
  44ac65:	cc                   	int3
  44ac66:	cc                   	int3
  44ac67:	cc                   	int3
  44ac68:	cc                   	int3
  44ac69:	cc                   	int3
  44ac6a:	cc                   	int3
  44ac6b:	cc                   	int3
  44ac6c:	cc                   	int3
  44ac6d:	cc                   	int3
  44ac6e:	cc                   	int3
  44ac6f:	cc                   	int3
  44ac70:	cc                   	int3
  44ac71:	cc                   	int3
  44ac72:	cc                   	int3
  44ac73:	cc                   	int3
  44ac74:	cc                   	int3
  44ac75:	cc                   	int3
  44ac76:	cc                   	int3
  44ac77:	cc                   	int3
  44ac78:	cc                   	int3
  44ac79:	cc                   	int3
  44ac7a:	cc                   	int3
  44ac7b:	cc                   	int3
  44ac7c:	cc                   	int3
  44ac7d:	cc                   	int3
  44ac7e:	cc                   	int3
  44ac7f:	cc                   	int3
  44ac80:	cc                   	int3
  44ac81:	cc                   	int3
  44ac82:	cc                   	int3
  44ac83:	cc                   	int3
  44ac84:	cc                   	int3
  44ac85:	cc                   	int3
  44ac86:	cc                   	int3
  44ac87:	cc                   	int3
  44ac88:	cc                   	int3
  44ac89:	cc                   	int3
  44ac8a:	cc                   	int3
  44ac8b:	cc                   	int3
  44ac8c:	cc                   	int3
  44ac8d:	cc                   	int3
  44ac8e:	cc                   	int3
  44ac8f:	cc                   	int3
  44ac90:	cc                   	int3
  44ac91:	cc                   	int3
  44ac92:	cc                   	int3
  44ac93:	cc                   	int3
  44ac94:	cc                   	int3
  44ac95:	cc                   	int3
  44ac96:	cc                   	int3
  44ac97:	cc                   	int3
  44ac98:	cc                   	int3
  44ac99:	cc                   	int3
  44ac9a:	cc                   	int3
  44ac9b:	cc                   	int3
  44ac9c:	cc                   	int3
  44ac9d:	cc                   	int3
  44ac9e:	cc                   	int3
  44ac9f:	cc                   	int3
  44aca0:	cc                   	int3
  44aca1:	cc                   	int3
  44aca2:	cc                   	int3
  44aca3:	cc                   	int3
  44aca4:	cc                   	int3
  44aca5:	cc                   	int3
  44aca6:	cc                   	int3
  44aca7:	cc                   	int3
  44aca8:	cc                   	int3
  44aca9:	cc                   	int3
  44acaa:	cc                   	int3
  44acab:	cc                   	int3
  44acac:	cc                   	int3
  44acad:	cc                   	int3
  44acae:	cc                   	int3
  44acaf:	cc                   	int3
  44acb0:	cc                   	int3
  44acb1:	cc                   	int3
  44acb2:	cc                   	int3
  44acb3:	cc                   	int3
  44acb4:	cc                   	int3
  44acb5:	cc                   	int3
  44acb6:	cc                   	int3
  44acb7:	cc                   	int3
  44acb8:	cc                   	int3
  44acb9:	cc                   	int3
  44acba:	cc                   	int3
  44acbb:	cc                   	int3
  44acbc:	cc                   	int3
  44acbd:	cc                   	int3
  44acbe:	cc                   	int3
  44acbf:	cc                   	int3
  44acc0:	cc                   	int3
  44acc1:	cc                   	int3
  44acc2:	cc                   	int3
  44acc3:	cc                   	int3
  44acc4:	cc                   	int3
  44acc5:	cc                   	int3
  44acc6:	cc                   	int3
  44acc7:	cc                   	int3
  44acc8:	cc                   	int3
  44acc9:	cc                   	int3
  44acca:	cc                   	int3
  44accb:	cc                   	int3
  44accc:	cc                   	int3
  44accd:	cc                   	int3
  44acce:	cc                   	int3
  44accf:	cc                   	int3
  44acd0:	cc                   	int3
  44acd1:	cc                   	int3
  44acd2:	cc                   	int3
  44acd3:	cc                   	int3
  44acd4:	cc                   	int3
  44acd5:	cc                   	int3
  44acd6:	cc                   	int3
  44acd7:	cc                   	int3
  44acd8:	cc                   	int3
  44acd9:	cc                   	int3
  44acda:	cc                   	int3
  44acdb:	cc                   	int3
  44acdc:	cc                   	int3
  44acdd:	cc                   	int3
  44acde:	cc                   	int3
  44acdf:	cc                   	int3
  44ace0:	cc                   	int3
  44ace1:	cc                   	int3
  44ace2:	cc                   	int3
  44ace3:	cc                   	int3
  44ace4:	cc                   	int3
  44ace5:	cc                   	int3
  44ace6:	cc                   	int3
  44ace7:	cc                   	int3
  44ace8:	cc                   	int3
  44ace9:	cc                   	int3
  44acea:	cc                   	int3
  44aceb:	cc                   	int3
  44acec:	cc                   	int3
  44aced:	cc                   	int3
  44acee:	cc                   	int3
  44acef:	cc                   	int3
  44acf0:	cc                   	int3
  44acf1:	cc                   	int3
  44acf2:	cc                   	int3
  44acf3:	cc                   	int3
  44acf4:	cc                   	int3
  44acf5:	cc                   	int3
  44acf6:	cc                   	int3
  44acf7:	cc                   	int3
  44acf8:	cc                   	int3
  44acf9:	cc                   	int3
  44acfa:	cc                   	int3
  44acfb:	cc                   	int3
  44acfc:	cc                   	int3
  44acfd:	cc                   	int3
  44acfe:	cc                   	int3
  44acff:	cc                   	int3
  44ad00:	cc                   	int3
  44ad01:	cc                   	int3
  44ad02:	cc                   	int3
  44ad03:	cc                   	int3
  44ad04:	cc                   	int3
  44ad05:	cc                   	int3
  44ad06:	cc                   	int3
  44ad07:	cc                   	int3
  44ad08:	cc                   	int3
  44ad09:	cc                   	int3
  44ad0a:	cc                   	int3
  44ad0b:	cc                   	int3
  44ad0c:	cc                   	int3
  44ad0d:	cc                   	int3
  44ad0e:	cc                   	int3
  44ad0f:	cc                   	int3
  44ad10:	cc                   	int3
  44ad11:	cc                   	int3
  44ad12:	cc                   	int3
  44ad13:	cc                   	int3
  44ad14:	cc                   	int3
  44ad15:	cc                   	int3
  44ad16:	cc                   	int3
  44ad17:	cc                   	int3
  44ad18:	cc                   	int3
  44ad19:	cc                   	int3
  44ad1a:	cc                   	int3
  44ad1b:	cc                   	int3
  44ad1c:	cc                   	int3
  44ad1d:	cc                   	int3
  44ad1e:	cc                   	int3
  44ad1f:	cc                   	int3
  44ad20:	cc                   	int3
  44ad21:	cc                   	int3
  44ad22:	cc                   	int3
  44ad23:	cc                   	int3
  44ad24:	cc                   	int3
  44ad25:	cc                   	int3
  44ad26:	cc                   	int3
  44ad27:	cc                   	int3
  44ad28:	cc                   	int3
  44ad29:	cc                   	int3
  44ad2a:	cc                   	int3
  44ad2b:	cc                   	int3
  44ad2c:	cc                   	int3
  44ad2d:	cc                   	int3
  44ad2e:	cc                   	int3
  44ad2f:	cc                   	int3
  44ad30:	cc                   	int3
  44ad31:	cc                   	int3
  44ad32:	cc                   	int3
  44ad33:	cc                   	int3
  44ad34:	cc                   	int3
  44ad35:	cc                   	int3
  44ad36:	cc                   	int3
  44ad37:	cc                   	int3
  44ad38:	cc                   	int3
  44ad39:	cc                   	int3
  44ad3a:	cc                   	int3
  44ad3b:	cc                   	int3
  44ad3c:	cc                   	int3
  44ad3d:	cc                   	int3
  44ad3e:	cc                   	int3
  44ad3f:	cc                   	int3
  44ad40:	cc                   	int3
  44ad41:	cc                   	int3
  44ad42:	cc                   	int3
  44ad43:	cc                   	int3
  44ad44:	cc                   	int3
  44ad45:	cc                   	int3
  44ad46:	cc                   	int3
  44ad47:	cc                   	int3
  44ad48:	cc                   	int3
  44ad49:	cc                   	int3
  44ad4a:	cc                   	int3
  44ad4b:	cc                   	int3
  44ad4c:	cc                   	int3
  44ad4d:	cc                   	int3
  44ad4e:	cc                   	int3
  44ad4f:	cc                   	int3
  44ad50:	83 ec 10             	sub    esp,0x10
  44ad53:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  44ad57:	53                   	push   ebx
  44ad58:	55                   	push   ebp
  44ad59:	56                   	push   esi
  44ad5a:	57                   	push   edi
  44ad5b:	8b 7c 24 34          	mov    edi,DWORD PTR [esp+0x34]
  44ad5f:	83 ff 01             	cmp    edi,0x1
  44ad62:	75 0c                	jne    0x44ad70
  44ad64:	8d 88 8a 00 00 00    	lea    ecx,[eax+0x8a]
  44ad6a:	89 4c 24 34          	mov    DWORD PTR [esp+0x34],ecx
  44ad6e:	eb 0a                	jmp    0x44ad7a
  44ad70:	8d 90 8e 00 00 00    	lea    edx,[eax+0x8e]
  44ad76:	89 54 24 34          	mov    DWORD PTR [esp+0x34],edx
  44ad7a:	80 78 07 02          	cmp    BYTE PTR [eax+0x7],0x2
  44ad7e:	75 29                	jne    0x44ada9
  44ad80:	8a 48 7b             	mov    cl,BYTE PTR [eax+0x7b]
  44ad83:	84 c9                	test   cl,cl
  44ad85:	75 22                	jne    0x44ada9
  44ad87:	8b 80 a6 00 00 00    	mov    eax,DWORD PTR [eax+0xa6]
  44ad8d:	8b 00                	mov    eax,DWORD PTR [eax]
  44ad8f:	80 78 31 01          	cmp    BYTE PTR [eax+0x31],0x1
  44ad93:	74 14                	je     0x44ada9
  44ad95:	8b 48 36             	mov    ecx,DWORD PTR [eax+0x36]
  44ad98:	f6 41 20 10          	test   BYTE PTR [ecx+0x20],0x10
  44ad9c:	75 0b                	jne    0x44ada9
  44ad9e:	b9 01 00 00 00       	mov    ecx,0x1
  44ada3:	89 4c 24 24          	mov    DWORD PTR [esp+0x24],ecx
  44ada7:	eb 0c                	jmp    0x44adb5
  44ada9:	c7 44 24 24 00 00 00 	mov    DWORD PTR [esp+0x24],0x0
  44adb0:	00 
  44adb1:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  44adb5:	8b 5c 24 28          	mov    ebx,DWORD PTR [esp+0x28]
  44adb9:	8b 03                	mov    eax,DWORD PTR [ebx]
  44adbb:	85 c0                	test   eax,eax
  44adbd:	0f 85 87 00 00 00    	jne    0x44ae4a
  44adc3:	85 c9                	test   ecx,ecx
  44adc5:	74 39                	je     0x44ae00
  44adc7:	8b 54 24 34          	mov    edx,DWORD PTR [esp+0x34]
  44adcb:	8b 02                	mov    eax,DWORD PTR [edx]
  44adcd:	85 c0                	test   eax,eax
  44adcf:	74 2f                	je     0x44ae00
  44add1:	8b 6c 24 30          	mov    ebp,DWORD PTR [esp+0x30]
  44add5:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  44add9:	6a 00                	push   0x0
  44addb:	55                   	push   ebp
  44addc:	56                   	push   esi
  44addd:	50                   	push   eax
  44adde:	e8 15 c2 01 00       	call   0x466ff8
  44ade3:	85 c0                	test   eax,eax
  44ade5:	89 03                	mov    DWORD PTR [ebx],eax
  44ade7:	75 59                	jne    0x44ae42
  44ade9:	68 dc 00 00 00       	push   0xdc
  44adee:	e8 a9 75 fb ff       	call   0x40239c
  44adf3:	83 c4 04             	add    esp,0x4
  44adf6:	33 c0                	xor    eax,eax
  44adf8:	5f                   	pop    edi
  44adf9:	5e                   	pop    esi
  44adfa:	5d                   	pop    ebp
  44adfb:	5b                   	pop    ebx
  44adfc:	83 c4 10             	add    esp,0x10
  44adff:	c3                   	ret
  44ae00:	8b 6c 24 30          	mov    ebp,DWORD PTR [esp+0x30]
  44ae04:	33 c0                	xor    eax,eax
  44ae06:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  44ae0a:	8b 15 c0 6c 4a 00    	mov    edx,DWORD PTR ds:0x4a6cc0
  44ae10:	85 c9                	test   ecx,ecx
  44ae12:	8b 0d 64 68 48 00    	mov    ecx,DWORD PTR ds:0x486864
  44ae18:	0f 95 c0             	setne  al
  44ae1b:	50                   	push   eax
  44ae1c:	57                   	push   edi
  44ae1d:	51                   	push   ecx
  44ae1e:	6a 00                	push   0x0
  44ae20:	55                   	push   ebp
  44ae21:	56                   	push   esi
  44ae22:	52                   	push   edx
  44ae23:	e8 2e c1 01 00       	call   0x466f56
  44ae28:	85 c0                	test   eax,eax
  44ae2a:	89 03                	mov    DWORD PTR [ebx],eax
  44ae2c:	75 14                	jne    0x44ae42
  44ae2e:	6a 15                	push   0x15
  44ae30:	e8 67 75 fb ff       	call   0x40239c
  44ae35:	83 c4 04             	add    esp,0x4
  44ae38:	33 c0                	xor    eax,eax
  44ae3a:	5f                   	pop    edi
  44ae3b:	5e                   	pop    esi
  44ae3c:	5d                   	pop    ebp
  44ae3d:	5b                   	pop    ebx
  44ae3e:	83 c4 10             	add    esp,0x10
  44ae41:	c3                   	ret
  44ae42:	89 2d 88 58 48 00    	mov    DWORD PTR ds:0x485888,ebp
  44ae48:	eb 37                	jmp    0x44ae81
  44ae4a:	8b 0d 88 58 48 00    	mov    ecx,DWORD PTR ds:0x485888
  44ae50:	8b 6c 24 30          	mov    ebp,DWORD PTR [esp+0x30]
  44ae54:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  44ae58:	51                   	push   ecx
  44ae59:	55                   	push   ebp
  44ae5a:	56                   	push   esi
  44ae5b:	50                   	push   eax
  44ae5c:	e8 97 c1 01 00       	call   0x466ff8
  44ae61:	85 c0                	test   eax,eax
  44ae63:	89 03                	mov    DWORD PTR [ebx],eax
  44ae65:	75 14                	jne    0x44ae7b
  44ae67:	6a 16                	push   0x16
  44ae69:	e8 2e 75 fb ff       	call   0x40239c
  44ae6e:	83 c4 04             	add    esp,0x4
  44ae71:	33 c0                	xor    eax,eax
  44ae73:	5f                   	pop    edi
  44ae74:	5e                   	pop    esi
  44ae75:	5d                   	pop    ebp
  44ae76:	5b                   	pop    ebx
  44ae77:	83 c4 10             	add    esp,0x10
  44ae7a:	c3                   	ret
  44ae7b:	01 2d 88 58 48 00    	add    DWORD PTR ds:0x485888,ebp
  44ae81:	a1 10 6d 4a 00       	mov    eax,ds:0x4a6d10
  44ae86:	a8 10                	test   al,0x10
  44ae88:	0f 84 16 01 00 00    	je     0x44afa4
  44ae8e:	a9 ff ff 00 00       	test   eax,0xffff
  44ae93:	74 1d                	je     0x44aeb2
  44ae95:	8b 15 84 58 48 00    	mov    edx,DWORD PTR ds:0x485884
  44ae9b:	a1 88 58 48 00       	mov    eax,ds:0x485888
  44aea0:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  44aea2:	52                   	push   edx
  44aea3:	50                   	push   eax
  44aea4:	51                   	push   ecx
  44aea5:	68 18 b0 47 00       	push   0x47b018
  44aeaa:	e8 44 69 fb ff       	call   0x4017f3
  44aeaf:	83 c4 10             	add    esp,0x10
  44aeb2:	83 ff 01             	cmp    edi,0x1
  44aeb5:	75 58                	jne    0x44af0f
  44aeb7:	bf 2b 00 00 00       	mov    edi,0x2b
  44aebc:	3b ef                	cmp    ebp,edi
  44aebe:	7e 33                	jle    0x44aef3
  44aec0:	8a 1c 37             	mov    bl,BYTE PTR [edi+esi*1]
  44aec3:	c6 04 37 00          	mov    BYTE PTR [edi+esi*1],0x0
  44aec7:	f7 05 10 6d 4a 00 ff 	test   DWORD PTR ds:0x4a6d10,0xffff
  44aece:	ff 00 00 
  44aed1:	74 0e                	je     0x44aee1
  44aed3:	56                   	push   esi
  44aed4:	68 10 b0 47 00       	push   0x47b010
  44aed9:	e8 15 69 fb ff       	call   0x4017f3
  44aede:	83 c4 08             	add    esp,0x8
  44aee1:	88 1c 37             	mov    BYTE PTR [edi+esi*1],bl
  44aee4:	8b 5c 24 28          	mov    ebx,DWORD PTR [esp+0x28]
  44aee8:	2b ef                	sub    ebp,edi
  44aeea:	03 f7                	add    esi,edi
  44aeec:	bf 35 00 00 00       	mov    edi,0x35
  44aef1:	eb c9                	jmp    0x44aebc
  44aef3:	f7 05 10 6d 4a 00 ff 	test   DWORD PTR ds:0x4a6d10,0xffff
  44aefa:	ff 00 00 
  44aefd:	74 51                	je     0x44af50
  44aeff:	56                   	push   esi
  44af00:	68 f0 ae 47 00       	push   0x47aef0
  44af05:	e8 e9 68 fb ff       	call   0x4017f3
  44af0a:	83 c4 08             	add    esp,0x8
  44af0d:	eb 41                	jmp    0x44af50
  44af0f:	f7 05 10 6d 4a 00 ff 	test   DWORD PTR ds:0x4a6d10,0xffff
  44af16:	ff 00 00 
  44af19:	74 0d                	je     0x44af28
  44af1b:	68 78 72 47 00       	push   0x477278
  44af20:	e8 ce 68 fb ff       	call   0x4017f3
  44af25:	83 c4 04             	add    esp,0x4
  44af28:	55                   	push   ebp
  44af29:	56                   	push   esi
  44af2a:	68 98 ae 47 00       	push   0x47ae98
  44af2f:	e8 be 64 fb ff       	call   0x4013f2
  44af34:	a1 10 6d 4a 00       	mov    eax,ds:0x4a6d10
  44af39:	83 c4 0c             	add    esp,0xc
  44af3c:	a9 ff ff 00 00       	test   eax,0xffff
  44af41:	74 0d                	je     0x44af50
  44af43:	68 0c b0 47 00       	push   0x47b00c
  44af48:	e8 a6 68 fb ff       	call   0x4017f3
  44af4d:	83 c4 04             	add    esp,0x4
  44af50:	a1 84 58 48 00       	mov    eax,ds:0x485884
  44af55:	8b 15 88 58 48 00    	mov    edx,DWORD PTR ds:0x485888
  44af5b:	8b c8                	mov    ecx,eax
  44af5d:	40                   	inc    eax
  44af5e:	a3 84 58 48 00       	mov    ds:0x485884,eax
  44af63:	52                   	push   edx
  44af64:	51                   	push   ecx
  44af65:	8d 44 24 18          	lea    eax,[esp+0x18]
  44af69:	68 04 b0 47 00       	push   0x47b004
  44af6e:	50                   	push   eax
  44af6f:	ff 15 7c 61 6c 00    	call   DWORD PTR ds:0x6c617c
  44af75:	8b 13                	mov    edx,DWORD PTR [ebx]
  44af77:	83 c4 0c             	add    esp,0xc
  44af7a:	40                   	inc    eax
  44af7b:	8d 4c 24 14          	lea    ecx,[esp+0x14]
  44af7f:	50                   	push   eax
  44af80:	51                   	push   ecx
  44af81:	52                   	push   edx
  44af82:	e8 71 c0 01 00       	call   0x466ff8
  44af87:	85 c0                	test   eax,eax
  44af89:	89 03                	mov    DWORD PTR [ebx],eax
  44af8b:	75 17                	jne    0x44afa4
  44af8d:	68 dc 00 00 00       	push   0xdc
  44af92:	e8 05 74 fb ff       	call   0x40239c
  44af97:	83 c4 04             	add    esp,0x4
  44af9a:	33 c0                	xor    eax,eax
  44af9c:	5f                   	pop    edi
  44af9d:	5e                   	pop    esi
  44af9e:	5d                   	pop    ebp
  44af9f:	5b                   	pop    ebx
  44afa0:	83 c4 10             	add    esp,0x10
  44afa3:	c3                   	ret
  44afa4:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  44afa8:	85 c0                	test   eax,eax
  44afaa:	74 08                	je     0x44afb4
  44afac:	8b 4c 24 34          	mov    ecx,DWORD PTR [esp+0x34]
  44afb0:	8b 03                	mov    eax,DWORD PTR [ebx]
  44afb2:	89 01                	mov    DWORD PTR [ecx],eax
  44afb4:	8b 03                	mov    eax,DWORD PTR [ebx]
  44afb6:	5f                   	pop    edi
  44afb7:	5e                   	pop    esi
  44afb8:	5d                   	pop    ebp
  44afb9:	5b                   	pop    ebx
  44afba:	83 c4 10             	add    esp,0x10
  44afbd:	c3                   	ret
