==== mbdde.exe

/root/PL/PCU_old/H/mmc2/mbdde.exe:     file format pei-i386


Disassembly of section .text:

00431d30 <.text+0x30d30>:
  431d30:	ff 25 30 a6 44 00    	jmp    DWORD PTR ds:0x44a630
  431d36:	ff 25 2c a6 44 00    	jmp    DWORD PTR ds:0x44a62c
  431d3c:	ff 25 28 a6 44 00    	jmp    DWORD PTR ds:0x44a628
  431d42:	ff 25 24 a6 44 00    	jmp    DWORD PTR ds:0x44a624
  431d48:	ff 25 20 a6 44 00    	jmp    DWORD PTR ds:0x44a620
  431d4e:	ff 25 1c a6 44 00    	jmp    DWORD PTR ds:0x44a61c
  431d54:	ff 25 18 a6 44 00    	jmp    DWORD PTR ds:0x44a618
  431d5a:	ff 25 14 a6 44 00    	jmp    DWORD PTR ds:0x44a614
  431d60:	ff 25 10 a6 44 00    	jmp    DWORD PTR ds:0x44a610
  431d66:	ff 25 0c a6 44 00    	jmp    DWORD PTR ds:0x44a60c
  431d6c:	ff 25 08 a6 44 00    	jmp    DWORD PTR ds:0x44a608
  431d72:	ff 25 04 a6 44 00    	jmp    DWORD PTR ds:0x44a604
  431d78:	ff 25 00 a6 44 00    	jmp    DWORD PTR ds:0x44a600
  431d7e:	ff 25 fc a5 44 00    	jmp    DWORD PTR ds:0x44a5fc
  431d84:	ff 25 f8 a5      	jmp    DWORD PTR ds:0x44a5f8
==== ncdde.exe

/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00466ef0 <.text+0x65ef0>:
  466ef0:	ff 25 58 63 6c 00    	jmp    DWORD PTR ds:0x6c6358
  466ef6:	ff 25 5c 63 6c 00    	jmp    DWORD PTR ds:0x6c635c
  466efc:	ff 25 60 63 6c 00    	jmp    DWORD PTR ds:0x6c6360
  466f02:	ff 25 34 63 6c 00    	jmp    DWORD PTR ds:0x6c6334
  466f08:	ff 25 30 63 6c 00    	jmp    DWORD PTR ds:0x6c6330
  466f0e:	ff 25 2c 63 6c 00    	jmp    DWORD PTR ds:0x6c632c
  466f14:	ff 25 28 63 6c 00    	jmp    DWORD PTR ds:0x6c6328
  466f1a:	ff 25 24 63 6c 00    	jmp    DWORD PTR ds:0x6c6324
  466f20:	ff 25 20 63 6c 00    	jmp    DWORD PTR ds:0x6c6320
  466f26:	ff 25 1c 63 6c 00    	jmp    DWORD PTR ds:0x6c631c
  466f2c:	ff 25 18 63 6c 00    	jmp    DWORD PTR ds:0x6c6318
  466f32:	ff 25 14 63 6c 00    	jmp    DWORD PTR ds:0x6c6314
  466f38:	ff 25 64 63 6c 00    	jmp    DWORD PTR ds:0x6c6364
  466f3e:	ff 25 48 63 6c 00    	jmp    DWORD PTR ds:0x6c6348
  466f44:	ff 25 44 63 6c 00    	jmp    DWORD PTR ds:0x6c6344
  466f4a:	ff 25 40 63 6c 00    	jmp    DWORD PTR ds:0x6c6340
  466f50:	ff 25 3c 63 6c 00    	jmp    DWORD PTR ds:0x6c633c
  466f56:	ff 25 38 63 6c 00    	jmp    DWORD PTR ds:0x6c6338
  466f5c:	ff 25 d8 62 6c 00    	jmp    DWORD PTR ds:0x6c62d8
  466f62:	ff 25 7c 62 6c 00    	jmp    DWORD PTR ds:0x6c627c
  466f68:	ff 25 80 62 6c 00    	jmp    DWORD PTR ds:0x6c6280
  466f6e:	ff 25 84 62 6c 00    	jmp    DWORD PTR ds:0x6c6284
  466f74:	ff 25 88 62 6c 00    	jmp    DWORD PTR ds:0x6c6288
  466f7a:	ff 25 8c 62 6c 00    	jmp    DWORD PTR ds:0x6c628c
==== dhserver.exe

/root/PL/PCU_old/H/mmc2/dhserver.exe:     file format pei-i386


Disassembly of section .text:

00440940 <.text+0x3f940>:
  440940:	ff 25 50 cc 49 00    	jmp    DWORD PTR ds:0x49cc50
  440946:	ff 25 4c cc 49 00    	jmp    DWORD PTR ds:0x49cc4c
  44094c:	ff 25 64 d2 49 00    	jmp    DWORD PTR ds:0x49d264
  440952:	ff 25 68 d2 49 00    	jmp    DWORD PTR ds:0x49d268
  440958:	ff 25 6c d2 49 00    	jmp    DWORD PTR ds:0x49d26c
  44095e:	ff 25 70 d2 49 00    	jmp    DWORD PTR ds:0x49d270
  440964:	ff 25 74 d2 49 00    	jmp    DWORD PTR ds:0x49d274
  44096a:	ff 25 84 d2 49 00    	jmp    DWORD PTR ds:0x49d284
  440970:	ff 25 80 d2 49 00    	jmp    DWORD PTR ds:0x49d280
  440976:	ff 25 7c d2 49 00    	jmp    DWORD PTR ds:0x49d27c
  44097c:	ff 25 78 d2 49 00    	jmp    DWORD PTR ds:0x49d278
  440982:	ff 25 5c d2 49 00    	jmp    DWORD PTR ds:0x49d25c
  440988:	ff 25 58 d2 49 00    	jmp    DWORD PTR ds:0x49d258
  44098e:	ff 25 54 d2 49 00    	jmp    DWORD PTR ds:0x49d254
  440994:	ff 25 50 d2 49 00    	jmp    DWORD PTR ds:0x49d250
  44099a:	ff 25 4c d2 49 00    	jmp    DWORD PTR ds:0x49d24c
  4409a0:	ff 25 48 d2 49 00    	jmp    DWORD PTR ds:0x49d248
  4409a6:	ff 25 44 d2 49 00    	jmp    DWORD PTR ds:0x49d244
  4409ac:	ff 25 40 d2 49 00    	jmp    DWORD PTR ds:0x49d240
  4409b2:	ff 25 3c d2 49 00    	jmp    DWORD PTR ds:0x49d23c
  4409b8:	ff 25 38 d2 49 00    	jmp    DWORD PTR ds:0x49d238
  4409be:	ff 25 34 d2 49 00    	jmp    DWORD PTR ds:0x49d234
  4409c4:	ff 25 30 d2 49 00    	jmp    DWORD PTR ds:0x49d230
  4409ca:	ff 25 2c d2 49 00    	jmp    DWORD PTR ds:0x49d22c
==== ARServer.exe

/root/PL/PCU_old/H/mmc2/ARServer.exe:     file format pei-i386


Disassembly of section .text:

0042a900 <.text+0x29900>:
  42a900:	ff 25 d0 d4 42 00    	jmp    DWORD PTR ds:0x42d4d0
  42a906:	ff 25 cc d4 42 00    	jmp    DWORD PTR ds:0x42d4cc
  42a90c:	ff 25 c8 d4 42 00    	jmp    DWORD PTR ds:0x42d4c8
  42a912:	ff 25 c4 d4 42 00    	jmp    DWORD PTR ds:0x42d4c4
  42a918:	ff 25 c0 d4 42 00    	jmp    DWORD PTR ds:0x42d4c0
  42a91e:	ff 25 bc d4 42 00    	jmp    DWORD PTR ds:0x42d4bc
  42a924:	ff 25 b8 d4 42 00    	jmp    DWORD PTR ds:0x42d4b8
  42a92a:	ff 25 64 d4 42 00    	jmp    DWORD PTR ds:0x42d464
  42a930:	ff 25 24 d4 42 00    	jmp    DWORD PTR ds:0x42d424
  42a936:	ff 25 28 d4 42 00    	jmp    DWORD PTR ds:0x42d428
  42a93c:	ff 25 2c d4 42 00    	jmp    DWORD PTR ds:0x42d42c
  42a942:	ff 25 30 d4 42 00    	jmp    DWORD PTR ds:0x42d430
  42a948:	ff 25 34 d4 42 00    	jmp    DWORD PTR ds:0x42d434
  42a94e:	ff 25 38 d4 42 00    	jmp    DWORD PTR ds:0x42d438
  42a954:	ff 25 3c d4 42 00    	jmp    DWORD PTR ds:0x42d43c
  42a95a:	ff 25 40 d4 42 00    	jmp    DWORD PTR ds:0x42d440
  42a960:	ff 25 44 d4 42 00    	jmp    DWORD PTR ds:0x42d444
  42a966:	ff 25 48 d4 42 00    	jmp    DWORD PTR ds:0x42d448
  42a96c:	ff 25 4c d4 42 00    	jmp    DWORD PTR ds:0x42d44c
  42a972:	ff 25 50 d4 42 00    	jmp    DWORD PTR ds:0x42d450
  42a978:	ff 25 54 d4 42 00    	jmp    DWORD PTR ds:0x42d454
  42a97e:	ff 25 58 d4 42 00    	jmp    DWORD PTR ds:0x42d458
  42a984:	ff 25 5c d4 42 00    	jmp    DWORD PTR ds:0x42d45c
  42a98a:	ff 25 60 d4 42 00    	jmp    DWORD PTR ds:0x42d460
  42a990:	ff 25 fc d4 42 00    	jmp    DWORD PTR ds:0x42d4fc
  42a996:	ff 25 68 d4 42 00    	jmp    DWORD PTR ds:0x42d468
  42a99c:	ff 25 6c d4 42 00    	jmp    DWORD PTR ds:0x42d46c
  42a9a2:	ff 25 70 d4 42 00    	jmp    DWORD PTR ds:0x42d470
  42a9a8:	ff 25 74 d4 42 00    	jmp    DWORD PTR ds:0x42d474
  42a9ae:	ff 25 78 d4 42 00    	jmp    DWORD PTR ds:0x42d478
  42a9b4:	ff 25 7c d4 42 00    	jmp    DWORD PTR ds:0x42d47c
  42a9ba:	ff 25 80 d4 42 00    	jmp    DWORD PTR ds:0x42d480
  42a9c0:	ff 25 84 d4 42 00    	jmp    DWORD PTR ds:0x42d484
  42a9c6:	ff 25 88 d4 42 00    	jmp    DWORD PTR ds:0x42d488
  42a9cc:	ff 25 8c d4      	jmp    DWORD PTR ds:0x42d48c
==== rngkrnl.exe

/root/PL/PCU_old/H/mmc2/rngkrnl.exe:     file format pei-i386


Disassembly of section .text:

0041f700 <.text+0x1e700>:
  41f700:	00 5f 5e             	add    BYTE PTR [edi+0x5e],bl
  41f703:	a3 18 3a 45 00       	mov    ds:0x453a18,eax
  41f708:	5b                   	pop    ebx
  41f709:	81 c4 68 05 00 00    	add    esp,0x568
  41f70f:	c3                   	ret
  41f710:	a1 18 3a 45 00       	mov    eax,ds:0x453a18
  41f715:	83 ec 64             	sub    esp,0x64
  41f718:	85 c0                	test   eax,eax
  41f71a:	74 2b                	je     0x41f747
  41f71c:	8b 15 9c df 42 00    	mov    edx,DWORD PTR ds:0x42df9c
  41f722:	33 c0                	xor    eax,eax
  41f724:	85 d2                	test   edx,edx
  41f726:	7e 0e                	jle    0x41f736
  41f728:	8d 4c 24 00          	lea    ecx,[esp+0x0]
  41f72c:	89 01                	mov    DWORD PTR [ecx],eax
  41f72e:	40                   	inc    eax
  41f72f:	83 c1 04             	add    ecx,0x4
  41f732:	3b c2                	cmp    eax,edx
  41f734:	7c f6                	jl     0x41f72c
  41f736:	8d 44 24 00          	lea    eax,[esp+0x0]
  41f73a:	68 94 30 45 00       	push   0x453094
  41f73f:	50                   	push   eax
  41f740:	52                   	push   edx
  41f741:	ff 15 ec 81 42 00    	call   DWORD PTR ds:0x4281ec
  41f747:	83 c4 64             	add    esp,0x64
  41f74a:	c3                   	ret
  41f74b:	90                   	nop
  41f74c:	90                   	nop
  41f74d:	90                   	nop
  41f74e:	90                   	nop
  41f74f:	90                   	nop
  41f750:	ff 25 d0 80 42 00    	jmp    DWORD PTR ds:0x4280d0
  41f756:	ff 25 d4 82 42 00    	jmp    DWORD PTR ds:0x4282d4
  41f75c:	ff 25 d0 82 42 00    	jmp    DWORD PTR ds:0x4282d0
  41f762:	ff 25 cc 82 42 00    	jmp    DWORD PTR ds:0x4282cc
  41f768:	ff 25 c8 82 42 00    	jmp    DWORD PTR ds:0x4282c8
  41f76e:	ff 25 c4 82 42 00    	jmp    DWORD PTR ds:0x4282c4
  41f774:	ff 25 c0 82 42 00    	jmp    DWORD PTR ds:0x4282c0
  41f77a:	ff 25 bc 82 42 00    	jmp    DWORD PTR ds:0x4282bc
  41f780:	ff 25 b8 82 42 00    	jmp    DWORD PTR ds:0x4282b8
  41f786:	ff 25 b4 82 42 00    	jmp    DWORD PTR ds:0x4282b4
  41f78c:	ff 25 b0 82 42 00    	jmp    DWORD PTR ds:0x4282b0
  41f792:	ff 25 ac 82 42 00    	jmp    DWORD PTR ds:0x4282ac
  41f798:	ff 25 20 82 42 00    	jmp    DWORD PTR ds:0x428220
  41f79e:	ff 25 1c 82 42 00    	jmp    DWORD PTR ds:0x42821c
  41f7a4:	ff 25 18 82 42 00    	jmp    DWORD PTR ds:0x428218
  41f7aa:	ff 25 10 82 42 00    	jmp    DWORD PTR ds:0x428210
  41f7b0:	8b 54 24 04          	mov    edx,DWORD PTR [esp+0x4]
  41f7b4:	89 2a                	mov    DWORD PTR [edx],ebp
  41f7b6:	89 5a 04             	mov    DWORD PTR [edx+0x4],ebx
  41f7b9:	89 7a 08             	mov    DWORD PTR [edx+0x8],edi
  41f7bc:	89 72 0c             	mov    DWORD PTR [edx+0xc],esi
  41f7bf:	89 62 10             	mov    DWORD PTR [edx+0x10],esp
  41f7c2:	8b 04 24             	mov    eax,DWORD PTR [esp]
  41f7c5:	89 42 14             	mov    DWORD PTR [edx+0x14],eax
  41f7c8:	c7 42 20 30 32 43 56 	mov    DWORD PTR [edx+0x20],0x56433230
  41f7cf:	c7       	mov    DWORD PTR [edx+0x24],0x0
