# Phase 7 independent verification: ncdde.exe request dispatcher and DdeCreateDataHandle

## Artifact
- Binary: `PCU_old/H/mmc2/ncdde.exe`
- SHA-256: `40a030e0a7364aa358ae36494be1304810855997fb81804db91ea6fc05223916`
- PE32 image base: `0x00400000`
- Tools: GNU objdump 2.44, Rizin 0.10.0, Ghidra 12.2 PUBLIC headless

## Function boundaries / conventions
- Ghidra recovered `FUN_00448AC0`, body `0x00448AC0..0x00449AB7`.
- `0x00449173`, `0x00449265`, and `0x004492BD` are interior basic blocks, not function entries (Ghidra returned NO_FUNCTION at each).
- Rizin classified the containing function as `cdecl`; objdump shows standard EBP frame and `ret` epilogue. The request-code value is loaded from `[ebp+0x08]` into ESI; `[ebp+0x0C]` is used as the format/state value.
- `0x00466F56` is a six-byte import thunk (`ff 25 38 63 6c 00`: `jmp dword ptr [0x006c6338]`). Ghidra names the imported function `DdeCreateDataHandle` and classifies the thunk `__stdcall`; PE import table names IAT `0x006c6338` as `DdeCreateDataHandle`.

## Exact branch and call
At `0x449173`:
- `mov eax,esi; sub eax,0x20b0; je 0x449265`
- otherwise tests `0x32` and `0x1f6e` before default dispatch.
Thus the direct edge `0x449173 -> 0x449265` is accepted only for dispatch code `0x20B0`.

At `0x449265`, the branch rejects if global byte `[0x4a6d16]` is nonzero, loads `[ebp+0x0c]` into ESI, and accepts the create-data path only when ESI equals `7` (after checks against `1` and `[0x499950]`).

At `0x4492BD`, immediately preceding pushes are:
```
0x4492b1 push edi       ; cbOff
0x4492b2 push esi       ; wFmt, constrained to 7 on this path
0x4492b3 push edx       ; hszItem = [0x486864]
0x4492b4 push edi       ; afCmd
0x4492b5 push 6         ; cb
0x4492b7 push 0x479c64  ; pSrc = ASCII "Ncdde"
0x4492bc push eax       ; idInst = [0x4a6cc0]
0x4492bd call 0x466f56
```
The call jumps to the USER32 import through IAT `0x006c6338`. It then jumps to common result handling at `0x44992A`, where `mov esi,eax` consumes the returned handle/result.

## Accepted provenance edges
- `0x448AC0 -> 0x449173` (containing-function CFG path)
- `0x449173 -> 0x449265` when dispatch code is exactly `0x20B0`
- `0x449265 -> 0x4492BD` when format/state ESI is exactly `7` and preceding guards pass
- seven immediate argument-origin edges listed above -> `0x4492BD`
- `0x4492BD -> 0x466F56 -> [0x006C6338] -> USER32!DdeCreateDataHandle`
- `0x4492BD -> 0x44992A` (post-call jump)

## Rejected / blockers
- No accepted edge from a counter to any API argument.
- No accepted edge from a claimed 20-byte/header object or offsets `+6/+7` to `pSrc`, `cb`, or any other call argument.
- No accepted callback `XTYP_REQUEST` -> `0x449173` or callback -> serializer edge; the `0x20B0` value here is only proven as the containing dispatcher’s first argument value.
- No exact binary format/serializer semantics beyond the literal source pointer and `cb=6`; `wFmt=7` is an observed branch constraint, not a proven protocol format meaning.

Graph outputs: `research/graphs/COUNTER_ORIGIN_GRAPH.dot` and `.svg`.
