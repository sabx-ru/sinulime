/root/PL/PCU_old/H/mmc2/mbdde.exe:     file format pei-i386


Disassembly of section .text:

00431ce0 <.text+0x30ce0>:
  431ce0:	44                   	inc    esp
  431ce1:	00 ff                	add    bh,bh
  431ce3:	25 3c a2 44 00       	and    eax,0x44a23c
  431ce8:	ff 25 40 a2 44 00    	jmp    DWORD PTR ds:0x44a240
  431cee:	ff 25 44 a2 44 00    	jmp    DWORD PTR ds:0x44a244
  431cf4:	ff 25 48 a2 44 00    	jmp    DWORD PTR ds:0x44a248
  431cfa:	ff 25 4c a2 44 00    	jmp    DWORD PTR ds:0x44a24c
  431d00:	ff 25 50 a2 44 00    	jmp    DWORD PTR ds:0x44a250
  431d06:	ff 25 4c a6 44 00    	jmp    DWORD PTR ds:0x44a64c
  431d0c:	ff 25 48 a6 44 00    	jmp    DWORD PTR ds:0x44a648
  431d12:	ff 25 44 a6 44 00    	jmp    DWORD PTR ds:0x44a644
  431d18:	ff 25 40 a6 44 00    	jmp    DWORD PTR ds:0x44a640
  431d1e:	ff 25 3c a6 44 00    	jmp    DWORD PTR ds:0x44a63c
  431d24:	ff 25 38 a6 44 00    	jmp    DWORD PTR ds:0x44a638
  431d2a:	ff 25 34 a6 44 00    	jmp    DWORD PTR ds:0x44a634
  431d30:	ff 25 30 a6 44 00    	jmp    DWORD PTR ds:0x44a630
  431d36:	ff 25 2c a6 44 00    	jmp    DWORD PTR ds:0x44a62c
  431d3c:	ff 25 28 a6 44 00    	jmp    DWORD PTR ds:0x44a628
  431d42:	ff 25 24 a6 44 00    	jmp    DWORD PTR ds:0x44a624
  431d48:	ff 25 20 a6 44 00    	jmp    DWORD PTR ds:0x44a620
  431d4e:	ff 25 1c a6 44 00    	jmp    DWORD PTR ds:0x44a61c
  431d54:	ff 25 18 a6 44 00    	jmp    DWORD PTR ds:0x44a618
  431d5a:	ff 25 14 a6 44 00    	jmp    DWORD PTR ds:0x44a614
  431d60:	ff 25 10 a6 44 00    	jmp    DWORD PTR ds:0x44a610
  431d66:	ff 25 0c a6 44 00    	jmp    DWORD PTR ds:0x44a60c
  431d6c:	ff 25 08 a6 44 00    	jmp    DWORD PTR ds:0x44a608
  431d72:	ff 25 04 a6 44 00    	jmp    DWORD PTR ds:0x44a604
  431d78:	ff 25 00 a6 44 00    	jmp    DWORD PTR ds:0x44a600
  431d7e:	ff 25 fc a5 44 00    	jmp    DWORD PTR ds:0x44a5fc
  431d84:	ff 25 f8 a5 44 00    	jmp    DWORD PTR ds:0x44a5f8
  431d8a:	ff 25 f4 a5 44 00    	jmp    DWORD PTR ds:0x44a5f4
  431d90:	ff 25 f0 a5 44 00    	jmp    DWORD PTR ds:0x44a5f0
  431d96:	ff 25 ec a5 44 00    	jmp    DWORD PTR ds:0x44a5ec
  431d9c:	ff                   	.byte 0xff
  431d9d:	25                   	.byte 0x25
  431d9e:	e8                   	.byte 0xe8
  431d9f:	a5                   	movs   DWORD PTR es:[edi],DWORD PTR ds:[esi]