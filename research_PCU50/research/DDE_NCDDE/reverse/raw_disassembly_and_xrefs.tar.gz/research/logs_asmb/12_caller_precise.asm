
/root/PL/PCU_old/H/mmc2/mbdde.exe:     file format pei-i386


Disassembly of section .text:

0040be90 <.text+0xae90>:
  40be90:	d1 49 8d             	ror    DWORD PTR [ecx-0x73],1
  40be93:	74 0e                	je     0x40bea3
  40be95:	01 e8                	add    eax,ebp
  40be97:	18 98 02 00 83 c4    	sbb    BYTE PTR [eax-0x3b7cfffe],bl
  40be9d:	04 89                	add    al,0x89
  40be9f:	44                   	inc    esp
  40bea0:	24 18                	and    al,0x18
  40bea2:	85 c0                	test   eax,eax
  40bea4:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x4a
  40beab:	4a 
  40beac:	74 20                	je     0x40bece
  40beae:	8d 54 24 78          	lea    edx,[esp+0x78]
  40beb2:	8d 4c 24 4c          	lea    ecx,[esp+0x4c]
  40beb6:	52                   	push   edx
  40beb7:	8d 54 24 60          	lea    edx,[esp+0x60]
  40bebb:	51                   	push   ecx
  40bebc:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  40bebf:	52                   	push   edx
  40bec0:	8b 55 48             	mov    edx,DWORD PTR [ebp+0x48]
  40bec3:	51                   	push   ecx
  40bec4:	52                   	push   edx
  40bec5:	8b c8                	mov    ecx,eax
  40bec7:	e8 a4 4c 00 00       	call   0x410b70
  40becc:	eb 02                	jmp    0x40bed0
  40bece:	33 c0                	xor    eax,eax
  40bed0:	89 43 04             	mov    DWORD PTR [ebx+0x4],eax
  40bed3:	8b 40 2c             	mov    eax,DWORD PTR [eax+0x2c]
  40bed6:	89 43 0c             	mov    DWORD PTR [ebx+0xc],eax
  40bed9:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
  40bedc:	68 ec 03 00 00       	push   0x3ec
  40bee1:	68 28 75 45 00       	push   0x457528
  40bee6:	50                   	push   eax
  40bee7:	c6 84 24 ec 06 00 00 	mov    BYTE PTR [esp+0x6ec],0x46
  40beee:	46 
  40beef:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  40bef6:	00 
  40bef7:	e8 0a 5e 02 00       	call   0x431d06
  40befc:	8b f8                	mov    edi,eax
  40befe:	85 ff                	test   edi,edi
  40bf00:	0f 84 91 00 00 00    	je     0x40bf97
  40bf06:	8b 53 0c             	mov    edx,DWORD PTR [ebx+0xc]
  40bf09:	8d 4c 24 34          	lea    ecx,[esp+0x34]
  40bf0d:	51                   	push   ecx
  40bf0e:	68 10 27 00 00       	push   0x2710
  40bf13:	68 b0 20 00 00       	push   0x20b0
  40bf18:	6a 01                	push   0x1
  40bf1a:	57                   	push   edi
  40bf1b:	52                   	push   edx
  40bf1c:	6a 00                	push   0x0
  40bf1e:	6a 00                	push   0x0
  40bf20:	e8 bb 05 00 00       	call   0x40c4e0
  40bf25:	83 c4 20             	add    esp,0x20
  40bf28:	85 c0                	test   eax,eax
  40bf2a:	74 6b                	je     0x40bf97
  40bf2c:	6a 00                	push   0x0
  40bf2e:	8d 8c 24 fc 01 00 00 	lea    ecx,[esp+0x1fc]
  40bf35:	6a 1e                	push   0x1e
  40bf37:	51                   	push   ecx
  40bf38:	50                   	push   eax
  40bf39:	e8 3a 5e 02 00       	call   0x431d78
  40bf3e:	85 c0                	test   eax,eax
  40bf40:	74 55                	je     0x40bf97
  40bf42:	8d 54 24 10          	lea    edx,[esp+0x10]
  40bf46:	8d 44 24 10          	lea    eax,[esp+0x10]
  40bf4a:	52                   	push   edx
  40bf4b:	50                   	push   eax
  40bf4c:	8d                   	.byte 0x8d
  40bf4d:	8c 24 00             	mov    WORD PTR [eax+eax*1],fs
