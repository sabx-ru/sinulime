/root/PL/PCU_old/H/mmc2/mbdde.exe:     file format pei-i386


Disassembly of section .text:

0040e350 <.text+0xd350>:
  40e350:	c6 84 24 8c 02 00 00 	mov    BYTE PTR [esp+0x28c],0x5
  40e357:	05 
  40e358:	23 ca                	and    ecx,edx
  40e35a:	e9 99 07 00 00       	jmp    0x40eaf8
  40e35f:	85 f6                	test   esi,esi
  40e361:	0f 84 96 07 00 00    	je     0x40eafd
  40e367:	83 bc 24 98 02 00 00 	cmp    DWORD PTR [esp+0x298],0x1
  40e36e:	01 
  40e36f:	0f 85 88 07 00 00    	jne    0x40eafd
  40e375:	8b 84 24 a4 02 00 00 	mov    eax,DWORD PTR [esp+0x2a4]
  40e37c:	6a 00                	push   0x0
  40e37e:	6a 01                	push   0x1
  40e380:	50                   	push   eax
  40e381:	8b ce                	mov    ecx,esi
  40e383:	e8 b8 9a ff ff       	call   0x407e40
  40e388:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40e38c:	e9 6c 07 00 00       	jmp    0x40eafd
  40e391:	85 f6                	test   esi,esi
  40e393:	0f 84 64 07 00 00    	je     0x40eafd
  40e399:	8b 84 24 a8 02 00 00 	mov    eax,DWORD PTR [esp+0x2a8]
  40e3a0:	85 c0                	test   eax,eax
  40e3a2:	74 25                	je     0x40e3c9
  40e3a4:	6a 00                	push   0x0
  40e3a6:	8d 8c 24 94 00 00 00 	lea    ecx,[esp+0x94]
  40e3ad:	68 f3 01 00 00       	push   0x1f3
  40e3b2:	51                   	push   ecx
  40e3b3:	50                   	push   eax
  40e3b4:	e8 bf 39 02 00       	call   0x431d78
  40e3b9:	85 c0                	test   eax,eax
  40e3bb:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  40e3bf:	74 08                	je     0x40e3c9
  40e3c1:	c6 84 24 83 02 00 00 	mov    BYTE PTR [esp+0x283],0x0
  40e3c8:	00 
  40e3c9:	8d 94 24 90 00 00 00 	lea    edx,[esp+0x90]
  40e3d0:	8b ce                	mov    ecx,esi
  40e3d2:	52                   	push   edx
  40e3d3:	e8 48 a5 ff ff       	call   0x408920
  40e3d8:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40e3dc:	e9 1c 07 00 00       	jmp    0x40eafd
  40e3e1:	3d 72 80 00 00       	cmp    eax,0x8072
  40e3e6:	0f 87 f8 00 00 00    	ja     0x40e4e4
  40e3ec:	0f 84 aa 00 00 00    	je     0x40e49c
  40e3f2:	3d 90 40 00 00       	cmp    eax,0x4090
  40e3f7:	74 34                	je     0x40e42d
  40e3f9:	3d 40 80 00 00       	cmp    eax,0x8040
  40e3fe:	0f 85 f9 06 00 00    	jne    0x40eafd
  40e404:	85 f6                	test   esi,esi
  40e406:	0f 84 f1 06 00 00    	je     0x40eafd
  40e40c:	8b 84 24 98 02 00 00 	mov    eax,DWORD PTR [esp+0x298]
  40e413:	8b 8c 24 a4 02 00 00 	mov    ecx,DWORD PTR [esp+0x2a4]
  40e41a:	50                   	push   eax
  40e41b:	51                   	push   ecx
  40e41c:	55                   	push   ebp
  40e41d:	8b ce                	mov    ecx,esi
  40e41f:	e8 5c b3 ff ff       	call   0x409780
  40e424:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40e428:	e9 d0 06 00 00       	jmp    0x40eafd
  40e42d:	85 f6                	test   esi,esi
  40e42f:	0f 84 c8 06 00 00    	je     0x40eafd
  40e435:	83 bc 24 98 02 00 00 	cmp    DWORD PTR [esp+0x298],0x1
  40e43c:	01 
  40e43d:	0f 85 ba 06 00 00    	jne    0x40eafd
  40e443:	8b 84 24 a8 02 00 00 	mov    eax,DWORD PTR [esp+0x2a8]
  40e44a:	85 c0                	test   eax,eax
  40e44c:	74 27                	je     0x40e475
  40e44e:	6a 00                	push   0x0
  40e450:	8d 94 24 94 00 00 00 	lea    edx,[esp+0x94]
  40e457:	68 f3 01 00 00       	push   0x1f3
  40e45c:	52                   	push   edx
  40e45d:	50                   	push   eax
  40e45e:	e8 15 39 02 00       	call   0x431d78
  40e463:	85 c0                	test   eax,eax
  40e465:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  40e469:	74 0e                	je     0x40e479
  40e46b:	c6 84 24 83 02 00 00 	mov    BYTE PTR [esp+0x283],0x0
  40e472:	00 
  40e473:	eb 04                	jmp    0x40e479
  40e475:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  40e479:	8b 8c 24 a4 02 00 00 	mov    ecx,DWORD PTR [esp+0x2a4]
  40e480:	50                   	push   eax
  40e481:	8d 84 24 94 00 00 00 	lea    eax,[esp+0x94]
  40e488:	50                   	push   eax
  40e489:	6a 01                	push   0x1
  40e48b:	51                   	push   ecx
  40e48c:	8b ce                	mov    ecx,esi
  40e48e:	e8                   	.byte 0xe8
  40e48f:	0d                   	.byte 0xd