
mbdde.exe:     file format pei-i386


Disassembly of section .text:

0040a1d0 <.text+0x91d0>:
  40a1d0:	6a ff                	push   0xffffffff
  40a1d2:	68 42 69 44 00       	push   0x446942
  40a1d7:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  40a1dd:	50                   	push   eax
  40a1de:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  40a1e5:	81 ec c8 06 00 00    	sub    esp,0x6c8
  40a1eb:	a1 a4 83 45 00       	mov    eax,ds:0x4583a4
  40a1f0:	53                   	push   ebx
  40a1f1:	55                   	push   ebp
  40a1f2:	8b e9                	mov    ebp,ecx
  40a1f4:	bb 9c a6 44 00       	mov    ebx,0x44a69c
  40a1f9:	56                   	push   esi
  40a1fa:	89 45 1c             	mov    DWORD PTR [ebp+0x1c],eax
  40a1fd:	57                   	push   edi
  40a1fe:	89 ac 24 f4 00 00 00 	mov    DWORD PTR [esp+0xf4],ebp
  40a205:	89 5d 18             	mov    DWORD PTR [ebp+0x18],ebx
  40a208:	8d 75 28             	lea    esi,[ebp+0x28]
  40a20b:	33 ff                	xor    edi,edi
  40a20d:	6a 0a                	push   0xa
  40a20f:	8b ce                	mov    ecx,esi
  40a211:	89 bc 24 e4 06 00 00 	mov    DWORD PTR [esp+0x6e4],edi
  40a218:	e8 80 9c 02 00       	call   0x433e9d
  40a21d:	c7 06 70 a9 44 00    	mov    DWORD PTR [esi],0x44a970
  40a223:	8d 4d 68             	lea    ecx,[ebp+0x68]
  40a226:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x1
  40a22d:	01 
  40a22e:	e8 69 98 02 00       	call   0x433a9c
  40a233:	68 a0 16 40 00       	push   0x4016a0
  40a238:	68 60 16 40 00       	push   0x401660
  40a23d:	8d 45 7c             	lea    eax,[ebp+0x7c]
  40a240:	6a 15                	push   0x15
  40a242:	6a 08                	push   0x8
  40a244:	50                   	push   eax
  40a245:	c6 84 24 f4 06 00 00 	mov    BYTE PTR [esp+0x6f4],0x2
  40a24c:	02 
  40a24d:	e8 6c 6e 01 00       	call   0x4210be
  40a252:	8b 0d a4 83 45 00    	mov    ecx,DWORD PTR ds:0x4583a4
  40a258:	89 8d 28 01 00 00    	mov    DWORD PTR [ebp+0x128],ecx
  40a25e:	89 9d 24 01 00 00    	mov    DWORD PTR [ebp+0x124],ebx
  40a264:	8b 15 a4 83 45 00    	mov    edx,DWORD PTR ds:0x4583a4
  40a26a:	89 95 30 01 00 00    	mov    DWORD PTR [ebp+0x130],edx
  40a270:	89 9d 2c 01 00 00    	mov    DWORD PTR [ebp+0x12c],ebx
  40a276:	89 bd 68 02 00 00    	mov    DWORD PTR [ebp+0x268],edi
  40a27c:	89 bd 6c 02 00 00    	mov    DWORD PTR [ebp+0x26c],edi
  40a282:	89 bd 70 02 00 00    	mov    DWORD PTR [ebp+0x270],edi
  40a288:	89 bd 74 02 00 00    	mov    DWORD PTR [ebp+0x274],edi
  40a28e:	bf 0c 79 45 00       	mov    edi,0x45790c
  40a293:	83 c9 ff             	or     ecx,0xffffffff
  40a296:	33 c0                	xor    eax,eax
  40a298:	c7 45 00 6c a9 44 00 	mov    DWORD PTR [ebp+0x0],0x44a96c
  40a29f:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  40a2a1:	f7 d1                	not    ecx
  40a2a3:	2b f9                	sub    edi,ecx
  40a2a5:	8d 9d 54 01 00 00    	lea    ebx,[ebp+0x154]
  40a2ab:	8b c1                	mov    eax,ecx
  40a2ad:	8b f7                	mov    esi,edi
  40a2af:	8b fb                	mov    edi,ebx
  40a2b1:	68 00 01 00 00       	push   0x100
  40a2b6:	c1 e9 02             	shr    ecx,0x2
  40a2b9:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  40a2bb:	8b c8                	mov    ecx,eax
  40a2bd:	c6 84 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],0x5
  40a2c4:	05 
  40a2c5:	83 e1 03             	and    ecx,0x3
  40a2c8:	f3 a4                	rep movs BYTE PTR es:[edi],BYTE PTR ds:[esi]
  40a2ca:	8b 15 70 c5 45 00    	mov    edx,DWORD PTR ds:0x45c570
  40a2d0:	8d 8c 24 dc 04 00 00 	lea    ecx,[esp+0x4dc]
  40a2d7:	51                   	push   ecx
  40a2d8:	52                   	push   edx
  40a2d9:	ff 15 8c a3 44 00    	call   DWORD PTR ds:0x44a38c
  40a2df:	85 c0                	test   eax,eax
  40a2e1:	74 55                	je     0x40a338
  40a2e3:	6a 0c                	push   0xc
  40a2e5:	8d 84 24 dd 04 00 00 	lea    eax,[esp+0x4dd]
  40a2ec:	68 fc 78 45 00       	push   0x4578fc
  40a2f1:	50                   	push   eax
  40a2f2:	e8 09 76 01 00       	call   0x421900
  40a2f7:	83 c4 0c             	add    esp,0xc
  40a2fa:	85 c0                	test   eax,eax
  40a2fc:	74 3a                	je     0x40a338
  40a2fe:	8d 8c 24 d8 04 00 00 	lea    ecx,[esp+0x4d8]
  40a305:	6a 5c                	push   0x5c
  40a307:	51                   	push   ecx
  40a308:	e8 c3 75 01 00       	call   0x4218d0
  40a30d:	83 c4 08             	add    esp,0x8
  40a310:	85 c0                	test   eax,eax
  40a312:	74 24                	je     0x40a338
  40a314:	c6 00 00             	mov    BYTE PTR [eax],0x0
  40a317:	8d bc 24 d8 04 00 00 	lea    edi,[esp+0x4d8]
  40a31e:	83 c9 ff             	or     ecx,0xffffffff
  40a321:	33 c0                	xor    eax,eax
  40a323:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  40a325:	f7 d1                	not    ecx
  40a327:	2b f9                	sub    edi,ecx
  40a329:	8b c1                	mov    eax,ecx
  40a32b:	8b f7                	mov    esi,edi
  40a32d:	8b fb                	mov    edi,ebx
  40a32f:	c1 e9 02             	shr    ecx,0x2
  40a332:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  40a334:	8b c8                	mov    ecx,eax
  40a336:	eb 1d                	jmp    0x40a355
  40a338:	bf 0c 79 45 00       	mov    edi,0x45790c
  40a33d:	83 c9 ff             	or     ecx,0xffffffff
  40a340:	33 c0                	xor    eax,eax
  40a342:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  40a344:	f7 d1                	not    ecx
  40a346:	2b f9                	sub    edi,ecx
  40a348:	8b d1                	mov    edx,ecx
  40a34a:	8b f7                	mov    esi,edi
  40a34c:	8b fb                	mov    edi,ebx
  40a34e:	c1 e9 02             	shr    ecx,0x2
  40a351:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  40a353:	8b ca                	mov    ecx,edx
  40a355:	8b 84 24 ec 06 00 00 	mov    eax,DWORD PTR [esp+0x6ec]
  40a35c:	83 e1 03             	and    ecx,0x3
  40a35f:	8d 5d 08             	lea    ebx,[ebp+0x8]
  40a362:	f3 a4                	rep movs BYTE PTR es:[edi],BYTE PTR ds:[esi]
  40a364:	c7 03 00 00 00 00    	mov    DWORD PTR [ebx],0x0
  40a36a:	89 85 5c 02 00 00    	mov    DWORD PTR [ebp+0x25c],eax
  40a370:	a1 24 cb 45 00       	mov    eax,ds:0x45cb24
  40a375:	85 c0                	test   eax,eax
  40a377:	0f 85 c1 1f 00 00    	jne    0x40c33e
  40a37d:	68 f4 78 45 00       	push   0x4578f4
  40a382:	8d 8d 80 00 00 00    	lea    ecx,[ebp+0x80]
  40a388:	c7 84 24 a4 00 00 00 	mov    DWORD PTR [esp+0xa4],0x457330
  40a38f:	30 73 45 00 
  40a393:	c7 84 24 a8 00 00 00 	mov    DWORD PTR [esp+0xa8],0x4578f0
  40a39a:	f0 78 45 00 
  40a39e:	c7 84 24 ac 00 00 00 	mov    DWORD PTR [esp+0xac],0x4572fc
  40a3a5:	fc 72 45 00 
  40a3a9:	c7 84 24 b0 00 00 00 	mov    DWORD PTR [esp+0xb0],0x4578e8
  40a3b0:	e8 78 45 00 
  40a3b4:	c7 84 24 b4 00 00 00 	mov    DWORD PTR [esp+0xb4],0x4578e4
  40a3bb:	e4 78 45 00 
  40a3bf:	c7 84 24 b8 00 00 00 	mov    DWORD PTR [esp+0xb8],0x4578d4
  40a3c6:	d4 78 45 00 
  40a3ca:	c7 84 24 bc 00 00 00 	mov    DWORD PTR [esp+0xbc],0x4578b8
  40a3d1:	b8 78 45 00 
  40a3d5:	c7 84 24 c0 00 00 00 	mov    DWORD PTR [esp+0xc0],0x4578a8
  40a3dc:	a8 78 45 00 
  40a3e0:	c7 84 24 c4 00 00 00 	mov    DWORD PTR [esp+0xc4],0x4578a0
  40a3e7:	a0 78 45 00 
  40a3eb:	c7 84 24 c8 00 00 00 	mov    DWORD PTR [esp+0xc8],0x457894
  40a3f2:	94 78 45 00 
  40a3f6:	c7 84 24 cc 00 00 00 	mov    DWORD PTR [esp+0xcc],0x45788c
  40a3fd:	8c 78 45 00 
  40a401:	c7 84 24 d0 00 00 00 	mov    DWORD PTR [esp+0xd0],0x457884
  40a408:	84 78 45 00 
  40a40c:	c7 84 24 d4 00 00 00 	mov    DWORD PTR [esp+0xd4],0x45787c
  40a413:	7c 78 45 00 
  40a417:	c7 84 24 d8 00 00 00 	mov    DWORD PTR [esp+0xd8],0x457870
  40a41e:	70 78 45 00 
  40a422:	c7 84 24 dc 00 00 00 	mov    DWORD PTR [esp+0xdc],0x457868
  40a429:	68 78 45 00 
  40a42d:	c7 84 24 e0 00 00 00 	mov    DWORD PTR [esp+0xe0],0x457854
  40a434:	54 78 45 00 
  40a438:	c7 84 24 e4 00 00 00 	mov    DWORD PTR [esp+0xe4],0x457834
  40a43f:	34 78 45 00 
  40a443:	c7 84 24 e8 00 00 00 	mov    DWORD PTR [esp+0xe8],0x457820
  40a44a:	20 78 45 00 
  40a44e:	c7 84 24 ec 00 00 00 	mov    DWORD PTR [esp+0xec],0x457810
  40a455:	10 78 45 00 
  40a459:	c7 84 24 f0 00 00 00 	mov    DWORD PTR [esp+0xf0],0x457804
  40a460:	04 78 45 00 
  40a464:	c7 84 24 f4 00 00 00 	mov    DWORD PTR [esp+0xf4],0x4577f8
  40a46b:	f8 77 45 00 
  40a46f:	e8 f7 ac 02 00       	call   0x43516b
  40a474:	68 f0 77 45 00       	push   0x4577f0
  40a479:	8d 8d 88 00 00 00    	lea    ecx,[ebp+0x88]
  40a47f:	e8 e7 ac 02 00       	call   0x43516b
  40a484:	68 e8 77 45 00       	push   0x4577e8
  40a489:	8d 8d 90 00 00 00    	lea    ecx,[ebp+0x90]
  40a48f:	e8 d7 ac 02 00       	call   0x43516b
  40a494:	68 e0 77 45 00       	push   0x4577e0
  40a499:	8d 8d 98 00 00 00    	lea    ecx,[ebp+0x98]
  40a49f:	e8 c7 ac 02 00       	call   0x43516b
  40a4a4:	68 d8 77 45 00       	push   0x4577d8
  40a4a9:	8d 8d a0 00 00 00    	lea    ecx,[ebp+0xa0]
  40a4af:	e8 b7 ac 02 00       	call   0x43516b
  40a4b4:	68 d0 77 45 00       	push   0x4577d0
  40a4b9:	8d 8d a8 00 00 00    	lea    ecx,[ebp+0xa8]
  40a4bf:	e8 a7 ac 02 00       	call   0x43516b
  40a4c4:	68 c8 77 45 00       	push   0x4577c8
  40a4c9:	8d 8d b0 00 00 00    	lea    ecx,[ebp+0xb0]
  40a4cf:	e8 97 ac 02 00       	call   0x43516b
  40a4d4:	68 c0 77 45 00       	push   0x4577c0
  40a4d9:	8d 8d b8 00 00 00    	lea    ecx,[ebp+0xb8]
  40a4df:	e8 87 ac 02 00       	call   0x43516b
  40a4e4:	68 b8 77 45 00       	push   0x4577b8
  40a4e9:	8d 8d c0 00 00 00    	lea    ecx,[ebp+0xc0]
  40a4ef:	e8 77 ac 02 00       	call   0x43516b
  40a4f4:	68 b0 77 45 00       	push   0x4577b0
  40a4f9:	8d 8d c8 00 00 00    	lea    ecx,[ebp+0xc8]
  40a4ff:	e8 67 ac 02 00       	call   0x43516b
  40a504:	68 a8 77 45 00       	push   0x4577a8
  40a509:	8d 8d d0 00 00 00    	lea    ecx,[ebp+0xd0]
  40a50f:	e8 57 ac 02 00       	call   0x43516b
  40a514:	68 a0 77 45 00       	push   0x4577a0
  40a519:	8d 8d d8 00 00 00    	lea    ecx,[ebp+0xd8]
  40a51f:	e8 47 ac 02 00       	call   0x43516b
  40a524:	68 98 77 45 00       	push   0x457798
  40a529:	8d 8d e0 00 00 00    	lea    ecx,[ebp+0xe0]
  40a52f:	e8 37 ac 02 00       	call   0x43516b
  40a534:	68 90 77 45 00       	push   0x457790
  40a539:	8d 8d e8 00 00 00    	lea    ecx,[ebp+0xe8]
  40a53f:	e8 27 ac 02 00       	call   0x43516b
  40a544:	68 88 77 45 00       	push   0x457788
  40a549:	8d 8d f0 00 00 00    	lea    ecx,[ebp+0xf0]
  40a54f:	e8 17 ac 02 00       	call   0x43516b
  40a554:	68 7c 77 45 00       	push   0x45777c
  40a559:	8d 8d f8 00 00 00    	lea    ecx,[ebp+0xf8]
  40a55f:	e8 07 ac 02 00       	call   0x43516b
  40a564:	68 70 77 45 00       	push   0x457770
  40a569:	8d 8d 00 01 00 00    	lea    ecx,[ebp+0x100]
  40a56f:	e8 f7 ab 02 00       	call   0x43516b
  40a574:	68 64 77 45 00       	push   0x457764
  40a579:	8d 8d 08 01 00 00    	lea    ecx,[ebp+0x108]
  40a57f:	e8 e7 ab 02 00       	call   0x43516b
  40a584:	68 58 77 45 00       	push   0x457758
  40a589:	8d 8d 10 01 00 00    	lea    ecx,[ebp+0x110]
  40a58f:	e8 d7 ab 02 00       	call   0x43516b
  40a594:	68 4c 77 45 00       	push   0x45774c
  40a599:	8d 8d 18 01 00 00    	lea    ecx,[ebp+0x118]
  40a59f:	e8 c7 ab 02 00       	call   0x43516b
  40a5a4:	68 44 77 45 00       	push   0x457744
  40a5a9:	8d 8d 20 01 00 00    	lea    ecx,[ebp+0x120]
  40a5af:	e8 b7 ab 02 00       	call   0x43516b
  40a5b4:	a1 a4 83 45 00       	mov    eax,ds:0x4583a4
  40a5b9:	b9 9c a6 44 00       	mov    ecx,0x44a69c
  40a5be:	89 84 24 8c 00 00 00 	mov    DWORD PTR [esp+0x8c],eax
  40a5c5:	89 8c 24 88 00 00 00 	mov    DWORD PTR [esp+0x88],ecx
  40a5cc:	89 84 24 84 00 00 00 	mov    DWORD PTR [esp+0x84],eax
  40a5d3:	89 8c 24 80 00 00 00 	mov    DWORD PTR [esp+0x80],ecx
  40a5da:	c7 44 24 40 32 00 00 	mov    DWORD PTR [esp+0x40],0x32
  40a5e1:	00 
  40a5e2:	c7 44 24 3c 00 02 00 	mov    DWORD PTR [esp+0x3c],0x200
  40a5e9:	00 
  40a5ea:	c7 44 24 6c 0a 00 00 	mov    DWORD PTR [esp+0x6c],0xa
  40a5f1:	00 
  40a5f2:	89 84 24 94 00 00 00 	mov    DWORD PTR [esp+0x94],eax
  40a5f9:	89 8c 24 90 00 00 00 	mov    DWORD PTR [esp+0x90],ecx
  40a600:	89 44 24 60          	mov    DWORD PTR [esp+0x60],eax
  40a604:	89 4c 24 5c          	mov    DWORD PTR [esp+0x5c],ecx
  40a608:	89 44 24 50          	mov    DWORD PTR [esp+0x50],eax
  40a60c:	89 4c 24 4c          	mov    DWORD PTR [esp+0x4c],ecx
  40a610:	89 44 24 48          	mov    DWORD PTR [esp+0x48],eax
  40a614:	89 4c 24 44          	mov    DWORD PTR [esp+0x44],ecx
  40a618:	89 84 24 9c 00 00 00 	mov    DWORD PTR [esp+0x9c],eax
  40a61f:	89 8c 24 98 00 00 00 	mov    DWORD PTR [esp+0x98],ecx
  40a626:	89 44 24 68          	mov    DWORD PTR [esp+0x68],eax
  40a62a:	89 4c 24 64          	mov    DWORD PTR [esp+0x64],ecx
  40a62e:	89 44 24 7c          	mov    DWORD PTR [esp+0x7c],eax
  40a632:	89 4c 24 78          	mov    DWORD PTR [esp+0x78],ecx
  40a636:	33 f6                	xor    esi,esi
  40a638:	8d bd 34 01 00 00    	lea    edi,[ebp+0x134]
  40a63e:	89 35 f8 ca 45 00    	mov    DWORD PTR ds:0x45caf8,esi
  40a644:	b9 07 00 00 00       	mov    ecx,0x7
  40a649:	b8 64 00 00 00       	mov    eax,0x64
  40a64e:	89 75 4c             	mov    DWORD PTR [ebp+0x4c],esi
  40a651:	89 75 60             	mov    DWORD PTR [ebp+0x60],esi
  40a654:	89 75 44             	mov    DWORD PTR [ebp+0x44],esi
  40a657:	89 75 48             	mov    DWORD PTR [ebp+0x48],esi
  40a65a:	c7 85 80 02 00 00 09 	mov    DWORD PTR [ebp+0x280],0x9
  40a661:	00 00 00 
  40a664:	89 b5 84 02 00 00    	mov    DWORD PTR [ebp+0x284],esi
  40a66a:	68 38 74 45 00       	push   0x457438
  40a66f:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  40a671:	8d 8c 24 fc 00 00 00 	lea    ecx,[esp+0xfc]
  40a678:	68 00 01 00 00       	push   0x100
  40a67d:	51                   	push   ecx
  40a67e:	68 f0 72 45 00       	push   0x4572f0
  40a683:	89 35 cc c5 45 00    	mov    DWORD PTR ds:0x45c5cc,esi
  40a689:	89 2d 2c cb 45 00    	mov    DWORD PTR ds:0x45cb2c,ebp
  40a68f:	68 3c 77 45 00       	push   0x45773c
  40a694:	89 75 10             	mov    DWORD PTR [ebp+0x10],esi
  40a697:	68 f0 72 45 00       	push   0x4572f0
  40a69c:	c6 84 24 f8 06 00 00 	mov    BYTE PTR [esp+0x6f8],0xe
  40a6a3:	0e 
  40a6a4:	c7 45 20 01 00 00 00 	mov    DWORD PTR [ebp+0x20],0x1
  40a6ab:	89 75 14             	mov    DWORD PTR [ebp+0x14],esi
  40a6ae:	89 b5 54 02 00 00    	mov    DWORD PTR [ebp+0x254],esi
  40a6b4:	e8 c7 53 01 00       	call   0x41fa80
  40a6b9:	83 c4 18             	add    esp,0x18
  40a6bc:	3b c6                	cmp    eax,esi
  40a6be:	74 2d                	je     0x40a6ed
  40a6c0:	8d bc 24 f8 00 00 00 	lea    edi,[esp+0xf8]
  40a6c7:	83 c9 ff             	or     ecx,0xffffffff
  40a6ca:	33 c0                	xor    eax,eax
  40a6cc:	8d 94 24 58 04 00 00 	lea    edx,[esp+0x458]
  40a6d3:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  40a6d5:	f7 d1                	not    ecx
  40a6d7:	2b f9                	sub    edi,ecx
  40a6d9:	8b c1                	mov    eax,ecx
  40a6db:	8b f7                	mov    esi,edi
  40a6dd:	8b fa                	mov    edi,edx
  40a6df:	c1 e9 02             	shr    ecx,0x2
  40a6e2:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  40a6e4:	8b c8                	mov    ecx,eax
  40a6e6:	83 e1 03             	and    ecx,0x3
  40a6e9:	f3 a4                	rep movs BYTE PTR es:[edi],BYTE PTR ds:[esi]
  40a6eb:	33 f6                	xor    esi,esi
  40a6ed:	89 35 fc ca 45 00    	mov    DWORD PTR ds:0x45cafc,esi
  40a6f3:	89 35 f8 ca 45 00    	mov    DWORD PTR ds:0x45caf8,esi
  40a6f9:	68 c8 00 00 00       	push   0xc8
  40a6fe:	c7 45 24 40 df 40 00 	mov    DWORD PTR [ebp+0x24],0x40df40
  40a705:	e8 36 45 00 00       	call   0x40ec40
  40a70a:	8b 4d 24             	mov    ecx,DWORD PTR [ebp+0x24]
  40a70d:	83 c4 04             	add    esp,0x4
  40a710:	56                   	push   esi
  40a711:	56                   	push   esi
  40a712:	51                   	push   ecx
  40a713:	53                   	push   ebx
  40a714:	e8 2f 76 02 00       	call   0x431d48
  40a719:	68 c8 00 00 00       	push   0xc8
  40a71e:	e8 1d 45 00 00       	call   0x40ec40
  40a723:	6a 0c                	push   0xc
  40a725:	e8 89 af 02 00       	call   0x4356b3
  40a72a:	83 c4 08             	add    esp,0x8
  40a72d:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  40a731:	3b c6                	cmp    eax,esi
  40a733:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0xf
  40a73a:	0f 
  40a73b:	74 1a                	je     0x40a757
  40a73d:	8b d5                	mov    edx,ebp
  40a73f:	8d 8c 24 58 04 00 00 	lea    ecx,[esp+0x458]
  40a746:	f7 da                	neg    edx
  40a748:	1b d2                	sbb    edx,edx
  40a74a:	51                   	push   ecx
  40a74b:	23 d3                	and    edx,ebx
  40a74d:	8b c8                	mov    ecx,eax
  40a74f:	52                   	push   edx
  40a750:	e8 4b 86 ff ff       	call   0x402da0
  40a755:	eb 02                	jmp    0x40a759
  40a757:	33 c0                	xor    eax,eax
  40a759:	68 c8 00 00 00       	push   0xc8
  40a75e:	c6 84 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],0xe
  40a765:	0e 
  40a766:	89 45 50             	mov    DWORD PTR [ebp+0x50],eax
  40a769:	e8 d2 44 00 00       	call   0x40ec40
  40a76e:	8b 4d 50             	mov    ecx,DWORD PTR [ebp+0x50]
  40a771:	83 c4 04             	add    esp,0x4
  40a774:	6a 01                	push   0x1
  40a776:	56                   	push   esi
  40a777:	e8 a4 87 ff ff       	call   0x402f20
  40a77c:	8b 13                	mov    edx,DWORD PTR [ebx]
  40a77e:	50                   	push   eax
  40a77f:	52                   	push   edx
  40a780:	e8 f9 75 02 00       	call   0x431d7e
  40a785:	68 c8 00 00 00       	push   0xc8
  40a78a:	e8 b1 44 00 00       	call   0x40ec40
  40a78f:	6a 0c                	push   0xc
  40a791:	e8 1d af 02 00       	call   0x4356b3
  40a796:	83 c4 08             	add    esp,0x8
  40a799:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  40a79d:	3b c6                	cmp    eax,esi
  40a79f:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x10
  40a7a6:	10 
  40a7a7:	74 17                	je     0x40a7c0
  40a7a9:	8b d5                	mov    edx,ebp
  40a7ab:	68 34 77 45 00       	push   0x457734
  40a7b0:	f7 da                	neg    edx
  40a7b2:	1b d2                	sbb    edx,edx
  40a7b4:	8b c8                	mov    ecx,eax
  40a7b6:	23 d3                	and    edx,ebx
  40a7b8:	52                   	push   edx
  40a7b9:	e8 e2 85 ff ff       	call   0x402da0
  40a7be:	eb 02                	jmp    0x40a7c2
  40a7c0:	33 c0                	xor    eax,eax
  40a7c2:	6a 0c                	push   0xc
  40a7c4:	c6 84 24 e4 06 00 00 	mov    BYTE PTR [esp+0x6e4],0xe
  40a7cb:	0e 
  40a7cc:	89 45 54             	mov    DWORD PTR [ebp+0x54],eax
  40a7cf:	e8 df ae 02 00       	call   0x4356b3
  40a7d4:	83 c4 04             	add    esp,0x4
  40a7d7:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  40a7db:	3b c6                	cmp    eax,esi
  40a7dd:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x11
  40a7e4:	11 
  40a7e5:	74 17                	je     0x40a7fe
  40a7e7:	8b d5                	mov    edx,ebp
  40a7e9:	68 2c 77 45 00       	push   0x45772c
  40a7ee:	f7 da                	neg    edx
  40a7f0:	1b d2                	sbb    edx,edx
  40a7f2:	8b c8                	mov    ecx,eax
  40a7f4:	23 d3                	and    edx,ebx
  40a7f6:	52                   	push   edx
  40a7f7:	e8 a4 85 ff ff       	call   0x402da0
  40a7fc:	eb 02                	jmp    0x40a800
  40a7fe:	33 c0                	xor    eax,eax
  40a800:	89 45 58             	mov    DWORD PTR [ebp+0x58],eax
  40a803:	8b 03                	mov    eax,DWORD PTR [ebx]
  40a805:	68 ec 03 00 00       	push   0x3ec
  40a80a:	68 1c 77 45 00       	push   0x45771c
  40a80f:	50                   	push   eax
  40a810:	c6 84 24 ec 06 00 00 	mov    BYTE PTR [esp+0x6ec],0xe
  40a817:	0e 
  40a818:	e8 e9 74 02 00       	call   0x431d06
  40a81d:	8b 4d 58             	mov    ecx,DWORD PTR [ebp+0x58]
  40a820:	89 85 88 02 00 00    	mov    DWORD PTR [ebp+0x288],eax
  40a826:	e8 f5 86 ff ff       	call   0x402f20
  40a82b:	8b 4d 54             	mov    ecx,DWORD PTR [ebp+0x54]
  40a82e:	8b f0                	mov    esi,eax
  40a830:	e8 eb 86 ff ff       	call   0x402f20
  40a835:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  40a837:	6a 00                	push   0x0
  40a839:	56                   	push   esi
  40a83a:	50                   	push   eax
  40a83b:	51                   	push   ecx
  40a83c:	89 44 24 20          	mov    DWORD PTR [esp+0x20],eax
  40a840:	89 4c 24 24          	mov    DWORD PTR [esp+0x24],ecx
  40a844:	e8 f9 74 02 00       	call   0x431d42
  40a849:	8b f8                	mov    edi,eax
  40a84b:	85 ff                	test   edi,edi
  40a84d:	74 43                	je     0x40a892
  40a84f:	6a 30                	push   0x30
  40a851:	e8 5d ae 02 00       	call   0x4356b3
  40a856:	83 c4 04             	add    esp,0x4
  40a859:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  40a85d:	85 c0                	test   eax,eax
  40a85f:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0x12
  40a866:	12 
  40a867:	74 15                	je     0x40a87e
  40a869:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  40a86d:	8b 54 24 14          	mov    edx,DWORD PTR [esp+0x14]
  40a871:	56                   	push   esi
  40a872:	51                   	push   ecx
  40a873:	52                   	push   edx
  40a874:	57                   	push   edi
  40a875:	8b c8                	mov    ecx,eax
  40a877:	e8 74 47 00 00       	call   0x40eff0
  40a87c:	eb 02                	jmp    0x40a880
  40a87e:	33 c0                	xor    eax,eax
  40a880:	85 c0                	test   eax,eax
  40a882:	c6 84 24 e0 06 00 00 	mov    BYTE PTR [esp+0x6e0],0xe
  40a889:	0e 
  40a88a:	75 08                	jne    0x40a894
  40a88c:	57                   	push   edi
  40a88d:	e8 d4 74 02 00       	call   0x431d66
  40a892:	33 ff                	xor    edi,edi
  40a894:	8b 03                	mov    eax,DWORD PTR [ebx]
  40a896:	68 ec 03 00 00       	push   0x3ec
  40a89b:	68 10 77 45 00       	push   0x457710
  40a8a0:	50                   	push   eax
  40a8a1:	89 7d 5c             	mov    DWORD PTR [ebp+0x5c],edi
  40a8a4:	e8 5d 74 02 00       	call   0x431d06
  40a8a9:	68 38 74 45 00       	push   0x457438
  40a8ae:	8d 94 24 fc 00 00 00 	lea    edx,[esp+0xfc]
  40a8b5:	68 00 01 00 00       	push   0x100
  40a8ba:	89 45 0c             	mov    DWORD PTR [ebp+0xc],eax
  40a8bd:	52                   	push   edx
  40a8be:	89 2d 24 cb 45 00    	mov    DWORD PTR ds:0x45cb24,ebp
  40a8c4:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  40a8c6:	68 18 74 45 00       	push   0x457418
  40a8cb:	68 08 77 45 00       	push   0x457708
  40a8d0:	68 f0 72 45 00       	push   0x4572f0
  40a8d5:	89 0d 28 cb 45 00    	mov    DWORD PTR ds:0x45cb28,ecx
  40a8db:	e8 a0 51 01 00       	call   0x41fa80
  40a8e0:	83 c4 18             	add    esp,0x18
  40a8e3:	85 c0                	test   eax,eax
  40a8e5:	74 18                	je     0x40a8ff
  40a8e7:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  40a8e9:	8d 84 24 f8 00 00 00 	lea    eax,[esp+0xf8]
  40a8f0:	68 ec 03 00 00       	push   0x3ec
  40a8f5:	50                   	push   eax
  40a8f6:	51                   	push   ecx
  40a8f7:	e8 0a 74 02 00       	call   0x431d06
  40a8fc:	89 45 64             	mov    DWORD PTR [ebp+0x64],eax
  40a8ff:	68 38 74 45 00       	push   0x457438
  40a904:	8d 94 24 fc 00 00 00 	lea    edx,[esp+0xfc]
  40a90b:	68 00 01 00 00       	push   0x100
  40a910:	52                   	push   edx
  40a911:	68 34 77 45 00       	push   0x457734
  40a916:	68 f4 76 45 00       	push   0x4576f4
  40a91b:	68 ec 76 45 00       	push   0x4576ec
  40a920:	e8 5b 51 01 00       	call   0x41fa80
  40a925:	83 c4 18             	add    esp,0x18
  40a928:	85 c0                	test   eax,eax
  40a92a:	74 11                	je     0x40a93d
  40a92c:	8d 84 24 f8 00 00 00 	lea    eax,[esp+0xf8]
  40a933:	8d 4c 24 60          	lea    ecx,[esp+0x60]
  40a937:	50                   	push   eax
  40a938:	e8 2e a8 02 00       	call   0x43516b
  40a93d:	68 38 74 45 00       	push   0x457438
  40a942:	8d 8c 24 fc 00 00 00 	lea    ecx,[esp+0xfc]
  40a949:	68 00 01 00 00       	push   0x100
  40a94e:	51                   	push   ecx
  40a94f:	68 48 c2 45 00       	push   0x45c248
  40a954:	68 d8 76 45 00       	push   0x4576d8
  40a959:	68 ec 76 45 00       	push   0x4576ec
  40a95e:	e8 1d 51 01 00       	call   0x41fa80
  40a963:	83 c4 18             	add    esp,0x18
  40a966:	85 c0                	test   eax,eax
  40a968:	74 11                	je     0x40a97b
  40a96a:	8d 94 24 f8 00 00 00 	lea    edx,[esp+0xf8]
  40a971:	8d 4c 24 50          	lea    ecx,[esp+0x50]
  40a975:	52                   	push   edx
  40a976:	e8 f0 a7 02 00       	call   0x43516b
  40a97b:	68 38 74 45 00       	push   0x457438
  40a980:	8d 84 24 fc 00 00 00 	lea    eax,[esp+0xfc]
  40a987:	68 00 01 00 00       	push   0x100
  40a98c:	50                   	push   eax
  40a98d:	68 48 c2 45 00       	push   0x45c248
  40a992:	68 cc 76 45 00       	push   0x4576cc
  40a997:	68 ec 76 45 00       	push   0x4576ec
  40a99c:	e8 df 50 01 00       	call   0x41fa80
  40a9a1:	6a 04                	push   0x4
  40a9a3:	8d 8c 24 14 01 00 00 	lea    ecx,[esp+0x114]
  40a9aa:	68 c4 76 45 00       	push   0x4576c4
  40a9af:	51                   	push   ecx
  40a9b0:	e8 4b 6f 01 00       	call   0x421900
  40a9b5:	83 c4 24             	add    esp,0x24
  40a9b8:	85 c0                	test   eax,eax
  40a9ba:	75 03                	jne    0x40a9bf
  40a9bc:	89 45 20             	mov    DWORD PTR [ebp+0x20],eax
  40a9bf:	a1 24 75 45 00       	mov    eax,ds:0x457524
  40a9c4:	be e8 03 00 00       	mov    esi,0x3e8
  40a9c9:	83 f8 ff             	cmp    eax,0xffffffff
  40a9cc:	75 5e                	jne    0x40aa2c
  40a9ce:	68 d0 71 45 00       	push   0x4571d0
  40a9d3:	6a 00                	push   0x0
  40a9d5:	68 b0 76 45 00       	push   0x4576b0
  40a9da:	68 d0 73 45 00       	push   0x4573d0
  40a9df:	e8 ec 4c 01 00       	call   0x41f6d0
  40a9e4:	83 c4 10             	add    esp,0x10
  40a9e7:	a3 20 75 45 00       	mov    ds:0x457520,eax
  40a9ec:	85 c0                	test   eax,eax
  40a9ee:	74 0f                	je     0x40a9ff
  40a9f0:	83 f8 1e             	cmp    eax,0x1e
  40a9f3:	73 0a                	jae    0x40a9ff
  40a9f5:	c7 05 20 75 45 00 1e 	mov    DWORD PTR ds:0x457520,0x1e
  40a9fc:	00 00 00 
  40a9ff:	68 d0 71 45 00       	push   0x4571d0
  40aa04:	6a 64                	push   0x64
  40aa06:	68 a4 76 45 00       	push   0x4576a4
  40aa0b:	68 d0 73 45 00       	push   0x4573d0
  40aa10:	e8 bb 4c 01 00       	call   0x41f6d0
  40aa15:	8d 04 80             	lea    eax,[eax+eax*4]
  40aa18:	83 c4 10             	add    esp,0x10
  40aa1b:	d1 e0                	shl    eax,1
  40aa1d:	3b c6                	cmp    eax,esi
  40aa1f:	a3 24 75 45 00       	mov    ds:0x457524,eax
  40aa24:	73 06                	jae    0x40aa2c
  40aa26:	89 35 24 75 45 00    	mov    DWORD PTR ds:0x457524,esi
  40aa2c:	68 d0 71 45 00       	push   0x4571d0
  40aa31:	8d 94 24 fc 00 00 00 	lea    edx,[esp+0xfc]
  40aa38:	68 00 01 00 00       	push   0x100
  40aa3d:	52                   	push   edx
  40aa3e:	68 9c 76 45 00       	push   0x45769c
  40aa43:	68 94 76 45 00       	push   0x457694
  40aa48:	68 a8 71 45 00       	push   0x4571a8
  40aa4d:	e8 2e 50 01 00       	call   0x41fa80
  40aa52:	83 c4 18             	add    esp,0x18
  40aa55:	85 c0                	test   eax,eax
  40aa57:	74 11                	je     0x40aa6a
  40aa59:	8d 84 24 f8 00 00 00 	lea    eax,[esp+0xf8]
  40aa60:	8d 4c 24 68          	lea    ecx,[esp+0x68]
  40aa64:	50                   	push   eax
  40aa65:	e8 01 a7 02 00       	call   0x43516b
  40aa6a:	68 d0 71 45 00       	push   0x4571d0
  40aa6f:	8d 8c 24 fc 00 00 00 	lea    ecx,[esp+0xfc]
  40aa76:	68 00 01 00 00       	push   0x100
  40aa7b:	51                   	push   ecx
  40aa7c:	68 48 c2 45 00       	push   0x45c248
  40aa81:	68 8c 76 45 00       	push   0x45768c
  40aa86:	68 84 76 45 00       	push   0x457684
  40aa8b:	e8 f0 4f 01 00       	call   0x41fa80
  40aa90:	83 c4 18             	add    esp,0x18
  40aa93:	85 c0                	test   eax,eax
  40aa95:	74 10                	je     0x40aaa7
  40aa97:	8d 94 24 f8 00 00 00 	lea    edx,[esp+0xf8]
  40aa9e:	52                   	push   edx
  40aa9f:	e8 ac 40 00 00       	call   0x40eb50
  40aaa4:	83 c4 04             	add    esp,0x4
  40aaa7:	68 d0 71 45 00       	push   0x4571d0
  40aaac:	8d 84 24 fc 00 00 00 	lea    eax,[esp+0xfc]
  40aab3:	68 00 01 00 00       	push   0x100
  40aab8:	50                   	push   eax
  40aab9:	68 48 c2 45 00       	push   0x45c248
  40aabe:	68 7c 76 45 00       	push   0x45767c
  40aac3:	68 a8 71 45 00       	push   0x4571a8
  40aac8:	e8 b3 4f 01 00       	call   0x41fa80
  40aacd:	83 c4 18             	add    esp,0x18
  40aad0:	85 c0                	test   eax,eax
  40aad2:	74 13                	je     0x40aae7
  40aad4:	8d 8c 24 f8 00 00 00 	lea    ecx,[esp+0xf8]
  40aadb:	51                   	push   ecx
  40aadc:	8d 8d 30 01 00 00    	lea    ecx,[ebp+0x130]
  40aae2:	e8 84 a6 02 00       	call   0x43516b
  40aae7:	68 38 74 45 00       	push   0x457438
  40aaec:	8d 94 24 fc 00 00 00 	lea    edx,[esp+0xfc]
  40aaf3:	68 00 01 00 00       	push   0x100
  40aaf8:	52                   	push   edx
  40aaf9:	68 78 76 45 00       	push   0x457678
  40aafe:	68 6c 76 45 00       	push   0x45766c
  40ab03:	68 60 76 45 00       	push   0x457660
  40ab08:	e8 73 4f 01 00       	call   0x41fa80
  40ab0d:	83 c4 18             	add    esp,0x18
  40ab10:	85 c0                	test   eax,eax
  40ab12:	74 10                	je     0x40ab24
  40ab14:	8d 84 24 f8 00 00 00 	lea    eax,[esp+0xf8]
  40ab1b:	8d 4d 1c             	lea    ecx,[ebp+0x1c]
  40ab1e:	50                   	push   eax
  40ab1f:	e8 47 a6 02 00       	call   0x43516b
  40ab24:	68 d0 71 45 00       	push   0x4571d0
  40ab29:	8d 8c 24 fc 00 00 00 	lea    ecx,[esp+0xfc]
  40ab30:	68 00 01 00 00       	push   0x100
  40ab35:	51                   	push   ecx
  40ab36:	68 44 73 45 00       	push   0x457344
  40ab3b:	68 58 76 45 00       	push   0x457658
  40ab40:	68 a8 71 45 00       	push   0x4571a8
  40ab45:	e8 36 4f 01 00       	call   0x41fa80
  40ab4a:	83 c4 18             	add    esp,0x18
  40ab4d:	85 c0                	test   eax,eax
  40ab4f:	74 33                	je     0x40ab84
  40ab51:	8d 94 24 f8 00 00 00 	lea    edx,[esp+0xf8]
  40ab58:	52                   	push   edx
  40ab59:	e8 9b 64 01 00       	call   0x420ff9
  40ab5e:	83 c4 04             	add    esp,0x4
  40ab61:	83 f8 0a             	cmp    eax,0xa
  40ab64:	89 85 50 01 00 00    	mov    DWORD PTR [ebp+0x150],eax
  40ab6a:	7d 0a                	jge    0x40ab76
  40ab6c:	c7 85 50 01 00 00 0a 	mov    DWORD PTR [ebp+0x150],0xa
  40ab73:	00 00 00 
  40ab76:	39 b5 50 01 00 00    	cmp    DWORD PTR [ebp+0x150],esi
  40ab7c:	7e 06                	jle    0x40ab84
  40ab7e:	89 b5        	mov    DWORD PTR [ebp+0x150],esi
