
/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00466e80 <.text+0x65e80>:
  466e80:	a8 5b                	test   al,0x5b
  466e82:	6c                   	ins    BYTE PTR es:[edi],dx
  466e83:	00 ff                	add    bh,bh
  466e85:	25 ac 5b 6c 00       	and    eax,0x6c5bac
  466e8a:	ff 25 b0 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bb0
  466e90:	ff 25 b4 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bb4
  466e96:	ff 25 b8 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bb8
  466e9c:	ff 25 bc 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bbc
  466ea2:	ff 25 c0 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bc0
  466ea8:	ff 25 c4 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bc4
  466eae:	ff 25 c8 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bc8
  466eb4:	ff 25 cc 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bcc
  466eba:	ff 25 d0 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bd0
  466ec0:	ff 25 d4 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bd4
  466ec6:	ff 25 d8 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bd8
  466ecc:	ff 25 dc 5b 6c 00    	jmp    DWORD PTR ds:0x6c5bdc
  466ed2:	ff 25 e0 5b 6c 00    	jmp    DWORD PTR ds:0x6c5be0
  466ed8:	ff 25 e4 5b 6c 00    	jmp    DWORD PTR ds:0x6c5be4
  466ede:	ff 25 e8 5b 6c 00    	jmp    DWORD PTR ds:0x6c5be8
  466ee4:	ff 25 50 63 6c 00    	jmp    DWORD PTR ds:0x6c6350
  466eea:	ff 25 54 63 6c 00    	jmp    DWORD PTR ds:0x6c6354
  466ef0:	ff 25 58 63 6c 00    	jmp    DWORD PTR ds:0x6c6358
  466ef6:	ff 25 5c 63 6c 00    	jmp    DWORD PTR ds:0x6c635c
  466efc:	ff 25 60 63 6c 00    	jmp    DWORD PTR ds:0x6c6360
  466f02:	ff 25 34 63 6c 00    	jmp    DWORD PTR ds:0x6c6334
  466f08:	ff 25 30 63 6c 00    	jmp    DWORD PTR ds:0x6c6330
  466f0e:	ff 25 2c 63 6c 00    	jmp    DWORD PTR ds:0x6c632c
  466f14:	ff 25 28 63 6c 00    	jmp    DWORD PTR ds:0x6c6328
  466f1a:	ff 25 24 63 6c 00    	jmp    DWORD PTR ds:0x6c6324
  466f20:	ff 25 20 63 6c 00    	jmp    DWORD PTR ds:0x6c6320
  466f26:	ff 25 1c 63 6c 00    	jmp    DWORD PTR ds:0x6c631c
  466f2c:	ff 25 18 63 6c 00    	jmp    DWORD PTR ds:0x6c6318
  466f32:	ff 25 14 63 6c 00    	jmp    DWORD PTR ds:0x6c6314
  466f38:	ff 25 64 63 6c 00    	jmp    DWORD PTR ds:0x6c6364
  466f3e:	ff 25 48 63 6c 00    	jmp    DWORD PTR ds:0x6c6348
  466f44:	ff 25 44 63 6c 00    	jmp    DWORD PTR ds:0x6c6344
  466f4a:	ff 25 40 63 6c 00    	jmp    DWORD PTR ds:0x6c6340
  466f50:	ff 25 3c 63 6c 00    	jmp    DWORD PTR ds:0x6c633c
  466f56:	ff 25 38 63 6c 00    	jmp    DWORD PTR ds:0x6c6338
  466f5c:	ff 25 d8 62 6c 00    	jmp    DWORD PTR ds:0x6c62d8
  466f62:	ff 25 7c 62 6c 00    	jmp    DWORD PTR ds:0x6c627c
  466f68:	ff 25 80 62 6c 00    	jmp    DWORD PTR ds:0x6c6280
  466f6e:	ff 25 84 62 6c 00    	jmp    DWORD PTR ds:0x6c6284
  466f74:	ff 25 88 62 6c 00    	jmp    DWORD PTR ds:0x6c6288
  466f7a:	ff 25 8c 62 6c 00    	jmp    DWORD PTR ds:0x6c628c
  466f80:	ff 25 90 62 6c 00    	jmp    DWORD PTR ds:0x6c6290
  466f86:	ff 25 94 62 6c 00    	jmp    DWORD PTR ds:0x6c6294
  466f8c:	ff 25 98 62 6c 00    	jmp    DWORD PTR ds:0x6c6298
  466f92:	ff 25 9c 62 6c 00    	jmp    DWORD PTR ds:0x6c629c
  466f98:	ff 25 a0 62 6c 00    	jmp    DWORD PTR ds:0x6c62a0
  466f9e:	ff 25 a4 62 6c 00    	jmp    DWORD PTR ds:0x6c62a4
  466fa4:	ff 25 a8 62 6c 00    	jmp    DWORD PTR ds:0x6c62a8
  466faa:	ff 25 ac 62 6c 00    	jmp    DWORD PTR ds:0x6c62ac
  466fb0:	ff 25 b0 62 6c 00    	jmp    DWORD PTR ds:0x6c62b0
  466fb6:	ff 25 b4 62 6c 00    	jmp    DWORD PTR ds:0x6c62b4
  466fbc:	ff 25 b8 62 6c 00    	jmp    DWORD PTR ds:0x6c62b8
  466fc2:	ff 25 bc 62 6c 00    	jmp    DWORD PTR ds:0x6c62bc
  466fc8:	ff 25 c0 62 6c 00    	jmp    DWORD PTR ds:0x6c62c0
  466fce:	ff 25 c4 62 6c 00    	jmp    DWORD PTR ds:0x6c62c4
  466fd4:	ff 25 c8 62 6c 00    	jmp    DWORD PTR ds:0x6c62c8
  466fda:	ff 25 cc 62 6c 00    	jmp    DWORD PTR ds:0x6c62cc
  466fe0:	ff 25 d0 62 6c 00    	jmp    DWORD PTR ds:0x6c62d0
  466fe6:	ff 25 d4 62 6c 00    	jmp    DWORD PTR ds:0x6c62d4
  466fec:	ff 25 4c 63 6c 00    	jmp    DWORD PTR ds:0x6c634c
  466ff2:	ff 25 dc 62 6c 00    	jmp    DWORD PTR ds:0x6c62dc
  466ff8:	ff 25 e0 62 6c 00    	jmp    DWORD PTR ds:0x6c62e0
  466ffe:	ff 25 e4 62 6c 00    	jmp    DWORD PTR ds:0x6c62e4
  467004:	ff 25 e8 62 6c 00    	jmp    DWORD PTR ds:0x6c62e8
  46700a:	ff 25 ec 62 6c 00    	jmp    DWORD PTR ds:0x6c62ec
  467010:	ff 25 f0 62 6c 00    	jmp    DWORD PTR ds:0x6c62f0
  467016:	ff 25 f4 62 6c 00    	jmp    DWORD PTR ds:0x6c62f4
  46701c:	ff 25 f8 62 6c 00    	jmp    DWORD PTR ds:0x6c62f8
  467022:	ff 25 fc 62 6c 00    	jmp    DWORD PTR ds:0x6c62fc
  467028:	ff 25 00 63 6c 00    	jmp    DWORD PTR ds:0x6c6300
  46702e:	ff 25 04 63 6c 00    	jmp    DWORD PTR ds:0x6c6304
  467034:	ff 25 08 63 6c 00    	jmp    DWORD PTR ds:0x6c6308
  46703a:	ff 25 0c 63 6c 00    	jmp    DWORD PTR ds:0x6c630c
  467040:	ff 25 10 63 6c 00    	jmp    DWORD PTR ds:0x6c6310
  467046:	ff 25 ec 5a 6c 00    	jmp    DWORD PTR ds:0x6c5aec
  46704c:	ff 25 a4 5a 6c 00    	jmp    DWORD PTR ds:0x6c5aa4
  467052:	ff 25 a8 5a 6c 00    	jmp    DWORD PTR ds:0x6c5aa8
  467058:	ff 25 ac 5a 6c 00    	jmp    DWORD PTR ds:0x6c5aac
  46705e:	ff 25 b0 5a 6c 00    	jmp    DWORD PTR ds:0x6c5ab0
  467064:	ff 25 b4 5a 6c 00    	jmp    DWORD PTR ds:0x6c5ab4
  46706a:	ff 25 b8 5a 6c 00    	jmp    DWORD PTR ds:0x6c5ab8
  467070:	ff 25 28 64 6c 00    	jmp    DWORD PTR ds:0x6c6428
  467076:	ff 25 ec 63 6c 00    	jmp    DWORD PTR ds:0x6c63ec
  46707c:	ff                   	.byte 0xff
  46707d:	25                   	.byte 0x25
  46707e:	e8                   	.byte 0xe8
  46707f:	63                   	.byte 0x63
