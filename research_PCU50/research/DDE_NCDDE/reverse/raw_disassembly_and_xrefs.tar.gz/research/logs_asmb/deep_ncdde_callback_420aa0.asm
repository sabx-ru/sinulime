
ncdde.exe:     file format pei-i386


Disassembly of section .text:

00420aa0 <.text+0x1faa0>:
  420aa0:	a0 00 c6 47 00       	mov    al,ds:0x47c600
  420aa5:	84 c0                	test   al,al
  420aa7:	74 06                	je     0x420aaf
  420aa9:	fe 05 e9 6c 4a 00    	inc    BYTE PTR ds:0x4a6ce9
  420aaf:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  420ab3:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  420ab7:	8b 54 24 18          	mov    edx,DWORD PTR [esp+0x18]
  420abb:	50                   	push   eax
  420abc:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  420ac0:	51                   	push   ecx
  420ac1:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  420ac5:	52                   	push   edx
  420ac6:	8b 54 24 18          	mov    edx,DWORD PTR [esp+0x18]
  420aca:	50                   	push   eax
  420acb:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  420acf:	51                   	push   ecx
  420ad0:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  420ad4:	52                   	push   edx
  420ad5:	50                   	push   eax
  420ad6:	51                   	push   ecx
  420ad7:	b9 a0 78 66 00       	mov    ecx,0x6678a0
  420adc:	e8 a7 18 fe ff       	call   0x402388
  420ae1:	8a 0d 00 c6 47 00    	mov    cl,BYTE PTR ds:0x47c600
  420ae7:	84 c9                	test   cl,cl
  420ae9:	74 06                	je     0x420af1
  420aeb:	fe 0d e9 6c 4a 00    	dec    BYTE PTR ds:0x4a6ce9
  420af1:	c2 20 00             	ret    0x20
  420af4:	90                   	nop
  420af5:	90                   	nop
  420af6:	90                   	nop
  420af7:	90                   	nop
  420af8:	90                   	nop
  420af9:	90                   	nop
  420afa:	90                   	nop
  420afb:	90                   	nop
  420afc:	90                   	nop
  420afd:	90                   	nop
  420afe:	90                   	nop
  420aff:	90                   	nop
  420b00:	cc                   	int3
  420b01:	cc                   	int3
  420b02:	cc                   	int3
  420b03:	cc                   	int3
  420b04:	cc                   	int3
  420b05:	cc                   	int3
  420b06:	cc                   	int3
  420b07:	cc                   	int3
  420b08:	cc                   	int3
  420b09:	cc                   	int3
  420b0a:	cc                   	int3
  420b0b:	cc                   	int3
  420b0c:	cc                   	int3
  420b0d:	cc                   	int3
  420b0e:	cc                   	int3
  420b0f:	cc                   	int3
  420b10:	cc                   	int3
  420b11:	cc                   	int3
  420b12:	cc                   	int3
  420b13:	cc                   	int3
  420b14:	cc                   	int3
  420b15:	cc                   	int3
  420b16:	cc                   	int3
  420b17:	cc                   	int3
  420b18:	cc                   	int3
  420b19:	cc                   	int3
  420b1a:	cc                   	int3
  420b1b:	cc                   	int3
  420b1c:	cc                   	int3
  420b1d:	cc                   	int3
  420b1e:	cc                   	int3
  420b1f:	cc                   	int3
  420b20:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  420b24:	53                   	push   ebx
  420b25:	55                   	push   ebp
  420b26:	56                   	push   esi
  420b27:	3d 10 40 00 00       	cmp    eax,0x4010
  420b2c:	57                   	push   edi
  420b2d:	8b f1                	mov    esi,ecx
  420b2f:	0f 87 f1 01 00 00    	ja     0x420d26
  420b35:	0f 84 2d 01 00 00    	je     0x420c68
  420b3b:	3d 22 20 00 00       	cmp    eax,0x2022
  420b40:	0f 87 80 03 00 00    	ja     0x420ec6
  420b46:	0f 84 a6 00 00 00    	je     0x420bf2
  420b4c:	2d 30 10 00 00       	sub    eax,0x1030
  420b51:	74 68                	je     0x420bbb
  420b53:	83 e8 32             	sub    eax,0x32
  420b56:	0f 85 6a 03 00 00    	jne    0x420ec6
  420b5c:	8b 86 14 25 00 00    	mov    eax,DWORD PTR [esi+0x2514]
  420b62:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  420b66:	50                   	push   eax
  420b67:	51                   	push   ecx
  420b68:	e8 b9 63 04 00       	call   0x466f26
  420b6d:	85 c0                	test   eax,eax
  420b6f:	0f 85 51 03 00 00    	jne    0x420ec6
  420b75:	8b 6c 24 20          	mov    ebp,DWORD PTR [esp+0x20]
  420b79:	33 ff                	xor    edi,edi
  420b7b:	8d 9e ce 27 00 00    	lea    ebx,[esi+0x27ce]
  420b81:	8b 13                	mov    edx,DWORD PTR [ebx]
  420b83:	52                   	push   edx
  420b84:	55                   	push   ebp
  420b85:	e8 9c 63 04 00       	call   0x466f26
  420b8a:	85 c0                	test   eax,eax
  420b8c:	74 12                	je     0x420ba0
  420b8e:	47                   	inc    edi
  420b8f:	83 c3 2c             	add    ebx,0x2c
  420b92:	83 ff 04             	cmp    edi,0x4
  420b95:	7c ea                	jl     0x420b81
  420b97:	5f                   	pop    edi
  420b98:	5e                   	pop    esi
  420b99:	5d                   	pop    ebp
  420b9a:	33 c0                	xor    eax,eax
  420b9c:	5b                   	pop    ebx
  420b9d:	c2 20 00             	ret    0x20
  420ba0:	8d 04 bf             	lea    eax,[edi+edi*4]
  420ba3:	8d 0c 47             	lea    ecx,[edi+eax*2]
  420ba6:	33 c0                	xor    eax,eax
  420ba8:	5f                   	pop    edi
  420ba9:	8b 94 8e d2 27 00 00 	mov    edx,DWORD PTR [esi+ecx*4+0x27d2]
  420bb0:	5e                   	pop    esi
  420bb1:	85 d2                	test   edx,edx
  420bb3:	5d                   	pop    ebp
  420bb4:	5b                   	pop    ebx
  420bb5:	0f 94 c0             	sete   al
  420bb8:	c2 20 00             	ret    0x20
  420bbb:	8b 5c 24 24          	mov    ebx,DWORD PTR [esp+0x24]
  420bbf:	33 ff                	xor    edi,edi
  420bc1:	81 c6 18 25 00 00    	add    esi,0x2518
  420bc7:	8b 16                	mov    edx,DWORD PTR [esi]
  420bc9:	52                   	push   edx
  420bca:	53                   	push   ebx
  420bcb:	e8 56 63 04 00       	call   0x466f26
  420bd0:	85 c0                	test   eax,eax
  420bd2:	74 12                	je     0x420be6
  420bd4:	47                   	inc    edi
  420bd5:	83 c6 04             	add    esi,0x4
  420bd8:	83 ff 22             	cmp    edi,0x22
  420bdb:	7c ea                	jl     0x420bc7
  420bdd:	5f                   	pop    edi
  420bde:	5e                   	pop    esi
  420bdf:	5d                   	pop    ebp
  420be0:	33 c0                	xor    eax,eax
  420be2:	5b                   	pop    ebx
  420be3:	c2 20 00             	ret    0x20
  420be6:	5f                   	pop    edi
  420be7:	5e                   	pop    esi
  420be8:	5d                   	pop    ebp
  420be9:	b8 01 00 00 00       	mov    eax,0x1
  420bee:	5b                   	pop    ebx
  420bef:	c2 20 00             	ret    0x20
  420bf2:	8b 86 2c 26 00 00    	mov    eax,DWORD PTR [esi+0x262c]
  420bf8:	85 c0                	test   eax,eax
  420bfa:	0f 84 c6 02 00 00    	je     0x420ec6
  420c00:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  420c04:	8b 8e 30 26 00 00    	mov    ecx,DWORD PTR [esi+0x2630]
  420c0a:	3b c1                	cmp    eax,ecx
  420c0c:	0f 85 b4 02 00 00    	jne    0x420ec6
  420c12:	8b 8e 34 26 00 00    	mov    ecx,DWORD PTR [esi+0x2634]
  420c18:	8b 7c 24 24          	mov    edi,DWORD PTR [esp+0x24]
  420c1c:	51                   	push   ecx
  420c1d:	57                   	push   edi
  420c1e:	e8 03 63 04 00       	call   0x466f26
  420c23:	85 c0                	test   eax,eax
  420c25:	0f 85 9b 02 00 00    	jne    0x420ec6
  420c2b:	8b 96 28 26 00 00    	mov    edx,DWORD PTR [esi+0x2628]
  420c31:	8b 8e 2c 26 00 00    	mov    ecx,DWORD PTR [esi+0x262c]
  420c37:	50                   	push   eax
  420c38:	52                   	push   edx
  420c39:	8b 96 10 25 00 00    	mov    edx,DWORD PTR [esi+0x2510]
  420c3f:	57                   	push   edi
  420c40:	50                   	push   eax
  420c41:	8b 86 38 26 00 00    	mov    eax,DWORD PTR [esi+0x2638]
  420c47:	50                   	push   eax
  420c48:	51                   	push   ecx
  420c49:	52                   	push   edx
  420c4a:	e8 07 63 04 00       	call   0x466f56
  420c4f:	85 c0                	test   eax,eax
  420c51:	0f 84 6f 02 00 00    	je     0x420ec6
  420c57:	c7 86 2c 26 00 00 00 	mov    DWORD PTR [esi+0x262c],0x0
  420c5e:	00 00 00 
  420c61:	5f                   	pop    edi
  420c62:	5e                   	pop    esi
  420c63:	5d                   	pop    ebp
  420c64:	5b                   	pop    ebx
  420c65:	c2 20 00             	ret    0x20
  420c68:	8a 86 cc 27 00 00    	mov    al,BYTE PTR [esi+0x27cc]
  420c6e:	3c 64                	cmp    al,0x64
  420c70:	0f 8d a4 00 00 00    	jge    0x420d1a
  420c76:	0f be c8             	movsx  ecx,al
  420c79:	8b bc 8e 3c 26 00 00 	mov    edi,DWORD PTR [esi+ecx*4+0x263c]
  420c80:	85 ff                	test   edi,edi
  420c82:	75 30                	jne    0x420cb4
  420c84:	68 f1 00 00 00       	push   0xf1
  420c89:	ff 15 28 61 6c 00    	call   DWORD PTR ds:0x6c6128
  420c8f:	0f be 96 cc 27 00 00 	movsx  edx,BYTE PTR [esi+0x27cc]
  420c96:	83 c4 04             	add    esp,0x4
  420c99:	89 84 96 3c 26 00 00 	mov    DWORD PTR [esi+edx*4+0x263c],eax
  420ca0:	8a 86 cc 27 00 00    	mov    al,BYTE PTR [esi+0x27cc]
  420ca6:	0f be c8             	movsx  ecx,al
  420ca9:	8b bc 8e 3c 26 00 00 	mov    edi,DWORD PTR [esi+ecx*4+0x263c]
  420cb0:	85 ff                	test   edi,edi
  420cb2:	74 66                	je     0x420d1a
  420cb4:	fe c0                	inc    al
  420cb6:	6a 00                	push   0x0
  420cb8:	88 86 cc 27 00 00    	mov    BYTE PTR [esi+0x27cc],al
  420cbe:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  420cc2:	8d 57 01             	lea    edx,[edi+0x1]
  420cc5:	68 f0 00 00 00       	push   0xf0
  420cca:	52                   	push   edx
  420ccb:	50                   	push   eax
  420ccc:	e8 4f 62 04 00       	call   0x466f20
  420cd1:	8b 54 24 1c          	mov    edx,DWORD PTR [esp+0x1c]
  420cd5:	c6 07 00             	mov    BYTE PTR [edi],0x0
  420cd8:	8a 0f                	mov    cl,BYTE PTR [edi]
  420cda:	8b c1                	mov    eax,ecx
  420cdc:	25 ff 00 00 00       	and    eax,0xff
  420ce1:	8d 1c 80             	lea    ebx,[eax+eax*4]
  420ce4:	8d 04 58             	lea    eax,[eax+ebx*2]
  420ce7:	39 94 86 d2 27 00 00 	cmp    DWORD PTR [esi+eax*4+0x27d2],edx
  420cee:	74 0a                	je     0x420cfa
  420cf0:	8a c1                	mov    al,cl
  420cf2:	fe c0                	inc    al
  420cf4:	3c 04                	cmp    al,0x4
  420cf6:	88 07                	mov    BYTE PTR [edi],al
  420cf8:	72 de                	jb     0x420cd8
  420cfa:	66 ff 86 04 0d 00 00 	inc    WORD PTR [esi+0xd04]
  420d01:	6a 01                	push   0x1
  420d03:	56                   	push   esi
  420d04:	b9 b8 97 4a 00       	mov    ecx,0x4a97b8
  420d09:	e8 e0 14 fe ff       	call   0x4021ee
  420d0e:	5f                   	pop    edi
  420d0f:	5e                   	pop    esi
  420d10:	5d                   	pop    ebp
  420d11:	b8 00 80 00 00       	mov    eax,0x8000
  420d16:	5b                   	pop    ebx
  420d17:	c2 20 00             	ret    0x20
  420d1a:	5f                   	pop    edi
  420d1b:	5e                   	pop    esi
  420d1c:	5d                   	pop    ebp
  420d1d:	b8 00 40 00 00       	mov    eax,0x4000
  420d22:	5b                   	pop    ebx
  420d23:	c2 20 00             	ret    0x20
  420d26:	3d 72 80 00 00       	cmp    eax,0x8072
  420d2b:	0f 87 36 01 00 00    	ja     0x420e67
  420d31:	0f 84 d7 00 00 00    	je     0x420e0e
  420d37:	3d 90 40 00 00       	cmp    eax,0x4090
  420d3c:	0f 85 84 01 00 00    	jne    0x420ec6
  420d42:	8b 6c 24 20          	mov    ebp,DWORD PTR [esp+0x20]
  420d46:	33 db                	xor    ebx,ebx
  420d48:	8d be ce 27 00 00    	lea    edi,[esi+0x27ce]
  420d4e:	8b 0f                	mov    ecx,DWORD PTR [edi]
  420d50:	51                   	push   ecx
  420d51:	55                   	push   ebp
  420d52:	e8 cf 61 04 00       	call   0x466f26
  420d57:	85 c0                	test   eax,eax
  420d59:	74 12                	je     0x420d6d
  420d5b:	43                   	inc    ebx
  420d5c:	83 c7 2c             	add    edi,0x2c
  420d5f:	83 fb 04             	cmp    ebx,0x4
  420d62:	7c ea                	jl     0x420d4e
  420d64:	5f                   	pop    edi
  420d65:	5e                   	pop    esi
  420d66:	5d                   	pop    ebp
  420d67:	33 c0                	xor    eax,eax
  420d69:	5b                   	pop    ebx
  420d6a:	c2 20 00             	ret    0x20
  420d6d:	83 fb 04             	cmp    ebx,0x4
  420d70:	0f 8d 50 01 00 00    	jge    0x420ec6
  420d76:	8a 86 cc 27 00 00    	mov    al,BYTE PTR [esi+0x27cc]
  420d7c:	3c 64                	cmp    al,0x64
  420d7e:	7d 7d                	jge    0x420dfd
  420d80:	0f be d0             	movsx  edx,al
  420d83:	8b bc 96 3c 26 00 00 	mov    edi,DWORD PTR [esi+edx*4+0x263c]
  420d8a:	85 ff                	test   edi,edi
  420d8c:	75 30                	jne    0x420dbe
  420d8e:	68 f1 00 00 00       	push   0xf1
  420d93:	ff 15 28 61 6c 00    	call   DWORD PTR ds:0x6c6128
  420d99:	0f be 8e cc 27 00 00 	movsx  ecx,BYTE PTR [esi+0x27cc]
  420da0:	83 c4 04             	add    esp,0x4
  420da3:	89 84 8e 3c 26 00 00 	mov    DWORD PTR [esi+ecx*4+0x263c],eax
  420daa:	8a 86 cc 27 00 00    	mov    al,BYTE PTR [esi+0x27cc]
  420db0:	0f be d0             	movsx  edx,al
  420db3:	8b bc 96 3c 26 00 00 	mov    edi,DWORD PTR [esi+edx*4+0x263c]
  420dba:	85 ff                	test   edi,edi
  420dbc:	74 3f                	je     0x420dfd
  420dbe:	8b 4c 24 28          	mov    ecx,DWORD PTR [esp+0x28]
  420dc2:	fe c0                	inc    al
  420dc4:	88 86 cc 27 00 00    	mov    BYTE PTR [esi+0x27cc],al
  420dca:	6a 00                	push   0x0
  420dcc:	8d 47 01             	lea    eax,[edi+0x1]
  420dcf:	68 f0 00 00 00       	push   0xf0
  420dd4:	50                   	push   eax
  420dd5:	51                   	push   ecx
  420dd6:	e8 45 61 04 00       	call   0x466f20
  420ddb:	6a 01                	push   0x1
  420ddd:	88 1f                	mov    BYTE PTR [edi],bl
  420ddf:	66 ff 86 04 0d 00 00 	inc    WORD PTR [esi+0xd04]
  420de6:	56                   	push   esi
  420de7:	b9 b8 97 4a 00       	mov    ecx,0x4a97b8
  420dec:	e8 fd 13 fe ff       	call   0x4021ee
  420df1:	5f                   	pop    edi
  420df2:	5e                   	pop    esi
  420df3:	5d                   	pop    ebp
  420df4:	b8 00 80 00 00       	mov    eax,0x8000
  420df9:	5b                   	pop    ebx
  420dfa:	c2 20 00             	ret    0x20
  420dfd:	c6 86 cd 27 00 00 01 	mov    BYTE PTR [esi+0x27cd],0x1
  420e04:	5f                   	pop    edi
  420e05:	5e                   	pop    esi
  420e06:	5d                   	pop    ebp
  420e07:	83 c8 ff             	or     eax,0xffffffff
  420e0a:	5b                   	pop    ebx
  420e0b:	c2 20 00             	ret    0x20
  420e0e:	8b 6c 24 20          	mov    ebp,DWORD PTR [esp+0x20]
  420e12:	33 ff                	xor    edi,edi
  420e14:	8d 9e ce 27 00 00    	lea    ebx,[esi+0x27ce]
  420e1a:	8b 13                	mov    edx,DWORD PTR [ebx]
  420e1c:	52                   	push   edx
  420e1d:	55                   	push   ebp
  420e1e:	e8 03 61 04 00       	call   0x466f26
  420e23:	85 c0                	test   eax,eax
  420e25:	74 12                	je     0x420e39
  420e27:	47                   	inc    edi
  420e28:	83 c3 2c             	add    ebx,0x2c
  420e2b:	83 ff 04             	cmp    edi,0x4
  420e2e:	7c ea                	jl     0x420e1a
  420e30:	5f                   	pop    edi
  420e31:	5e                   	pop    esi
  420e32:	5d                   	pop    ebp
  420e33:	33 c0                	xor    eax,eax
  420e35:	5b                   	pop    ebx
  420e36:	c2 20 00             	ret    0x20
  420e39:	8b 54 24 1c          	mov    edx,DWORD PTR [esp+0x1c]
  420e3d:	8d 04 bf             	lea    eax,[edi+edi*4]
  420e40:	6a 00                	push   0x0
  420e42:	8d 0c 47             	lea    ecx,[edi+eax*2]
  420e45:	89 94 8e d2 27 00 00 	mov    DWORD PTR [esi+ecx*4+0x27d2],edx
  420e4c:	c7 05 a8 9d 66 00 01 	mov    DWORD PTR ds:0x669da8,0x1
  420e53:	00 00 00 
  420e56:	e8 ef 11 fe ff       	call   0x40204a
  420e5b:	83 c4 04             	add    esp,0x4
  420e5e:	33 c0                	xor    eax,eax
  420e60:	5f                   	pop    edi
  420e61:	5e                   	pop    esi
  420e62:	5d                   	pop    ebp
  420e63:	5b                   	pop    ebx
  420e64:	c2 20 00             	ret    0x20
  420e67:	3d c2 80 00 00       	cmp    eax,0x80c2
  420e6c:	75 58                	jne    0x420ec6
  420e6e:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  420e72:	50                   	push   eax
  420e73:	e8 e9 04 fe ff       	call   0x401361
  420e78:	8b f8                	mov    edi,eax
  420e7a:	33 db                	xor    ebx,ebx
  420e7c:	83 c4 04             	add    esp,0x4
  420e7f:	3b fb                	cmp    edi,ebx
  420e81:	7c 43                	jl     0x420ec6
  420e83:	57                   	push   edi
  420e84:	8b ce                	mov    ecx,esi
  420e86:	e8 21 05 fe ff       	call   0x4013ac
  420e8b:	8d 0c bf             	lea    ecx,[edi+edi*4]
  420e8e:	33 c0                	xor    eax,eax
  420e90:	8d 14 4f             	lea    edx,[edi+ecx*2]
  420e93:	8d 8e d2 27 00 00    	lea    ecx,[esi+0x27d2]
  420e99:	89 9c 96 d2 27 00 00 	mov    DWORD PTR [esi+edx*4+0x27d2],ebx
  420ea0:	89 9e 08 25 00 00    	mov    DWORD PTR [esi+0x2508],ebx
  420ea6:	39 19                	cmp    DWORD PTR [ecx],ebx
  420ea8:	75 12                	jne    0x420ebc
  420eaa:	40                   	inc    eax
  420eab:	83 c1 2c             	add    ecx,0x2c
  420eae:	83 f8 04             	cmp    eax,0x4
  420eb1:	7c f3                	jl     0x420ea6
  420eb3:	5f                   	pop    edi
  420eb4:	5e                   	pop    esi
  420eb5:	5d                   	pop    ebp
  420eb6:	33 c0                	xor    eax,eax
  420eb8:	5b                   	pop    ebx
  420eb9:	c2 20 00             	ret    0x20
  420ebc:	c7 86 08 25 00 00 01 	mov    DWORD PTR [esi+0x2508],0x1
  420ec3:	00 00 00 
  420ec6:	5f                   	pop    edi
  420ec7:	5e                   	pop    esi
  420ec8:	5d                   	pop    ebp
  420ec9:	33 c0                	xor    eax,eax
  420ecb:	5b                   	pop    ebx
  420ecc:	c2 20 00             	ret    0x20
  420ecf:	90                   	nop
  420ed0:	cc                   	int3
  420ed1:	cc                   	int3
  420ed2:	cc                   	int3
  420ed3:	cc                   	int3
  420ed4:	cc                   	int3
  420ed5:	cc                   	int3
  420ed6:	cc                   	int3
  420ed7:	cc                   	int3
  420ed8:	cc                   	int3
  420ed9:	cc                   	int3
  420eda:	cc                   	int3
  420edb:	cc                   	int3
  420edc:	cc                   	int3
  420edd:	cc                   	int3
  420ede:	cc                   	int3
  420edf:	cc                   	int3
  420ee0:	cc                   	int3
  420ee1:	cc                   	int3
  420ee2:	cc                   	int3
  420ee3:	cc                   	int3
  420ee4:	cc                   	int3
  420ee5:	cc                   	int3
  420ee6:	cc                   	int3
  420ee7:	cc                   	int3
  420ee8:	cc                   	int3
  420ee9:	cc                   	int3
  420eea:	cc                   	int3
  420eeb:	cc                   	int3
  420eec:	cc                   	int3
  420eed:	cc                   	int3
  420eee:	cc                   	int3
  420eef:	cc                   	int3
  420ef0:	cc                   	int3
  420ef1:	cc                   	int3
  420ef2:	cc                   	int3
  420ef3:	cc                   	int3
  420ef4:	cc                   	int3
  420ef5:	cc                   	int3
  420ef6:	cc                   	int3
  420ef7:	cc                   	int3
  420ef8:	cc                   	int3
  420ef9:	cc                   	int3
  420efa:	cc                   	int3
  420efb:	cc                   	int3
  420efc:	cc                   	int3
  420efd:	cc                   	int3
  420efe:	cc                   	int3
  420eff:	cc                   	int3
  420f00:	cc                   	int3
  420f01:	cc                   	int3
  420f02:	cc                   	int3
  420f03:	cc                   	int3
  420f04:	cc                   	int3
  420f05:	cc                   	int3
  420f06:	cc                   	int3
  420f07:	cc                   	int3
  420f08:	cc                   	int3
  420f09:	cc                   	int3
  420f0a:	cc                   	int3
  420f0b:	cc                   	int3
  420f0c:	cc                   	int3
  420f0d:	cc                   	int3
  420f0e:	cc                   	int3
  420f0f:	cc                   	int3
  420f10:	cc                   	int3
  420f11:	cc                   	int3
  420f12:	cc                   	int3
  420f13:	cc                   	int3
  420f14:	cc                   	int3
  420f15:	cc                   	int3
  420f16:	cc                   	int3
  420f17:	cc                   	int3
  420f18:	cc                   	int3
  420f19:	cc                   	int3
  420f1a:	cc                   	int3
  420f1b:	cc                   	int3
  420f1c:	cc                   	int3
  420f1d:	cc                   	int3
  420f1e:	cc                   	int3
  420f1f:	cc                   	int3
  420f20:	cc                   	int3
  420f21:	cc                   	int3
  420f22:	cc                   	int3
  420f23:	cc                   	int3
  420f24:	cc                   	int3
  420f25:	cc                   	int3
  420f26:	cc                   	int3
  420f27:	cc                   	int3
  420f28:	cc                   	int3
  420f29:	cc                   	int3
  420f2a:	cc                   	int3
  420f2b:	cc                   	int3
  420f2c:	cc                   	int3
  420f2d:	cc                   	int3
  420f2e:	cc                   	int3
  420f2f:	cc                   	int3
  420f30:	cc                   	int3
  420f31:	cc                   	int3
  420f32:	cc                   	int3
  420f33:	cc                   	int3
  420f34:	cc                   	int3
  420f35:	cc                   	int3
  420f36:	cc                   	int3
  420f37:	cc                   	int3
  420f38:	cc                   	int3
  420f39:	cc                   	int3
  420f3a:	cc                   	int3
  420f3b:	cc                   	int3
  420f3c:	cc                   	int3
  420f3d:	cc                   	int3
  420f3e:	cc                   	int3
  420f3f:	cc                   	int3
  420f40:	cc                   	int3
  420f41:	cc                   	int3
  420f42:	cc                   	int3
  420f43:	cc                   	int3
  420f44:	cc                   	int3
  420f45:	cc                   	int3
  420f46:	cc                   	int3
  420f47:	cc                   	int3
  420f48:	cc                   	int3
  420f49:	cc                   	int3
  420f4a:	cc                   	int3
  420f4b:	cc                   	int3
  420f4c:	cc                   	int3
  420f4d:	cc                   	int3
  420f4e:	cc                   	int3
  420f4f:	cc                   	int3
  420f50:	cc                   	int3
  420f51:	cc                   	int3
  420f52:	cc                   	int3
  420f53:	cc                   	int3
  420f54:	cc                   	int3
  420f55:	cc                   	int3
  420f56:	cc                   	int3
  420f57:	cc                   	int3
  420f58:	cc                   	int3
  420f59:	cc                   	int3
  420f5a:	cc                   	int3
  420f5b:	cc                   	int3
  420f5c:	cc                   	int3
  420f5d:	cc                   	int3
  420f5e:	cc                   	int3
  420f5f:	cc                   	int3
