
/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00449260 <.text+0x48260>:
  449260:	ff 8b f0 eb cd a0    	dec    DWORD PTR [ebx-0x5f321410]
  449266:	16                   	push   ss
  449267:	6d                   	ins    DWORD PTR es:[edi],dx
  449268:	4a                   	dec    edx
  449269:	00 84 c0 0f 85 e1 07 	add    BYTE PTR [eax+eax*8+0x7e1850f],al
  449270:	00 00                	add    BYTE PTR [eax],al
  449272:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  449275:	83 fe 01             	cmp    esi,0x1
  449278:	74 59                	je     0x4492d3
  44927a:	33 d2                	xor    edx,edx
  44927c:	66 8b 15 50 99 49 00 	mov    dx,WORD PTR ds:0x499950
  449283:	3b f2                	cmp    esi,edx
  449285:	74 4c                	je     0x4492d3
  449287:	83 fe 07             	cmp    esi,0x7
  44928a:	75 3b                	jne    0x4492c7
  44928c:	a1 64 68 48 00       	mov    eax,ds:0x486864
  449291:	8b 0d 18 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d18
  449297:	50                   	push   eax
  449298:	51                   	push   ecx
  449299:	e8 88 dc 01 00       	call   0x466f26
  44929e:	85 c0                	test   eax,eax
  4492a0:	0f 85 ad 07 00 00    	jne    0x449a53
  4492a6:	8b 15 64 68 48 00    	mov    edx,DWORD PTR ds:0x486864
  4492ac:	a1 c0 6c 4a 00       	mov    eax,ds:0x4a6cc0
  4492b1:	57                   	push   edi
  4492b2:	56                   	push   esi
  4492b3:	52                   	push   edx
  4492b4:	57                   	push   edi
  4492b5:	6a 06                	push   0x6
  4492b7:	68 64 9c 47 00       	push   0x479c64
  4492bc:	50                   	push   eax
  4492bd:	e8 94 dc 01 00       	call   0x466f56
  4492c2:	e9 63 06 00 00       	jmp    0x44992a
  4492c7:	6a 04                	push   0x4
  4492c9:	e8 93 85 fb ff       	call   0x401861
  4492ce:	e9 54 06 00 00       	jmp    0x449927
  4492d3:	a1 d0 6c 4a 00       	mov    eax,ds:0x4a6cd0
  4492d8:	83 f8 01             	cmp    eax,0x1
  4492db:	74 1a                	je     0x4492f7
  4492dd:	83 f8 02             	cmp    eax,0x2
  4492e0:	75 09                	jne    0x4492eb
  4492e2:	a0 e8 6c 4a 00       	mov    al,ds:0x4a6ce8
  4492e7:	84 c0                	test   al,al
  4492e9:	75 0c                	jne    0x4492f7
  4492eb:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  4492f1:	51                   	push   ecx
  4492f2:	e9 2b 06 00 00       	jmp    0x449922
  4492f7:	68 d0 42 48 00       	push   0x4842d0
  4492fc:	e8 50 90 fb ff       	call   0x402351
  449301:	83 c4 04             	add    esp,0x4
  449304:	8d 55 9c             	lea    edx,[ebp-0x64]
  449307:	8d 4d e8             	lea    ecx,[ebp-0x18]
  44930a:	a3 60 68 48 00       	mov    ds:0x486860,eax
  44930f:	6a 01                	push   0x1
  449311:	52                   	push   edx
  449312:	51                   	push   ecx
  449313:	50                   	push   eax
  449314:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  449319:	e8 b3 88 fb ff       	call   0x401bd1
  44931e:	85 c0                	test   eax,eax
  449320:	75 0c                	jne    0x44932e
  449322:	6a 04                	push   0x4
  449324:	e8 e4 92 fb ff       	call   0x40260d
  449329:	e9 f9 05 00 00       	jmp    0x449927
  44932e:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449331:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  449335:	75 0e                	jne    0x449345
  449337:	8b 15 2c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d2c
  44933d:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  449340:	a3 68 68 48 00       	mov    ds:0x486868,eax
  449345:	8b 15 9c 40 48 00    	mov    edx,DWORD PTR ds:0x48409c
  44934b:	8b 02                	mov    eax,DWORD PTR [edx]
  44934d:	b2 ff                	mov    dl,0xff
  44934f:	38 50 2f             	cmp    BYTE PTR [eax+0x2f],dl
  449352:	0f 85 04 01 00 00    	jne    0x44945c
  449358:	8b 79 19             	mov    edi,DWORD PTR [ecx+0x19]
  44935b:	38 57 3f             	cmp    BYTE PTR [edi+0x3f],dl
  44935e:	0f 85 f6 00 00 00    	jne    0x44945a
  449364:	f6 41 1f 04          	test   BYTE PTR [ecx+0x1f],0x4
  449368:	0f 85 ec 00 00 00    	jne    0x44945a
  44936e:	83 3d 8c 40 48 00 01 	cmp    DWORD PTR ds:0x48408c,0x1
  449375:	0f 85 df 00 00 00    	jne    0x44945a
  44937b:	8d 55 e0             	lea    edx,[ebp-0x20]
  44937e:	6a 01                	push   0x1
  449380:	52                   	push   edx
  449381:	8b 15 68 68 48 00    	mov    edx,DWORD PTR ds:0x486868
  449387:	83 c0 04             	add    eax,0x4
  44938a:	52                   	push   edx
  44938b:	50                   	push   eax
  44938c:	e8 f6 90 fb ff       	call   0x402487
  449391:	33 ff                	xor    edi,edi
  449393:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  449396:	3b c7                	cmp    eax,edi
  449398:	0f 84 b7 00 00 00    	je     0x449455
  44939e:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  4493a4:	a3 54 68 48 00       	mov    ds:0x486854,eax
  4493a9:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  4493ad:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  4493b4:	8d 4d d8             	lea    ecx,[ebp-0x28]
  4493b7:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  4493ba:	e8 85 d0 01 00       	call   0x466444
  4493bf:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4493c2:	56                   	push   esi
  4493c3:	68 98 40 48 00       	push   0x484098
  4493c8:	c6 45 fc 08          	mov    BYTE PTR [ebp-0x4],0x8
  4493cc:	c6 40 7b 01          	mov    BYTE PTR [eax+0x7b],0x1
  4493d0:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4493d3:	51                   	push   ecx
  4493d4:	e8 d4 8d fb ff       	call   0x4021ad
  4493d9:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  4493dc:	83 c4 0c             	add    esp,0xc
  4493df:	8b f0                	mov    esi,eax
  4493e1:	c6 42 7b 00          	mov    BYTE PTR [edx+0x7b],0x0
  4493e5:	eb 16                	jmp    0x4493fd
  4493e7:	8b 45 0c             	mov    eax,DWORD PTR [ebp+0xc]
  4493ea:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4493ed:	89 45 dc             	mov    DWORD PTR [ebp-0x24],eax
  4493f0:	b8 fa 93 44 00       	mov    eax,0x4493fa
  4493f5:	c6 41 7b 00          	mov    BYTE PTR [ecx+0x7b],0x0
  4493f9:	c3                   	ret
  4493fa:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  4493fd:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  449404:	e8 35 d0 01 00       	call   0x46643e
  449409:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  44940c:	8b 42 2a             	mov    eax,DWORD PTR [edx+0x2a]
  44940f:	85 c0                	test   eax,eax
  449411:	74 11                	je     0x449424
  449413:	50                   	push   eax
  449414:	6a 00                	push   0x0
  449416:	6a 00                	push   0x0
  449418:	6a 00                	push   0x0
  44941a:	6a 01                	push   0x1
  44941c:	e8 81 89 fb ff       	call   0x401da2
  449421:	83 c4 14             	add    esp,0x14
  449424:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449428:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  44942f:	66 3d ff ff          	cmp    ax,0xffff
  449433:	0f 84 0a fe ff ff    	je     0x449243
  449439:	0f bf c0             	movsx  eax,ax
  44943c:	8d 04 40             	lea    eax,[eax+eax*2]
  44943f:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  449446:	00 
  449447:	66 83 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],0x0
  44944e:	00 00 
  449450:	e9 fd 04 00 00       	jmp    0x449952
  449455:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449458:	eb 02                	jmp    0x44945c
  44945a:	33 ff                	xor    edi,edi
  44945c:	68 48 68 48 00       	push   0x486848
  449461:	8d 45 ec             	lea    eax,[ebp-0x14]
  449464:	6a 01                	push   0x1
  449466:	50                   	push   eax
  449467:	e8 d6 93 fb ff       	call   0x402842
  44946c:	85 c0                	test   eax,eax
  44946e:	0f 8c df 05 00 00    	jl     0x449a53
  449474:	a0 02 c6 47 00       	mov    al,ds:0x47c602
  449479:	84 c0                	test   al,al
  44947b:	74 3b                	je     0x4494b8
  44947d:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  449480:	8d 4d e4             	lea    ecx,[ebp-0x1c]
  449483:	51                   	push   ecx
  449484:	52                   	push   edx
  449485:	e8 41 92 fb ff       	call   0x4026cb
  44948a:	83 c4 08             	add    esp,0x8
  44948d:	85 c0                	test   eax,eax
  44948f:	74 27                	je     0x4494b8
  449491:	8b 45 e4             	mov    eax,DWORD PTR [ebp-0x1c]
  449494:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  449497:	50                   	push   eax
  449498:	57                   	push   edi
  449499:	6a 04                	push   0x4
  44949b:	57                   	push   edi
  44949c:	51                   	push   ecx
  44949d:	e8 00 89 fb ff       	call   0x401da2
  4494a2:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  4494a5:	68 48 68 48 00       	push   0x486848
  4494aa:	52                   	push   edx
  4494ab:	e8 da 91 fb ff       	call   0x40268a
  4494b0:	83 c4 1c             	add    esp,0x1c
  4494b3:	e9 9b 05 00 00       	jmp    0x449a53
  4494b8:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4494bb:	3b c7                	cmp    eax,edi
  4494bd:	a3 54 68 48 00       	mov    ds:0x486854,eax
  4494c2:	74 0d                	je     0x4494d1
  4494c4:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  4494c8:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  4494cf:	eb 07                	jmp    0x4494d8
  4494d1:	66 89 3d 50 68 48 00 	mov    WORD PTR ds:0x486850,di
  4494d8:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  4494de:	8d 4d d0             	lea    ecx,[ebp-0x30]
  4494e1:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  4494e4:	e8 5b cf 01 00       	call   0x466444
  4494e9:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4494ec:	c6 45 fc 0b          	mov    BYTE PTR [ebp-0x4],0xb
  4494f0:	8a 48 04             	mov    cl,BYTE PTR [eax+0x4]
  4494f3:	84 c9                	test   cl,cl
  4494f5:	74 55                	je     0x44954c
  4494f7:	39 78 2a             	cmp    DWORD PTR [eax+0x2a],edi
  4494fa:	75 50                	jne    0x44954c
  4494fc:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  449500:	e8 39 cf 01 00       	call   0x46643e
  449505:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449509:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  44950c:	66 3b c3             	cmp    ax,bx
  44950f:	0f 84 ad 02 00 00    	je     0x4497c2
  449515:	0f bf c0             	movsx  eax,ax
  449518:	8d 04 40             	lea    eax,[eax+eax*2]
  44951b:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  449522:	00 
  449523:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  44952a:	00 
  44952b:	0f 85 91 02 00 00    	jne    0x4497c2
  449531:	8d 4d cc             	lea    ecx,[ebp-0x34]
  449534:	e8 ca 86 fb ff       	call   0x401c03
  449539:	8b c3                	mov    eax,ebx
  44953b:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  44953e:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  449545:	5f                   	pop    edi
  449546:	5e                   	pop    esi
  449547:	5b                   	pop    ebx
  449548:	8b e5                	mov    esp,ebp
  44954a:	5d                   	pop    ebp
  44954b:	c3                   	ret
  44954c:	8d 88 a2 00 00 00    	lea    ecx,[eax+0xa2]
  449552:	56                   	push   esi
  449553:	51                   	push   ecx
  449554:	50                   	push   eax
  449555:	e8 53 8c fb ff       	call   0x4021ad
  44955a:	8b f0                	mov    esi,eax
  44955c:	83 c4 0c             	add    esp,0xc
  44955f:	3b f3                	cmp    esi,ebx
  449561:	74 1f                	je     0x449582
  449563:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  449566:	68 48 68 48 00       	push   0x486848
  44956b:	52                   	push   edx
  44956c:	e8 19 91 fb ff       	call   0x40268a
  449571:	83 c4 08             	add    esp,0x8
  449574:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  449578:	e8 c1 ce 01 00       	call   0x46643e
  44957d:	e9 aa 03 00 00       	jmp    0x44992c
  449582:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  449585:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  449589:	c6 40 04 01          	mov    BYTE PTR [eax+0x4],0x1
  44958d:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449590:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  449593:	8a 51 27             	mov    dl,BYTE PTR [ecx+0x27]
  449596:	88 50 32             	mov    BYTE PTR [eax+0x32],dl
  449599:	e8 a0 ce 01 00       	call   0x46643e
  44959e:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  4495a2:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  4495a5:	66 3b c3             	cmp    ax,bx
  4495a8:	0f 84 14 02 00 00    	je     0x4497c2
  4495ae:	0f bf c0             	movsx  eax,ax
  4495b1:	8d 04 40             	lea    eax,[eax+eax*2]
  4495b4:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  4495bb:	00 
  4495bc:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  4495c3:	00 
  4495c4:	0f 85 f8 01 00 00    	jne    0x4497c2
  4495ca:	8d 4d cc             	lea    ecx,[ebp-0x34]
  4495cd:	e8 31 86 fb ff       	call   0x401c03
  4495d2:	8b c3                	mov    eax,ebx
  4495d4:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4495d7:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4495de:	5f                   	pop    edi
  4495df:	5e                   	pop    esi
  4495e0:	5b                   	pop    ebx
  4495e1:	8b e5                	mov    esp,ebp
  4495e3:	5d                   	pop    ebp
  4495e4:	c3                   	ret
  4495e5:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  4495e8:	8b 4d 0c             	mov    ecx,DWORD PTR [ebp+0xc]
  4495eb:	68 48 68 48 00       	push   0x486848
  4495f0:	52                   	push   edx
  4495f1:	89 4d d4             	mov    DWORD PTR [ebp-0x2c],ecx
  4495f4:	e8 91 90 fb ff       	call   0x40268a
  4495f9:	83 c4 08             	add    esp,0x8
  4495fc:	e8 37 ce 01 00       	call   0x466438
  449601:	6a 00                	push   0x0
  449603:	6a 00                	push   0x0
  449605:	e8 c6 d4 01 00       	call   0x466ad0
  44960a:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  44960f:	84 c0                	test   al,al
  449611:	0f 85 3c 04 00 00    	jne    0x449a53
  449617:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  44961a:	83 fe 01             	cmp    esi,0x1
  44961d:	74 18                	je     0x449637
  44961f:	33 c0                	xor    eax,eax
  449621:	66 a1 50 99 49 00    	mov    ax,ds:0x499950
  449627:	3b f0                	cmp    esi,eax
  449629:	74 0c                	je     0x449637
  44962b:	6a 05                	push   0x5
  44962d:	e8 2f 82 fb ff       	call   0x401861
  449632:	e9 f0 02 00 00       	jmp    0x449927
  449637:	a1 d0 6c 4a 00       	mov    eax,ds:0x4a6cd0
  44963c:	83 f8 01             	cmp    eax,0x1
  44963f:	74 1a                	je     0x44965b
  449641:	83 f8 02             	cmp    eax,0x2
  449644:	75 09                	jne    0x44964f
  449646:	a0 e8 6c 4a 00       	mov    al,ds:0x4a6ce8
  44964b:	84 c0                	test   al,al
  44964d:	75 0c                	jne    0x44965b
  44964f:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  449655:	51                   	push   ecx
  449656:	e9 c7 02 00 00       	jmp    0x449922
  44965b:	68 d0 42 48 00       	push   0x4842d0
  449660:	e8 ec 8c fb ff       	call   0x402351
  449665:	6a 03                	push   0x3
  449667:	a3 60 68 48 00       	mov    ds:0x486860,eax
  44966c:	e8 7d 81 fb ff       	call   0x4017ee
  449671:	83 c4 08             	add    esp,0x8
  449674:	3b c7                	cmp    eax,edi
  449676:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  449679:	74 10                	je     0x44968b
  44967b:	8b 90 a6 00 00 00    	mov    edx,DWORD PTR [eax+0xa6]
  449681:	8b 0a                	mov    ecx,DWORD PTR [edx]
  449683:	8b 49 36             	mov    ecx,DWORD PTR [ecx+0x36]
  449686:	89 4d e8             	mov    DWORD PTR [ebp-0x18],ecx
  449689:	eb 64                	jmp    0x4496ef
  44968b:	8b 0d 60 68 48 00    	mov    ecx,DWORD PTR ds:0x486860
  449691:	8d 55 9c             	lea    edx,[ebp-0x64]
  449694:	6a 01                	push   0x1
  449696:	8d 45 e8             	lea    eax,[ebp-0x18]
  449699:	52                   	push   edx
  44969a:	50                   	push   eax
  44969b:	51                   	push   ecx
  44969c:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  4496a1:	e8 2b 85 fb ff       	call   0x401bd1
  4496a6:	85 c0                	test   eax,eax
  4496a8:	75 0c                	jne    0x4496b6
  4496aa:	6a 05                	push   0x5
  4496ac:	e8 5c 8f fb ff       	call   0x40260d
  4496b1:	e9 71 02 00 00       	jmp    0x449927
  4496b6:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  4496b9:	6a 03                	push   0x3
  4496bb:	e8 e7 8b fb ff       	call   0x4022a7
  4496c0:	3b c7                	cmp    eax,edi
  4496c2:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  4496c5:	75 28                	jne    0x4496ef
  4496c7:	8b 55 e8             	mov    edx,DWORD PTR [ebp-0x18]
  4496ca:	f6 42 1f 01          	test   BYTE PTR [edx+0x1f],0x1
  4496ce:	75 0d                	jne    0x4496dd
  4496d0:	a1 2c 6d 4a 00       	mov    eax,ds:0x4a6d2c
  4496d5:	8b 40 04             	mov    eax,DWORD PTR [eax+0x4]
  4496d8:	a3 68 68 48 00       	mov    ds:0x486868,eax
  4496dd:	68 44 68 48 00       	push   0x486844
  4496e2:	6a 03                	push   0x3
  4496e4:	e8 5c 7a fb ff       	call   0x401145
  4496e9:	83 c4 08             	add    esp,0x8
  4496ec:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  4496ef:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  4496f2:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  4496f6:	75 0f                	jne    0x449707
  4496f8:	8b 15 2c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d2c
  4496fe:	8b 4a 04             	mov    ecx,DWORD PTR [edx+0x4]
  449701:	89 0d 68 68 48 00    	mov    DWORD PTR ds:0x486868,ecx
  449707:	8a 0d 02 c6 47 00    	mov    cl,BYTE PTR ds:0x47c602
  44970d:	84 c9                	test   cl,cl
  44970f:	74 3b                	je     0x44974c
  449711:	8d 4d e4             	lea    ecx,[ebp-0x1c]
  449714:	51                   	push   ecx
  449715:	50                   	push   eax
  449716:	e8 b0 8f fb ff       	call   0x4026cb
  44971b:	83 c4 08             	add    esp,0x8
  44971e:	85 c0                	test   eax,eax
  449720:	74 27                	je     0x449749
  449722:	8b 55 e4             	mov    edx,DWORD PTR [ebp-0x1c]
  449725:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  449728:	52                   	push   edx
  449729:	57                   	push   edi
  44972a:	6a 05                	push   0x5
  44972c:	57                   	push   edi
  44972d:	50                   	push   eax
  44972e:	e8 6f 86 fb ff       	call   0x401da2
  449733:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  449736:	68 44 68 48 00       	push   0x486844
  44973b:	51                   	push   ecx
  44973c:	e8 49 8f fb ff       	call   0x40268a
  449741:	83 c4 1c             	add    esp,0x1c
  449744:	e9 0a 03 00 00       	jmp    0x449a53
  449749:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  44974c:	3b c7                	cmp    eax,edi
  44974e:	a3 54 68 48 00       	mov    ds:0x486854,eax
  449753:	74 0d                	je     0x449762
  449755:	66 8b 50 36          	mov    dx,WORD PTR [eax+0x36]
  449759:	66 89 15 50 68 48 00 	mov    WORD PTR ds:0x486850,dx
  449760:	eb 07                	jmp    0x449769
  449762:	66 89 3d 50 68 48 00 	mov    WORD PTR ds:0x486850,di
  449769:	8b 0d 60 68 48 00    	mov    ecx,DWORD PTR ds:0x486860
  44976f:	89 48 08             	mov    DWORD PTR [eax+0x8],ecx
  449772:	8d 4d d8             	lea    ecx,[ebp-0x28]
  449775:	e8 ca cc 01 00       	call   0x466444
  44977a:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  44977d:	c6 45 fc 05          	mov    BYTE PTR [ebp-0x4],0x5
  449781:	8a 48 04             	mov    cl,BYTE PTR [eax+0x4]
  449784:	84 c9                	test   cl,cl
  449786:	74 4d                	je     0x4497d5
  449788:	39 78 2a             	cmp    DWORD PTR [eax+0x2a],edi
  44978b:	75 48                	jne    0x4497d5
  44978d:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  449791:	e8 a8 cc 01 00       	call   0x46643e
  449796:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  44979a:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  44979d:	66 3b c3             	cmp    ax,bx
  4497a0:	74 20                	je     0x4497c2
  4497a2:	0f bf c0             	movsx  eax,ax
  4497a5:	8d 04 40             	lea    eax,[eax+eax*2]
  4497a8:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  4497af:	00 
  4497b0:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  4497b7:	00 
  4497b8:	75 08                	jne    0x4497c2
  4497ba:	8d 4d cc             	lea    ecx,[ebp-0x34]
  4497bd:	e8 41 84 fb ff       	call   0x401c03
  4497c2:	8b c3                	mov    eax,ebx
  4497c4:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4497c7:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4497ce:	5f                   	pop    edi
  4497cf:	5e                   	pop    esi
  4497d0:	5b                   	pop    ebx
  4497d1:	8b e5                	mov    esp,ebp
  4497d3:	5d                   	pop    ebp
  4497d4:	c3                   	ret
  4497d5:	8b 55 10             	mov    edx,DWORD PTR [ebp+0x10]
  4497d8:	52                   	push   edx
  4497d9:	56                   	push   esi
  4497da:	50                   	push   eax
  4497db:	e8 48 82 fb ff       	call   0x401a28
  4497e0:	8b f0                	mov    esi,eax
  4497e2:	83 c4 0c             	add    esp,0xc
  4497e5:	3b f3                	cmp    esi,ebx
  4497e7:	74 0e                	je     0x4497f7
  4497e9:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4497ec:	68 44 68 48 00       	push   0x486844
  4497f1:	50                   	push   eax
  4497f2:	e9 75 fd ff ff       	jmp    0x44956c
  4497f7:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4497fa:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  4497fe:	c6 41 04 01          	mov    BYTE PTR [ecx+0x4],0x1
  449802:	8b 55 e8             	mov    edx,DWORD PTR [ebp-0x18]
  449805:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  449808:	8a 42 27             	mov    al,BYTE PTR [edx+0x27]
  44980b:	88 41 32             	mov    BYTE PTR [ecx+0x32],al
  44980e:	e8 2b cc 01 00       	call   0x46643e
  449813:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449817:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  44981a:	66 3b c3             	cmp    ax,bx
  44981d:	74 a3                	je     0x4497c2
  44981f:	0f bf c0             	movsx  eax,ax
  449822:	8d 04 40             	lea    eax,[eax+eax*2]
  449825:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  44982c:	00 
  44982d:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  449834:	00 
  449835:	75 8b                	jne    0x4497c2
  449837:	8d 4d cc             	lea    ecx,[ebp-0x34]
  44983a:	e8 c4 83 fb ff       	call   0x401c03
  44983f:	8b c3                	mov    eax,ebx
  449841:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  449844:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  44984b:	5f                   	pop    edi
  44984c:	5e                   	pop    esi
  44984d:	5b                   	pop    ebx
  44984e:	8b e5                	mov    esp,ebp
  449850:	5d                   	pop    ebp
  449851:	c3                   	ret
  449852:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  449855:	8b 55 0c             	mov    edx,DWORD PTR [ebp+0xc]
  449858:	68 44 68 48 00       	push   0x486844
  44985d:	50                   	push   eax
  44985e:	89 55 dc             	mov    DWORD PTR [ebp-0x24],edx
  449861:	e8 24 8e fb ff       	call   0x40268a
  449866:	83 c4 08             	add    esp,0x8
  449869:	e8 ca cb 01 00       	call   0x466438
  44986e:	6a 00                	push   0x0
  449870:	6a 00                	push   0x0
  449872:	e8 59 d2 01 00       	call   0x466ad0
  449877:	8d 86 fe 7f ff ff    	lea    eax,[esi-0x8002]
  44987d:	3d d0 00 00 00       	cmp    eax,0xd0
  449882:	0f 87 f1 01 00 00    	ja     0x449a79
  449888:	33 c9                	xor    ecx,ecx
  44988a:	8a 88 14 9b 44 00    	mov    cl,BYTE PTR [eax+0x449b14]
  449890:	ff 24 8d fc 9a 44 00 	jmp    DWORD PTR [ecx*4+0x449afc]
  449897:	a1 5c 68 48 00       	mov    eax,ds:0x48685c
  44989c:	8b 0d 04 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d04
  4498a2:	3b c8                	cmp    ecx,eax
  4498a4:	75 06                	jne    0x4498ac
  4498a6:	89 3d 04 6d 4a 00    	mov    DWORD PTR ds:0x4a6d04,edi
  4498ac:	39 05 08 6d 4a 00    	cmp    DWORD PTR ds:0x4a6d08,eax
  4498b2:	75 06                	jne    0x4498ba
  4498b4:	89 3d 08 6d 4a 00    	mov    DWORD PTR ds:0x4a6d08,edi
  4498ba:	39 05 0c 6d 4a 00    	cmp    DWORD PTR ds:0x4a6d0c,eax
  4498c0:	75 06                	jne    0x4498c8
  4498c2:	89 3d 0c 6d 4a 00    	mov    DWORD PTR ds:0x4a6d0c,edi
  4498c8:	8a 0d 16 6d 4a 00    	mov    cl,BYTE PTR ds:0x4a6d16
  4498ce:	84 c9                	test   cl,cl
  4498d0:	75 10                	jne    0x4498e2
  4498d2:	83 3d d0 6c 4a 00 01 	cmp    DWORD PTR ds:0x4a6cd0,0x1
  4498d9:	74 07                	je     0x4498e2
  4498db:	e8 25 77 fb ff       	call   0x401005
  4498e0:	eb 09                	jmp    0x4498eb
  4498e2:	50                   	push   eax
  4498e3:	e8 6a 8e fb ff       	call   0x402752
  4498e8:	83 c4 04             	add    esp,0x4
  4498eb:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  4498ee:	66 39 5d cc          	cmp    WORD PTR [ebp-0x34],bx
  4498f2:	74 08                	je     0x4498fc
  4498f4:	8d 4d cc             	lea    ecx,[ebp-0x34]
  4498f7:	e8 b3 86 fb ff       	call   0x401faf
  4498fc:	b8 01 00 00 00       	mov    eax,0x1
  449901:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  449904:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  44990b:	5f                   	pop    edi
  44990c:	5e                   	pop    esi
  44990d:	5b                   	pop    ebx
  44990e:	8b e5                	mov    esp,ebp
  449910:	5d                   	pop    ebp
  449911:	c3                   	ret
  449912:	83 3d d0 6c 4a 00 01 	cmp    DWORD PTR ds:0x4a6cd0,0x1
  449919:	74 58                	je     0x449973
  44991b:	8b 15 5c 68 48 00    	mov    edx,DWORD PTR ds:0x48685c
  449921:	52                   	push   edx
  449922:	e8 83 81 fb ff       	call   0x401aaa
  449927:	83 c4 04             	add    esp,0x4
  44992a:	8b f0                	mov    esi,eax
  44992c:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449930:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  449933:	66 3b c3             	cmp    ax,bx
  449936:	0f 84 07 f9 ff ff    	je     0x449243
  44993c:	0f bf c0             	movsx  eax,ax
  44993f:	8d 04 40             	lea    eax,[eax+eax*2]
  449942:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  449949:	00 
  44994a:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  449951:	00 
  449952:	0f 85 eb f8 ff ff    	jne    0x449243
  449958:	8d 4d cc             	lea    ecx,[ebp-0x34]
  44995b:	e8 a3 82 fb ff       	call   0x401c03
  449960:	8b c6                	mov    eax,esi
  449962:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  449965:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  44996c:	5f                   	pop    edi
  44996d:	5e                   	pop    esi
  44996e:	5b                   	pop    ebx
  44996f:	8b e5                	mov    esp,ebp
  449971:	5d                   	pop    ebp
  449972:	c3                   	ret
  449973:	68 d0 42 48 00       	push   0x4842d0
  449978:	e8 d4 89 fb ff       	call   0x402351
  44997d:	83 c4 04             	add    esp,0x4
  449980:	8d 4d 9c             	lea    ecx,[ebp-0x64]
  449983:	8d 55 e8             	lea    edx,[ebp-0x18]
  449986:	a3 60 68 48 00       	mov    ds:0x486860,eax
  44998b:	6a 01                	push   0x1
  44998d:	51                   	push   ecx
  44998e:	52                   	push   edx
  44998f:	50                   	push   eax
  449990:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  449995:	e8 37 82 fb ff       	call   0x401bd1
  44999a:	85 c0                	test   eax,eax
  44999c:	75 53                	jne    0x4499f1
  44999e:	6a 0a                	push   0xa
  4499a0:	e8 68 8c fb ff       	call   0x40260d
  4499a5:	8b f0                	mov    esi,eax
  4499a7:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  4499ab:	83 c4 04             	add    esp,0x4
  4499ae:	66 3b c3             	cmp    ax,bx
  4499b1:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  4499b4:	0f 84 89 f8 ff ff    	je     0x449243
  4499ba:	0f bf c0             	movsx  eax,ax
  4499bd:	8d 04 40             	lea    eax,[eax+eax*2]
  4499c0:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  4499c7:	00 
  4499c8:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  4499cf:	00 
  4499d0:	0f 85 6d f8 ff ff    	jne    0x449243
  4499d6:	8d 4d cc             	lea    ecx,[ebp-0x34]
  4499d9:	e8 25 82 fb ff       	call   0x401c03
  4499de:	8b c6                	mov    eax,esi
  4499e0:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4499e3:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4499ea:	5f                   	pop    edi
  4499eb:	5e                   	pop    esi
  4499ec:	5b                   	pop    ebx
  4499ed:	8b e5                	mov    esp,ebp
  4499ef:	5d                   	pop    ebp
  4499f0:	c3                   	ret
  4499f1:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  4499f4:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  4499f8:	75 0d                	jne    0x449a07
  4499fa:	a1 2c 6d 4a 00       	mov    eax,ds:0x4a6d2c
  4499ff:	8b 40 04             	mov    eax,DWORD PTR [eax+0x4]
  449a02:	a3 68 68 48 00       	mov    ds:0x486868,eax
  449a07:	6a 02                	push   0x2
  449a09:	e8 99 88 fb ff       	call   0x4022a7
  449a0e:	3b c7                	cmp    eax,edi
  449a10:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  449a13:	74 3e                	je     0x449a53
  449a15:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  449a1b:	a3 54 68 48 00       	mov    ds:0x486854,eax
  449a20:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  449a24:	56                   	push   esi
  449a25:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  449a2c:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  449a2f:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  449a32:	50                   	push   eax
  449a33:	e8 21 81 fb ff       	call   0x401b59
  449a38:	83 c4 08             	add    esp,0x8
  449a3b:	e9 ea fe ff ff       	jmp    0x44992a
  449a40:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  449a46:	6a 03                	push   0x3
  449a48:	51                   	push   ecx
  449a49:	b9 a8 26 48 00       	mov    ecx,0x4826a8
  449a4e:	e8 e7 77 fb ff       	call   0x40123a
  449a53:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449a57:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  449a5a:	66 3b c3             	cmp    ax,bx
  449a5d:	74 46                	je     0x449aa5
  449a5f:	0f bf c0             	movsx  eax,ax
  449a62:	8d 04 40             	lea    eax,[eax+eax*2]
  449a65:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  449a6c:	00 
  449a6d:	66 39 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],di
  449a74:	00 
  449a75:	75 2e                	jne    0x449aa5
  449a77:	eb 24                	jmp    0x449a9d
  449a79:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449a7d:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
