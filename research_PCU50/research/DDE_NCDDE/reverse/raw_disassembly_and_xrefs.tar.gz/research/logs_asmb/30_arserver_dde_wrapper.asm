
/root/PL/PCU_old/H/mmc2/ARServer.exe:     file format pei-i386


Disassembly of section .text:

0042a880 <.text+0x29880>:
  42a880:	42                   	inc    edx
  42a881:	00 ff                	add    bh,bh
  42a883:	25 48 d0 42 00       	and    eax,0x42d048
  42a888:	ff 25 44 d0 42 00    	jmp    DWORD PTR ds:0x42d044
  42a88e:	ff 25 40 d0 42 00    	jmp    DWORD PTR ds:0x42d040
  42a894:	ff 25 3c d0 42 00    	jmp    DWORD PTR ds:0x42d03c
  42a89a:	ff 25 38 d0 42 00    	jmp    DWORD PTR ds:0x42d038
  42a8a0:	ff 25 34 d0 42 00    	jmp    DWORD PTR ds:0x42d034
  42a8a6:	ff 25 30 d0 42 00    	jmp    DWORD PTR ds:0x42d030
  42a8ac:	ff 25 2c d0 42 00    	jmp    DWORD PTR ds:0x42d02c
  42a8b2:	ff 25 28 d0 42 00    	jmp    DWORD PTR ds:0x42d028
  42a8b8:	ff 25 24 d0 42 00    	jmp    DWORD PTR ds:0x42d024
  42a8be:	ff 25 f8 d4 42 00    	jmp    DWORD PTR ds:0x42d4f8
  42a8c4:	ff 25 f4 d4 42 00    	jmp    DWORD PTR ds:0x42d4f4
  42a8ca:	ff 25 f0 d4 42 00    	jmp    DWORD PTR ds:0x42d4f0
  42a8d0:	ff 25 ec d4 42 00    	jmp    DWORD PTR ds:0x42d4ec
  42a8d6:	ff 25 e8 d4 42 00    	jmp    DWORD PTR ds:0x42d4e8
  42a8dc:	ff 25 00 d5 42 00    	jmp    DWORD PTR ds:0x42d500
  42a8e2:	ff 25 e4 d4 42 00    	jmp    DWORD PTR ds:0x42d4e4
  42a8e8:	ff 25 e0 d4 42 00    	jmp    DWORD PTR ds:0x42d4e0
  42a8ee:	ff 25 dc d4 42 00    	jmp    DWORD PTR ds:0x42d4dc
  42a8f4:	ff 25 d8 d4 42 00    	jmp    DWORD PTR ds:0x42d4d8
  42a8fa:	ff 25 d4 d4 42 00    	jmp    DWORD PTR ds:0x42d4d4
  42a900:	ff 25 d0 d4 42 00    	jmp    DWORD PTR ds:0x42d4d0
  42a906:	ff 25 cc d4 42 00    	jmp    DWORD PTR ds:0x42d4cc
  42a90c:	ff 25 c8 d4 42 00    	jmp    DWORD PTR ds:0x42d4c8
  42a912:	ff 25 c4 d4 42 00    	jmp    DWORD PTR ds:0x42d4c4
  42a918:	ff 25 c0 d4 42 00    	jmp    DWORD PTR ds:0x42d4c0
  42a91e:	ff 25 bc d4 42 00    	jmp    DWORD PTR ds:0x42d4bc
  42a924:	ff 25 b8 d4 42 00    	jmp    DWORD PTR ds:0x42d4b8
  42a92a:	ff 25 64 d4 42 00    	jmp    DWORD PTR ds:0x42d464
  42a930:	ff 25 24 d4 42 00    	jmp    DWORD PTR ds:0x42d424
  42a936:	ff 25 28 d4 42 00    	jmp    DWORD PTR ds:0x42d428
  42a93c:	ff 25 2c d4 42 00    	jmp    DWORD PTR ds:0x42d42c
  42a942:	ff 25 30 d4 42 00    	jmp    DWORD PTR ds:0x42d430
  42a948:	ff 25 34 d4 42 00    	jmp    DWORD PTR ds:0x42d434
  42a94e:	ff 25 38 d4 42 00    	jmp    DWORD PTR ds:0x42d438
  42a954:	ff 25 3c d4 42 00    	jmp    DWORD PTR ds:0x42d43c
  42a95a:	ff 25 40 d4 42 00    	jmp    DWORD PTR ds:0x42d440
  42a960:	ff 25 44 d4 42 00    	jmp    DWORD PTR ds:0x42d444
  42a966:	ff 25 48 d4 42 00    	jmp    DWORD PTR ds:0x42d448
  42a96c:	ff 25 4c d4 42 00    	jmp    DWORD PTR ds:0x42d44c
  42a972:	ff 25 50 d4 42 00    	jmp    DWORD PTR ds:0x42d450
  42a978:	ff 25 54 d4 42 00    	jmp    DWORD PTR ds:0x42d454
  42a97e:	ff 25 58 d4 42 00    	jmp    DWORD PTR ds:0x42d458
  42a984:	ff 25 5c d4 42 00    	jmp    DWORD PTR ds:0x42d45c
  42a98a:	ff 25 60 d4 42 00    	jmp    DWORD PTR ds:0x42d460
  42a990:	ff 25 fc d4 42 00    	jmp    DWORD PTR ds:0x42d4fc
  42a996:	ff 25 68 d4 42 00    	jmp    DWORD PTR ds:0x42d468
  42a99c:	ff 25 6c d4 42 00    	jmp    DWORD PTR ds:0x42d46c
  42a9a2:	ff 25 70 d4 42 00    	jmp    DWORD PTR ds:0x42d470
  42a9a8:	ff 25 74 d4 42 00    	jmp    DWORD PTR ds:0x42d474
  42a9ae:	ff 25 78 d4 42 00    	jmp    DWORD PTR ds:0x42d478
  42a9b4:	ff 25 7c d4 42 00    	jmp    DWORD PTR ds:0x42d47c
  42a9ba:	ff 25 80 d4 42 00    	jmp    DWORD PTR ds:0x42d480
  42a9c0:	ff 25 84 d4 42 00    	jmp    DWORD PTR ds:0x42d484
  42a9c6:	ff 25 88 d4 42 00    	jmp    DWORD PTR ds:0x42d488
  42a9cc:	ff 25 8c d4 42 00    	jmp    DWORD PTR ds:0x42d48c
  42a9d2:	ff 25 90 d4 42 00    	jmp    DWORD PTR ds:0x42d490
  42a9d8:	ff 25 94 d4 42 00    	jmp    DWORD PTR ds:0x42d494
  42a9de:	ff 25 98 d4 42 00    	jmp    DWORD PTR ds:0x42d498
  42a9e4:	ff 25 9c d4 42 00    	jmp    DWORD PTR ds:0x42d49c
  42a9ea:	ff 25 a0 d4 42 00    	jmp    DWORD PTR ds:0x42d4a0
  42a9f0:	ff 25 a4 d4 42 00    	jmp    DWORD PTR ds:0x42d4a4
  42a9f6:	ff 25 a8 d4 42 00    	jmp    DWORD PTR ds:0x42d4a8
  42a9fc:	ff 25 ac d4 42 00    	jmp    DWORD PTR ds:0x42d4ac
  42aa02:	ff 25 b0 d4 42 00    	jmp    DWORD PTR ds:0x42d4b0
  42aa08:	ff 25 b4 d4 42 00    	jmp    DWORD PTR ds:0x42d4b4
  42aa0e:	ff 25 14 d0 42 00    	jmp    DWORD PTR ds:0x42d014
  42aa14:	ff 25 08 d0 42 00    	jmp    DWORD PTR ds:0x42d008
  42aa1a:	ff 25 0c d0 42 00    	jmp    DWORD PTR ds:0x42d00c
