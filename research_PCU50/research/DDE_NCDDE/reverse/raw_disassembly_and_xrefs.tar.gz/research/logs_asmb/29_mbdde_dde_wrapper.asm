
/root/PL/PCU_old/H/mmc2/mbdde.exe:     file format pei-i386


Disassembly of section .text:

00431cc0 <.text+0x30cc0>:
  431cc0:	24 a2                	and    al,0xa2
  431cc2:	44                   	inc    esp
  431cc3:	00 ff                	add    bh,bh
  431cc5:	25 28 a2 44 00       	and    eax,0x44a228
  431cca:	ff 25 2c a2 44 00    	jmp    DWORD PTR ds:0x44a22c
  431cd0:	ff 25 30 a2 44 00    	jmp    DWORD PTR ds:0x44a230
  431cd6:	ff 25 34 a2 44 00    	jmp    DWORD PTR ds:0x44a234
  431cdc:	ff 25 38 a2 44 00    	jmp    DWORD PTR ds:0x44a238
  431ce2:	ff 25 3c a2 44 00    	jmp    DWORD PTR ds:0x44a23c
  431ce8:	ff 25 40 a2 44 00    	jmp    DWORD PTR ds:0x44a240
  431cee:	ff 25 44 a2 44 00    	jmp    DWORD PTR ds:0x44a244
  431cf4:	ff 25 48 a2 44 00    	jmp    DWORD PTR ds:0x44a248
  431cfa:	ff 25 4c a2 44 00    	jmp    DWORD PTR ds:0x44a24c
  431d00:	ff 25 50 a2 44 00    	jmp    DWORD PTR ds:0x44a250
  431d06:	ff 25 4c a6 44 00    	jmp    DWORD PTR ds:0x44a64c
  431d0c:	ff 25 48 a6 44 00    	jmp    DWORD PTR ds:0x44a648
  431d12:	ff 25 44 a6 44 00    	jmp    DWORD PTR ds:0x44a644
  431d18:	ff 25 40 a6 44 00    	jmp    DWORD PTR ds:0x44a640
  431d1e:	ff 25 3c a6 44 00    	jmp    DWORD PTR ds:0x44a63c
  431d24:	ff 25 38 a6 44 00    	jmp    DWORD PTR ds:0x44a638
  431d2a:	ff 25 34 a6 44 00    	jmp    DWORD PTR ds:0x44a634
  431d30:	ff 25 30 a6 44 00    	jmp    DWORD PTR ds:0x44a630
  431d36:	ff 25 2c a6 44 00    	jmp    DWORD PTR ds:0x44a62c
  431d3c:	ff 25 28 a6 44 00    	jmp    DWORD PTR ds:0x44a628
  431d42:	ff 25 24 a6 44 00    	jmp    DWORD PTR ds:0x44a624
  431d48:	ff 25 20 a6 44 00    	jmp    DWORD PTR ds:0x44a620
  431d4e:	ff 25 1c a6 44 00    	jmp    DWORD PTR ds:0x44a61c
  431d54:	ff 25 18 a6 44 00    	jmp    DWORD PTR ds:0x44a618
  431d5a:	ff 25 14 a6 44 00    	jmp    DWORD PTR ds:0x44a614
  431d60:	ff 25 10 a6 44 00    	jmp    DWORD PTR ds:0x44a610
  431d66:	ff 25 0c a6 44 00    	jmp    DWORD PTR ds:0x44a60c
  431d6c:	ff 25 08 a6 44 00    	jmp    DWORD PTR ds:0x44a608
  431d72:	ff 25 04 a6 44 00    	jmp    DWORD PTR ds:0x44a604
  431d78:	ff 25 00 a6 44 00    	jmp    DWORD PTR ds:0x44a600
  431d7e:	ff 25 fc a5 44 00    	jmp    DWORD PTR ds:0x44a5fc
  431d84:	ff 25 f8 a5 44 00    	jmp    DWORD PTR ds:0x44a5f8
  431d8a:	ff 25 f4 a5 44 00    	jmp    DWORD PTR ds:0x44a5f4
  431d90:	ff 25 f0 a5 44 00    	jmp    DWORD PTR ds:0x44a5f0
  431d96:	ff 25 ec a5 44 00    	jmp    DWORD PTR ds:0x44a5ec
  431d9c:	ff 25 e8 a5 44 00    	jmp    DWORD PTR ds:0x44a5e8
  431da2:	ff 25 e4 a5 44 00    	jmp    DWORD PTR ds:0x44a5e4
  431da8:	ff 25 e0 a5 44 00    	jmp    DWORD PTR ds:0x44a5e0
  431dae:	ff 25 dc a5 44 00    	jmp    DWORD PTR ds:0x44a5dc
  431db4:	ff 25 d8 a5 44 00    	jmp    DWORD PTR ds:0x44a5d8
  431dba:	ff 25 d4 a5 44 00    	jmp    DWORD PTR ds:0x44a5d4
  431dc0:	ff 25 d0 a5 44 00    	jmp    DWORD PTR ds:0x44a5d0
  431dc6:	ff 25 cc a5 44 00    	jmp    DWORD PTR ds:0x44a5cc
  431dcc:	ff 25 c8 a5 44 00    	jmp    DWORD PTR ds:0x44a5c8
  431dd2:	ff 25 c4 a5 44 00    	jmp    DWORD PTR ds:0x44a5c4
  431dd8:	ff 25 c0 a5 44 00    	jmp    DWORD PTR ds:0x44a5c0
  431dde:	ff 25 bc a5 44 00    	jmp    DWORD PTR ds:0x44a5bc
  431de4:	ff 25 b8 a5 44 00    	jmp    DWORD PTR ds:0x44a5b8
  431dea:	ff 25 b4 a5 44 00    	jmp    DWORD PTR ds:0x44a5b4
  431df0:	ff 25 b0 a5 44 00    	jmp    DWORD PTR ds:0x44a5b0
  431df6:	ff 25 ac a5 44 00    	jmp    DWORD PTR ds:0x44a5ac
  431dfc:	ff 25 a8 a5 44 00    	jmp    DWORD PTR ds:0x44a5a8
  431e02:	ff 25 a4 a5 44 00    	jmp    DWORD PTR ds:0x44a5a4
  431e08:	ff 25 a0 a5 44 00    	jmp    DWORD PTR ds:0x44a5a0
  431e0e:	ff 25 9c a5 44 00    	jmp    DWORD PTR ds:0x44a59c
  431e14:	ff 25 98 a5 44 00    	jmp    DWORD PTR ds:0x44a598
  431e1a:	ff 25 94 a5 44 00    	jmp    DWORD PTR ds:0x44a594
