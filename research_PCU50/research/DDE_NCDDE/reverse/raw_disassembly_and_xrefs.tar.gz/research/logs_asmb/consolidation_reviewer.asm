
/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

0044a440 <.text+0x49440>:
  44a440:	83 ec 10             	sub    esp,0x10
  44a443:	53                   	push   ebx
  44a444:	55                   	push   ebp
  44a445:	8b 6c 24 1c          	mov    ebp,DWORD PTR [esp+0x1c]
  44a449:	56                   	push   esi
  44a44a:	57                   	push   edi
  44a44b:	8b 85 a6 00 00 00    	mov    eax,DWORD PTR [ebp+0xa6]
  44a451:	8b 08                	mov    ecx,DWORD PTR [eax]
  44a453:	8a 45 07             	mov    al,BYTE PTR [ebp+0x7]
  44a456:	3c 02                	cmp    al,0x2
  44a458:	8b 71 36             	mov    esi,DWORD PTR [ecx+0x36]
  44a45b:	75 54                	jne    0x44a4b1
  44a45d:	8b 55 1c             	mov    edx,DWORD PTR [ebp+0x1c]
  44a460:	a1 64 68 48 00       	mov    eax,ds:0x486864
  44a465:	3b d0                	cmp    edx,eax
  44a467:	75 2b                	jne    0x44a494
  44a469:	8b 45 20             	mov    eax,DWORD PTR [ebp+0x20]
  44a46c:	8b 0d 68 68 48 00    	mov    ecx,DWORD PTR ds:0x486868
  44a472:	3b c1                	cmp    eax,ecx
  44a474:	75 1e                	jne    0x44a494
  44a476:	8b 4d 2e             	mov    ecx,DWORD PTR [ebp+0x2e]
  44a479:	a1 5c 68 48 00       	mov    eax,ds:0x48685c
  44a47e:	3b c8                	cmp    ecx,eax
  44a480:	75 12                	jne    0x44a494
  44a482:	8b 85 80 00 00 00    	mov    eax,DWORD PTR [ebp+0x80]
  44a488:	f7 d8                	neg    eax
  44a48a:	1b c0                	sbb    eax,eax
  44a48c:	23 c5                	and    eax,ebp
  44a48e:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  44a492:	eb 25                	jmp    0x44a4b9
  44a494:	6a 02                	push   0x2
  44a496:	8b ce                	mov    ecx,esi
  44a498:	e8 0a 7e fb ff       	call   0x4022a7
  44a49d:	85 c0                	test   eax,eax
  44a49f:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  44a4a3:	74 14                	je     0x44a4b9
  44a4a5:	8b d0                	mov    edx,eax
  44a4a7:	8b 82 80 00 00 00    	mov    eax,DWORD PTR [edx+0x80]
  44a4ad:	85 c0                	test   eax,eax
  44a4af:	75 08                	jne    0x44a4b9
  44a4b1:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  44a4b8:	00 
  44a4b9:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  44a4bd:	8b 8d aa 00 00 00    	mov    ecx,DWORD PTR [ebp+0xaa]
  44a4c3:	ba 01 00 00 00       	mov    edx,0x1
  44a4c8:	c7 44 24 14 00 00 00 	mov    DWORD PTR [esp+0x14],0x0
  44a4cf:	00 
  44a4d0:	3b c2                	cmp    eax,edx
  44a4d2:	89 4c 24 18          	mov    DWORD PTR [esp+0x18],ecx
  44a4d6:	0f 84 fd 00 00 00    	je     0x44a5d9
  44a4dc:	3b ca                	cmp    ecx,edx
  44a4de:	74 11                	je     0x44a4f1
  44a4e0:	55                   	push   ebp
  44a4e1:	e8 80 6e fb ff       	call   0x401366
  44a4e6:	83 c4 04             	add    esp,0x4
  44a4e9:	5f                   	pop    edi
  44a4ea:	5e                   	pop    esi
  44a4eb:	5d                   	pop    ebp
  44a4ec:	5b                   	pop    ebx
  44a4ed:	83 c4 10             	add    esp,0x10
  44a4f0:	c3                   	ret
  44a4f1:	f6 46 1f 01          	test   BYTE PTR [esi+0x1f],0x1
  44a4f5:	0f 85 af 00 00 00    	jne    0x44a5aa
  44a4fb:	8b 85 a6 00 00 00    	mov    eax,DWORD PTR [ebp+0xa6]
  44a501:	83 cf ff             	or     edi,0xffffffff
  44a504:	8b 08                	mov    ecx,DWORD PTR [eax]
  44a506:	8b 41 16             	mov    eax,DWORD PTR [ecx+0x16]
  44a509:	3b c7                	cmp    eax,edi
  44a50b:	75 15                	jne    0x44a522
  44a50d:	8b 51 06             	mov    edx,DWORD PTR [ecx+0x6]
  44a510:	3b d7                	cmp    edx,edi
  44a512:	75 08                	jne    0x44a51c
  44a514:	89 3d b8 6c 4a 00    	mov    DWORD PTR ds:0x4a6cb8,edi
  44a51a:	eb 0f                	jmp    0x44a52b
  44a51c:	8b 41 0a             	mov    eax,DWORD PTR [ecx+0xa]
  44a51f:	2b c2                	sub    eax,edx
  44a521:	40                   	inc    eax
  44a522:	3b c7                	cmp    eax,edi
  44a524:	a3 b8 6c 4a 00       	mov    ds:0x4a6cb8,eax
  44a529:	75 2d                	jne    0x44a558
  44a52b:	8b 4e 19             	mov    ecx,DWORD PTR [esi+0x19]
  44a52e:	8b 41 26             	mov    eax,DWORD PTR [ecx+0x26]
  44a531:	3b c7                	cmp    eax,edi
  44a533:	75 15                	jne    0x44a54a
  44a535:	8b 51 16             	mov    edx,DWORD PTR [ecx+0x16]
  44a538:	3b d7                	cmp    edx,edi
  44a53a:	75 08                	jne    0x44a544
  44a53c:	89 3d b8 6c 4a 00    	mov    DWORD PTR ds:0x4a6cb8,edi
  44a542:	eb 0f                	jmp    0x44a553
  44a544:	8b 41 1a             	mov    eax,DWORD PTR [ecx+0x1a]
  44a547:	2b c2                	sub    eax,edx
  44a549:	40                   	inc    eax
  44a54a:	3b c7                	cmp    eax,edi
  44a54c:	a3 b8 6c 4a 00       	mov    ds:0x4a6cb8,eax
  44a551:	75 05                	jne    0x44a558
  44a553:	b8 01 00 00 00       	mov    eax,0x1
  44a558:	8b 4e 15             	mov    ecx,DWORD PTR [esi+0x15]
  44a55b:	49                   	dec    ecx
  44a55c:	74 2d                	je     0x44a58b
  44a55e:	83 e9 02             	sub    ecx,0x2
  44a561:	75 3e                	jne    0x44a5a1
  44a563:	83 f8 01             	cmp    eax,0x1
  44a566:	74 11                	je     0x44a579
  44a568:	55                   	push   ebp
  44a569:	e8 f8 6d fb ff       	call   0x401366
  44a56e:	83 c4 04             	add    esp,0x4
  44a571:	5f                   	pop    edi
  44a572:	5e                   	pop    esi
  44a573:	5d                   	pop    ebp
  44a574:	5b                   	pop    ebx
  44a575:	83 c4 10             	add    esp,0x10
  44a578:	c3                   	ret
  44a579:	8b 54 24 2c          	mov    edx,DWORD PTR [esp+0x2c]
  44a57d:	8b 46 09             	mov    eax,DWORD PTR [esi+0x9]
  44a580:	8b 4e 11             	mov    ecx,DWORD PTR [esi+0x11]
  44a583:	52                   	push   edx
  44a584:	50                   	push   eax
  44a585:	51                   	push   ecx
  44a586:	e9 ef 00 00 00       	jmp    0x44a67a
  44a58b:	83 f8 01             	cmp    eax,0x1
  44a58e:	74 11                	je     0x44a5a1
  44a590:	55                   	push   ebp
  44a591:	e8 d0 6d fb ff       	call   0x401366
  44a596:	83 c4 04             	add    esp,0x4
  44a599:	5f                   	pop    edi
  44a59a:	5e                   	pop    esi
  44a59b:	5d                   	pop    ebp
  44a59c:	5b                   	pop    ebx
  44a59d:	83 c4 10             	add    esp,0x10
  44a5a0:	c3                   	ret
  44a5a1:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44a5a5:	ba 01 00 00 00       	mov    edx,0x1
  44a5aa:	66 c7 05 d0 6b 48 00 	mov    WORD PTR ds:0x486bd0,0x14
  44a5b1:	14 00 
  44a5b3:	66 89 15 d2 6b 48 00 	mov    WORD PTR ds:0x486bd2,dx
  44a5ba:	c7 05 e0 6b 48 00 f9 	mov    DWORD PTR ds:0x486be0,0xf6f7f8f9
  44a5c1:	f8 f7 f6 
  44a5c4:	66 c7 05 d6 6b 48 00 	mov    WORD PTR ds:0x486bd6,0x0
  44a5cb:	00 00 
  44a5cd:	bf 03 00 00 00       	mov    edi,0x3
  44a5d2:	b8 e4 6b 48 00       	mov    eax,0x486be4
  44a5d7:	eb 07                	jmp    0x44a5e0
  44a5d9:	8b fa                	mov    edi,edx
  44a5db:	b8 d0 6b 48 00       	mov    eax,0x486bd0
  44a5e0:	33 f6                	xor    esi,esi
  44a5e2:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  44a5e6:	85 c9                	test   ecx,ecx
  44a5e8:	89 54 24 1c          	mov    DWORD PTR [esp+0x1c],edx
  44a5ec:	7e 3f                	jle    0x44a62d
  44a5ee:	8b 5c 24 28          	mov    ebx,DWORD PTR [esp+0x28]
  44a5f2:	8b 4c 24 2c          	mov    ecx,DWORD PTR [esp+0x2c]
  44a5f6:	57                   	push   edi
  44a5f7:	8d 54 24 18          	lea    edx,[esp+0x18]
  44a5fb:	51                   	push   ecx
  44a5fc:	8d 44 24 2c          	lea    eax,[esp+0x2c]
  44a600:	52                   	push   edx
  44a601:	50                   	push   eax
  44a602:	56                   	push   esi
  44a603:	53                   	push   ebx
  44a604:	8d 4c 24 34          	lea    ecx,[esp+0x34]
  44a608:	55                   	push   ebp
  44a609:	51                   	push   ecx
  44a60a:	e8 2c 7a fb ff       	call   0x40203b
  44a60f:	83 c4 20             	add    esp,0x20
  44a612:	83 f8 fd             	cmp    eax,0xfffffffd
  44a615:	74 42                	je     0x44a659
  44a617:	83 f8 fe             	cmp    eax,0xfffffffe
  44a61a:	74 47                	je     0x44a663
  44a61c:	85 c0                	test   eax,eax
  44a61e:	74 39                	je     0x44a659
  44a620:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  44a624:	46                   	inc    esi
  44a625:	3b f0                	cmp    esi,eax
  44a627:	7c c9                	jl     0x44a5f2
  44a629:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  44a62d:	8b 4c 24 2c          	mov    ecx,DWORD PTR [esp+0x2c]
  44a631:	83 f9 01             	cmp    ecx,0x1
  44a634:	75 0c                	jne    0x44a642
  44a636:	c6 00 00             	mov    BYTE PTR [eax],0x0
  44a639:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  44a63d:	40                   	inc    eax
  44a63e:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  44a642:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  44a646:	85 d2                	test   edx,edx
  44a648:	74 24                	je     0x44a66e
  44a64a:	8b 8a 80 00 00 00    	mov    ecx,DWORD PTR [edx+0x80]
  44a650:	68 d0 6b 48 00       	push   0x486bd0
  44a655:	8b 11                	mov    edx,DWORD PTR [ecx]
  44a657:	ff 12                	call   DWORD PTR [edx]
  44a659:	5f                   	pop    edi
  44a65a:	5e                   	pop    esi
  44a65b:	5d                   	pop    ebp
  44a65c:	33 c0                	xor    eax,eax
  44a65e:	5b                   	pop    ebx
  44a65f:	83 c4 10             	add    esp,0x10
  44a662:	c3                   	ret
  44a663:	5f                   	pop    edi
  44a664:	5e                   	pop    esi
  44a665:	5d                   	pop    ebp
  44a666:	83 c8 ff             	or     eax,0xffffffff
  44a669:	5b                   	pop    ebx
  44a66a:	83 c4 10             	add    esp,0x10
  44a66d:	c3                   	ret
  44a66e:	2d d0 6b 48 00       	sub    eax,0x486bd0
  44a673:	51                   	push   ecx
  44a674:	50                   	push   eax
  44a675:	68 d0 6b 48 00       	push   0x486bd0
  44a67a:	8d 44 24 20          	lea    eax,[esp+0x20]
  44a67e:	50                   	push   eax
  44a67f:	55                   	push   ebp
  44a680:	e8 73 6c fb ff       	call   0x4012f8
  44a685:	83 c4 14             	add    esp,0x14
  44a688:	5f                   	pop    edi
  44a689:	5e                   	pop    esi
  44a68a:	5d                   	pop    ebp
  44a68b:	5b                   	pop    ebx
  44a68c:	83 c4 10             	add    esp,0x10
  44a68f:	c3                   	ret
  44a690:	cc                   	int3
  44a691:	cc                   	int3
  44a692:	cc                   	int3
  44a693:	cc                   	int3
  44a694:	cc                   	int3
  44a695:	cc                   	int3
  44a696:	cc                   	int3
  44a697:	cc                   	int3
  44a698:	cc                   	int3
  44a699:	cc                   	int3
  44a69a:	cc                   	int3
  44a69b:	cc                   	int3
  44a69c:	cc                   	int3
  44a69d:	cc                   	int3
  44a69e:	cc                   	int3
  44a69f:	cc                   	int3
  44a6a0:	cc                   	int3
  44a6a1:	cc                   	int3
  44a6a2:	cc                   	int3
  44a6a3:	cc                   	int3
  44a6a4:	cc                   	int3
  44a6a5:	cc                   	int3
  44a6a6:	cc                   	int3
  44a6a7:	cc                   	int3
  44a6a8:	cc                   	int3
  44a6a9:	cc                   	int3
  44a6aa:	cc                   	int3
  44a6ab:	cc                   	int3
  44a6ac:	cc                   	int3
  44a6ad:	cc                   	int3
  44a6ae:	cc                   	int3
  44a6af:	cc                   	int3
  44a6b0:	cc                   	int3
  44a6b1:	cc                   	int3
  44a6b2:	cc                   	int3
  44a6b3:	cc                   	int3
  44a6b4:	cc                   	int3
  44a6b5:	cc                   	int3
  44a6b6:	cc                   	int3
  44a6b7:	cc                   	int3
  44a6b8:	cc                   	int3
  44a6b9:	cc                   	int3
  44a6ba:	cc                   	int3
  44a6bb:	cc                   	int3
  44a6bc:	cc                   	int3
  44a6bd:	cc                   	int3
  44a6be:	cc                   	int3
  44a6bf:	cc                   	int3
  44a6c0:	cc                   	int3
  44a6c1:	cc                   	int3
  44a6c2:	cc                   	int3
  44a6c3:	cc                   	int3
  44a6c4:	cc                   	int3
  44a6c5:	cc                   	int3
  44a6c6:	cc                   	int3
  44a6c7:	cc                   	int3
  44a6c8:	cc                   	int3
  44a6c9:	cc                   	int3
  44a6ca:	cc                   	int3
  44a6cb:	cc                   	int3
  44a6cc:	cc                   	int3
  44a6cd:	cc                   	int3
  44a6ce:	cc                   	int3
  44a6cf:	cc                   	int3
  44a6d0:	cc                   	int3
  44a6d1:	cc                   	int3
  44a6d2:	cc                   	int3
  44a6d3:	cc                   	int3
  44a6d4:	cc                   	int3
  44a6d5:	cc                   	int3
  44a6d6:	cc                   	int3
  44a6d7:	cc                   	int3
  44a6d8:	cc                   	int3
  44a6d9:	cc                   	int3
  44a6da:	cc                   	int3
  44a6db:	cc                   	int3
  44a6dc:	cc                   	int3
  44a6dd:	cc                   	int3
  44a6de:	cc                   	int3
  44a6df:	cc                   	int3
  44a6e0:	cc                   	int3
  44a6e1:	cc                   	int3
  44a6e2:	cc                   	int3
  44a6e3:	cc                   	int3
  44a6e4:	cc                   	int3
  44a6e5:	cc                   	int3
  44a6e6:	cc                   	int3
  44a6e7:	cc                   	int3
  44a6e8:	cc                   	int3
  44a6e9:	cc                   	int3
  44a6ea:	cc                   	int3
  44a6eb:	cc                   	int3
  44a6ec:	cc                   	int3
  44a6ed:	cc                   	int3
  44a6ee:	cc                   	int3
  44a6ef:	cc                   	int3
  44a6f0:	cc                   	int3
  44a6f1:	cc                   	int3
  44a6f2:	cc                   	int3
  44a6f3:	cc                   	int3
  44a6f4:	cc                   	int3
  44a6f5:	cc                   	int3
  44a6f6:	cc                   	int3
  44a6f7:	cc                   	int3
  44a6f8:	cc                   	int3
  44a6f9:	cc                   	int3
  44a6fa:	cc                   	int3
  44a6fb:	cc                   	int3
  44a6fc:	cc                   	int3
  44a6fd:	cc                   	int3
  44a6fe:	cc                   	int3
  44a6ff:	cc                   	int3
  44a700:	cc                   	int3
  44a701:	cc                   	int3
  44a702:	cc                   	int3
  44a703:	cc                   	int3
  44a704:	cc                   	int3
  44a705:	cc                   	int3
  44a706:	cc                   	int3
  44a707:	cc                   	int3
  44a708:	cc                   	int3
  44a709:	cc                   	int3
  44a70a:	cc                   	int3
  44a70b:	cc                   	int3
  44a70c:	cc                   	int3
  44a70d:	cc                   	int3
  44a70e:	cc                   	int3
  44a70f:	cc                   	int3
  44a710:	cc                   	int3
  44a711:	cc                   	int3
  44a712:	cc                   	int3
  44a713:	cc                   	int3
  44a714:	cc                   	int3
  44a715:	cc                   	int3
  44a716:	cc                   	int3
  44a717:	cc                   	int3
  44a718:	cc                   	int3
  44a719:	cc                   	int3
  44a71a:	cc                   	int3
  44a71b:	cc                   	int3
  44a71c:	cc                   	int3
  44a71d:	cc                   	int3
  44a71e:	cc                   	int3
  44a71f:	cc                   	int3
  44a720:	cc                   	int3
  44a721:	cc                   	int3
  44a722:	cc                   	int3
  44a723:	cc                   	int3
  44a724:	cc                   	int3
  44a725:	cc                   	int3
  44a726:	cc                   	int3
  44a727:	cc                   	int3
  44a728:	cc                   	int3
  44a729:	cc                   	int3
  44a72a:	cc                   	int3
  44a72b:	cc                   	int3
  44a72c:	cc                   	int3
  44a72d:	cc                   	int3
  44a72e:	cc                   	int3
  44a72f:	cc                   	int3
  44a730:	83 ec 20             	sub    esp,0x20
  44a733:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  44a737:	53                   	push   ebx
  44a738:	55                   	push   ebp
  44a739:	56                   	push   esi
  44a73a:	8b 88 a6 00 00 00    	mov    ecx,DWORD PTR [eax+0xa6]
  44a740:	8b 44 24 3c          	mov    eax,DWORD PTR [esp+0x3c]
  44a744:	57                   	push   edi
  44a745:	8b 14 81             	mov    edx,DWORD PTR [ecx+eax*4]
  44a748:	8b 4c 24 3c          	mov    ecx,DWORD PTR [esp+0x3c]
  44a74c:	8b 5a 36             	mov    ebx,DWORD PTR [edx+0x36]
  44a74f:	8b 51 04             	mov    edx,DWORD PTR [ecx+0x4]
  44a752:	8b 3c 82             	mov    edi,DWORD PTR [edx+eax*4]
  44a755:	c7 44 24 1c 04 00 00 	mov    DWORD PTR [esp+0x1c],0x4
  44a75c:	00 
  44a75d:	83 c7 04             	add    edi,0x4
  44a760:	c7 44 24 20 00 00 00 	mov    DWORD PTR [esp+0x20],0x0
  44a767:	00 
  44a768:	89 7c 24 24          	mov    DWORD PTR [esp+0x24],edi
  44a76c:	8a 47 2a             	mov    al,BYTE PTR [edi+0x2a]
  44a76f:	3c ff                	cmp    al,0xff
  44a771:	75 08                	jne    0x44a77b
  44a773:	8b 43 19             	mov    eax,DWORD PTR [ebx+0x19]
  44a776:	8a 40 3e             	mov    al,BYTE PTR [eax+0x3e]
  44a779:	3c ff                	cmp    al,0xff
  44a77b:	8b 4f 02             	mov    ecx,DWORD PTR [edi+0x2]
  44a77e:	0f 95 44 24 3c       	setne  BYTE PTR [esp+0x3c]
  44a783:	83 cd ff             	or     ebp,0xffffffff
  44a786:	3b cd                	cmp    ecx,ebp
  44a788:	74 08                	je     0x44a792
  44a78a:	8b f1                	mov    esi,ecx
  44a78c:	89 74 24 18          	mov    DWORD PTR [esp+0x18],esi
  44a790:	eb 19                	jmp    0x44a7ab
  44a792:	8b 53 19             	mov    edx,DWORD PTR [ebx+0x19]
  44a795:	8b 42 16             	mov    eax,DWORD PTR [edx+0x16]
  44a798:	3b c5                	cmp    eax,ebp
  44a79a:	75 09                	jne    0x44a7a5
  44a79c:	8a 43 20             	mov    al,BYTE PTR [ebx+0x20]
  44a79f:	c1 e8 05             	shr    eax,0x5
  44a7a2:	83 e0 01             	and    eax,0x1
  44a7a5:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  44a7a9:	8b f0                	mov    esi,eax
  44a7ab:	8b 47 12             	mov    eax,DWORD PTR [edi+0x12]
  44a7ae:	3b c5                	cmp    eax,ebp
  44a7b0:	75 12                	jne    0x44a7c4
  44a7b2:	3b cd                	cmp    ecx,ebp
  44a7b4:	75 08                	jne    0x44a7be
  44a7b6:	89 2d b8 6c 4a 00    	mov    DWORD PTR ds:0x4a6cb8,ebp
  44a7bc:	eb 0f                	jmp    0x44a7cd
  44a7be:	8b 47 06             	mov    eax,DWORD PTR [edi+0x6]
  44a7c1:	2b c1                	sub    eax,ecx
  44a7c3:	40                   	inc    eax
  44a7c4:	3b c5                	cmp    eax,ebp
  44a7c6:	a3 b8 6c 4a 00       	mov    ds:0x4a6cb8,eax
  44a7cb:	75 2d                	jne    0x44a7fa
  44a7cd:	8b 4b 19             	mov    ecx,DWORD PTR [ebx+0x19]
  44a7d0:	8b 41 26             	mov    eax,DWORD PTR [ecx+0x26]
  44a7d3:	3b c5                	cmp    eax,ebp
  44a7d5:	75 15                	jne    0x44a7ec
  44a7d7:	8b 51 16             	mov    edx,DWORD PTR [ecx+0x16]
  44a7da:	3b d5                	cmp    edx,ebp
  44a7dc:	75 08                	jne    0x44a7e6
  44a7de:	89 2d b8 6c 4a 00    	mov    DWORD PTR ds:0x4a6cb8,ebp
  44a7e4:	eb 0f                	jmp    0x44a7f5
  44a7e6:	8b 41 1a             	mov    eax,DWORD PTR [ecx+0x1a]
  44a7e9:	2b c2                	sub    eax,edx
  44a7eb:	40                   	inc    eax
  44a7ec:	3b c5                	cmp    eax,ebp
  44a7ee:	a3 b8 6c 4a 00       	mov    ds:0x4a6cb8,eax
  44a7f3:	75 05                	jne    0x44a7fa
  44a7f5:	b8 01 00 00 00       	mov    eax,0x1
  44a7fa:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44a7fe:	8d 44 30 ff          	lea    eax,[eax+esi*1-0x1]
  44a802:	33 ff                	xor    edi,edi
  44a804:	3b f0                	cmp    esi,eax
  44a806:	8b 29                	mov    ebp,DWORD PTR [ecx]
  44a808:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  44a80c:	89 74 24 14          	mov    DWORD PTR [esp+0x14],esi
  44a810:	c6 44 24 13 00       	mov    BYTE PTR [esp+0x13],0x0
  44a815:	0f 8f 4c 03 00 00    	jg     0x44ab67
  44a81b:	eb 04                	jmp    0x44a821
  44a81d:	8b 74 24 14          	mov    esi,DWORD PTR [esp+0x14]
  44a821:	f6 05 cc 6c 4a 00 01 	test   BYTE PTR ds:0x4a6ccc,0x1
  44a828:	74 16                	je     0x44a840
  44a82a:	83 7c 24 4c 01       	cmp    DWORD PTR [esp+0x4c],0x1
  44a82f:	75 0f                	jne    0x44a840
  44a831:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  44a835:	80 7a 2c 01          	cmp    BYTE PTR [edx+0x2c],0x1
  44a839:	75 05                	jne    0x44a840
  44a83b:	c6 45 00 7c          	mov    BYTE PTR [ebp+0x0],0x7c
  44a83f:	45                   	inc    ebp
  44a840:	8a 44 24 3c          	mov    al,BYTE PTR [esp+0x3c]
  44a844:	84 c0                	test   al,al
  44a846:	74 2f                	je     0x44a877
  44a848:	81 ff 88 13 00 00    	cmp    edi,0x1388
  44a84e:	7d 27                	jge    0x44a877
  44a850:	83 7c 24 4c 01       	cmp    DWORD PTR [esp+0x4c],0x1
  44a855:	75 1a                	jne    0x44a871
  44a857:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44a85b:	56                   	push   esi
  44a85c:	68 fc af 47 00       	push   0x47affc
  44a861:	8b 08                	mov    ecx,DWORD PTR [eax]
  44a863:	51                   	push   ecx
  44a864:	ff 15 7c 61 6c 00    	call   DWORD PTR ds:0x6c617c
  44a86a:	83 c4 0c             	add    esp,0xc
  44a86d:	03 e8                	add    ebp,eax
  44a86f:	eb 06                	jmp    0x44a877
  44a871:	89 75 00             	mov    DWORD PTR [ebp+0x0],esi
  44a874:	83 c5 04             	add    ebp,0x4
  44a877:	a0 02 c6 47 00       	mov    al,ds:0x47c602
  44a87c:	84 c0                	test   al,al
  44a87e:	74 59                	je     0x44a8d9
  44a880:	8a 53 1f             	mov    dl,BYTE PTR [ebx+0x1f]
  44a883:	80 e2 01             	and    dl,0x1
  44a886:	80 fa 01             	cmp    dl,0x1
  44a889:	75 4e                	jne    0x44a8d9
  44a88b:	8b 7c 24 38          	mov    edi,DWORD PTR [esp+0x38]
  44a88f:	80 7f 07 02          	cmp    BYTE PTR [edi+0x7],0x2
  44a893:	75 48                	jne    0x44a8dd
  44a895:	8d 44 24 2c          	lea    eax,[esp+0x2c]
  44a899:	50                   	push   eax
  44a89a:	57                   	push   edi
  44a89b:	e8 2b 7e fb ff       	call   0x4026cb
  44a8a0:	83 c4 08             	add    esp,0x8
  44a8a3:	85 c0                	test   eax,eax
  44a8a5:	74 36                	je     0x44a8dd
  44a8a7:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44a8ab:	8b 13                	mov    edx,DWORD PTR [ebx]
  44a8ad:	49                   	dec    ecx
  44a8ae:	8d 44 24 20          	lea    eax,[esp+0x20]
  44a8b2:	f7 d9                	neg    ecx
  44a8b4:	1b c9                	sbb    ecx,ecx
  44a8b6:	6a 00                	push   0x0
  44a8b8:	83 e1 02             	and    ecx,0x2
  44a8bb:	50                   	push   eax
  44a8bc:	8b 44 24 48          	mov    eax,DWORD PTR [esp+0x48]
  44a8c0:	41                   	inc    ecx
  44a8c1:	51                   	push   ecx
  44a8c2:	8b 4f 18             	mov    ecx,DWORD PTR [edi+0x18]
  44a8c5:	50                   	push   eax
  44a8c6:	51                   	push   ecx
  44a8c7:	8b cb                	mov    ecx,ebx
  44a8c9:	ff 52 18             	call   DWORD PTR [edx+0x18]
  44a8cc:	8b 74 24 34          	mov    esi,DWORD PTR [esp+0x34]
  44a8d0:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  44a8d4:	83 cf ff             	or     edi,0xffffffff
  44a8d7:	eb 7a                	jmp    0x44a953
  44a8d9:	8b 7c 24 38          	mov    edi,DWORD PTR [esp+0x38]
  44a8dd:	8b 4c 24 50          	mov    ecx,DWORD PTR [esp+0x50]
  44a8e1:	8d 44 24 1c          	lea    eax,[esp+0x1c]
  44a8e5:	8b 13                	mov    edx,DWORD PTR [ebx]
  44a8e7:	50                   	push   eax
  44a8e8:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44a8ec:	51                   	push   ecx
  44a8ed:	8b 4f 18             	mov    ecx,DWORD PTR [edi+0x18]
  44a8f0:	56                   	push   esi
  44a8f1:	8b 74 24 40          	mov    esi,DWORD PTR [esp+0x40]
  44a8f5:	50                   	push   eax
  44a8f6:	55                   	push   ebp
  44a8f7:	51                   	push   ecx
  44a8f8:	8b 06                	mov    eax,DWORD PTR [esi]
  44a8fa:	8b cb                	mov    ecx,ebx
  44a8fc:	50                   	push   eax
  44a8fd:	ff 52 1c             	call   DWORD PTR [edx+0x1c]
  44a900:	8b f8                	mov    edi,eax
  44a902:	83 ff fd             	cmp    edi,0xfffffffd
  44a905:	0f 84 ca 02 00 00    	je     0x44abd5
  44a90b:	83 ff fe             	cmp    edi,0xfffffffe
  44a90e:	0f 84 b4 02 00 00    	je     0x44abc8
  44a914:	83 ff ff             	cmp    edi,0xffffffff
  44a917:	75 36                	jne    0x44a94f
  44a919:	8b 44 24 38          	mov    eax,DWORD PTR [esp+0x38]
  44a91d:	80 78 07 02          	cmp    BYTE PTR [eax+0x7],0x2
  44a921:	0f 85 40 02 00 00    	jne    0x44ab67
  44a927:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44a92b:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
  44a92e:	49                   	dec    ecx
  44a92f:	8b 13                	mov    edx,DWORD PTR [ebx]
  44a931:	f7 d9                	neg    ecx
  44a933:	1b c9                	sbb    ecx,ecx
  44a935:	6a 00                	push   0x0
  44a937:	83 e1 02             	and    ecx,0x2
  44a93a:	6a 00                	push   0x0
  44a93c:	41                   	inc    ecx
  44a93d:	51                   	push   ecx
  44a93e:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44a942:	51                   	push   ecx
  44a943:	50                   	push   eax
  44a944:	8b cb                	mov    ecx,ebx
  44a946:	ff 52 18             	call   DWORD PTR [edx+0x18]
  44a949:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  44a94d:	eb 04                	jmp    0x44a953
  44a94f:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  44a953:	83 f8 01             	cmp    eax,0x1
  44a956:	c7 06 00 00 00 00    	mov    DWORD PTR [esi],0x0
  44a95c:	75 20                	jne    0x44a97e
  44a95e:	84 43 1f             	test   BYTE PTR [ebx+0x1f],al
  44a961:	75 1b                	jne    0x44a97e
  44a963:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  44a967:	80 79 28 ff          	cmp    BYTE PTR [ecx+0x28],0xff
  44a96b:	75 09                	jne    0x44a976
  44a96d:	8b 53 19             	mov    edx,DWORD PTR [ebx+0x19]
  44a970:	80 7a 3c ff          	cmp    BYTE PTR [edx+0x3c],0xff
  44a974:	74 08                	je     0x44a97e
  44a976:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44a97a:	89 4c 24 28          	mov    DWORD PTR [esp+0x28],ecx
  44a97e:	81 ff 0f 27 00 00    	cmp    edi,0x270f
  44a984:	7e 21                	jle    0x44a9a7
  44a986:	8a 4c 24 3c          	mov    cl,BYTE PTR [esp+0x3c]
  44a98a:	81 ef 10 27 00 00    	sub    edi,0x2710
  44a990:	84 c9                	test   cl,cl
  44a992:	74 13                	je     0x44a9a7
  44a994:	8b 54 24 38          	mov    edx,DWORD PTR [esp+0x38]
  44a998:	80 7a 07 02          	cmp    BYTE PTR [edx+0x7],0x2
  44a99c:	75 09                	jne    0x44a9a7
  44a99e:	ff 44 24 14          	inc    DWORD PTR [esp+0x14]
  44a9a2:	e9 a2 01 00 00       	jmp    0x44ab49
  44a9a7:	83 7c 24 4c 01       	cmp    DWORD PTR [esp+0x4c],0x1
  44a9ac:	75 57                	jne    0x44aa05
  44a9ae:	81 ff 87 13 00 00    	cmp    edi,0x1387
  44a9b4:	8d 87 78 ec ff ff    	lea    eax,[edi-0x1388]
  44a9ba:	7f 02                	jg     0x44a9be
  44a9bc:	8b c7                	mov    eax,edi
  44a9be:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  44a9c2:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  44a9c6:	51                   	push   ecx
  44a9c7:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44a9cb:	52                   	push   edx
  44a9cc:	8b 54 24 40          	mov    edx,DWORD PTR [esp+0x40]
  44a9d0:	6a 01                	push   0x1
  44a9d2:	50                   	push   eax
  44a9d3:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  44a9d7:	55                   	push   ebp
  44a9d8:	50                   	push   eax
  44a9d9:	51                   	push   ecx
  44a9da:	52                   	push   edx
  44a9db:	e8 f7 6b fb ff       	call   0x4015d7
  44a9e0:	8b f0                	mov    esi,eax
  44a9e2:	83 c4 20             	add    esp,0x20
  44a9e5:	85 f6                	test   esi,esi
  44a9e7:	0f 8d f4 00 00 00    	jge    0x44aae1
  44a9ed:	8b 44 24 38          	mov    eax,DWORD PTR [esp+0x38]
  44a9f1:	80 78 07 02          	cmp    BYTE PTR [eax+0x7],0x2
  44a9f5:	0f 85 6c 01 00 00    	jne    0x44ab67
  44a9fb:	be 01 00 00 00       	mov    esi,0x1
  44aa00:	e9 dc 00 00 00       	jmp    0x44aae1
  44aa05:	85 ff                	test   edi,edi
  44aa07:	0f 8c 64 01 00 00    	jl     0x44ab71
  44aa0d:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44aa11:	8b 54 24 14          	mov    edx,DWORD PTR [esp+0x14]
  44aa15:	3b d1                	cmp    edx,ecx
  44aa17:	0f 85 b4 00 00 00    	jne    0x44aad1
  44aa1d:	81 ff 88 13 00 00    	cmp    edi,0x1388
  44aa23:	0f 8d a8 00 00 00    	jge    0x44aad1
  44aa29:	83 f8 03             	cmp    eax,0x3
  44aa2c:	8b f7                	mov    esi,edi
  44aa2e:	77 26                	ja     0x44aa56
  44aa30:	ff 24 85 f8 ab 44 00 	jmp    DWORD PTR [eax*4+0x44abf8]
  44aa37:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0x1
  44aa3e:	01 00 
  44aa40:	eb 14                	jmp    0x44aa56
  44aa42:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0x2
  44aa49:	02 00 
  44aa4b:	eb 09                	jmp    0x44aa56
  44aa4d:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0x64
  44aa54:	64 00 
  44aa56:	8a 44 24 3c          	mov    al,BYTE PTR [esp+0x3c]
  44aa5a:	84 c0                	test   al,al
  44aa5c:	74 07                	je     0x44aa65
  44aa5e:	80 0d d5 6b 48 00 01 	or     BYTE PTR ds:0x486bd5,0x1
  44aa65:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  44aa69:	85 c0                	test   eax,eax
  44aa6b:	75 1d                	jne    0x44aa8a
  44aa6d:	8b 4c 24 40          	mov    ecx,DWORD PTR [esp+0x40]
  44aa71:	8b 13                	mov    edx,DWORD PTR [ebx]
  44aa73:	8d 44 24 20          	lea    eax,[esp+0x20]
  44aa77:	6a 00                	push   0x0
  44aa79:	50                   	push   eax
  44aa7a:	8b 44 24 40          	mov    eax,DWORD PTR [esp+0x40]
  44aa7e:	6a 03                	push   0x3
  44aa80:	51                   	push   ecx
  44aa81:	8b 48 18             	mov    ecx,DWORD PTR [eax+0x18]
  44aa84:	51                   	push   ecx
  44aa85:	8b cb                	mov    ecx,ebx
  44aa87:	ff 52 18             	call   DWORD PTR [edx+0x18]
  44aa8a:	a0 84 68 48 00       	mov    al,ds:0x486884
  44aa8f:	66 33 d2             	xor    dx,dx
  44aa92:	66 0f b6 4c 24 20    	movzx  cx,BYTE PTR [esp+0x20]
  44aa98:	8a d0                	mov    dl,al
  44aa9a:	c1 e2 08             	shl    edx,0x8
  44aa9d:	03 d1                	add    edx,ecx
  44aa9f:	8b 4c 24 18          	mov    ecx,DWORD PTR [esp+0x18]
  44aaa3:	66 89 15 d6 6b 48 00 	mov    WORD PTR ds:0x486bd6,dx
  44aaaa:	8b 54 24 28          	mov    edx,DWORD PTR [esp+0x28]
  44aaae:	2b d1                	sub    edx,ecx
  44aab0:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44aab4:	fe c0                	inc    al
  44aab6:	42                   	inc    edx
  44aab7:	a2 84 68 48 00       	mov    ds:0x486884,al
  44aabc:	89 15 d8 6b 48 00    	mov    DWORD PTR ds:0x486bd8,edx
  44aac2:	8b 11                	mov    edx,DWORD PTR [ecx]
  44aac4:	8b c5                	mov    eax,ebp
  44aac6:	2b c2                	sub    eax,edx
  44aac8:	03 c7                	add    eax,edi
  44aaca:	a3 dc 6b 48 00       	mov    ds:0x486bdc,eax
  44aacf:	eb 10                	jmp    0x44aae1
  44aad1:	81 ff 87 13 00 00    	cmp    edi,0x1387
  44aad7:	8d b7 78 ec ff ff    	lea    esi,[edi-0x1388]
  44aadd:	7f 02                	jg     0x44aae1
  44aadf:	8b f7                	mov    esi,edi
  44aae1:	81 ff 87 13 00 00    	cmp    edi,0x1387
  44aae7:	7e 0a                	jle    0x44aaf3
  44aae9:	8b 54 24 44          	mov    edx,DWORD PTR [esp+0x44]
  44aaed:	03 f5                	add    esi,ebp
  44aaef:	89 32                	mov    DWORD PTR [edx],esi
  44aaf1:	eb 56                	jmp    0x44ab49
  44aaf3:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  44aaf7:	c6 44 24 13 01       	mov    BYTE PTR [esp+0x13],0x1
  44aafc:	40                   	inc    eax
  44aafd:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  44ab01:	8b c6                	mov    eax,esi
  44ab03:	2d d0 6b 48 00       	sub    eax,0x486bd0
  44ab08:	03 c5                	add    eax,ebp
  44ab0a:	3d 00 02 00 00       	cmp    eax,0x200
  44ab0f:	7e 30                	jle    0x44ab41
  44ab11:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  44ab15:	83 f9 01             	cmp    ecx,0x1
  44ab18:	74 27                	je     0x44ab41
  44ab1a:	8b 74 24 48          	mov    esi,DWORD PTR [esp+0x48]
  44ab1e:	51                   	push   ecx
  44ab1f:	8b 4c 24 3c          	mov    ecx,DWORD PTR [esp+0x3c]
  44ab23:	50                   	push   eax
  44ab24:	68 d0 6b 48 00       	push   0x486bd0
  44ab29:	56                   	push   esi
  44ab2a:	51                   	push   ecx
  44ab2b:	e8 c8 67 fb ff       	call   0x4012f8
  44ab30:	8b 54 24 58          	mov    edx,DWORD PTR [esp+0x58]
  44ab34:	89 06                	mov    DWORD PTR [esi],eax
  44ab36:	83 c4 14             	add    esp,0x14
  44ab39:	c7 02 d0 6b 48 00    	mov    DWORD PTR [edx],0x486bd0
  44ab3f:	eb 08                	jmp    0x44ab49
  44ab41:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44ab45:	03 f5                	add    esi,ebp
  44ab47:	89 30                	mov    DWORD PTR [eax],esi
  44ab49:	8b 4c 24 44          	mov    ecx,DWORD PTR [esp+0x44]
  44ab4d:	8b 54 24 14          	mov    edx,DWORD PTR [esp+0x14]
  44ab51:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  44ab55:	8b 29                	mov    ebp,DWORD PTR [ecx]
  44ab57:	3b d0                	cmp    edx,eax
  44ab59:	0f 8e be fc ff ff    	jle    0x44a81d
  44ab5f:	8a 44 24 13          	mov    al,BYTE PTR [esp+0x13]
  44ab63:	84 c0                	test   al,al
  44ab65:	75 54                	jne    0x44abbb
  44ab67:	5f                   	pop    edi
  44ab68:	5e                   	pop    esi
  44ab69:	5d                   	pop    ebp
  44ab6a:	33 c0                	xor    eax,eax
  44ab6c:	5b                   	pop    ebx
  44ab6d:	83 c4 20             	add    esp,0x20
  44ab70:	c3                   	ret
  44ab71:	a1 d0 6b 48 00       	mov    eax,ds:0x486bd0
  44ab76:	8b 4c 24 38          	mov    ecx,DWORD PTR [esp+0x38]
  44ab7a:	66 c7 05 d4 6b 48 00 	mov    WORD PTR ds:0x486bd4,0xffff
  44ab81:	ff ff 
  44ab83:	25 ff ff 00 00       	and    eax,0xffff
  44ab88:	8b 51 2a             	mov    edx,DWORD PTR [ecx+0x2a]
  44ab8b:	89 90 d0 6b 48 00    	mov    DWORD PTR [eax+0x486bd0],edx
  44ab91:	8b 44 24 44          	mov    eax,DWORD PTR [esp+0x44]
  44ab95:	66 83 05 d0 6b 48 00 	add    WORD PTR ds:0x486bd0,0x4
  44ab9c:	04 
  44ab9d:	66 ff 05 d2 6b 48 00 	inc    WORD PTR ds:0x486bd2
  44aba4:	c7 05 d8 6b 48 00 00 	mov    DWORD PTR ds:0x486bd8,0x0
  44abab:	00 00 00 
  44abae:	c7 05 dc 6b 48 00 00 	mov    DWORD PTR ds:0x486bdc,0x0
  44abb5:	00 00 00 
  44abb8:	83 00 04             	add    DWORD PTR [eax],0x4
  44abbb:	5f                   	pop    edi
  44abbc:	5e                   	pop    esi
  44abbd:	5d                   	pop    ebp
  44abbe:	b8 01 00 00 00       	mov    eax,0x1
  44abc3:	5b                   	pop    ebx
  44abc4:	83 c4 20             	add    esp,0x20
  44abc7:	c3                   	ret
  44abc8:	5f                   	pop    edi
  44abc9:	5e                   	pop    esi
  44abca:	5d                   	pop    ebp
  44abcb:	b8 fe ff ff ff       	mov    eax,0xfffffffe
  44abd0:	5b                   	pop    ebx
  44abd1:	83 c4 20             	add    esp,0x20
  44abd4:	c3                   	ret
  44abd5:	8b 4c 24 38          	mov    ecx,DWORD PTR [esp+0x38]
  44abd9:	c7 06 00 00 00 00    	mov    DWORD PTR [esi],0x0
  44abdf:	33 c0                	xor    eax,eax
  44abe1:	5f                   	pop    edi
  44abe2:	8a 51 07             	mov    dl,BYTE PTR [ecx+0x7]
  44abe5:	5e                   	pop    esi
  44abe6:	80 fa 02             	cmp    dl,0x2
  44abe9:	5d                   	pop    ebp
  44abea:	0f 95 c0             	setne  al
  44abed:	83 c0 fd             	add    eax,0xfffffffd
  44abf0:	5b                   	pop    ebx
  44abf1:	83 c4 20             	add    esp,0x20
  44abf4:	c3                   	ret
  44abf5:	8d 49 00             	lea    ecx,[ecx+0x0]
  44abf8:	37                   	aaa
  44abf9:	aa                   	stos   BYTE PTR es:[edi],al
  44abfa:	44                   	inc    esp
  44abfb:	00 4d aa             	add    BYTE PTR [ebp-0x56],cl
  44abfe:	44                   	inc    esp
  44abff:	00 42 aa             	add    BYTE PTR [edx-0x56],al
  44ac02:	44                   	inc    esp
  44ac03:	00 4d aa             	add    BYTE PTR [ebp-0x56],cl
  44ac06:	44                   	inc    esp
  44ac07:	00 90 90 90 90 90    	add    BYTE PTR [eax-0x6f6f6f70],dl
  44ac0d:	90                   	nop
  44ac0e:	90                   	nop
  44ac0f:	90                   	nop
  44ac10:	cc                   	int3
  44ac11:	cc                   	int3
  44ac12:	cc                   	int3
  44ac13:	cc                   	int3
  44ac14:	cc                   	int3
  44ac15:	cc                   	int3
  44ac16:	cc                   	int3
  44ac17:	cc                   	int3
  44ac18:	cc                   	int3
  44ac19:	cc                   	int3
  44ac1a:	cc                   	int3
  44ac1b:	cc                   	int3
  44ac1c:	cc                   	int3
  44ac1d:	cc                   	int3
  44ac1e:	cc                   	int3
  44ac1f:	cc                   	int3
  44ac20:	cc                   	int3
  44ac21:	cc                   	int3
  44ac22:	cc                   	int3
  44ac23:	cc                   	int3
  44ac24:	cc                   	int3
  44ac25:	cc                   	int3
  44ac26:	cc                   	int3
  44ac27:	cc                   	int3
  44ac28:	cc                   	int3
  44ac29:	cc                   	int3
  44ac2a:	cc                   	int3
  44ac2b:	cc                   	int3
  44ac2c:	cc                   	int3
  44ac2d:	cc                   	int3
  44ac2e:	cc                   	int3
  44ac2f:	cc                   	int3
  44ac30:	cc                   	int3
  44ac31:	cc                   	int3
  44ac32:	cc                   	int3
  44ac33:	cc                   	int3
  44ac34:	cc                   	int3
  44ac35:	cc                   	int3
  44ac36:	cc                   	int3
  44ac37:	cc                   	int3
  44ac38:	cc                   	int3
  44ac39:	cc                   	int3
  44ac3a:	cc                   	int3
  44ac3b:	cc                   	int3
  44ac3c:	cc                   	int3
  44ac3d:	cc                   	int3
  44ac3e:	cc                   	int3
  44ac3f:	cc                   	int3
  44ac40:	cc                   	int3
  44ac41:	cc                   	int3
  44ac42:	cc                   	int3
  44ac43:	cc                   	int3
  44ac44:	cc                   	int3
  44ac45:	cc                   	int3
  44ac46:	cc                   	int3
  44ac47:	cc                   	int3
  44ac48:	cc                   	int3
  44ac49:	cc                   	int3
  44ac4a:	cc                   	int3
  44ac4b:	cc                   	int3
  44ac4c:	cc                   	int3
  44ac4d:	cc                   	int3
  44ac4e:	cc                   	int3
  44ac4f:	cc                   	int3
  44ac50:	cc                   	int3
  44ac51:	cc                   	int3
  44ac52:	cc                   	int3
  44ac53:	cc                   	int3
  44ac54:	cc                   	int3
  44ac55:	cc                   	int3
  44ac56:	cc                   	int3
  44ac57:	cc                   	int3
  44ac58:	cc                   	int3
  44ac59:	cc                   	int3
  44ac5a:	cc                   	int3
  44ac5b:	cc                   	int3
  44ac5c:	cc                   	int3
  44ac5d:	cc                   	int3
  44ac5e:	cc                   	int3
  44ac5f:	cc                   	int3
  44ac60:	cc                   	int3
  44ac61:	cc                   	int3
  44ac62:	cc                   	int3
  44ac63:	cc                   	int3
  44ac64:	cc                   	int3
  44ac65:	cc                   	int3
  44ac66:	cc                   	int3
  44ac67:	cc                   	int3
  44ac68:	cc                   	int3
  44ac69:	cc                   	int3
  44ac6a:	cc                   	int3
  44ac6b:	cc                   	int3
  44ac6c:	cc                   	int3
  44ac6d:	cc                   	int3
  44ac6e:	cc                   	int3
  44ac6f:	cc                   	int3
  44ac70:	cc                   	int3
  44ac71:	cc                   	int3
  44ac72:	cc                   	int3
  44ac73:	cc                   	int3
  44ac74:	cc                   	int3
  44ac75:	cc                   	int3
  44ac76:	cc                   	int3
  44ac77:	cc                   	int3
  44ac78:	cc                   	int3
  44ac79:	cc                   	int3
  44ac7a:	cc                   	int3
  44ac7b:	cc                   	int3
  44ac7c:	cc                   	int3
  44ac7d:	cc                   	int3
  44ac7e:	cc                   	int3
  44ac7f:	cc                   	int3
  44ac80:	cc                   	int3
  44ac81:	cc                   	int3
  44ac82:	cc                   	int3
  44ac83:	cc                   	int3
  44ac84:	cc                   	int3
  44ac85:	cc                   	int3
  44ac86:	cc                   	int3
  44ac87:	cc                   	int3
  44ac88:	cc                   	int3
  44ac89:	cc                   	int3
  44ac8a:	cc                   	int3
  44ac8b:	cc                   	int3
  44ac8c:	cc                   	int3
  44ac8d:	cc                   	int3
  44ac8e:	cc                   	int3
  44ac8f:	cc                   	int3
  44ac90:	cc                   	int3
  44ac91:	cc                   	int3
  44ac92:	cc                   	int3
  44ac93:	cc                   	int3
  44ac94:	cc                   	int3
  44ac95:	cc                   	int3
  44ac96:	cc                   	int3
  44ac97:	cc                   	int3
  44ac98:	cc                   	int3
  44ac99:	cc                   	int3
  44ac9a:	cc                   	int3
  44ac9b:	cc                   	int3
  44ac9c:	cc                   	int3
  44ac9d:	cc                   	int3
  44ac9e:	cc                   	int3
  44ac9f:	cc                   	int3
  44aca0:	cc                   	int3
  44aca1:	cc                   	int3
  44aca2:	cc                   	int3
  44aca3:	cc                   	int3
  44aca4:	cc                   	int3
  44aca5:	cc                   	int3
  44aca6:	cc                   	int3
  44aca7:	cc                   	int3
  44aca8:	cc                   	int3
  44aca9:	cc                   	int3
  44acaa:	cc                   	int3
  44acab:	cc                   	int3
  44acac:	cc                   	int3
  44acad:	cc                   	int3
  44acae:	cc                   	int3
  44acaf:	cc                   	int3
  44acb0:	cc                   	int3
  44acb1:	cc                   	int3
  44acb2:	cc                   	int3
  44acb3:	cc                   	int3
  44acb4:	cc                   	int3
  44acb5:	cc                   	int3
  44acb6:	cc                   	int3
  44acb7:	cc                   	int3
  44acb8:	cc                   	int3
  44acb9:	cc                   	int3
  44acba:	cc                   	int3
  44acbb:	cc                   	int3
  44acbc:	cc                   	int3
  44acbd:	cc                   	int3
  44acbe:	cc                   	int3
  44acbf:	cc                   	int3
  44acc0:	cc                   	int3
  44acc1:	cc                   	int3
  44acc2:	cc                   	int3
  44acc3:	cc                   	int3
  44acc4:	cc                   	int3
  44acc5:	cc                   	int3
  44acc6:	cc                   	int3
  44acc7:	cc                   	int3
  44acc8:	cc                   	int3
  44acc9:	cc                   	int3
  44acca:	cc                   	int3
  44accb:	cc                   	int3
  44accc:	cc                   	int3
  44accd:	cc                   	int3
  44acce:	cc                   	int3
  44accf:	cc                   	int3
  44acd0:	cc                   	int3
  44acd1:	cc                   	int3
  44acd2:	cc                   	int3
  44acd3:	cc                   	int3
  44acd4:	cc                   	int3
  44acd5:	cc                   	int3
  44acd6:	cc                   	int3
  44acd7:	cc                   	int3
  44acd8:	cc                   	int3
  44acd9:	cc                   	int3
  44acda:	cc                   	int3
  44acdb:	cc                   	int3
  44acdc:	cc                   	int3
  44acdd:	cc                   	int3
  44acde:	cc                   	int3
  44acdf:	cc                   	int3
  44ace0:	cc                   	int3
  44ace1:	cc                   	int3
  44ace2:	cc                   	int3
  44ace3:	cc                   	int3
  44ace4:	cc                   	int3
  44ace5:	cc                   	int3
  44ace6:	cc                   	int3
  44ace7:	cc                   	int3
  44ace8:	cc                   	int3
  44ace9:	cc                   	int3
  44acea:	cc                   	int3
  44aceb:	cc                   	int3
  44acec:	cc                   	int3
  44aced:	cc                   	int3
  44acee:	cc                   	int3
  44acef:	cc                   	int3
  44acf0:	cc                   	int3
  44acf1:	cc                   	int3
  44acf2:	cc                   	int3
  44acf3:	cc                   	int3
  44acf4:	cc                   	int3
  44acf5:	cc                   	int3
  44acf6:	cc                   	int3
  44acf7:	cc                   	int3
  44acf8:	cc                   	int3
  44acf9:	cc                   	int3
  44acfa:	cc                   	int3
  44acfb:	cc                   	int3
  44acfc:	cc                   	int3
  44acfd:	cc                   	int3
  44acfe:	cc                   	int3
  44acff:	cc                   	int3
  44ad00:	cc                   	int3
  44ad01:	cc                   	int3
  44ad02:	cc                   	int3
  44ad03:	cc                   	int3
  44ad04:	cc                   	int3
  44ad05:	cc                   	int3
  44ad06:	cc                   	int3
  44ad07:	cc                   	int3
  44ad08:	cc                   	int3
  44ad09:	cc                   	int3
  44ad0a:	cc                   	int3
  44ad0b:	cc                   	int3
  44ad0c:	cc                   	int3
  44ad0d:	cc                   	int3
  44ad0e:	cc                   	int3
  44ad0f:	cc                   	int3
  44ad10:	cc                   	int3
  44ad11:	cc                   	int3
  44ad12:	cc                   	int3
  44ad13:	cc                   	int3
  44ad14:	cc                   	int3
  44ad15:	cc                   	int3
  44ad16:	cc                   	int3
  44ad17:	cc                   	int3
  44ad18:	cc                   	int3
  44ad19:	cc                   	int3
  44ad1a:	cc                   	int3
  44ad1b:	cc                   	int3
  44ad1c:	cc                   	int3
  44ad1d:	cc                   	int3
  44ad1e:	cc                   	int3
  44ad1f:	cc                   	int3
  44ad20:	cc                   	int3
  44ad21:	cc                   	int3
  44ad22:	cc                   	int3
  44ad23:	cc                   	int3
  44ad24:	cc                   	int3
  44ad25:	cc                   	int3
  44ad26:	cc                   	int3
  44ad27:	cc                   	int3
  44ad28:	cc                   	int3
  44ad29:	cc                   	int3
  44ad2a:	cc                   	int3
  44ad2b:	cc                   	int3
  44ad2c:	cc                   	int3
  44ad2d:	cc                   	int3
  44ad2e:	cc                   	int3
  44ad2f:	cc                   	int3
  44ad30:	cc                   	int3
  44ad31:	cc                   	int3
  44ad32:	cc                   	int3
  44ad33:	cc                   	int3
  44ad34:	cc                   	int3
  44ad35:	cc                   	int3
  44ad36:	cc                   	int3
  44ad37:	cc                   	int3
  44ad38:	cc                   	int3
  44ad39:	cc                   	int3
  44ad3a:	cc                   	int3
  44ad3b:	cc                   	int3
  44ad3c:	cc                   	int3
  44ad3d:	cc                   	int3
  44ad3e:	cc                   	int3
  44ad3f:	cc                   	int3
  44ad40:	cc                   	int3
  44ad41:	cc                   	int3
  44ad42:	cc                   	int3
  44ad43:	cc                   	int3
  44ad44:	cc                   	int3
  44ad45:	cc                   	int3
  44ad46:	cc                   	int3
  44ad47:	cc                   	int3
  44ad48:	cc                   	int3
  44ad49:	cc                   	int3
  44ad4a:	cc                   	int3
  44ad4b:	cc                   	int3
  44ad4c:	cc                   	int3
  44ad4d:	cc                   	int3
  44ad4e:	cc                   	int3
  44ad4f:	cc                   	int3
  44ad50:	83 ec 10             	sub    esp,0x10
  44ad53:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  44ad57:	53                   	push   ebx
  44ad58:	55                   	push   ebp
  44ad59:	56                   	push   esi
  44ad5a:	57                   	push   edi
  44ad5b:	8b 7c 24 34          	mov    edi,DWORD PTR [esp+0x34]
  44ad5f:	83 ff 01             	cmp    edi,0x1
  44ad62:	75 0c                	jne    0x44ad70
  44ad64:	8d 88 8a 00 00 00    	lea    ecx,[eax+0x8a]
  44ad6a:	89 4c 24 34          	mov    DWORD PTR [esp+0x34],ecx
  44ad6e:	eb 0a                	jmp    0x44ad7a
  44ad70:	8d 90 8e 00 00 00    	lea    edx,[eax+0x8e]
  44ad76:	89 54 24 34          	mov    DWORD PTR [esp+0x34],edx
  44ad7a:	80 78 07 02          	cmp    BYTE PTR [eax+0x7],0x2
  44ad7e:	75 29                	jne    0x44ada9
  44ad80:	8a 48 7b             	mov    cl,BYTE PTR [eax+0x7b]
  44ad83:	84 c9                	test   cl,cl
  44ad85:	75 22                	jne    0x44ada9
  44ad87:	8b 80 a6 00 00 00    	mov    eax,DWORD PTR [eax+0xa6]
  44ad8d:	8b 00                	mov    eax,DWORD PTR [eax]
  44ad8f:	80 78 31 01          	cmp    BYTE PTR [eax+0x31],0x1
  44ad93:	74 14                	je     0x44ada9
  44ad95:	8b 48 36             	mov    ecx,DWORD PTR [eax+0x36]
  44ad98:	f6 41 20 10          	test   BYTE PTR [ecx+0x20],0x10
  44ad9c:	75 0b                	jne    0x44ada9
  44ad9e:	b9 01 00 00 00       	mov    ecx,0x1
  44ada3:	89 4c 24 24          	mov    DWORD PTR [esp+0x24],ecx
  44ada7:	eb 0c                	jmp    0x44adb5
  44ada9:	c7 44 24 24 00 00 00 	mov    DWORD PTR [esp+0x24],0x0
  44adb0:	00 
  44adb1:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  44adb5:	8b 5c 24 28          	mov    ebx,DWORD PTR [esp+0x28]
  44adb9:	8b 03                	mov    eax,DWORD PTR [ebx]
  44adbb:	85 c0                	test   eax,eax
  44adbd:	0f 85 87 00 00 00    	jne    0x44ae4a
  44adc3:	85 c9                	test   ecx,ecx
  44adc5:	74 39                	je     0x44ae00
  44adc7:	8b 54 24 34          	mov    edx,DWORD PTR [esp+0x34]
  44adcb:	8b 02                	mov    eax,DWORD PTR [edx]
  44adcd:	85 c0                	test   eax,eax
  44adcf:	74 2f                	je     0x44ae00
  44add1:	8b 6c 24 30          	mov    ebp,DWORD PTR [esp+0x30]
  44add5:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  44add9:	6a 00                	push   0x0
  44addb:	55                   	push   ebp
  44addc:	56                   	push   esi
  44addd:	50                   	push   eax
  44adde:	e8 15 c2 01 00       	call   0x466ff8
  44ade3:	85 c0                	test   eax,eax
  44ade5:	89 03                	mov    DWORD PTR [ebx],eax
  44ade7:	75 59                	jne    0x44ae42
  44ade9:	68 dc 00 00 00       	push   0xdc
  44adee:	e8 a9 75 fb ff       	call   0x40239c
  44adf3:	83 c4 04             	add    esp,0x4
  44adf6:	33 c0                	xor    eax,eax
  44adf8:	5f                   	pop    edi
  44adf9:	5e                   	pop    esi
  44adfa:	5d                   	pop    ebp
  44adfb:	5b                   	pop    ebx
  44adfc:	83 c4 10             	add    esp,0x10
  44adff:	c3                   	ret
  44ae00:	8b 6c 24 30          	mov    ebp,DWORD PTR [esp+0x30]
  44ae04:	33 c0                	xor    eax,eax
  44ae06:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  44ae0a:	8b 15 c0 6c 4a 00    	mov    edx,DWORD PTR ds:0x4a6cc0
  44ae10:	85 c9                	test   ecx,ecx
  44ae12:	8b 0d 64 68 48 00    	mov    ecx,DWORD PTR ds:0x486864
  44ae18:	0f 95 c0             	setne  al
  44ae1b:	50                   	push   eax
  44ae1c:	57                   	push   edi
  44ae1d:	51                   	push   ecx
  44ae1e:	6a 00                	push   0x0
  44ae20:	55                   	push   ebp
  44ae21:	56                   	push   esi
  44ae22:	52                   	push   edx
  44ae23:	e8 2e c1 01 00       	call   0x466f56
  44ae28:	85 c0                	test   eax,eax
  44ae2a:	89 03                	mov    DWORD PTR [ebx],eax
  44ae2c:	75 14                	jne    0x44ae42
  44ae2e:	6a 15                	push   0x15
  44ae30:	e8 67 75 fb ff       	call   0x40239c
  44ae35:	83 c4 04             	add    esp,0x4
  44ae38:	33 c0                	xor    eax,eax
  44ae3a:	5f                   	pop    edi
  44ae3b:	5e                   	pop    esi
  44ae3c:	5d                   	pop    ebp
  44ae3d:	5b                   	pop    ebx
  44ae3e:	83 c4 10             	add    esp,0x10
  44ae41:	c3                   	ret
  44ae42:	89 2d 88 58 48 00    	mov    DWORD PTR ds:0x485888,ebp
  44ae48:	eb 37                	jmp    0x44ae81
  44ae4a:	8b 0d 88 58 48 00    	mov    ecx,DWORD PTR ds:0x485888
  44ae50:	8b 6c 24 30          	mov    ebp,DWORD PTR [esp+0x30]
  44ae54:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  44ae58:	51                   	push   ecx
  44ae59:	55                   	push   ebp
  44ae5a:	56                   	push   esi
  44ae5b:	50                   	push   eax
  44ae5c:	e8 97 c1 01 00       	call   0x466ff8
  44ae61:	85 c0                	test   eax,eax
  44ae63:	89 03                	mov    DWORD PTR [ebx],eax
  44ae65:	75 14                	jne    0x44ae7b
  44ae67:	6a 16                	push   0x16
  44ae69:	e8 2e 75 fb ff       	call   0x40239c
  44ae6e:	83 c4 04             	add    esp,0x4
  44ae71:	33 c0                	xor    eax,eax
  44ae73:	5f                   	pop    edi
  44ae74:	5e                   	pop    esi
  44ae75:	5d                   	pop    ebp
  44ae76:	5b                   	pop    ebx
  44ae77:	83 c4 10             	add    esp,0x10
  44ae7a:	c3                   	ret
  44ae7b:	01                   	.byte 0x1
  44ae7c:	2d                   	.byte 0x2d
  44ae7d:	88 58 48             	mov    BYTE PTR [eax+0x48],bl


/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00449265 <.text+0x48265>:
  449265:	a0 16 6d 4a 00       	mov    al,ds:0x4a6d16
  44926a:	84 c0                	test   al,al
  44926c:	0f 85 e1 07 00 00    	jne    0x449a53
  449272:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  449275:	83 fe 01             	cmp    esi,0x1
  449278:	74 59                	je     0x4492d3
  44927a:	33 d2                	xor    edx,edx
  44927c:	66 8b 15 50 99 49 00 	mov    dx,WORD PTR ds:0x499950
  449283:	3b f2                	cmp    esi,edx
  449285:	74 4c                	je     0x4492d3
  449287:	83 fe 07             	cmp    esi,0x7
  44928a:	75 3b                	jne    0x4492c7
  44928c:	a1 64 68 48 00       	mov    eax,ds:0x486864
  449291:	8b 0d 18 6d 4a 00    	mov    ecx,DWORD PTR ds:0x4a6d18
  449297:	50                   	push   eax
  449298:	51                   	push   ecx
  449299:	e8 88 dc 01 00       	call   0x466f26
  44929e:	85 c0                	test   eax,eax
  4492a0:	0f 85 ad 07 00 00    	jne    0x449a53
  4492a6:	8b 15 64 68 48 00    	mov    edx,DWORD PTR ds:0x486864
  4492ac:	a1 c0 6c 4a 00       	mov    eax,ds:0x4a6cc0
  4492b1:	57                   	push   edi
  4492b2:	56                   	push   esi
  4492b3:	52                   	push   edx
  4492b4:	57                   	push   edi
  4492b5:	6a 06                	push   0x6
  4492b7:	68 64 9c 47 00       	push   0x479c64
  4492bc:	50                   	push   eax
  4492bd:	e8 94 dc 01 00       	call   0x466f56
  4492c2:	e9 63 06 00 00       	jmp    0x44992a
  4492c7:	6a 04                	push   0x4
  4492c9:	e8 93 85 fb ff       	call   0x401861
  4492ce:	e9 54 06 00 00       	jmp    0x449927
  4492d3:	a1 d0 6c 4a 00       	mov    eax,ds:0x4a6cd0
  4492d8:	83 f8 01             	cmp    eax,0x1
  4492db:	74 1a                	je     0x4492f7
  4492dd:	83 f8 02             	cmp    eax,0x2
  4492e0:	75 09                	jne    0x4492eb
  4492e2:	a0 e8 6c 4a 00       	mov    al,ds:0x4a6ce8
  4492e7:	84 c0                	test   al,al
  4492e9:	75 0c                	jne    0x4492f7
  4492eb:	8b 0d 5c 68 48 00    	mov    ecx,DWORD PTR ds:0x48685c
  4492f1:	51                   	push   ecx
  4492f2:	e9 2b 06 00 00       	jmp    0x449922
  4492f7:	68 d0 42 48 00       	push   0x4842d0
  4492fc:	e8 50 90 fb ff       	call   0x402351
  449301:	83 c4 04             	add    esp,0x4
  449304:	8d 55 9c             	lea    edx,[ebp-0x64]
  449307:	8d 4d e8             	lea    ecx,[ebp-0x18]
  44930a:	a3 60 68 48 00       	mov    ds:0x486860,eax
  44930f:	6a 01                	push   0x1
  449311:	52                   	push   edx
  449312:	51                   	push   ecx
  449313:	50                   	push   eax
  449314:	b9 b0 40 48 00       	mov    ecx,0x4840b0
  449319:	e8 b3 88 fb ff       	call   0x401bd1
  44931e:	85 c0                	test   eax,eax
  449320:	75 0c                	jne    0x44932e
  449322:	6a 04                	push   0x4
  449324:	e8 e4 92 fb ff       	call   0x40260d
  449329:	e9 f9 05 00 00       	jmp    0x449927
  44932e:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449331:	f6 41 1f 01          	test   BYTE PTR [ecx+0x1f],0x1
  449335:	75 0e                	jne    0x449345
  449337:	8b 15 2c 6d 4a 00    	mov    edx,DWORD PTR ds:0x4a6d2c
  44933d:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  449340:	a3 68 68 48 00       	mov    ds:0x486868,eax
  449345:	8b 15 9c 40 48 00    	mov    edx,DWORD PTR ds:0x48409c
  44934b:	8b 02                	mov    eax,DWORD PTR [edx]
  44934d:	b2 ff                	mov    dl,0xff
  44934f:	38 50 2f             	cmp    BYTE PTR [eax+0x2f],dl
  449352:	0f 85 04 01 00 00    	jne    0x44945c
  449358:	8b 79 19             	mov    edi,DWORD PTR [ecx+0x19]
  44935b:	38 57 3f             	cmp    BYTE PTR [edi+0x3f],dl
  44935e:	0f 85 f6 00 00 00    	jne    0x44945a
  449364:	f6 41 1f 04          	test   BYTE PTR [ecx+0x1f],0x4
  449368:	0f 85 ec 00 00 00    	jne    0x44945a
  44936e:	83 3d 8c 40 48 00 01 	cmp    DWORD PTR ds:0x48408c,0x1
  449375:	0f 85 df 00 00 00    	jne    0x44945a
  44937b:	8d 55 e0             	lea    edx,[ebp-0x20]
  44937e:	6a 01                	push   0x1
  449380:	52                   	push   edx
  449381:	8b 15 68 68 48 00    	mov    edx,DWORD PTR ds:0x486868
  449387:	83 c0 04             	add    eax,0x4
  44938a:	52                   	push   edx
  44938b:	50                   	push   eax
  44938c:	e8 f6 90 fb ff       	call   0x402487
  449391:	33 ff                	xor    edi,edi
  449393:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  449396:	3b c7                	cmp    eax,edi
  449398:	0f 84 b7 00 00 00    	je     0x449455
  44939e:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  4493a4:	a3 54 68 48 00       	mov    ds:0x486854,eax
  4493a9:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  4493ad:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  4493b4:	8d 4d d8             	lea    ecx,[ebp-0x28]
  4493b7:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  4493ba:	e8 85 d0 01 00       	call   0x466444
  4493bf:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4493c2:	56                   	push   esi
  4493c3:	68 98 40 48 00       	push   0x484098
  4493c8:	c6 45 fc 08          	mov    BYTE PTR [ebp-0x4],0x8
  4493cc:	c6 40 7b 01          	mov    BYTE PTR [eax+0x7b],0x1
  4493d0:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4493d3:	51                   	push   ecx
  4493d4:	e8 d4 8d fb ff       	call   0x4021ad
  4493d9:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  4493dc:	83 c4 0c             	add    esp,0xc
  4493df:	8b f0                	mov    esi,eax
  4493e1:	c6 42 7b 00          	mov    BYTE PTR [edx+0x7b],0x0
  4493e5:	eb 16                	jmp    0x4493fd
  4493e7:	8b 45 0c             	mov    eax,DWORD PTR [ebp+0xc]
  4493ea:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4493ed:	89 45 dc             	mov    DWORD PTR [ebp-0x24],eax
  4493f0:	b8 fa 93 44 00       	mov    eax,0x4493fa
  4493f5:	c6 41 7b 00          	mov    BYTE PTR [ecx+0x7b],0x0
  4493f9:	c3                   	ret
  4493fa:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  4493fd:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  449404:	e8 35 d0 01 00       	call   0x46643e
  449409:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  44940c:	8b 42 2a             	mov    eax,DWORD PTR [edx+0x2a]
  44940f:	85 c0                	test   eax,eax
  449411:	74 11                	je     0x449424
  449413:	50                   	push   eax
  449414:	6a 00                	push   0x0
  449416:	6a 00                	push   0x0
  449418:	6a 00                	push   0x0
  44941a:	6a 01                	push   0x1
  44941c:	e8 81 89 fb ff       	call   0x401da2
  449421:	83 c4 14             	add    esp,0x14
  449424:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449428:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  44942f:	66 3d ff ff          	cmp    ax,0xffff
  449433:	0f 84 0a fe ff ff    	je     0x449243
  449439:	0f bf c0             	movsx  eax,ax
  44943c:	8d 04 40             	lea    eax,[eax+eax*2]
  44943f:	66 ff 0c 45 c4 25 48 	dec    WORD PTR [eax*2+0x4825c4]
  449446:	00 
  449447:	66 83 3c 45 c4 25 48 	cmp    WORD PTR [eax*2+0x4825c4],0x0
  44944e:	00 00 
  449450:	e9 fd 04 00 00       	jmp    0x449952
  449455:	8b 4d e8             	mov    ecx,DWORD PTR [ebp-0x18]
  449458:	eb 02                	jmp    0x44945c
  44945a:	33 ff                	xor    edi,edi
  44945c:	68 48 68 48 00       	push   0x486848
  449461:	8d 45 ec             	lea    eax,[ebp-0x14]
  449464:	6a 01                	push   0x1
  449466:	50                   	push   eax
  449467:	e8 d6 93 fb ff       	call   0x402842
  44946c:	85 c0                	test   eax,eax
  44946e:	0f 8c df 05 00 00    	jl     0x449a53
  449474:	a0 02 c6 47 00       	mov    al,ds:0x47c602
  449479:	84 c0                	test   al,al
  44947b:	74 3b                	je     0x4494b8
  44947d:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  449480:	8d 4d e4             	lea    ecx,[ebp-0x1c]
  449483:	51                   	push   ecx
  449484:	52                   	push   edx
  449485:	e8 41 92 fb ff       	call   0x4026cb
  44948a:	83 c4 08             	add    esp,0x8
  44948d:	85 c0                	test   eax,eax
  44948f:	74 27                	je     0x4494b8
  449491:	8b 45 e4             	mov    eax,DWORD PTR [ebp-0x1c]
  449494:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  449497:	50                   	push   eax
  449498:	57                   	push   edi
  449499:	6a 04                	push   0x4
  44949b:	57                   	push   edi
  44949c:	51                   	push   ecx
  44949d:	e8 00 89 fb ff       	call   0x401da2
  4494a2:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  4494a5:	68 48 68 48 00       	push   0x486848
  4494aa:	52                   	push   edx
  4494ab:	e8 da 91 fb ff       	call   0x40268a
  4494b0:	83 c4 1c             	add    esp,0x1c
  4494b3:	e9 9b 05 00 00       	jmp    0x449a53
  4494b8:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4494bb:	3b c7                	cmp    eax,edi
  4494bd:	a3 54 68 48 00       	mov    ds:0x486854,eax
  4494c2:	74 0d                	je     0x4494d1
  4494c4:	66 8b 48 36          	mov    cx,WORD PTR [eax+0x36]
  4494c8:	66 89 0d 50 68 48 00 	mov    WORD PTR ds:0x486850,cx
  4494cf:	eb 07                	jmp    0x4494d8
  4494d1:	66 89 3d 50 68 48 00 	mov    WORD PTR ds:0x486850,di
  4494d8:	8b 15 60 68 48 00    	mov    edx,DWORD PTR ds:0x486860
  4494de:	8d 4d d0             	lea    ecx,[ebp-0x30]
  4494e1:	89 50 08             	mov    DWORD PTR [eax+0x8],edx
  4494e4:	e8 5b cf 01 00       	call   0x466444
  4494e9:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  4494ec:	c6 45 fc 0b          	mov    BYTE PTR [ebp-0x4],0xb
  4494f0:	8a 48 04             	mov    cl,BYTE PTR [eax+0x4]
  4494f3:	84 c9                	test   cl,cl
  4494f5:	74 55                	je     0x44954c
  4494f7:	39 78 2a             	cmp    DWORD PTR [eax+0x2a],edi
  4494fa:	75 50                	jne    0x44954c
  4494fc:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  449500:	e8 39 cf 01 00       	call   0x46643e
  449505:	66 8b 45 cc          	mov    ax,WORD PTR [ebp-0x34]
  449509:	89 5d fc             	mov    DWORD PTR [ebp-0x4],ebx
  44950c:	66 3b c3             	cmp    ax,bx
  44950f:	0f 84 ad 02 00 00    	je     0x4497c2
  449515:	0f bf c0             	movsx  eax,ax
  449518:	8d 04 40             	lea    eax,[eax+eax*2]
  44951b:	66                   	data16
  44951c:	ff                   	.byte 0xff
  44951d:	0c 45                	or     al,0x45
  44951f:	c4                   	.byte 0xc4


/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00420730 <.text+0x1f730>:
  420730:	56                   	push   esi
  420731:	8b 74 24 08          	mov    esi,DWORD PTR [esp+0x8]
  420735:	8b c6                	mov    eax,esi
  420737:	25 ff ff 00 00       	and    eax,0xffff
  42073c:	83 f8 1a             	cmp    eax,0x1a
  42073f:	7c 52                	jl     0x420793
  420741:	83 f8 1b             	cmp    eax,0x1b
  420744:	7f 4d                	jg     0x420793
  420746:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  42074a:	66 8b 4c 24 10       	mov    cx,WORD PTR [esp+0x10]
  42074f:	ba 50 00 00 00       	mov    edx,0x50
  420754:	66 89 48 05          	mov    WORD PTR [eax+0x5],cx
  420758:	33 c9                	xor    ecx,ecx
  42075a:	88 50 04             	mov    BYTE PTR [eax+0x4],dl
  42075d:	c6 40 07 02          	mov    BYTE PTR [eax+0x7],0x2
  420761:	c6 40 08 01          	mov    BYTE PTR [eax+0x8],0x1
  420765:	c6 40 0c 22          	mov    BYTE PTR [eax+0xc],0x22
  420769:	88 48 0d             	mov    BYTE PTR [eax+0xd],cl
  42076c:	66 89 48 10          	mov    WORD PTR [eax+0x10],cx
  420770:	66 c7 40 13 04 01    	mov    WORD PTR [eax+0x13],0x104
  420776:	66 89 50 15          	mov    WORD PTR [eax+0x15],dx
  42077a:	66 89 48 19          	mov    WORD PTR [eax+0x19],cx
  42077e:	66 89 48 1c          	mov    WORD PTR [eax+0x1c],cx
  420782:	66 89 50 1e          	mov    WORD PTR [eax+0x1e],dx
  420786:	88 48 22             	mov    BYTE PTR [eax+0x22],cl
  420789:	66 89 70 26          	mov    WORD PTR [eax+0x26],si
  42078d:	33 c0                	xor    eax,eax
  42078f:	5e                   	pop    esi
  420790:	c2 0c 00             	ret    0xc
  420793:	83                   	.byte 0x83


/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

00466f50 <.text+0x65f50>:
  466f50:	ff 25 3c 63 6c 00    	jmp    DWORD PTR ds:0x6c633c
  466f56:	ff 25 38 63 6c 00    	jmp    DWORD PTR ds:0x6c6338
  466f5c:	ff                   	.byte 0xff
  466f5d:	25                   	.byte 0x25
  466f5e:	d8                   	.byte 0xd8
  466f5f:	62                   	.byte 0x62


/root/PL/PCU_old/H/mmc2/ncdde.exe:     file format pei-i386


Disassembly of section .text:

004012f8 <.text+0x2f8>:
  4012f8:	e9 53 9a 04 00       	jmp    0x44ad50

; LITERAL AND CONSTRUCTION SCAN

FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/ncdde.exe ImageBase=0x400000
literal 03090085 raw offsets=[]

FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll ImageBase=0x10000000
literal 03090085 raw offsets=[]

FILE /root/PL/PCU_old/H/mmc2/ncdde.exe ImageBase=0x400000
literal 03090085 raw offsets=[]

FILE /root/PL/PCU_old/H/mmc2/MCVar.dll ImageBase=0x10000000
literal 03090085 raw offsets=[]

FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/ncdde.exe
0x449fe3 00 2d 9e 44 00 90 add byte ptr [0x9000449e], ch
FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
FILE /root/PL/PCU_old/H/mmc2/ncdde.exe
0x4303c8 bc 02 43 00 90 mov esp, 0x90004302
0x438757 00 b9 86 43 00 09 add byte ptr [ecx + 0x9004386], bh
FILE /root/PL/PCU_old/H/mmc2/MCVar.dll
OLD DATA AND IMPORTS
0x486bd0 raw=0x86bd0 
0x479c64 raw=0x79c64 4e 63 64 64 65 00 00 00 43 6f 6d 70
0x486884 raw=0x86884 
0x44a5aa raw=0x4a5aa 66 c7 05 d0 6b 48 00 14 00 66 89 15 d2 6b 48 00 c7 05 e0 6b 48 00 f9 f8 f7 f6 66 c7 05 d6 6b 48 00 00 00 bf 03 00 00 00 b8 e4 6b 48 00 eb 07 8b fa b8
IAT 0x6c62e0 b'DdeAddData'
IAT 0x6c631c b'DdeCmpStringHandles'
IAT 0x6c6338 b'DdeCreateDataHandle'


/root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll:     file format pei-i386


Disassembly of section .text:

10007d80 <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x80>:
10007d80:	8b 10                	mov    edx,DWORD PTR [eax]
10007d82:	6a 01                	push   0x1
10007d84:	8b c8                	mov    ecx,eax
10007d86:	ff 12                	call   DWORD PTR [edx]
10007d88:	eb e3                	jmp    10007d6d <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x6d>
10007d8a:	5e                   	pop    esi
10007d8b:	c3                   	ret
10007d8c:	56                   	push   esi

10007d8d <?SetData@CDdeAction@@IAEXAAHJF@Z>:
10007d8d:	8b f1                	mov    esi,ecx
10007d8f:	8b 46 0c             	mov    eax,DWORD PTR [esi+0xc]
10007d92:	85 c0                	test   eax,eax
10007d94:	74 25                	je     10007dbb <?SetData@CDdeAction@@IAEXAAHJF@Z+0x2e>
10007d96:	57                   	push   edi
10007d97:	50                   	push   eax
10007d98:	8b ce                	mov    ecx,esi
10007d9a:	e8 e5 93 ff ff       	call   10001184 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0xe7c>
10007d9f:	8b f8                	mov    edi,eax
10007da1:	85 ff                	test   edi,edi
10007da3:	74 0e                	je     10007db3 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x26>
10007da5:	8b cf                	mov    ecx,edi
10007da7:	e8 b8 00 00 00       	call   10007e64 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x3f>
10007dac:	57                   	push   edi
10007dad:	e8 2a fd 00 00       	call   10017adc <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007db2:	59                   	pop    ecx
10007db3:	8b 46 0c             	mov    eax,DWORD PTR [esi+0xc]
10007db6:	85 c0                	test   eax,eax
10007db8:	75 dd                	jne    10007d97 <?SetData@CDdeAction@@IAEXAAHJF@Z+0xa>
10007dba:	5f                   	pop    edi
10007dbb:	5e                   	pop    esi
10007dbc:	c3                   	ret
10007dbd:	56                   	push   esi
10007dbe:	8b 31                	mov    esi,DWORD PTR [ecx]
10007dc0:	85 f6                	test   esi,esi
10007dc2:	74 0e                	je     10007dd2 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x45>
10007dc4:	8b ce                	mov    ecx,esi
10007dc6:	e8 09 00 00 00       	call   10007dd4 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x47>
10007dcb:	56                   	push   esi
10007dcc:	e8 0b fd 00 00       	call   10017adc <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007dd1:	59                   	pop    ecx
10007dd2:	5e                   	pop    esi
10007dd3:	c3                   	ret
10007dd4:	56                   	push   esi
10007dd5:	8b f1                	mov    esi,ecx
10007dd7:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007dda:	85 c0                	test   eax,eax
10007ddc:	74 0c                	je     10007dea <?SetData@CDdeAction@@IAEXAAHJF@Z+0x5d>
10007dde:	80 38 00             	cmp    BYTE PTR [eax],0x0
10007de1:	74 07                	je     10007dea <?SetData@CDdeAction@@IAEXAAHJF@Z+0x5d>
10007de3:	50                   	push   eax
10007de4:	e8 f3 fc 00 00       	call   10017adc <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007de9:	59                   	pop    ecx
10007dea:	c7 46 04 84 84 03 10 	mov    DWORD PTR [esi+0x4],0x10038484
10007df1:	5e                   	pop    esi
10007df2:	c3                   	ret
10007df3:	53                   	push   ebx
10007df4:	56                   	push   esi
10007df5:	8b f1                	mov    esi,ecx
10007df7:	33 db                	xor    ebx,ebx
10007df9:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007dfc:	85 c0                	test   eax,eax
10007dfe:	74 41                	je     10007e41 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x1c>
10007e00:	8d 48 04             	lea    ecx,[eax+0x4]
10007e03:	e8 5d fe ff ff       	call   10007c65 <?NcddeDAT2Date@CXVariant@@QAENPAD@Z+0x27>
10007e08:	85 c0                	test   eax,eax
10007e0a:	74 35                	je     10007e41 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x1c>
10007e0c:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007e0f:	57                   	push   edi
10007e10:	8d 56 e4             	lea    edx,[esi-0x1c]
10007e13:	8b 78 18             	mov    edi,DWORD PTR [eax+0x18]
10007e16:	21 58 18             	and    DWORD PTR [eax+0x18],ebx
10007e19:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
10007e1c:	8b c7                	mov    eax,edi
10007e1e:	24 fe                	and    al,0xfe
10007e20:	89 41 18             	mov    DWORD PTR [ecx+0x18],eax
10007e23:	8b                   	.byte 0x8b
10007e24:	4e                   	dec    esi

10007e25 <?Print@CXVariant@@QAE?AVString@@PBD@Z>:
10007e25:	04 8b                	add    al,0x8b
10007e27:	c6                   	(bad)
10007e28:	f7 d8                	neg    eax
10007e2a:	1b c0                	sbb    eax,eax
10007e2c:	23 c2                	and    eax,edx
10007e2e:	50                   	push   eax
10007e2f:	e8 a9 b0 ff ff       	call   10002edd <?AddTail@CPtrList@@QAEPAVCListNode@@PAX@Z+0x3c>
10007e34:	8b d8                	mov    ebx,eax
10007e36:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007e39:	89 78 18             	mov    DWORD PTR [eax+0x18],edi
10007e3c:	83 66 04 00          	and    DWORD PTR [esi+0x4],0x0
10007e40:	5f                   	pop    edi
10007e41:	8b c3                	mov    eax,ebx
10007e43:	5e                   	pop    esi
10007e44:	5b                   	pop    ebx
10007e45:	c3                   	ret
10007e46:	56                   	push   esi
10007e47:	8b f1                	mov    esi,ecx
10007e49:	57                   	push   edi
10007e4a:	8b 3e                	mov    edi,DWORD PTR [esi]
10007e4c:	85 ff                	test   edi,edi
10007e4e:	75 04                	jne    10007e54 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x2f>
10007e50:	33 c0                	xor    eax,eax
10007e52:	eb 0d                	jmp    10007e61 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x3c>
10007e54:	56                   	push   esi
10007e55:	8b cf                	mov    ecx,edi
10007e57:	e8 b1 97 ff ff       	call   1000160d <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x9f3>
10007e5c:	83 26 00             	and    DWORD PTR [esi],0x0
10007e5f:	8b c7                	mov    eax,edi
10007e61:	5f                   	pop    edi
10007e62:	5e                   	pop    esi
10007e63:	c3                   	ret
10007e64:	56                   	push   esi
10007e65:	8b f1                	mov    esi,ecx
10007e67:	57                   	push   edi
10007e68:	8b 3d 88 d1 02 10    	mov    edi,DWORD PTR ds:0x1002d188
10007e6e:	66 8b 46 02          	mov    ax,WORD PTR [esi+0x2]
10007e72:	66 85 c0             	test   ax,ax
10007e75:	74 08                	je     10007e7f <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x5a>
10007e77:	50                   	push   eax
10007e78:	ff d7                	call   edi
10007e7a:	66 83 66 02 00       	and    WORD PTR [esi+0x2],0x0
10007e7f:	66 8b 06             	mov    ax,WORD PTR [esi]
10007e82:	66 85 c0             	test   ax,ax
10007e85:	74 07                	je     10007e8e <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x69>
10007e87:	50                   	push   eax
10007e88:	ff d7                	call   edi
10007e8a:	66 83 26 00          	and    WORD PTR [esi],0x0
10007e8e:	5f                   	pop    edi
10007e8f:	5e                   	pop    esi
10007e90:	c3                   	ret
10007e91:	83 e9 08             	sub    ecx,0x8
10007e94:	e9 b5 a3 ff ff       	jmp    1000224e <??0CWinVer@@QAE@XZ+0x3b>
10007e99:	83 e9 1c             	sub    ecx,0x1c
10007e9c:	e9 ad a3 ff ff       	jmp    1000224e <??0CWinVer@@QAE@XZ+0x3b>
10007ea1:	83 e9 08             	sub    ecx,0x8
10007ea4:	e9 af b0 ff ff       	jmp    10002f58 <?TryConnect@CDdeClass@@IAEPAVCResult@@AAV?$CSmart@PAVCDdeCon@@@@AAVCAtom@@1AAVCDdeAction@@@Z+0x31>
10007ea9:	ff 15 74 d0 02 10    	call   DWORD PTR ds:0x1002d074

10007eaf <??4String@@QAEXPBD@Z>:
10007eaf:	68 c0 7e 00 10       	push   0x10007ec0
10007eb4:	a3 90 84 03 10       	mov    ds:0x10038490,eax
10007eb9:	e8 a7 fc 00 00       	call   10017b65 <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x460>
10007ebe:	59                   	pop    ecx
10007ebf:	c3                   	ret
10007ec0:	a1 90 84 03 10       	mov    eax,ds:0x10038490
10007ec5:	83 f8 ff             	cmp    eax,0xffffffff
10007ec8:	74 07                	je     10007ed1 <??4String@@QAEXPBD@Z+0x22>
10007eca:	50                   	push   eax
10007ecb:	ff 15 78 d0 02 10    	call   DWORD PTR ds:0x1002d078
10007ed1:	c3                   	ret
10007ed2:	b9 8c 84 03 10       	mov    ecx,0x1003848c
10007ed7:	e9                   	.byte 0xe9
10007ed8:	37                   	aaa

10007ed9 <?LineBreak@String@@QAEXD@Z>:
10007ed9:	93                   	xchg   ebx,eax
10007eda:	ff                   	(bad)
10007edb:	ff 68 90             	jmp    FWORD PTR [eax-0x70]
10007ede:	1d 03 10 b9 28       	sbb    eax,0x28b91003
10007ee3:	86 03                	xchg   BYTE PTR [ebx],al
10007ee5:	10 e8                	adc    al,ch
10007ee7:	8a 9e ff ff 68 f7    	mov    bl,BYTE PTR [esi-0x8970001]
10007eed:	7e 00                	jle    10007eef <?LineBreak@String@@QAEXD@Z+0x16>
10007eef:	10 e8                	adc    al,ch
10007ef1:	70 fc                	jo     10007eef <?LineBreak@String@@QAEXD@Z+0x16>
10007ef3:	00 00                	add    BYTE PTR [eax],al
10007ef5:	59                   	pop    ecx
10007ef6:	c3                   	ret
10007ef7:	a1 28 86 03 10       	mov    eax,ds:0x10038628
10007efc:	85 c0                	test   eax,eax
10007efe:	74 0c                	je     10007f0c <?LineBreak@String@@QAEXD@Z+0x33>
10007f00:	80 38 00             	cmp    BYTE PTR [eax],0x0
10007f03:	74 07                	je     10007f0c <?LineBreak@String@@QAEXD@Z+0x33>
10007f05:	50                   	push   eax
10007f06:	e8 d1 fb 00 00       	call   10017adc <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007f0b:	59                   	pop    ecx
10007f0c:	c7 05 28 86 03 10 84 	mov    DWORD PTR ds:0x10038628,0x10038484
10007f13:	84 03 10 
10007f16:	c3                   	ret
10007f17:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
10007f1b:	ff 74 24 10          	push   DWORD PTR [esp+0x10]
10007f1f:	8b 01                	mov    eax,DWORD PTR [ecx]
10007f21:	ff 50 0c             	call   DWORD PTR [eax+0xc]
10007f24:	c2 10 00             	ret    0x10
10007f27:	8b c1                	mov    eax,ecx
10007f29:	8b 48 10             	mov    ecx,DWORD PTR [eax+0x10]
10007f2c:	c7 00 5c d3 02 10    	mov    DWORD PTR [eax],0x1002d35c
10007f32:	85 c9                	test   ecx,ecx
10007f34:	74 06                	je     10007f3c <?LineBreak@String@@QAEXD@Z+0x63>
10007f36:	50                   	push   eax
10007f37:	e8 4e af ff ff       	call   10002e8a <?OutOfHeap@CResult@@SAPAV1@XZ+0x17>
10007f3c:	c3                   	ret
10007f3d:	55                   	push   ebp
10007f3e:	8b ec                	mov    ebp,esp
10007f40:	51                   	push   ecx
10007f41:	0f b7 45 14          	movzx  eax,WORD PTR [ebp+0x14]
10007f45:	53                   	push   ebx
10007f46:	56                   	push   esi
10007f47:	57                   	push   edi
10007f48:	50                   	push   eax
10007f49:	ff 75 10             	push   DWORD PTR [ebp+0x10]
10007f4c:	8d 45 fc             	lea    eax,[ebp-0x4]
10007f4f:	8b d9                	mov    ebx,ecx
10007f51:	ff 75 0c             	push   DWORD PTR [ebp+0xc]
10007f54:	68 a0 1d 03 10       	push   0x10031da0
10007f59:	50                   	push   eax
10007f5a:	e8 f1 fb ff ff       	call   10007b50 <?Dt2Date@CXVariant@@QAENPAEH@Z+0x1a>
10007f5f:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
10007f62:	83 c4 14             	add    esp,0x14
10007f65:	66 8b 06             	mov    ax,WORD PTR [esi]
10007f68:	66 3d 0a 00          	cmp    ax,0xa
10007f6c:	75 0d                	jne    10007f7b <?LineBreak@String@@QAEXD@Z+0xa2>
10007f6e:	81 7e 08 04 00 02 80 	cmp    DWORD PTR [esi+0x8],0x80020004
10007f75:	0f 84 08 01 00 00    	je     10008083 <?_Print@CXVariant@@QAE?AVString@@AAV2@@Z+0xcb>
10007f7b:	66 85 c0             	test   ax,ax
10007f7e:	0f 84 ff 00 00 00    	je     10008083 <?_Print@CXVariant@@QAE?AVString@@AAV2@@Z+0xcb>
10007f84:	b9 00 20 00 00       	mov    ecx,0x2000
10007f89:	66 85 c1             	test   cx,ax
10007f8c:	74 0a                	je     10007f98 <?LineBreak@String@@QAEXD@Z+0xbf>
10007f8e:	83                   	.byte 0x83
10007f8f:	7e                   	.byte 0x7e


/root/PL/PCU_old/H/mmc2/MCVar.dll:     file format pei-i386


Disassembly of section .text:

10007c70 <?S5Date2Date@CXVariant@@QAENG@Z+0x30>:
10007c70:	74 ed                	je     10007c5f <?S5Date2Date@CXVariant@@QAENG@Z+0x1f>
10007c72:	8b 10                	mov    edx,DWORD PTR [eax]
10007c74:	6a 01                	push   0x1
10007c76:	8b c8                	mov    ecx,eax
10007c78:	ff 12                	call   DWORD PTR [edx]
10007c7a:	eb e3                	jmp    10007c5f <?S5Date2Date@CXVariant@@QAENG@Z+0x1f>
10007c7c:	5e                   	pop    esi
10007c7d:	c3                   	ret

10007c7e <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z>:
10007c7e:	56                   	push   esi
10007c7f:	8b f1                	mov    esi,ecx
10007c81:	8b 46 0c             	mov    eax,DWORD PTR [esi+0xc]
10007c84:	85 c0                	test   eax,eax
10007c86:	74 25                	je     10007cad <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x2f>
10007c88:	57                   	push   edi
10007c89:	50                   	push   eax
10007c8a:	8b ce                	mov    ecx,esi
10007c8c:	e8 f3 94 ff ff       	call   10001184 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0xe7c>
10007c91:	8b f8                	mov    edi,eax
10007c93:	85 ff                	test   edi,edi
10007c95:	74 0e                	je     10007ca5 <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x27>
10007c97:	8b cf                	mov    ecx,edi
10007c99:	e8 b8 00 00 00       	call   10007d56 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x4b>
10007c9e:	57                   	push   edi
10007c9f:	e8 2e fd 00 00       	call   100179d2 <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007ca4:	59                   	pop    ecx
10007ca5:	8b 46 0c             	mov    eax,DWORD PTR [esi+0xc]
10007ca8:	85 c0                	test   eax,eax
10007caa:	75 dd                	jne    10007c89 <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0xb>
10007cac:	5f                   	pop    edi
10007cad:	5e                   	pop    esi
10007cae:	c3                   	ret
10007caf:	56                   	push   esi
10007cb0:	8b 31                	mov    esi,DWORD PTR [ecx]
10007cb2:	85 f6                	test   esi,esi
10007cb4:	74 0e                	je     10007cc4 <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x46>
10007cb6:	8b ce                	mov    ecx,esi
10007cb8:	e8 09 00 00 00       	call   10007cc6 <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x48>
10007cbd:	56                   	push   esi
10007cbe:	e8 0f fd 00 00       	call   100179d2 <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007cc3:	59                   	pop    ecx
10007cc4:	5e                   	pop    esi
10007cc5:	c3                   	ret
10007cc6:	56                   	push   esi
10007cc7:	8b f1                	mov    esi,ecx
10007cc9:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007ccc:	85 c0                	test   eax,eax
10007cce:	74 0c                	je     10007cdc <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x5e>
10007cd0:	80 38 00             	cmp    BYTE PTR [eax],0x0
10007cd3:	74 07                	je     10007cdc <?DecodeError@CDdeAction@@IAEHAAUNCDDE_BINARY_HEADER@@PAJPAF@Z+0x5e>
10007cd5:	50                   	push   eax
10007cd6:	e8 f7 fc 00 00       	call   100179d2 <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007cdb:	59                   	pop    ecx
10007cdc:	c7 46 04 30 74 03 10 	mov    DWORD PTR [esi+0x4],0x10037430
10007ce3:	5e                   	pop    esi
10007ce4:	c3                   	ret
10007ce5:	53                   	push   ebx
10007ce6:	56                   	push   esi
10007ce7:	8b f1                	mov    esi,ecx
10007ce9:	33 db                	xor    ebx,ebx
10007ceb:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007cee:	85 c0                	test   eax,eax
10007cf0:	74 41                	je     10007d33 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x28>
10007cf2:	8d 48 04             	lea    ecx,[eax+0x4]
10007cf5:	e8 5d fe ff ff       	call   10007b57 <?Dt2Date@CXVariant@@QAENPAE@Z+0x8d>
10007cfa:	85 c0                	test   eax,eax
10007cfc:	74 35                	je     10007d33 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x28>
10007cfe:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007d01:	57                   	push   edi
10007d02:	8d 56 e4             	lea    edx,[esi-0x1c]
10007d05:	8b 78 18             	mov    edi,DWORD PTR [eax+0x18]
10007d08:	21 58 18             	and    DWORD PTR [eax+0x18],ebx

10007d0b <?SetData@CDdeAction@@IAEXAAHJF@Z>:
10007d0b:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
10007d0e:	8b c7                	mov    eax,edi
10007d10:	24 fe                	and    al,0xfe
10007d12:	89 41 18             	mov    DWORD PTR [ecx+0x18],eax
10007d15:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
10007d18:	8b c6                	mov    eax,esi
10007d1a:	f7 d8                	neg    eax
10007d1c:	1b c0                	sbb    eax,eax
10007d1e:	23 c2                	and    eax,edx
10007d20:	50                   	push   eax
10007d21:	e8 78 b1 ff ff       	call   10002e9e <?OutOfHeap@CResult@@SAPAV1@XZ+0x2b>
10007d26:	8b d8                	mov    ebx,eax
10007d28:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
10007d2b:	89 78 18             	mov    DWORD PTR [eax+0x18],edi
10007d2e:	83 66 04 00          	and    DWORD PTR [esi+0x4],0x0
10007d32:	5f                   	pop    edi
10007d33:	8b c3                	mov    eax,ebx
10007d35:	5e                   	pop    esi
10007d36:	5b                   	pop    ebx
10007d37:	c3                   	ret
10007d38:	56                   	push   esi
10007d39:	8b f1                	mov    esi,ecx
10007d3b:	57                   	push   edi
10007d3c:	8b 3e                	mov    edi,DWORD PTR [esi]
10007d3e:	85 ff                	test   edi,edi
10007d40:	75 04                	jne    10007d46 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x3b>
10007d42:	33 c0                	xor    eax,eax
10007d44:	eb 0d                	jmp    10007d53 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x48>
10007d46:	56                   	push   esi
10007d47:	8b cf                	mov    ecx,edi
10007d49:	e8 bf 98 ff ff       	call   1000160d <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x9f3>
10007d4e:	83 26 00             	and    DWORD PTR [esi],0x0
10007d51:	8b c7                	mov    eax,edi
10007d53:	5f                   	pop    edi
10007d54:	5e                   	pop    esi
10007d55:	c3                   	ret
10007d56:	56                   	push   esi
10007d57:	8b f1                	mov    esi,ecx
10007d59:	57                   	push   edi
10007d5a:	8b 3d 88 c1 02 10    	mov    edi,DWORD PTR ds:0x1002c188
10007d60:	66 8b 46 02          	mov    ax,WORD PTR [esi+0x2]
10007d64:	66 85 c0             	test   ax,ax
10007d67:	74 08                	je     10007d71 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x66>
10007d69:	50                   	push   eax
10007d6a:	ff d7                	call   edi
10007d6c:	66 83 66 02 00       	and    WORD PTR [esi+0x2],0x0
10007d71:	66 8b 06             	mov    ax,WORD PTR [esi]
10007d74:	66 85 c0             	test   ax,ax
10007d77:	74 07                	je     10007d80 <?SetData@CDdeAction@@IAEXAAHJF@Z+0x75>
10007d79:	50                   	push   eax
10007d7a:	ff d7                	call   edi
10007d7c:	66 83 26 00          	and    WORD PTR [esi],0x0
10007d80:	5f                   	pop    edi
10007d81:	5e                   	pop    esi
10007d82:	c3                   	ret
10007d83:	83 e9 08             	sub    ecx,0x8
10007d86:	e9 84 a4 ff ff       	jmp    1000220f <?WinVer@CWinVer@@CAAAV1@XZ+0x28>
10007d8b:	83 e9 1c             	sub    ecx,0x1c
10007d8e:	e9 7c a4 ff ff       	jmp    1000220f <?WinVer@CWinVer@@CAAAV1@XZ+0x28>
10007d93:	83 e9 08             	sub    ecx,0x8
10007d96:	e9 7e b1 ff ff       	jmp    10002f19 <?TryConnect@CDdeClass@@IAEPAVCResult@@AAV?$CSmart@PAVCDdeCon@@@@AAVCAtom@@1AAVCDdeAction@@@Z+0x31>
10007d9b:	ff 15 74 c0 02 10    	call   DWORD PTR ds:0x1002c074
10007da1:	68                   	.byte 0x68
10007da2:	b2                   	.byte 0xb2

10007da3 <?Print@CXVariant@@QAE?AVString@@PBD@Z>:
10007da3:	7d 00                	jge    10007da5 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x2>
10007da5:	10 a3 3c 74 03 10    	adc    BYTE PTR [ebx+0x1003743c],ah
10007dab:	e8 ab fc 00 00       	call   10017a5b <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x460>
10007db0:	59                   	pop    ecx
10007db1:	c3                   	ret
10007db2:	a1 3c 74 03 10       	mov    eax,ds:0x1003743c
10007db7:	83 f8 ff             	cmp    eax,0xffffffff
10007dba:	74 07                	je     10007dc3 <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x20>
10007dbc:	50                   	push   eax
10007dbd:	ff 15 78 c0 02 10    	call   DWORD PTR ds:0x1002c078
10007dc3:	c3                   	ret
10007dc4:	b9 38 74 03 10       	mov    ecx,0x10037438
10007dc9:	e9 45 94 ff ff       	jmp    10001213 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0xded>
10007dce:	68 40 0d 03 10       	push   0x10030d40
10007dd3:	b9 d4 75 03 10       	mov    ecx,0x100375d4
10007dd8:	e8 98 9f ff ff       	call   10001d75 <??_Estringdispid@CComTypeInfoHolder@ATL@@QAEPAXI@Z-0x28b>
10007ddd:	68 e9 7d 00 10       	push   0x10007de9
10007de2:	e8 74 fc 00 00       	call   10017a5b <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x460>
10007de7:	59                   	pop    ecx
10007de8:	c3                   	ret
10007de9:	a1 d4 75 03 10       	mov    eax,ds:0x100375d4
10007dee:	85 c0                	test   eax,eax
10007df0:	74 0c                	je     10007dfe <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x5b>
10007df2:	80 38 00             	cmp    BYTE PTR [eax],0x0
10007df5:	74 07                	je     10007dfe <?Print@CXVariant@@QAE?AVString@@PBD@Z+0x5b>
10007df7:	50                   	push   eax
10007df8:	e8 d5 fb 00 00       	call   100179d2 <?ASLookupVarType@CVar2@@SAGAAVCComBSTR@ATL@@@Z+0x3d7>
10007dfd:	59                   	pop    ecx
10007dfe:	c7 05 d4 75 03 10 30 	mov    DWORD PTR ds:0x100375d4,0x10037430
10007e05:	74 03 10 
10007e08:	c3                   	ret
10007e09:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
10007e0d:	ff 74 24 10          	push   DWORD PTR [esp+0x10]
10007e11:	8b 01                	mov    eax,DWORD PTR [ecx]
10007e13:	ff 50 0c             	call   DWORD PTR [eax+0xc]
10007e16:	c2 10 00             	ret    0x10
10007e19:	8b c1                	mov    eax,ecx
10007e1b:	8b 48 10             	mov    ecx,DWORD PTR [eax+0x10]
10007e1e:	c7 00 4c c3 02 10    	mov    DWORD PTR [eax],0x1002c34c
10007e24:	85 c9                	test   ecx,ecx
10007e26:	74 06                	je     10007e2e <??4String@@QAEXPBD@Z+0x1>
10007e28:	50                   	push   eax
10007e29:	e8                   	.byte 0xe8
10007e2a:	1d                   	.byte 0x1d
10007e2b:	b0 ff                	mov    al,0xff

10007e2d <??4String@@QAEXPBD@Z>:
10007e2d:	ff c3                	inc    ebx
10007e2f:	55                   	push   ebp
10007e30:	8b ec                	mov    ebp,esp
10007e32:	51                   	push   ecx
10007e33:	0f b7 45 14          	movzx  eax,WORD PTR [ebp+0x14]
10007e37:	53                   	push   ebx
10007e38:	56                   	push   esi
10007e39:	57                   	push   edi
10007e3a:	50                   	push   eax
10007e3b:	ff 75 10             	push   DWORD PTR [ebp+0x10]
10007e3e:	8d 45 fc             	lea    eax,[ebp-0x4]
10007e41:	8b d9                	mov    ebx,ecx
10007e43:	ff 75 0c             	push   DWORD PTR [ebp+0xc]
10007e46:	68 50 0d 03 10       	push   0x10030d50
10007e4b:	50                   	push   eax
10007e4c:	e8 f1 fb ff ff       	call   10007a42 <??0CSafeArrayDataBase@@QAE@GHH@Z+0x2b>
10007e51:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
10007e54:	83 c4 14             	add    esp,0x14

10007e57 <?LineBreak@String@@QAEXD@Z>:
10007e57:	66 8b 06             	mov    ax,WORD PTR [esi]
10007e5a:	66 3d 0a 00          	cmp    ax,0xa
10007e5e:	75 0d                	jne    10007e6d <?LineBreak@String@@QAEXD@Z+0x16>
10007e60:	81 7e 08 04 00 02 80 	cmp    DWORD PTR [esi+0x8],0x80020004
10007e67:	0f 84 08 01 00 00    	je     10007f75 <?_Print@CXVariant@@QAE?AVString@@AAV2@@Z+0x3f>
10007e6d:	66 85 c0             	test   ax,ax
10007e70:	0f 84 ff 00 00 00    	je     10007f75 <?_Print@CXVariant@@QAE?AVString@@AAV2@@Z+0x3f>
10007e76:	b9 00 20 00 00       	mov    ecx,0x2000
10007e7b:	66 85 c1             	test   cx,ax
10007e7e:	74 0a                	je     10007e8a <?LineBreak@String@@QAEXD@Z+0x33>

; ERROR CONSTRUCTION CANDIDATES
FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
0x10001a87 1b ff sbb edi, edi
0x10001a89 53 push ebx
0x10001a8a 81 e7 00 00 00 40 and edi, 0x40000000
0x10001a90 53 push ebx
0x10001a91 53 push ebx
0x10001a92 81 c7 00 00 00 08 add edi, 0x8000000
0x10001a98 53 push ebx
0x10001a99 57 push edi
0x10001a9a ff 75 08 push dword ptr [ebp + 8]
0x10001a9d 68 d0 11 03 10 push 0x100311d0
0x10001aa2 53 push ebx
0x10001aa3 ff 15 60 d2 02 10 call dword ptr [0x1002d260]

0x10002064 8b f0 mov esi, eax
0x10002066 83 c4 14 add esp, 0x14
0x10002069 85 f6 test esi, esi
0x1000206b 74 1f je 0x1000208c
0x1000206d 8d 85 00 ff ff ff lea eax, [ebp - 0x100]
0x10002073 81 cf 00 00 07 80 or edi, 0x80070000
0x10002079 50 push eax
0x1000207a 8d 4e 04 lea ecx, [esi + 4]
0x1000207d 89 3e mov dword ptr [esi], edi
0x1000207f e8 f1 fc ff ff call 0x10001d75
0x10002084 83 66 08 00 and dword ptr [esi + 8], 0
0x10002088 8b c6 mov eax, esi

0x10002da6 89 03 mov dword ptr [ebx], eax
0x10002da8 89 4d fc mov dword ptr [ebp - 4], ecx
0x10002dab 8b 48 08 mov ecx, dword ptr [eax + 8]
0x10002dae 83 c3 04 add ebx, 4
0x10002db1 03 f1 add esi, ecx
0x10002db3 81 c9 00 00 00 80 or ecx, 0x80000000
0x10002db9 89 70 04 mov dword ptr [eax + 4], esi
0x10002dbc 89 48 08 mov dword ptr [eax + 8], ecx
0x10002dbf 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10002dc2 81 f9 00 01 00 00 cmp ecx, 0x100
0x10002dc8 7c ca jl 0x10002d94
0x10002dca 8b c1 mov eax, ecx

0x10002df5 75 f5 jne 0x10002dec
0x10002df7 33 c0 xor eax, eax
0x10002df9 85 c0 test eax, eax
0x10002dfb 74 56 je 0x10002e53
0x10002dfd 8b 32 mov esi, dword ptr [edx]
0x10002dff bb 00 00 00 80 mov ebx, 0x80000000
0x10002e04 85 5e 08 test dword ptr [esi + 8], ebx
0x10002e07 74 4a je 0x10002e53
0x10002e09 ff 76 0c push dword ptr [esi + 0xc]
0x10002e0c 8d 45 f4 lea eax, [ebp - 0xc]
0x10002e0f 56 push esi
0x10002e10 57 push edi

0x1000a774 7f 04 jg 0x1000a77a
0x1000a776 33 c0 xor eax, eax
0x1000a778 eb 1d jmp 0x1000a797
0x1000a77a 3b c7 cmp eax, edi
0x1000a77c 7d 07 jge 0x1000a785
0x1000a77e b8 00 00 00 80 mov eax, 0x80000000
0x1000a783 eb 12 jmp 0x1000a797
0x1000a785 8b 0e mov ecx, dword ptr [esi]
0x1000a787 ff 74 24 0c push dword ptr [esp + 0xc]
0x1000a78b 2b cf sub ecx, edi
0x1000a78d 03 c8 add ecx, eax
0x1000a78f 51 push ecx

0x1000af07 1b c9 sbb ecx, ecx
0x1000af09 57 push edi
0x1000af0a 66 81 e1 00 f8 and cx, 0xf800
0x1000af0f 53 push ebx
0x1000af10 ff 75 30 push dword ptr [ebp + 0x30]
0x1000af13 81 c1 00 08 00 00 add ecx, 0x800
0x1000af19 0b c1 or eax, ecx
0x1000af1b 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x1000af1e 0d 3b 00 02 08 or eax, 0x802003b
0x1000af23 50 push eax
0x1000af24 8d 45 08 lea eax, [ebp + 8]
0x1000af27 ff 75 34 push dword ptr [ebp + 0x34]

0x1000c188 f7 d9 neg ecx
0x1000c18a 1b c9 sbb ecx, ecx
0x1000c18c 56 push esi
0x1000c18d 66 81 e1 00 f8 and cx, 0xf800
0x1000c192 56 push esi
0x1000c193 81 c1 00 08 00 00 add ecx, 0x800
0x1000c199 56 push esi
0x1000c19a 0b c1 or eax, ecx
0x1000c19c 56 push esi
0x1000c19d 0d 20 01 04 08 or eax, 0x8040120
0x1000c1a2 8b cf mov ecx, edi
0x1000c1a4 50 push eax

0x1000c4aa f7 d9 neg ecx
0x1000c4ac 1b c9 sbb ecx, ecx
0x1000c4ae 56 push esi
0x1000c4af 66 81 e1 00 f8 and cx, 0xf800
0x1000c4b4 56 push esi
0x1000c4b5 81 c1 00 08 00 00 add ecx, 0x800
0x1000c4bb 56 push esi
0x1000c4bc 0b c1 or eax, ecx
0x1000c4be 56 push esi
0x1000c4bf 0d 3f 04 0a 08 or eax, 0x80a043f
0x1000c4c4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1000c4c7 50 push eax

0x1000f401 f7 d9 neg ecx
0x1000f403 1b c9 sbb ecx, ecx
0x1000f405 56 push esi
0x1000f406 66 81 e1 00 f8 and cx, 0xf800
0x1000f40b 56 push esi
0x1000f40c 81 c1 00 08 00 00 add ecx, 0x800
0x1000f412 56 push esi
0x1000f413 0b c1 or eax, ecx
0x1000f415 56 push esi
0x1000f416 0d 24 05 0c 08 or eax, 0x80c0524
0x1000f41b 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1000f41e 50 push eax

0x1000fba7 1b d2 sbb edx, edx
0x1000fba9 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1000fbac 66 81 e2 00 f8 and dx, 0xf800
0x1000fbb1 56 push esi
0x1000fbb2 8d 75 1c lea esi, [ebp + 0x1c]
0x1000fbb5 81 c2 00 08 00 00 add edx, 0x800
0x1000fbbb 56 push esi
0x1000fbbc 0b c2 or eax, edx
0x1000fbbe 8d 75 0c lea esi, [ebp + 0xc]
0x1000fbc1 0d 3f 04 08 0f or eax, 0xf08043f
0x1000fbc6 56 push esi
0x1000fbc7 50 push eax

0x10010c75 f7 d8 neg eax
0x10010c77 1b c0 sbb eax, eax
0x10010c79 8d 55 30 lea edx, [ebp + 0x30]
0x10010c7c 66 25 00 f8 and ax, 0xf800
0x10010c80 56 push esi
0x10010c81 05 00 08 00 00 add eax, 0x800
0x10010c86 52 push edx
0x10010c87 f7 d9 neg ecx
0x10010c89 8d 55 20 lea edx, [ebp + 0x20]
0x10010c8c 1b c9 sbb ecx, ecx
0x10010c8e 52 push edx
0x10010c8f 66 81 e1 00 fe and cx, 0xfe00

0x10011304 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10011307 8b f8 mov edi, eax
0x10011309 f7 df neg edi
0x1001130b 1b ff sbb edi, edi
0x1001130d 66 81 e7 00 f8 and di, 0xf800
0x10011312 81 c7 00 08 00 00 add edi, 0x800
0x10011318 e8 a4 00 00 00 call 0x100113c1
0x1001131d f7 d8 neg eax
0x1001131f 1b c0 sbb eax, eax
0x10011321 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10011324 25 00 fe cf ff and eax, 0xffcffe00
0x10011329 05 00 02 30 00 add eax, 0x300200

0x10011e76 84 c9 test cl, cl
0x10011e78 76 0f jbe 0x10011e89
0x10011e7a 80 f9 0c cmp cl, 0xc
0x10011e7d 73 0a jae 0x10011e89
0x10011e7f 25 ff ff 00 ff and eax, 0xff00ffff
0x10011e84 0d 00 00 00 80 or eax, 0x80000000
0x10011e89 c3 ret 
0x10011e8a d9 81 8c 00 00 00 fld dword ptr [ecx + 0x8c]
0x10011e90 c3 ret 
0x10011e91 55 push ebp
0x10011e92 8b ec mov ebp, esp
0x10011e94 81 ec 30 01 00 00 sub esp, 0x130

0x1002196a 75 1c jne 0x10021988
0x1002196c 25 00 01 01 81 and eax, 0x81010100
0x10021971 74 d3 je 0x10021946
0x10021973 25 00 01 01 01 and eax, 0x1010100
0x10021978 75 08 jne 0x10021982
0x1002197a 81 e6 00 00 00 80 and esi, 0x80000000
0x10021980 75 c4 jne 0x10021946
0x10021982 5e pop esi
0x10021983 5f pop edi
0x10021984 5b pop ebx
0x10021985 33 c0 xor eax, eax
0x10021987 c3 ret 

0x1002425e 8b 4b 04 mov ecx, dword ptr [ebx + 4]
0x10024261 3b 4b 08 cmp ecx, dword ptr [ebx + 8]
0x10024264 75 4c jne 0x100242b2
0x10024266 83 fa 20 cmp edx, 0x20
0x10024269 73 1e jae 0x10024289
0x1002426b bb 00 00 00 80 mov ebx, 0x80000000
0x10024270 8b ca mov ecx, edx
0x10024272 d3 eb shr ebx, cl
0x10024274 8d 4c 02 04 lea ecx, [edx + eax + 4]
0x10024278 f7 d3 not ebx
0x1002427a 21 5c b8 44 and dword ptr [eax + edi*4 + 0x44], ebx
0x1002427e fe 09 dec byte ptr [ecx]

0x10024280 75 28 jne 0x100242aa
0x10024282 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024285 21 19 and dword ptr [ecx], ebx
0x10024287 eb 21 jmp 0x100242aa
0x10024289 8d 4a e0 lea ecx, [edx - 0x20]
0x1002428c bb 00 00 00 80 mov ebx, 0x80000000
0x10024291 d3 eb shr ebx, cl
0x10024293 8d 4c 02 04 lea ecx, [edx + eax + 4]
0x10024297 f7 d3 not ebx
0x10024299 21 9c b8 c4 00 00 00 and dword ptr [eax + edi*4 + 0xc4], ebx
0x100242a0 fe 09 dec byte ptr [ecx]
0x100242a2 75 06 jne 0x100242aa

0x1002431c 8b 71 04 mov esi, dword ptr [ecx + 4]
0x1002431f 3b 71 08 cmp esi, dword ptr [ecx + 8]
0x10024322 75 40 jne 0x10024364
0x10024324 83 fb 20 cmp ebx, 0x20
0x10024327 73 1c jae 0x10024345
0x10024329 be 00 00 00 80 mov esi, 0x80000000
0x1002432e 8b cb mov ecx, ebx
0x10024330 d3 ee shr esi, cl
0x10024332 f7 d6 not esi
0x10024334 21 74 b8 44 and dword ptr [eax + edi*4 + 0x44], esi
0x10024338 fe 4c 03 04 dec byte ptr [ebx + eax + 4]
0x1002433c 75 26 jne 0x10024364

0x1002433c 75 26 jne 0x10024364
0x1002433e 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024341 21 31 and dword ptr [ecx], esi
0x10024343 eb 1f jmp 0x10024364
0x10024345 8d 4b e0 lea ecx, [ebx - 0x20]
0x10024348 be 00 00 00 80 mov esi, 0x80000000
0x1002434d d3 ee shr esi, cl
0x1002434f f7 d6 not esi
0x10024351 21 b4 b8 c4 00 00 00 and dword ptr [eax + edi*4 + 0xc4], esi
0x10024358 fe 4c 03 04 dec byte ptr [ebx + eax + 4]
0x1002435c 75 06 jne 0x10024364
0x1002435e 8b 4d 08 mov ecx, dword ptr [ebp + 8]

0x100243bd fe c1 inc cl
0x100243bf 88 4c 02 04 mov byte ptr [edx + eax + 4], cl
0x100243c3 73 25 jae 0x100243ea
0x100243c5 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x100243c9 75 0e jne 0x100243d9
0x100243cb bb 00 00 00 80 mov ebx, 0x80000000
0x100243d0 8b ca mov ecx, edx
0x100243d2 d3 eb shr ebx, cl
0x100243d4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100243d7 09 19 or dword ptr [ecx], ebx
0x100243d9 bb 00 00 00 80 mov ebx, 0x80000000
0x100243de 8b ca mov ecx, edx

0x100243cb bb 00 00 00 80 mov ebx, 0x80000000
0x100243d0 8b ca mov ecx, edx
0x100243d2 d3 eb shr ebx, cl
0x100243d4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100243d7 09 19 or dword ptr [ecx], ebx
0x100243d9 bb 00 00 00 80 mov ebx, 0x80000000
0x100243de 8b ca mov ecx, edx
0x100243e0 d3 eb shr ebx, cl
0x100243e2 8d 44 b8 44 lea eax, [eax + edi*4 + 0x44]
0x100243e6 09 18 or dword ptr [eax], ebx
0x100243e8 eb 29 jmp 0x10024413
0x100243ea 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0

0x100243e6 09 18 or dword ptr [eax], ebx
0x100243e8 eb 29 jmp 0x10024413
0x100243ea 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x100243ee 75 10 jne 0x10024400
0x100243f0 8d 4a e0 lea ecx, [edx - 0x20]
0x100243f3 bb 00 00 00 80 mov ebx, 0x80000000
0x100243f8 d3 eb shr ebx, cl
0x100243fa 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100243fd 09 59 04 or dword ptr [ecx + 4], ebx
0x10024400 8d 4a e0 lea ecx, [edx - 0x20]
0x10024403 ba 00 00 00 80 mov edx, 0x80000000
0x10024408 d3 ea shr edx, cl

0x100243f3 bb 00 00 00 80 mov ebx, 0x80000000
0x100243f8 d3 eb shr ebx, cl
0x100243fa 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100243fd 09 59 04 or dword ptr [ecx + 4], ebx
0x10024400 8d 4a e0 lea ecx, [edx - 0x20]
0x10024403 ba 00 00 00 80 mov edx, 0x80000000
0x10024408 d3 ea shr edx, cl
0x1002440a 8d 84 b8 c4 00 00 00 lea eax, [eax + edi*4 + 0xc4]
0x10024411 09 10 or dword ptr [eax], edx
0x10024413 8b 45 fc mov eax, dword ptr [ebp - 4]
0x10024416 89 06 mov dword ptr [esi], eax
0x10024418 89 44 30 fc mov dword ptr [eax + esi - 4], eax

0x10024450 53 push ebx
0x10024451 51 push ecx
0x10024452 ff d6 call esi
0x10024454 8b 0d 48 a2 03 10 mov ecx, dword ptr [0x1003a248]
0x1002445a a1 54 a2 03 10 mov eax, dword ptr [0x1003a254]
0x1002445f ba 00 00 00 80 mov edx, 0x80000000
0x10024464 d3 ea shr edx, cl
0x10024466 09 50 08 or dword ptr [eax + 8], edx
0x10024469 a1 54 a2 03 10 mov eax, dword ptr [0x1003a254]
0x1002446e 8b 0d 48 a2 03 10 mov ecx, dword ptr [0x1003a248]
0x10024474 8b 40 10 mov eax, dword ptr [eax + 0x10]
0x10024477 83 a4 88 c4 00 00 00 00 and dword ptr [eax + ecx*4 + 0xc4], 0

0x100246cd 8b 4a 04 mov ecx, dword ptr [edx + 4]
0x100246d0 3b 4a 08 cmp ecx, dword ptr [edx + 8]
0x100246d3 75 61 jne 0x10024736
0x100246d5 83 ff 20 cmp edi, 0x20
0x100246d8 7d 2b jge 0x10024705
0x100246da bb 00 00 00 80 mov ebx, 0x80000000
0x100246df 8b cf mov ecx, edi
0x100246e1 d3 eb shr ebx, cl
0x100246e3 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100246e6 8d 7c 38 04 lea edi, [eax + edi + 4]
0x100246ea f7 d3 not ebx
0x100246ec 89 5d ec mov dword ptr [ebp - 0x14], ebx

0x100246fb 8b 5d 08 mov ebx, dword ptr [ebp + 8]
0x100246fe 8b 4d ec mov ecx, dword ptr [ebp - 0x14]
0x10024701 21 0b and dword ptr [ebx], ecx
0x10024703 eb 31 jmp 0x10024736
0x10024705 8d 4f e0 lea ecx, [edi - 0x20]
0x10024708 bb 00 00 00 80 mov ebx, 0x80000000
0x1002470d d3 eb shr ebx, cl
0x1002470f 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10024712 8d 7c 38 04 lea edi, [eax + edi + 4]
0x10024716 8d 8c 88 c4 00 00 00 lea ecx, [eax + ecx*4 + 0xc4]
0x1002471d f7 d3 not ebx
0x1002471f 21 19 and dword ptr [ecx], ebx

0x1002477d 7d 29 jge 0x100247a8
0x1002477f fe c1 inc cl
0x10024781 80 7d 0b 00 cmp byte ptr [ebp + 0xb], 0
0x10024785 88 4c 06 04 mov byte ptr [esi + eax + 4], cl
0x10024789 75 0b jne 0x10024796
0x1002478b bf 00 00 00 80 mov edi, 0x80000000
0x10024790 8b ce mov ecx, esi
0x10024792 d3 ef shr edi, cl
0x10024794 09 3b or dword ptr [ebx], edi
0x10024796 bf 00 00 00 80 mov edi, 0x80000000
0x1002479b 8b ce mov ecx, esi
0x1002479d d3 ef shr edi, cl

0x10024789 75 0b jne 0x10024796
0x1002478b bf 00 00 00 80 mov edi, 0x80000000
0x10024790 8b ce mov ecx, esi
0x10024792 d3 ef shr edi, cl
0x10024794 09 3b or dword ptr [ebx], edi
0x10024796 bf 00 00 00 80 mov edi, 0x80000000
0x1002479b 8b ce mov ecx, esi
0x1002479d d3 ef shr edi, cl
0x1002479f 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100247a2 09 7c 88 44 or dword ptr [eax + ecx*4 + 0x44], edi
0x100247a6 eb 2f jmp 0x100247d7
0x100247a8 fe c1 inc cl

0x100247a8 fe c1 inc cl
0x100247aa 80 7d 0b 00 cmp byte ptr [ebp + 0xb], 0
0x100247ae 88 4c 06 04 mov byte ptr [esi + eax + 4], cl
0x100247b2 75 0d jne 0x100247c1
0x100247b4 8d 4e e0 lea ecx, [esi - 0x20]
0x100247b7 bf 00 00 00 80 mov edi, 0x80000000
0x100247bc d3 ef shr edi, cl
0x100247be 09 7b 04 or dword ptr [ebx + 4], edi
0x100247c1 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100247c4 8d bc 88 c4 00 00 00 lea edi, [eax + ecx*4 + 0xc4]
0x100247cb 8d 4e e0 lea ecx, [esi - 0x20]
0x100247ce be 00 00 00 80 mov esi, 0x80000000

0x100247bc d3 ef shr edi, cl
0x100247be 09 7b 04 or dword ptr [ebx + 4], edi
0x100247c1 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100247c4 8d bc 88 c4 00 00 00 lea edi, [eax + ecx*4 + 0xc4]
0x100247cb 8d 4e e0 lea ecx, [esi - 0x20]
0x100247ce be 00 00 00 80 mov esi, 0x80000000
0x100247d3 d3 ee shr esi, cl
0x100247d5 09 37 or dword ptr [edi], esi
0x100247d7 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x100247da 85 c9 test ecx, ecx
0x100247dc 74 0b je 0x100247e9
0x100247de 89 0a mov dword ptr [edx], ecx

0x100249b6 84 c0 test al, al
0x100249b8 8b 45 08 mov eax, dword ptr [ebp + 8]
0x100249bb 88 4e 43 mov byte ptr [esi + 0x43], cl
0x100249be 75 03 jne 0x100249c3
0x100249c0 09 78 04 or dword ptr [eax + 4], edi
0x100249c3 ba 00 00 00 80 mov edx, 0x80000000
0x100249c8 8b cb mov ecx, ebx
0x100249ca d3 ea shr edx, cl
0x100249cc f7 d2 not edx
0x100249ce 21 50 08 and dword ptr [eax + 8], edx
0x100249d1 8b c3 mov eax, ebx
0x100249d3 5f pop edi

0x10024a4f 8b 5f 04 mov ebx, dword ptr [edi + 4]
0x10024a52 3b 5f 08 cmp ebx, dword ptr [edi + 8]
0x10024a55 75 48 jne 0x10024a9f
0x10024a57 83 f9 20 cmp ecx, 0x20
0x10024a5a 73 1f jae 0x10024a7b
0x10024a5c bb 00 00 00 80 mov ebx, 0x80000000
0x10024a61 d3 eb shr ebx, cl
0x10024a63 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x10024a66 8d 4c 01 04 lea ecx, [ecx + eax + 4]
0x10024a6a f7 d3 not ebx
0x10024a6c 21 5c 90 44 and dword ptr [eax + edx*4 + 0x44], ebx
0x10024a70 fe 09 dec byte ptr [ecx]

0x10024a72 75 2b jne 0x10024a9f
0x10024a74 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024a77 21 19 and dword ptr [ecx], ebx
0x10024a79 eb 24 jmp 0x10024a9f
0x10024a7b 83 c1 e0 add ecx, -0x20
0x10024a7e bb 00 00 00 80 mov ebx, 0x80000000
0x10024a83 d3 eb shr ebx, cl
0x10024a85 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x10024a88 8d 4c 01 04 lea ecx, [ecx + eax + 4]
0x10024a8c f7 d3 not ebx
0x10024a8e 21 9c 90 c4 00 00 00 and dword ptr [eax + edx*4 + 0xc4], ebx
0x10024a95 fe 09 dec byte ptr [ecx]

0x10024b09 fe c1 inc cl
0x10024b0b 88 4c 07 04 mov byte ptr [edi + eax + 4], cl
0x10024b0f 73 21 jae 0x10024b32
0x10024b11 80 7d 13 00 cmp byte ptr [ebp + 0x13], 0
0x10024b15 75 0e jne 0x10024b25
0x10024b17 bb 00 00 00 80 mov ebx, 0x80000000
0x10024b1c 8b cf mov ecx, edi
0x10024b1e d3 eb shr ebx, cl
0x10024b20 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b23 09 19 or dword ptr [ecx], ebx
0x10024b25 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024b29 ba 00 00 00 80 mov edx, 0x80000000

0x10024b1c 8b cf mov ecx, edi
0x10024b1e d3 eb shr ebx, cl
0x10024b20 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b23 09 19 or dword ptr [ecx], ebx
0x10024b25 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024b29 ba 00 00 00 80 mov edx, 0x80000000
0x10024b2e 8b cf mov ecx, edi
0x10024b30 eb 25 jmp 0x10024b57
0x10024b32 80 7d 13 00 cmp byte ptr [ebp + 0x13], 0
0x10024b36 75 10 jne 0x10024b48
0x10024b38 8d 4f e0 lea ecx, [edi - 0x20]
0x10024b3b bb 00 00 00 80 mov ebx, 0x80000000

0x10024b2e 8b cf mov ecx, edi
0x10024b30 eb 25 jmp 0x10024b57
0x10024b32 80 7d 13 00 cmp byte ptr [ebp + 0x13], 0
0x10024b36 75 10 jne 0x10024b48
0x10024b38 8d 4f e0 lea ecx, [edi - 0x20]
0x10024b3b bb 00 00 00 80 mov ebx, 0x80000000
0x10024b40 d3 eb shr ebx, cl
0x10024b42 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b45 09 59 04 or dword ptr [ecx + 4], ebx
0x10024b48 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024b4f 8d 4f e0 lea ecx, [edi - 0x20]
0x10024b52 ba 00 00 00 80 mov edx, 0x80000000

0x10024b40 d3 eb shr ebx, cl
0x10024b42 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b45 09 59 04 or dword ptr [ecx + 4], ebx
0x10024b48 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024b4f 8d 4f e0 lea ecx, [edi - 0x20]
0x10024b52 ba 00 00 00 80 mov edx, 0x80000000
0x10024b57 d3 ea shr edx, cl
0x10024b59 09 10 or dword ptr [eax], edx
0x10024b5b 8b 55 0c mov edx, dword ptr [ebp + 0xc]
0x10024b5e 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10024b61 8d 44 32 fc lea eax, [edx + esi - 4]
0x10024b65 89 08 mov dword ptr [eax], ecx

0x10024bca 8b 4f 04 mov ecx, dword ptr [edi + 4]
0x10024bcd 3b 4f 08 cmp ecx, dword ptr [edi + 8]
0x10024bd0 75 47 jne 0x10024c19
0x10024bd2 83 fe 20 cmp esi, 0x20
0x10024bd5 73 1e jae 0x10024bf5
0x10024bd7 bb 00 00 00 80 mov ebx, 0x80000000
0x10024bdc 8b ce mov ecx, esi
0x10024bde d3 eb shr ebx, cl
0x10024be0 8d 74 06 04 lea esi, [esi + eax + 4]
0x10024be4 f7 d3 not ebx
0x10024be6 21 5c 90 44 and dword ptr [eax + edx*4 + 0x44], ebx
0x10024bea fe 0e dec byte ptr [esi]

0x10024bec 75 28 jne 0x10024c16
0x10024bee 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024bf1 21 19 and dword ptr [ecx], ebx
0x10024bf3 eb 21 jmp 0x10024c16
0x10024bf5 8d 4e e0 lea ecx, [esi - 0x20]
0x10024bf8 bb 00 00 00 80 mov ebx, 0x80000000
0x10024bfd d3 eb shr ebx, cl
0x10024bff 8d 4c 06 04 lea ecx, [esi + eax + 4]
0x10024c03 f7 d3 not ebx
0x10024c05 21 9c 90 c4 00 00 00 and dword ptr [eax + edx*4 + 0xc4], ebx
0x10024c0c fe 09 dec byte ptr [ecx]
0x10024c0e 75 06 jne 0x10024c16

0x10024c6b fe c1 inc cl
0x10024c6d 88 4c 06 04 mov byte ptr [esi + eax + 4], cl
0x10024c71 73 21 jae 0x10024c94
0x10024c73 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x10024c77 75 0e jne 0x10024c87
0x10024c79 bf 00 00 00 80 mov edi, 0x80000000
0x10024c7e 8b ce mov ecx, esi
0x10024c80 d3 ef shr edi, cl
0x10024c82 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024c85 09 39 or dword ptr [ecx], edi
0x10024c87 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024c8b ba 00 00 00 80 mov edx, 0x80000000

0x10024c7e 8b ce mov ecx, esi
0x10024c80 d3 ef shr edi, cl
0x10024c82 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024c85 09 39 or dword ptr [ecx], edi
0x10024c87 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024c8b ba 00 00 00 80 mov edx, 0x80000000
0x10024c90 8b ce mov ecx, esi
0x10024c92 eb 25 jmp 0x10024cb9
0x10024c94 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x10024c98 75 10 jne 0x10024caa
0x10024c9a 8d 4e e0 lea ecx, [esi - 0x20]
0x10024c9d bf 00 00 00 80 mov edi, 0x80000000

0x10024c90 8b ce mov ecx, esi
0x10024c92 eb 25 jmp 0x10024cb9
0x10024c94 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x10024c98 75 10 jne 0x10024caa
0x10024c9a 8d 4e e0 lea ecx, [esi - 0x20]
0x10024c9d bf 00 00 00 80 mov edi, 0x80000000
0x10024ca2 d3 ef shr edi, cl
0x10024ca4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024ca7 09 79 04 or dword ptr [ecx + 4], edi
0x10024caa 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024cb1 8d 4e e0 lea ecx, [esi - 0x20]
0x10024cb4 ba 00 00 00 80 mov edx, 0x80000000

0x10024ca2 d3 ef shr edi, cl
0x10024ca4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024ca7 09 79 04 or dword ptr [ecx + 4], edi
0x10024caa 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024cb1 8d 4e e0 lea ecx, [esi - 0x20]
0x10024cb4 ba 00 00 00 80 mov edx, 0x80000000
0x10024cb9 d3 ea shr edx, cl
0x10024cbb 09 10 or dword ptr [eax], edx
0x10024cbd 8b 45 10 mov eax, dword ptr [ebp + 0x10]
0x10024cc0 89 03 mov dword ptr [ebx], eax
0x10024cc2 89 44 18 fc mov dword ptr [eax + ebx - 4], eax
0x10024cc6 6a 01 push 1

0x10024cec 68 00 80 00 00 push 0x8000
0x10024cf1 51 push ecx
0x10024cf2 ff 15 f4 d0 02 10 call dword ptr [0x1002d0f4]
0x10024cf8 8b 0d 48 a2 03 10 mov ecx, dword ptr [0x1003a248]
0x10024cfe a1 54 a2 03 10 mov eax, dword ptr [0x1003a254]
0x10024d03 ba 00 00 00 80 mov edx, 0x80000000
0x10024d08 d3 ea shr edx, cl
0x10024d0a 09 50 08 or dword ptr [eax + 8], edx
0x10024d0d a1 54 a2 03 10 mov eax, dword ptr [0x1003a254]
0x10024d12 8b 0d 48 a2 03 10 mov ecx, dword ptr [0x1003a248]
0x10024d18 8b 40 10 mov eax, dword ptr [eax + 0x10]
0x10024d1b 83 a4 88 c4 00 00 00 00 and dword ptr [eax + ecx*4 + 0xc4], 0

0x10024f41 3b 0b cmp ecx, dword ptr [ebx]
0x10024f43 74 7e je 0x10024fc3
0x10024f45 8b 4d f4 mov ecx, dword ptr [ebp - 0xc]
0x10024f48 3b c1 cmp eax, ecx
0x10024f4a 0f 82 69 01 00 00 jb 0x100250b9
0x10024f50 81 c1 00 80 00 00 add ecx, 0x8000
0x10024f56 3b c1 cmp eax, ecx
0x10024f58 0f 83 5b 01 00 00 jae 0x100250b9
0x10024f5e 8b c8 mov ecx, eax
0x10024f60 66 81 e1 00 f0 and cx, 0xf000
0x10024f65 83 c1 0c add ecx, 0xc
0x10024f68 8d 91 f0 0f 00 00 lea edx, [ecx + 0xff0]

0x10024fc3 83 7d f0 00 cmp dword ptr [ebp - 0x10], 0
0x10024fc7 74 27 je 0x10024ff0
0x10024fc9 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x10024fcc 83 f9 20 cmp ecx, 0x20
0x10024fcf 7d 0f jge 0x10024fe0
0x10024fd1 b8 00 00 00 80 mov eax, 0x80000000
0x10024fd6 d3 e8 shr eax, cl
0x10024fd8 09 45 dc or dword ptr [ebp - 0x24], eax
0x10024fdb 09 45 d4 or dword ptr [ebp - 0x2c], eax
0x10024fde eb 10 jmp 0x10024ff0
0x10024fe0 83 c1 e0 add ecx, -0x20
0x10024fe3 b8 00 00 00 80 mov eax, 0x80000000

0x10024fd6 d3 e8 shr eax, cl
0x10024fd8 09 45 dc or dword ptr [ebp - 0x24], eax
0x10024fdb 09 45 d4 or dword ptr [ebp - 0x2c], eax
0x10024fde eb 10 jmp 0x10024ff0
0x10024fe0 83 c1 e0 add ecx, -0x20
0x10024fe3 b8 00 00 00 80 mov eax, 0x80000000
0x10024fe8 d3 e8 shr eax, cl
0x10024fea 09 45 e4 or dword ptr [ebp - 0x1c], eax
0x10024fed 09 45 e8 or dword ptr [ebp - 0x18], eax
0x10024ff0 39 72 04 cmp dword ptr [edx + 4], esi
0x10024ff3 0f 85 c8 00 00 00 jne 0x100250c1
0x10024ff9 8b 4d fc mov ecx, dword ptr [ebp - 4]

0x1002502b 3b 46 80 cmp eax, dword ptr [esi - 0x80]
0x1002502e 0f 85 91 00 00 00 jne 0x100250c5
0x10025034 8b 45 e4 mov eax, dword ptr [ebp - 0x1c]
0x10025037 3b 06 cmp eax, dword ptr [esi]
0x10025039 0f 85 86 00 00 00 jne 0x100250c5
0x1002503f 81 45 f4 00 80 00 00 add dword ptr [ebp - 0xc], 0x8000
0x10025046 81 45 d8 04 02 00 00 add dword ptr [ebp - 0x28], 0x204
0x1002504d d1 65 ec shl dword ptr [ebp - 0x14], 1
0x10025050 ff 45 d0 inc dword ptr [ebp - 0x30]
0x10025053 83 c6 04 add esi, 4
0x10025056 83 7d d0 20 cmp dword ptr [ebp - 0x30], 0x20
0x1002505a 89 75 c4 mov dword ptr [ebp - 0x3c], esi

0x10025e1a f6 c3 20 test bl, 0x20
0x10025e1d 74 02 je 0x10025e21
0x10025e1f 0c 01 or al, 1
0x10025e21 f6 c3 02 test bl, 2
0x10025e24 74 05 je 0x10025e2b
0x10025e26 0d 00 00 08 00 or eax, 0x80000
0x10025e2b 0f b7 cb movzx ecx, bx
0x10025e2e 56 push esi
0x10025e2f 8b d1 mov edx, ecx
0x10025e31 be 00 0c 00 00 mov esi, 0xc00
0x10025e36 bf 00 03 00 00 mov edi, 0x300
0x10025e3b 23 d6 and edx, esi

0x10025f32 f6 c1 20 test cl, 0x20
0x10025f35 74 02 je 0x10025f39
0x10025f37 0c 01 or al, 1
0x10025f39 f6 c1 02 test cl, 2
0x10025f3c 74 05 je 0x10025f43
0x10025f3e 0d 00 00 08 00 or eax, 0x80000
0x10025f43 c3 ret 
0x10025f44 8b 44 24 08 mov eax, dword ptr [esp + 8]
0x10025f48 56 push esi
0x10025f49 6a 20 push 0x20
0x10025f4b 99 cdq 
0x10025f4c 59 pop ecx

0x10026272 8b 7f 10 mov edi, dword ptr [edi + 0x10]
0x10026275 d3 e6 shl esi, cl
0x10026277 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1002627a f7 d9 neg ecx
0x1002627c 1b c9 sbb ecx, ecx
0x1002627e 81 e1 00 00 00 80 and ecx, 0x80000000
0x10026284 0b f1 or esi, ecx
0x10026286 0b 75 f4 or esi, dword ptr [ebp - 0xc]
0x10026289 83 ff 40 cmp edi, 0x40
0x1002628c 75 0d jne 0x1002629b
0x1002628e 8b 4d 0c mov ecx, dword ptr [ebp + 0xc]
0x10026291 8b 55 f8 mov edx, dword ptr [ebp - 8]

0x10026314 e8 ca fc ff ff call 0x10025fe3
0x10026319 59 pop ecx
0x1002631a 85 c0 test eax, eax
0x1002631c 59 pop ecx
0x1002631d 74 08 je 0x10026327
0x1002631f b9 00 00 00 80 mov ecx, 0x80000000
0x10026324 46 inc esi
0x10026325 eb 03 jmp 0x1002632a
0x10026327 8b 4d f0 mov ecx, dword ptr [ebp - 0x10]
0x1002632a 66 81 fe ff 7f cmp si, 0x7fff
0x1002632f 75 07 jne 0x10026338
0x10026331 c7 45 fc 01 00 00 00 mov dword ptr [ebp - 4], 1

0x100264c8 23 cf and ecx, edi
0x100264ca 89 45 0c mov dword ptr [ebp + 0xc], eax
0x100264cd 8b 42 04 mov eax, dword ptr [edx + 4]
0x100264d0 8b 12 mov edx, dword ptr [edx]
0x100264d2 0f b7 d9 movzx ebx, cx
0x100264d5 be 00 00 00 80 mov esi, 0x80000000
0x100264da 25 ff ff 0f 00 and eax, 0xfffff
0x100264df 85 db test ebx, ebx
0x100264e1 89 75 fc mov dword ptr [ebp - 4], esi
0x100264e4 74 13 je 0x100264f9
0x100264e6 3b df cmp ebx, edi
0x100264e8 74 08 je 0x100264f2

0x10028bca 75 1b jne 0x10028be7
0x10028bcc a8 01 test al, 1
0x10028bce 75 3e jne 0x10028c0e
0x10028bd0 83 e0 02 and eax, 2
0x10028bd3 74 09 je 0x10028bde
0x10028bd5 81 7d f8 00 00 00 80 cmp dword ptr [ebp - 8], 0x80000000
0x10028bdc 77 09 ja 0x10028be7
0x10028bde 85 c0 test eax, eax
0x10028be0 75 2c jne 0x10028c0e
0x10028be2 39 75 f8 cmp dword ptr [ebp - 8], esi
0x10028be5 76 27 jbe 0x10028c0e
0x10028be7 e8 34 f6 fe ff call 0x10018220

0x100296c7 8b 55 10 mov edx, dword ptr [ebp + 0x10]
0x100296ca 83 7d d4 00 cmp dword ptr [ebp - 0x2c], 0
0x100296ce 74 60 je 0x10029730
0x100296d0 33 db xor ebx, ebx
0x100296d2 b8 ff 7f 00 00 mov eax, 0x7fff
0x100296d7 be 00 00 00 80 mov esi, 0x80000000
0x100296dc 33 d2 xor edx, edx
0x100296de c7 45 ec 02 00 00 00 mov dword ptr [ebp - 0x14], 2
0x100296e5 eb 5e jmp 0x10029745
0x100296e7 3d b0 eb ff ff cmp eax, 0xffffebb0
0x100296ec 7d 09 jge 0x100296f7
0x100296ee c7 45 d0 01 00 00 00 mov dword ptr [ebp - 0x30], 1

0x1002984b c6 43 03 01 mov byte ptr [ebx + 3], 1
0x1002984f c6 43 04 30 mov byte ptr [ebx + 4], 0x30
0x10029853 e9 fe 01 00 00 jmp 0x10029a56
0x10029858 66 3b d6 cmp dx, si
0x1002985b 75 7a jne 0x100298d7
0x1002985d b8 00 00 00 80 mov eax, 0x80000000
0x10029862 66 c7 03 01 00 mov word ptr [ebx], 1
0x10029867 3b f8 cmp edi, eax
0x10029869 75 06 jne 0x10029871
0x1002986b 83 7d 08 00 cmp dword ptr [ebp + 8], 0
0x1002986f 74 0f je 0x10029880
0x10029871 f7 c7 00 00 00 40 test edi, 0x40000000

0x1002b4c0 66 89 46 0a mov word ptr [esi + 0xa], ax
0x1002b4c4 eb 1b jmp 0x1002b4e1
0x1002b4c6 66 f7 df neg di
0x1002b4c9 1b ff sbb edi, edi
0x1002b4cb 83 66 04 00 and dword ptr [esi + 4], 0
0x1002b4cf 81 e7 00 00 00 80 and edi, 0x80000000
0x1002b4d5 81 c7 00 80 ff 7f add edi, 0x7fff8000
0x1002b4db 83 26 00 and dword ptr [esi], 0
0x1002b4de 89 7e 08 mov dword ptr [esi + 8], edi
0x1002b4e1 5f pop edi
0x1002b4e2 5e pop esi
0x1002b4e3 5b pop ebx

FILE /root/PL/PCU_old/H/mmc2/MCVar.dll
0x10001a87 1b ff sbb edi, edi
0x10001a89 53 push ebx
0x10001a8a 81 e7 00 00 00 40 and edi, 0x40000000
0x10001a90 53 push ebx
0x10001a91 53 push ebx
0x10001a92 81 c7 00 00 00 08 add edi, 0x8000000
0x10001a98 53 push ebx
0x10001a99 57 push edi
0x10001a9a ff 75 08 push dword ptr [ebp + 8]
0x10001a9d 68 d0 01 03 10 push 0x100301d0
0x10001aa2 53 push ebx
0x10001aa3 ff 15 60 c2 02 10 call dword ptr [0x1002c260]

0x10002025 8b f0 mov esi, eax
0x10002027 83 c4 14 add esp, 0x14
0x1000202a 85 f6 test esi, esi
0x1000202c 74 1f je 0x1000204d
0x1000202e 8d 85 00 ff ff ff lea eax, [ebp - 0x100]
0x10002034 81 cf 00 00 07 80 or edi, 0x80070000
0x1000203a 50 push eax
0x1000203b 8d 4e 04 lea ecx, [esi + 4]
0x1000203e 89 3e mov dword ptr [esi], edi
0x10002040 e8 30 fd ff ff call 0x10001d75
0x10002045 83 66 08 00 and dword ptr [esi + 8], 0
0x10002049 8b c6 mov eax, esi

0x10002d67 89 03 mov dword ptr [ebx], eax
0x10002d69 89 4d fc mov dword ptr [ebp - 4], ecx
0x10002d6c 8b 48 08 mov ecx, dword ptr [eax + 8]
0x10002d6f 83 c3 04 add ebx, 4
0x10002d72 03 f1 add esi, ecx
0x10002d74 81 c9 00 00 00 80 or ecx, 0x80000000
0x10002d7a 89 70 04 mov dword ptr [eax + 4], esi
0x10002d7d 89 48 08 mov dword ptr [eax + 8], ecx
0x10002d80 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10002d83 81 f9 00 01 00 00 cmp ecx, 0x100
0x10002d89 7c ca jl 0x10002d55
0x10002d8b 8b c1 mov eax, ecx

0x10002db6 75 f5 jne 0x10002dad
0x10002db8 33 c0 xor eax, eax
0x10002dba 85 c0 test eax, eax
0x10002dbc 74 56 je 0x10002e14
0x10002dbe 8b 32 mov esi, dword ptr [edx]
0x10002dc0 bb 00 00 00 80 mov ebx, 0x80000000
0x10002dc5 85 5e 08 test dword ptr [esi + 8], ebx
0x10002dc8 74 4a je 0x10002e14
0x10002dca ff 76 0c push dword ptr [esi + 0xc]
0x10002dcd 8d 45 f4 lea eax, [ebp - 0xc]
0x10002dd0 56 push esi
0x10002dd1 57 push edi

0x1000a662 7f 04 jg 0x1000a668
0x1000a664 33 c0 xor eax, eax
0x1000a666 eb 1d jmp 0x1000a685
0x1000a668 3b c7 cmp eax, edi
0x1000a66a 7d 07 jge 0x1000a673
0x1000a66c b8 00 00 00 80 mov eax, 0x80000000
0x1000a671 eb 12 jmp 0x1000a685
0x1000a673 8b 0e mov ecx, dword ptr [esi]
0x1000a675 ff 74 24 0c push dword ptr [esp + 0xc]
0x1000a679 2b cf sub ecx, edi
0x1000a67b 03 c8 add ecx, eax
0x1000a67d 51 push ecx

0x1000adf5 1b c9 sbb ecx, ecx
0x1000adf7 57 push edi
0x1000adf8 66 81 e1 00 f8 and cx, 0xf800
0x1000adfd 53 push ebx
0x1000adfe ff 75 30 push dword ptr [ebp + 0x30]
0x1000ae01 81 c1 00 08 00 00 add ecx, 0x800
0x1000ae07 0b c1 or eax, ecx
0x1000ae09 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x1000ae0c 0d 3b 00 02 08 or eax, 0x802003b
0x1000ae11 50 push eax
0x1000ae12 8d 45 08 lea eax, [ebp + 8]
0x1000ae15 ff 75 34 push dword ptr [ebp + 0x34]

0x1000c076 f7 d9 neg ecx
0x1000c078 1b c9 sbb ecx, ecx
0x1000c07a 56 push esi
0x1000c07b 66 81 e1 00 f8 and cx, 0xf800
0x1000c080 56 push esi
0x1000c081 81 c1 00 08 00 00 add ecx, 0x800
0x1000c087 56 push esi
0x1000c088 0b c1 or eax, ecx
0x1000c08a 56 push esi
0x1000c08b 0d 20 01 04 08 or eax, 0x8040120
0x1000c090 8b cf mov ecx, edi
0x1000c092 50 push eax

0x1000c398 f7 d9 neg ecx
0x1000c39a 1b c9 sbb ecx, ecx
0x1000c39c 56 push esi
0x1000c39d 66 81 e1 00 f8 and cx, 0xf800
0x1000c3a2 56 push esi
0x1000c3a3 81 c1 00 08 00 00 add ecx, 0x800
0x1000c3a9 56 push esi
0x1000c3aa 0b c1 or eax, ecx
0x1000c3ac 56 push esi
0x1000c3ad 0d 3f 04 0a 08 or eax, 0x80a043f
0x1000c3b2 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1000c3b5 50 push eax

0x1000f2ef f7 d9 neg ecx
0x1000f2f1 1b c9 sbb ecx, ecx
0x1000f2f3 56 push esi
0x1000f2f4 66 81 e1 00 f8 and cx, 0xf800
0x1000f2f9 56 push esi
0x1000f2fa 81 c1 00 08 00 00 add ecx, 0x800
0x1000f300 56 push esi
0x1000f301 0b c1 or eax, ecx
0x1000f303 56 push esi
0x1000f304 0d 24 05 0c 08 or eax, 0x80c0524
0x1000f309 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1000f30c 50 push eax

0x1000fa95 1b d2 sbb edx, edx
0x1000fa97 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1000fa9a 66 81 e2 00 f8 and dx, 0xf800
0x1000fa9f 56 push esi
0x1000faa0 8d 75 1c lea esi, [ebp + 0x1c]
0x1000faa3 81 c2 00 08 00 00 add edx, 0x800
0x1000faa9 56 push esi
0x1000faaa 0b c2 or eax, edx
0x1000faac 8d 75 0c lea esi, [ebp + 0xc]
0x1000faaf 0d 3f 04 08 0f or eax, 0xf08043f
0x1000fab4 56 push esi
0x1000fab5 50 push eax

0x10010b63 f7 d8 neg eax
0x10010b65 1b c0 sbb eax, eax
0x10010b67 8d 55 30 lea edx, [ebp + 0x30]
0x10010b6a 66 25 00 f8 and ax, 0xf800
0x10010b6e 56 push esi
0x10010b6f 05 00 08 00 00 add eax, 0x800
0x10010b74 52 push edx
0x10010b75 f7 d9 neg ecx
0x10010b77 8d 55 20 lea edx, [ebp + 0x20]
0x10010b7a 1b c9 sbb ecx, ecx
0x10010b7c 52 push edx
0x10010b7d 66 81 e1 00 fe and cx, 0xfe00

0x100111f2 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100111f5 8b f8 mov edi, eax
0x100111f7 f7 df neg edi
0x100111f9 1b ff sbb edi, edi
0x100111fb 66 81 e7 00 f8 and di, 0xf800
0x10011200 81 c7 00 08 00 00 add edi, 0x800
0x10011206 e8 a4 00 00 00 call 0x100112af
0x1001120b f7 d8 neg eax
0x1001120d 1b c0 sbb eax, eax
0x1001120f 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10011212 25 00 fe cf ff and eax, 0xffcffe00
0x10011217 05 00 02 30 00 add eax, 0x300200

0x10011d64 84 c9 test cl, cl
0x10011d66 76 0f jbe 0x10011d77
0x10011d68 80 f9 0c cmp cl, 0xc
0x10011d6b 73 0a jae 0x10011d77
0x10011d6d 25 ff ff 00 ff and eax, 0xff00ffff
0x10011d72 0d 00 00 00 80 or eax, 0x80000000
0x10011d77 c3 ret 
0x10011d78 d9 81 8c 00 00 00 fld dword ptr [ecx + 0x8c]
0x10011d7e c3 ret 
0x10011d7f 55 push ebp
0x10011d80 8b ec mov ebp, esp
0x10011d82 81 ec 30 01 00 00 sub esp, 0x130

0x1002185a 75 1c jne 0x10021878
0x1002185c 25 00 01 01 81 and eax, 0x81010100
0x10021861 74 d3 je 0x10021836
0x10021863 25 00 01 01 01 and eax, 0x1010100
0x10021868 75 08 jne 0x10021872
0x1002186a 81 e6 00 00 00 80 and esi, 0x80000000
0x10021870 75 c4 jne 0x10021836
0x10021872 5e pop esi
0x10021873 5f pop edi
0x10021874 5b pop ebx
0x10021875 33 c0 xor eax, eax
0x10021877 c3 ret 

0x1002414e 8b 4b 04 mov ecx, dword ptr [ebx + 4]
0x10024151 3b 4b 08 cmp ecx, dword ptr [ebx + 8]
0x10024154 75 4c jne 0x100241a2
0x10024156 83 fa 20 cmp edx, 0x20
0x10024159 73 1e jae 0x10024179
0x1002415b bb 00 00 00 80 mov ebx, 0x80000000
0x10024160 8b ca mov ecx, edx
0x10024162 d3 eb shr ebx, cl
0x10024164 8d 4c 02 04 lea ecx, [edx + eax + 4]
0x10024168 f7 d3 not ebx
0x1002416a 21 5c b8 44 and dword ptr [eax + edi*4 + 0x44], ebx
0x1002416e fe 09 dec byte ptr [ecx]

0x10024170 75 28 jne 0x1002419a
0x10024172 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024175 21 19 and dword ptr [ecx], ebx
0x10024177 eb 21 jmp 0x1002419a
0x10024179 8d 4a e0 lea ecx, [edx - 0x20]
0x1002417c bb 00 00 00 80 mov ebx, 0x80000000
0x10024181 d3 eb shr ebx, cl
0x10024183 8d 4c 02 04 lea ecx, [edx + eax + 4]
0x10024187 f7 d3 not ebx
0x10024189 21 9c b8 c4 00 00 00 and dword ptr [eax + edi*4 + 0xc4], ebx
0x10024190 fe 09 dec byte ptr [ecx]
0x10024192 75 06 jne 0x1002419a

0x1002420c 8b 71 04 mov esi, dword ptr [ecx + 4]
0x1002420f 3b 71 08 cmp esi, dword ptr [ecx + 8]
0x10024212 75 40 jne 0x10024254
0x10024214 83 fb 20 cmp ebx, 0x20
0x10024217 73 1c jae 0x10024235
0x10024219 be 00 00 00 80 mov esi, 0x80000000
0x1002421e 8b cb mov ecx, ebx
0x10024220 d3 ee shr esi, cl
0x10024222 f7 d6 not esi
0x10024224 21 74 b8 44 and dword ptr [eax + edi*4 + 0x44], esi
0x10024228 fe 4c 03 04 dec byte ptr [ebx + eax + 4]
0x1002422c 75 26 jne 0x10024254

0x1002422c 75 26 jne 0x10024254
0x1002422e 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024231 21 31 and dword ptr [ecx], esi
0x10024233 eb 1f jmp 0x10024254
0x10024235 8d 4b e0 lea ecx, [ebx - 0x20]
0x10024238 be 00 00 00 80 mov esi, 0x80000000
0x1002423d d3 ee shr esi, cl
0x1002423f f7 d6 not esi
0x10024241 21 b4 b8 c4 00 00 00 and dword ptr [eax + edi*4 + 0xc4], esi
0x10024248 fe 4c 03 04 dec byte ptr [ebx + eax + 4]
0x1002424c 75 06 jne 0x10024254
0x1002424e 8b 4d 08 mov ecx, dword ptr [ebp + 8]

0x100242ad fe c1 inc cl
0x100242af 88 4c 02 04 mov byte ptr [edx + eax + 4], cl
0x100242b3 73 25 jae 0x100242da
0x100242b5 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x100242b9 75 0e jne 0x100242c9
0x100242bb bb 00 00 00 80 mov ebx, 0x80000000
0x100242c0 8b ca mov ecx, edx
0x100242c2 d3 eb shr ebx, cl
0x100242c4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100242c7 09 19 or dword ptr [ecx], ebx
0x100242c9 bb 00 00 00 80 mov ebx, 0x80000000
0x100242ce 8b ca mov ecx, edx

0x100242bb bb 00 00 00 80 mov ebx, 0x80000000
0x100242c0 8b ca mov ecx, edx
0x100242c2 d3 eb shr ebx, cl
0x100242c4 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100242c7 09 19 or dword ptr [ecx], ebx
0x100242c9 bb 00 00 00 80 mov ebx, 0x80000000
0x100242ce 8b ca mov ecx, edx
0x100242d0 d3 eb shr ebx, cl
0x100242d2 8d 44 b8 44 lea eax, [eax + edi*4 + 0x44]
0x100242d6 09 18 or dword ptr [eax], ebx
0x100242d8 eb 29 jmp 0x10024303
0x100242da 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0

0x100242d6 09 18 or dword ptr [eax], ebx
0x100242d8 eb 29 jmp 0x10024303
0x100242da 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x100242de 75 10 jne 0x100242f0
0x100242e0 8d 4a e0 lea ecx, [edx - 0x20]
0x100242e3 bb 00 00 00 80 mov ebx, 0x80000000
0x100242e8 d3 eb shr ebx, cl
0x100242ea 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100242ed 09 59 04 or dword ptr [ecx + 4], ebx
0x100242f0 8d 4a e0 lea ecx, [edx - 0x20]
0x100242f3 ba 00 00 00 80 mov edx, 0x80000000
0x100242f8 d3 ea shr edx, cl

0x100242e3 bb 00 00 00 80 mov ebx, 0x80000000
0x100242e8 d3 eb shr ebx, cl
0x100242ea 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x100242ed 09 59 04 or dword ptr [ecx + 4], ebx
0x100242f0 8d 4a e0 lea ecx, [edx - 0x20]
0x100242f3 ba 00 00 00 80 mov edx, 0x80000000
0x100242f8 d3 ea shr edx, cl
0x100242fa 8d 84 b8 c4 00 00 00 lea eax, [eax + edi*4 + 0xc4]
0x10024301 09 10 or dword ptr [eax], edx
0x10024303 8b 45 fc mov eax, dword ptr [ebp - 4]
0x10024306 89 06 mov dword ptr [esi], eax
0x10024308 89 44 30 fc mov dword ptr [eax + esi - 4], eax

0x10024340 53 push ebx
0x10024341 51 push ecx
0x10024342 ff d6 call esi
0x10024344 8b 0d e8 91 03 10 mov ecx, dword ptr [0x100391e8]
0x1002434a a1 f4 91 03 10 mov eax, dword ptr [0x100391f4]
0x1002434f ba 00 00 00 80 mov edx, 0x80000000
0x10024354 d3 ea shr edx, cl
0x10024356 09 50 08 or dword ptr [eax + 8], edx
0x10024359 a1 f4 91 03 10 mov eax, dword ptr [0x100391f4]
0x1002435e 8b 0d e8 91 03 10 mov ecx, dword ptr [0x100391e8]
0x10024364 8b 40 10 mov eax, dword ptr [eax + 0x10]
0x10024367 83 a4 88 c4 00 00 00 00 and dword ptr [eax + ecx*4 + 0xc4], 0

0x100245bd 8b 4a 04 mov ecx, dword ptr [edx + 4]
0x100245c0 3b 4a 08 cmp ecx, dword ptr [edx + 8]
0x100245c3 75 61 jne 0x10024626
0x100245c5 83 ff 20 cmp edi, 0x20
0x100245c8 7d 2b jge 0x100245f5
0x100245ca bb 00 00 00 80 mov ebx, 0x80000000
0x100245cf 8b cf mov ecx, edi
0x100245d1 d3 eb shr ebx, cl
0x100245d3 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100245d6 8d 7c 38 04 lea edi, [eax + edi + 4]
0x100245da f7 d3 not ebx
0x100245dc 89 5d ec mov dword ptr [ebp - 0x14], ebx

0x100245eb 8b 5d 08 mov ebx, dword ptr [ebp + 8]
0x100245ee 8b 4d ec mov ecx, dword ptr [ebp - 0x14]
0x100245f1 21 0b and dword ptr [ebx], ecx
0x100245f3 eb 31 jmp 0x10024626
0x100245f5 8d 4f e0 lea ecx, [edi - 0x20]
0x100245f8 bb 00 00 00 80 mov ebx, 0x80000000
0x100245fd d3 eb shr ebx, cl
0x100245ff 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10024602 8d 7c 38 04 lea edi, [eax + edi + 4]
0x10024606 8d 8c 88 c4 00 00 00 lea ecx, [eax + ecx*4 + 0xc4]
0x1002460d f7 d3 not ebx
0x1002460f 21 19 and dword ptr [ecx], ebx

0x1002466d 7d 29 jge 0x10024698
0x1002466f fe c1 inc cl
0x10024671 80 7d 0b 00 cmp byte ptr [ebp + 0xb], 0
0x10024675 88 4c 06 04 mov byte ptr [esi + eax + 4], cl
0x10024679 75 0b jne 0x10024686
0x1002467b bf 00 00 00 80 mov edi, 0x80000000
0x10024680 8b ce mov ecx, esi
0x10024682 d3 ef shr edi, cl
0x10024684 09 3b or dword ptr [ebx], edi
0x10024686 bf 00 00 00 80 mov edi, 0x80000000
0x1002468b 8b ce mov ecx, esi
0x1002468d d3 ef shr edi, cl

0x10024679 75 0b jne 0x10024686
0x1002467b bf 00 00 00 80 mov edi, 0x80000000
0x10024680 8b ce mov ecx, esi
0x10024682 d3 ef shr edi, cl
0x10024684 09 3b or dword ptr [ebx], edi
0x10024686 bf 00 00 00 80 mov edi, 0x80000000
0x1002468b 8b ce mov ecx, esi
0x1002468d d3 ef shr edi, cl
0x1002468f 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10024692 09 7c 88 44 or dword ptr [eax + ecx*4 + 0x44], edi
0x10024696 eb 2f jmp 0x100246c7
0x10024698 fe c1 inc cl

0x10024698 fe c1 inc cl
0x1002469a 80 7d 0b 00 cmp byte ptr [ebp + 0xb], 0
0x1002469e 88 4c 06 04 mov byte ptr [esi + eax + 4], cl
0x100246a2 75 0d jne 0x100246b1
0x100246a4 8d 4e e0 lea ecx, [esi - 0x20]
0x100246a7 bf 00 00 00 80 mov edi, 0x80000000
0x100246ac d3 ef shr edi, cl
0x100246ae 09 7b 04 or dword ptr [ebx + 4], edi
0x100246b1 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100246b4 8d bc 88 c4 00 00 00 lea edi, [eax + ecx*4 + 0xc4]
0x100246bb 8d 4e e0 lea ecx, [esi - 0x20]
0x100246be be 00 00 00 80 mov esi, 0x80000000

0x100246ac d3 ef shr edi, cl
0x100246ae 09 7b 04 or dword ptr [ebx + 4], edi
0x100246b1 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x100246b4 8d bc 88 c4 00 00 00 lea edi, [eax + ecx*4 + 0xc4]
0x100246bb 8d 4e e0 lea ecx, [esi - 0x20]
0x100246be be 00 00 00 80 mov esi, 0x80000000
0x100246c3 d3 ee shr esi, cl
0x100246c5 09 37 or dword ptr [edi], esi
0x100246c7 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x100246ca 85 c9 test ecx, ecx
0x100246cc 74 0b je 0x100246d9
0x100246ce 89 0a mov dword ptr [edx], ecx

0x100248a6 84 c0 test al, al
0x100248a8 8b 45 08 mov eax, dword ptr [ebp + 8]
0x100248ab 88 4e 43 mov byte ptr [esi + 0x43], cl
0x100248ae 75 03 jne 0x100248b3
0x100248b0 09 78 04 or dword ptr [eax + 4], edi
0x100248b3 ba 00 00 00 80 mov edx, 0x80000000
0x100248b8 8b cb mov ecx, ebx
0x100248ba d3 ea shr edx, cl
0x100248bc f7 d2 not edx
0x100248be 21 50 08 and dword ptr [eax + 8], edx
0x100248c1 8b c3 mov eax, ebx
0x100248c3 5f pop edi

0x1002493f 8b 5f 04 mov ebx, dword ptr [edi + 4]
0x10024942 3b 5f 08 cmp ebx, dword ptr [edi + 8]
0x10024945 75 48 jne 0x1002498f
0x10024947 83 f9 20 cmp ecx, 0x20
0x1002494a 73 1f jae 0x1002496b
0x1002494c bb 00 00 00 80 mov ebx, 0x80000000
0x10024951 d3 eb shr ebx, cl
0x10024953 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x10024956 8d 4c 01 04 lea ecx, [ecx + eax + 4]
0x1002495a f7 d3 not ebx
0x1002495c 21 5c 90 44 and dword ptr [eax + edx*4 + 0x44], ebx
0x10024960 fe 09 dec byte ptr [ecx]

0x10024962 75 2b jne 0x1002498f
0x10024964 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024967 21 19 and dword ptr [ecx], ebx
0x10024969 eb 24 jmp 0x1002498f
0x1002496b 83 c1 e0 add ecx, -0x20
0x1002496e bb 00 00 00 80 mov ebx, 0x80000000
0x10024973 d3 eb shr ebx, cl
0x10024975 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x10024978 8d 4c 01 04 lea ecx, [ecx + eax + 4]
0x1002497c f7 d3 not ebx
0x1002497e 21 9c 90 c4 00 00 00 and dword ptr [eax + edx*4 + 0xc4], ebx
0x10024985 fe 09 dec byte ptr [ecx]

0x100249f9 fe c1 inc cl
0x100249fb 88 4c 07 04 mov byte ptr [edi + eax + 4], cl
0x100249ff 73 21 jae 0x10024a22
0x10024a01 80 7d 13 00 cmp byte ptr [ebp + 0x13], 0
0x10024a05 75 0e jne 0x10024a15
0x10024a07 bb 00 00 00 80 mov ebx, 0x80000000
0x10024a0c 8b cf mov ecx, edi
0x10024a0e d3 eb shr ebx, cl
0x10024a10 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024a13 09 19 or dword ptr [ecx], ebx
0x10024a15 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024a19 ba 00 00 00 80 mov edx, 0x80000000

0x10024a0c 8b cf mov ecx, edi
0x10024a0e d3 eb shr ebx, cl
0x10024a10 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024a13 09 19 or dword ptr [ecx], ebx
0x10024a15 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024a19 ba 00 00 00 80 mov edx, 0x80000000
0x10024a1e 8b cf mov ecx, edi
0x10024a20 eb 25 jmp 0x10024a47
0x10024a22 80 7d 13 00 cmp byte ptr [ebp + 0x13], 0
0x10024a26 75 10 jne 0x10024a38
0x10024a28 8d 4f e0 lea ecx, [edi - 0x20]
0x10024a2b bb 00 00 00 80 mov ebx, 0x80000000

0x10024a1e 8b cf mov ecx, edi
0x10024a20 eb 25 jmp 0x10024a47
0x10024a22 80 7d 13 00 cmp byte ptr [ebp + 0x13], 0
0x10024a26 75 10 jne 0x10024a38
0x10024a28 8d 4f e0 lea ecx, [edi - 0x20]
0x10024a2b bb 00 00 00 80 mov ebx, 0x80000000
0x10024a30 d3 eb shr ebx, cl
0x10024a32 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024a35 09 59 04 or dword ptr [ecx + 4], ebx
0x10024a38 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024a3f 8d 4f e0 lea ecx, [edi - 0x20]
0x10024a42 ba 00 00 00 80 mov edx, 0x80000000

0x10024a30 d3 eb shr ebx, cl
0x10024a32 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024a35 09 59 04 or dword ptr [ecx + 4], ebx
0x10024a38 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024a3f 8d 4f e0 lea ecx, [edi - 0x20]
0x10024a42 ba 00 00 00 80 mov edx, 0x80000000
0x10024a47 d3 ea shr edx, cl
0x10024a49 09 10 or dword ptr [eax], edx
0x10024a4b 8b 55 0c mov edx, dword ptr [ebp + 0xc]
0x10024a4e 8b 4d fc mov ecx, dword ptr [ebp - 4]
0x10024a51 8d 44 32 fc lea eax, [edx + esi - 4]
0x10024a55 89 08 mov dword ptr [eax], ecx

0x10024aba 8b 4f 04 mov ecx, dword ptr [edi + 4]
0x10024abd 3b 4f 08 cmp ecx, dword ptr [edi + 8]
0x10024ac0 75 47 jne 0x10024b09
0x10024ac2 83 fe 20 cmp esi, 0x20
0x10024ac5 73 1e jae 0x10024ae5
0x10024ac7 bb 00 00 00 80 mov ebx, 0x80000000
0x10024acc 8b ce mov ecx, esi
0x10024ace d3 eb shr ebx, cl
0x10024ad0 8d 74 06 04 lea esi, [esi + eax + 4]
0x10024ad4 f7 d3 not ebx
0x10024ad6 21 5c 90 44 and dword ptr [eax + edx*4 + 0x44], ebx
0x10024ada fe 0e dec byte ptr [esi]

0x10024adc 75 28 jne 0x10024b06
0x10024ade 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024ae1 21 19 and dword ptr [ecx], ebx
0x10024ae3 eb 21 jmp 0x10024b06
0x10024ae5 8d 4e e0 lea ecx, [esi - 0x20]
0x10024ae8 bb 00 00 00 80 mov ebx, 0x80000000
0x10024aed d3 eb shr ebx, cl
0x10024aef 8d 4c 06 04 lea ecx, [esi + eax + 4]
0x10024af3 f7 d3 not ebx
0x10024af5 21 9c 90 c4 00 00 00 and dword ptr [eax + edx*4 + 0xc4], ebx
0x10024afc fe 09 dec byte ptr [ecx]
0x10024afe 75 06 jne 0x10024b06

0x10024b5b fe c1 inc cl
0x10024b5d 88 4c 06 04 mov byte ptr [esi + eax + 4], cl
0x10024b61 73 21 jae 0x10024b84
0x10024b63 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x10024b67 75 0e jne 0x10024b77
0x10024b69 bf 00 00 00 80 mov edi, 0x80000000
0x10024b6e 8b ce mov ecx, esi
0x10024b70 d3 ef shr edi, cl
0x10024b72 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b75 09 39 or dword ptr [ecx], edi
0x10024b77 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024b7b ba 00 00 00 80 mov edx, 0x80000000

0x10024b6e 8b ce mov ecx, esi
0x10024b70 d3 ef shr edi, cl
0x10024b72 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b75 09 39 or dword ptr [ecx], edi
0x10024b77 8d 44 90 44 lea eax, [eax + edx*4 + 0x44]
0x10024b7b ba 00 00 00 80 mov edx, 0x80000000
0x10024b80 8b ce mov ecx, esi
0x10024b82 eb 25 jmp 0x10024ba9
0x10024b84 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x10024b88 75 10 jne 0x10024b9a
0x10024b8a 8d 4e e0 lea ecx, [esi - 0x20]
0x10024b8d bf 00 00 00 80 mov edi, 0x80000000

0x10024b80 8b ce mov ecx, esi
0x10024b82 eb 25 jmp 0x10024ba9
0x10024b84 80 7d 0f 00 cmp byte ptr [ebp + 0xf], 0
0x10024b88 75 10 jne 0x10024b9a
0x10024b8a 8d 4e e0 lea ecx, [esi - 0x20]
0x10024b8d bf 00 00 00 80 mov edi, 0x80000000
0x10024b92 d3 ef shr edi, cl
0x10024b94 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b97 09 79 04 or dword ptr [ecx + 4], edi
0x10024b9a 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024ba1 8d 4e e0 lea ecx, [esi - 0x20]
0x10024ba4 ba 00 00 00 80 mov edx, 0x80000000

0x10024b92 d3 ef shr edi, cl
0x10024b94 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x10024b97 09 79 04 or dword ptr [ecx + 4], edi
0x10024b9a 8d 84 90 c4 00 00 00 lea eax, [eax + edx*4 + 0xc4]
0x10024ba1 8d 4e e0 lea ecx, [esi - 0x20]
0x10024ba4 ba 00 00 00 80 mov edx, 0x80000000
0x10024ba9 d3 ea shr edx, cl
0x10024bab 09 10 or dword ptr [eax], edx
0x10024bad 8b 45 10 mov eax, dword ptr [ebp + 0x10]
0x10024bb0 89 03 mov dword ptr [ebx], eax
0x10024bb2 89 44 18 fc mov dword ptr [eax + ebx - 4], eax
0x10024bb6 6a 01 push 1

0x10024bdc 68 00 80 00 00 push 0x8000
0x10024be1 51 push ecx
0x10024be2 ff 15 f4 c0 02 10 call dword ptr [0x1002c0f4]
0x10024be8 8b 0d e8 91 03 10 mov ecx, dword ptr [0x100391e8]
0x10024bee a1 f4 91 03 10 mov eax, dword ptr [0x100391f4]
0x10024bf3 ba 00 00 00 80 mov edx, 0x80000000
0x10024bf8 d3 ea shr edx, cl
0x10024bfa 09 50 08 or dword ptr [eax + 8], edx
0x10024bfd a1 f4 91 03 10 mov eax, dword ptr [0x100391f4]
0x10024c02 8b 0d e8 91 03 10 mov ecx, dword ptr [0x100391e8]
0x10024c08 8b 40 10 mov eax, dword ptr [eax + 0x10]
0x10024c0b 83 a4 88 c4 00 00 00 00 and dword ptr [eax + ecx*4 + 0xc4], 0

0x10024e31 3b 0b cmp ecx, dword ptr [ebx]
0x10024e33 74 7e je 0x10024eb3
0x10024e35 8b 4d f4 mov ecx, dword ptr [ebp - 0xc]
0x10024e38 3b c1 cmp eax, ecx
0x10024e3a 0f 82 69 01 00 00 jb 0x10024fa9
0x10024e40 81 c1 00 80 00 00 add ecx, 0x8000
0x10024e46 3b c1 cmp eax, ecx
0x10024e48 0f 83 5b 01 00 00 jae 0x10024fa9
0x10024e4e 8b c8 mov ecx, eax
0x10024e50 66 81 e1 00 f0 and cx, 0xf000
0x10024e55 83 c1 0c add ecx, 0xc
0x10024e58 8d 91 f0 0f 00 00 lea edx, [ecx + 0xff0]

0x10024eb3 83 7d f0 00 cmp dword ptr [ebp - 0x10], 0
0x10024eb7 74 27 je 0x10024ee0
0x10024eb9 8b 4d f8 mov ecx, dword ptr [ebp - 8]
0x10024ebc 83 f9 20 cmp ecx, 0x20
0x10024ebf 7d 0f jge 0x10024ed0
0x10024ec1 b8 00 00 00 80 mov eax, 0x80000000
0x10024ec6 d3 e8 shr eax, cl
0x10024ec8 09 45 dc or dword ptr [ebp - 0x24], eax
0x10024ecb 09 45 d4 or dword ptr [ebp - 0x2c], eax
0x10024ece eb 10 jmp 0x10024ee0
0x10024ed0 83 c1 e0 add ecx, -0x20
0x10024ed3 b8 00 00 00 80 mov eax, 0x80000000

0x10024ec6 d3 e8 shr eax, cl
0x10024ec8 09 45 dc or dword ptr [ebp - 0x24], eax
0x10024ecb 09 45 d4 or dword ptr [ebp - 0x2c], eax
0x10024ece eb 10 jmp 0x10024ee0
0x10024ed0 83 c1 e0 add ecx, -0x20
0x10024ed3 b8 00 00 00 80 mov eax, 0x80000000
0x10024ed8 d3 e8 shr eax, cl
0x10024eda 09 45 e4 or dword ptr [ebp - 0x1c], eax
0x10024edd 09 45 e8 or dword ptr [ebp - 0x18], eax
0x10024ee0 39 72 04 cmp dword ptr [edx + 4], esi
0x10024ee3 0f 85 c8 00 00 00 jne 0x10024fb1
0x10024ee9 8b 4d fc mov ecx, dword ptr [ebp - 4]

0x10024f1b 3b 46 80 cmp eax, dword ptr [esi - 0x80]
0x10024f1e 0f 85 91 00 00 00 jne 0x10024fb5
0x10024f24 8b 45 e4 mov eax, dword ptr [ebp - 0x1c]
0x10024f27 3b 06 cmp eax, dword ptr [esi]
0x10024f29 0f 85 86 00 00 00 jne 0x10024fb5
0x10024f2f 81 45 f4 00 80 00 00 add dword ptr [ebp - 0xc], 0x8000
0x10024f36 81 45 d8 04 02 00 00 add dword ptr [ebp - 0x28], 0x204
0x10024f3d d1 65 ec shl dword ptr [ebp - 0x14], 1
0x10024f40 ff 45 d0 inc dword ptr [ebp - 0x30]
0x10024f43 83 c6 04 add esi, 4
0x10024f46 83 7d d0 20 cmp dword ptr [ebp - 0x30], 0x20
0x10024f4a 89 75 c4 mov dword ptr [ebp - 0x3c], esi

0x10025d0a f6 c3 20 test bl, 0x20
0x10025d0d 74 02 je 0x10025d11
0x10025d0f 0c 01 or al, 1
0x10025d11 f6 c3 02 test bl, 2
0x10025d14 74 05 je 0x10025d1b
0x10025d16 0d 00 00 08 00 or eax, 0x80000
0x10025d1b 0f b7 cb movzx ecx, bx
0x10025d1e 56 push esi
0x10025d1f 8b d1 mov edx, ecx
0x10025d21 be 00 0c 00 00 mov esi, 0xc00
0x10025d26 bf 00 03 00 00 mov edi, 0x300
0x10025d2b 23 d6 and edx, esi

0x10025e22 f6 c1 20 test cl, 0x20
0x10025e25 74 02 je 0x10025e29
0x10025e27 0c 01 or al, 1
0x10025e29 f6 c1 02 test cl, 2
0x10025e2c 74 05 je 0x10025e33
0x10025e2e 0d 00 00 08 00 or eax, 0x80000
0x10025e33 c3 ret 
0x10025e34 8b 44 24 08 mov eax, dword ptr [esp + 8]
0x10025e38 56 push esi
0x10025e39 6a 20 push 0x20
0x10025e3b 99 cdq 
0x10025e3c 59 pop ecx

0x10026162 8b 7f 10 mov edi, dword ptr [edi + 0x10]
0x10026165 d3 e6 shl esi, cl
0x10026167 8b 4d 08 mov ecx, dword ptr [ebp + 8]
0x1002616a f7 d9 neg ecx
0x1002616c 1b c9 sbb ecx, ecx
0x1002616e 81 e1 00 00 00 80 and ecx, 0x80000000
0x10026174 0b f1 or esi, ecx
0x10026176 0b 75 f4 or esi, dword ptr [ebp - 0xc]
0x10026179 83 ff 40 cmp edi, 0x40
0x1002617c 75 0d jne 0x1002618b
0x1002617e 8b 4d 0c mov ecx, dword ptr [ebp + 0xc]
0x10026181 8b 55 f8 mov edx, dword ptr [ebp - 8]

0x10026204 e8 ca fc ff ff call 0x10025ed3
0x10026209 59 pop ecx
0x1002620a 85 c0 test eax, eax
0x1002620c 59 pop ecx
0x1002620d 74 08 je 0x10026217
0x1002620f b9 00 00 00 80 mov ecx, 0x80000000
0x10026214 46 inc esi
0x10026215 eb 03 jmp 0x1002621a
0x10026217 8b 4d f0 mov ecx, dword ptr [ebp - 0x10]
0x1002621a 66 81 fe ff 7f cmp si, 0x7fff
0x1002621f 75 07 jne 0x10026228
0x10026221 c7 45 fc 01 00 00 00 mov dword ptr [ebp - 4], 1

0x100263b8 23 cf and ecx, edi
0x100263ba 89 45 0c mov dword ptr [ebp + 0xc], eax
0x100263bd 8b 42 04 mov eax, dword ptr [edx + 4]
0x100263c0 8b 12 mov edx, dword ptr [edx]
0x100263c2 0f b7 d9 movzx ebx, cx
0x100263c5 be 00 00 00 80 mov esi, 0x80000000
0x100263ca 25 ff ff 0f 00 and eax, 0xfffff
0x100263cf 85 db test ebx, ebx
0x100263d1 89 75 fc mov dword ptr [ebp - 4], esi
0x100263d4 74 13 je 0x100263e9
0x100263d6 3b df cmp ebx, edi
0x100263d8 74 08 je 0x100263e2

0x10028aba 75 1b jne 0x10028ad7
0x10028abc a8 01 test al, 1
0x10028abe 75 3e jne 0x10028afe
0x10028ac0 83 e0 02 and eax, 2
0x10028ac3 74 09 je 0x10028ace
0x10028ac5 81 7d f8 00 00 00 80 cmp dword ptr [ebp - 8], 0x80000000
0x10028acc 77 09 ja 0x10028ad7
0x10028ace 85 c0 test eax, eax
0x10028ad0 75 2c jne 0x10028afe
0x10028ad2 39 75 f8 cmp dword ptr [ebp - 8], esi
0x10028ad5 76 27 jbe 0x10028afe
0x10028ad7 e8 34 f6 fe ff call 0x10018110

0x100295b7 8b 55 10 mov edx, dword ptr [ebp + 0x10]
0x100295ba 83 7d d4 00 cmp dword ptr [ebp - 0x2c], 0
0x100295be 74 60 je 0x10029620
0x100295c0 33 db xor ebx, ebx
0x100295c2 b8 ff 7f 00 00 mov eax, 0x7fff
0x100295c7 be 00 00 00 80 mov esi, 0x80000000
0x100295cc 33 d2 xor edx, edx
0x100295ce c7 45 ec 02 00 00 00 mov dword ptr [ebp - 0x14], 2
0x100295d5 eb 5e jmp 0x10029635
0x100295d7 3d b0 eb ff ff cmp eax, 0xffffebb0
0x100295dc 7d 09 jge 0x100295e7
0x100295de c7 45 d0 01 00 00 00 mov dword ptr [ebp - 0x30], 1

0x1002973b c6 43 03 01 mov byte ptr [ebx + 3], 1
0x1002973f c6 43 04 30 mov byte ptr [ebx + 4], 0x30
0x10029743 e9 fe 01 00 00 jmp 0x10029946
0x10029748 66 3b d6 cmp dx, si
0x1002974b 75 7a jne 0x100297c7
0x1002974d b8 00 00 00 80 mov eax, 0x80000000
0x10029752 66 c7 03 01 00 mov word ptr [ebx], 1
0x10029757 3b f8 cmp edi, eax
0x10029759 75 06 jne 0x10029761
0x1002975b 83 7d 08 00 cmp dword ptr [ebp + 8], 0
0x1002975f 74 0f je 0x10029770
0x10029761 f7 c7 00 00 00 40 test edi, 0x40000000

0x1002b3b0 66 89 46 0a mov word ptr [esi + 0xa], ax
0x1002b3b4 eb 1b jmp 0x1002b3d1
0x1002b3b6 66 f7 df neg di
0x1002b3b9 1b ff sbb edi, edi
0x1002b3bb 83 66 04 00 and dword ptr [esi + 4], 0
0x1002b3bf 81 e7 00 00 00 80 and edi, 0x80000000
0x1002b3c5 81 c7 00 80 ff 7f add edi, 0x7fff8000
0x1002b3cb 83 26 00 and dword ptr [esi], 0
0x1002b3ce 89 7e 08 mov dword ptr [esi + 8], edi
0x1002b3d1 5f pop edi
0x1002b3d2 5e pop esi
0x1002b3d3 5b pop ebx

; TARGETED ERROR CANDIDATES
FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
0x10007958 03 00 add eax, dword ptr [eax]
0x1000795a 00 00 add byte ptr [eax], al
0x1000795c 04 00 add al, 0
0x1000795e 00 05 00 00 00 00 add byte ptr [0], al
0x10007964 05 05 00 00 05 add eax, 0x5000005
0x10007969 05 05 05 05 05 add eax, 0x5050505
0x1000796e 05 05 05 05 05 add eax, 0x5050505
0x10007973 05 00 55 8b ec add eax, 0xec8b5500
0x10007978 56 push esi
0x10007979 8d 45 08 lea eax, [ebp + 8]

0x1000fb73 56 push esi
0x1000fb74 57 push edi
0x1000fb75 25 00 00 00 f0 and eax, 0xf0000000
0x1000fb7a ff 75 68 push dword ptr [ebp + 0x68]
0x1000fb7d 05 00 00 00 10 add eax, 0x10000000
0x1000fb82 f7 d9 neg ecx
0x1000fb84 8d 75 54 lea esi, [ebp + 0x54]
0x1000fb87 53 push ebx
0x1000fb88 1b c9 sbb ecx, ecx
0x1000fb8a 56 push esi

0x1000fd03 51 push ecx
0x1000fd04 8d 4d 20 lea ecx, [ebp + 0x20]
0x1000fd07 ff 75 34 push dword ptr [ebp + 0x34]
0x1000fd0a 25 00 00 00 f0 and eax, 0xf0000000
0x1000fd0f 05 00 00 00 10 add eax, 0x10000000
0x1000fd14 ff 75 30 push dword ptr [ebp + 0x30]
0x1000fd17 51 push ecx
0x1000fd18 8d 4d 0c lea ecx, [ebp + 0xc]
0x1000fd1b 56 push esi
0x1000fd1c 51 push ecx

FILE /root/PL/PCU_old/H/mmc2/MCVar.dll
0x100078d5 02 03 add al, byte ptr [ebx]
0x100078d7 00 00 add byte ptr [eax], al
0x100078d9 00 04 00 add byte ptr [eax + eax], al
0x100078dc 00 05 00 00 00 00 add byte ptr [0], al
0x100078e2 05 05 00 00 05 add eax, 0x5000005
0x100078e7 05 05 05 05 05 add eax, 0x5050505
0x100078ec 05 05 05 05 05 add eax, 0x5050505
0x100078f1 05 00 55 8b ec add eax, 0xec8b5500
0x100078f6 56 push esi
0x100078f7 8d 45 08 lea eax, [ebp + 8]

0x1000fa61 56 push esi
0x1000fa62 57 push edi
0x1000fa63 25 00 00 00 f0 and eax, 0xf0000000
0x1000fa68 ff 75 68 push dword ptr [ebp + 0x68]
0x1000fa6b 05 00 00 00 10 add eax, 0x10000000
0x1000fa70 f7 d9 neg ecx
0x1000fa72 8d 75 54 lea esi, [ebp + 0x54]
0x1000fa75 53 push ebx
0x1000fa76 1b c9 sbb ecx, ecx
0x1000fa78 56 push esi

0x1000fbf1 51 push ecx
0x1000fbf2 8d 4d 20 lea ecx, [ebp + 0x20]
0x1000fbf5 ff 75 34 push dword ptr [ebp + 0x34]
0x1000fbf8 25 00 00 00 f0 and eax, 0xf0000000
0x1000fbfd 05 00 00 00 10 add eax, 0x10000000
0x1000fc02 ff 75 30 push dword ptr [ebp + 0x30]
0x1000fc05 51 push ecx
0x1000fc06 8d 4d 0c lea ecx, [ebp + 0xc]
0x1000fc09 56 push esi
0x1000fc0a 51 push ecx

; COHERENT CAPSTONE CROSSCHECK
FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
0x10006f21 89 45 f0 mov dword ptr [ebp - 0x10], eax
0x10006f7f 80 20 00 and byte ptr [eax], 0
0x10006fab 8b 45 f0 mov eax, dword ptr [ebp - 0x10]
0x10006fda 89 7d f0 mov dword ptr [ebp - 0x10], edi
0x10006ffb 8b 45 f0 mov eax, dword ptr [ebp - 0x10]
0x1000702d ff 76 10 push dword ptr [esi + 0x10]
0x1000704b ff 76 10 push dword ptr [esi + 0x10]
0x10007083 8b 45 f0 mov eax, dword ptr [ebp - 0x10]
0x100070c9 8b 46 10 mov eax, dword ptr [esi + 0x10]
0x100070ef 66 25 ff 0f and ax, 0xfff
0x10007103 23 c1 and eax, ecx
0x10007117 23 c1 and eax, ecx
0x10007127 66 25 ff 0f and ax, 0xfff
0x10007135 8d 45 f0 lea eax, [ebp - 0x10]
0x1000717a 3b 48 10 cmp ecx, dword ptr [eax + 0x10]
0x100071bf 23 c1 and eax, ecx
0x100071dd 8b 5c 24 10 mov ebx, dword ptr [esp + 0x10]
0x10007339 23 c8 and ecx, eax
0x1000736d 23 c1 and eax, ecx
0x1000739a 83 66 60 00 and dword ptr [esi + 0x60], 0
FILE /root/PL/PCU_old/H/mmc2/MCVar.dll
0x10006e9f 89 45 f0 mov dword ptr [ebp - 0x10], eax
0x10006efd 80 20 00 and byte ptr [eax], 0
0x10006f29 8b 45 f0 mov eax, dword ptr [ebp - 0x10]
0x10006f58 89 7d f0 mov dword ptr [ebp - 0x10], edi
0x10006f79 8b 45 f0 mov eax, dword ptr [ebp - 0x10]
0x10006fab ff 76 10 push dword ptr [esi + 0x10]
0x10006fc9 ff 76 10 push dword ptr [esi + 0x10]
0x10007001 8b 45 f0 mov eax, dword ptr [ebp - 0x10]
0x10007047 8b 46 10 mov eax, dword ptr [esi + 0x10]
0x1000706d 66 25 ff 0f and ax, 0xfff
0x10007081 23 c1 and eax, ecx
0x10007095 23 c1 and eax, ecx
0x100070a5 66 25 ff 0f and ax, 0xfff
0x100070b3 8d 45 f0 lea eax, [ebp - 0x10]
0x100070f8 3b 48 10 cmp ecx, dword ptr [eax + 0x10]
0x1000713d 23 c1 and eax, ecx
0x1000715b 8b 5c 24 10 mov ebx, dword ptr [esp + 0x10]
0x100072b7 23 c8 and ecx, eax
0x100072eb 23 c1 and eax, ecx
0x10007318 83 66 60 00 and dword ptr [esi + 0x60], 0
OLD PE SECTIONS [('.text', '0x1000', '0x6c1a8', '0x1000', '0x6d000'), ('.rdata', '0x6e000', '0x7a39', '0x6e000', '0x8000'), ('.data', '0x76000', '0x24e0c4', '0x76000', '0x9000'), ('.idata', '0x2c5000', '0x243c', '0x7f000', '0x3000'), ('.rsrc', '0x2c8000', '0xab9', '0x82000', '0x1000'), ('.reloc', '0x2c9000', '0x859a', '0x83000', '0x9000')]
RANGE 0x44a62d
0x44a62d raw=0x4a62d 8b 4c 24 2c mov ecx, dword ptr [esp + 0x2c]
0x44a631 raw=0x4a631 83 f9 01 cmp ecx, 1
0x44a634 raw=0x4a634 75 0c jne 0x44a642
0x44a636 raw=0x4a636 c6 00 00 mov byte ptr [eax], 0
0x44a639 raw=0x4a639 8b 44 24 24 mov eax, dword ptr [esp + 0x24]
0x44a63d raw=0x4a63d 40 inc eax
0x44a63e raw=0x4a63e 89 44 24 24 mov dword ptr [esp + 0x24], eax
0x44a642 raw=0x4a642 8b 54 24 10 mov edx, dword ptr [esp + 0x10]
0x44a646 raw=0x4a646 85 d2 test edx, edx
0x44a648 raw=0x4a648 74 24 je 0x44a66e
0x44a64a raw=0x4a64a 8b 8a 80 00 00 00 mov ecx, dword ptr [edx + 0x80]
0x44a650 raw=0x4a650 68 d0 6b 48 00 push 0x486bd0
0x44a655 raw=0x4a655 8b 11 mov edx, dword ptr [ecx]
0x44a657 raw=0x4a657 ff 12 call dword ptr [edx]
0x44a659 raw=0x4a659 5f pop edi
0x44a65a raw=0x4a65a 5e pop esi
0x44a65b raw=0x4a65b 5d pop ebp
0x44a65c raw=0x4a65c 33 c0 xor eax, eax
0x44a65e raw=0x4a65e 5b pop ebx
0x44a65f raw=0x4a65f 83 c4 10 add esp, 0x10
0x44a662 raw=0x4a662 c3 ret 
0x44a663 raw=0x4a663 5f pop edi
0x44a664 raw=0x4a664 5e pop esi
0x44a665 raw=0x4a665 5d pop ebp
0x44a666 raw=0x4a666 83 c8 ff or eax, 0xffffffff
0x44a669 raw=0x4a669 5b pop ebx
0x44a66a raw=0x4a66a 83 c4 10 add esp, 0x10
0x44a66d raw=0x4a66d c3 ret 
0x44a66e raw=0x4a66e 2d d0 6b 48 00 sub eax, 0x486bd0
0x44a673 raw=0x4a673 51 push ecx
0x44a674 raw=0x4a674 50 push eax
0x44a675 raw=0x4a675 68 d0 6b 48 00 push 0x486bd0
0x44a67a raw=0x4a67a 8d 44 24 20 lea eax, [esp + 0x20]
0x44a67e raw=0x4a67e 50 push eax
0x44a67f raw=0x4a67f 55 push ebp
0x44a680 raw=0x4a680 e8 73 6c fb ff call 0x4012f8
0x44a685 raw=0x4a685 83 c4 14 add esp, 0x14
0x44a688 raw=0x4a688 5f pop edi
0x44a689 raw=0x4a689 5e pop esi
0x44a68a raw=0x4a68a 5d pop ebp
0x44a68b raw=0x4a68b 5b pop ebx
0x44a68c raw=0x4a68c 83 c4 10 add esp, 0x10
0x44a68f raw=0x4a68f c3 ret 
0x44a690 raw=0x4a690 cc int3 
0x44a691 raw=0x4a691 cc int3 
0x44a692 raw=0x4a692 cc int3 
0x44a693 raw=0x4a693 cc int3 
0x44a694 raw=0x4a694 cc int3 
0x44a695 raw=0x4a695 cc int3 
0x44a696 raw=0x4a696 cc int3 
0x44a697 raw=0x4a697 cc int3 
RANGE 0x40203b
0x40203b raw=0x203b e9 f0 86 04 00 jmp 0x44a730
RANGE 0x466f26
0x466f26 raw=0x66f26 ff 25 1c 63 6c 00 jmp dword ptr [0x6c631c]
RANGE 0x420730
0x420730 raw=0x20730 56 push esi
0x420731 raw=0x20731 8b 74 24 08 mov esi, dword ptr [esp + 8]
0x420735 raw=0x20735 8b c6 mov eax, esi
0x420737 raw=0x20737 25 ff ff 00 00 and eax, 0xffff
0x42073c raw=0x2073c 83 f8 1a cmp eax, 0x1a
0x42073f raw=0x2073f 7c 52 jl 0x420793
0x420741 raw=0x20741 83 f8 1b cmp eax, 0x1b
0x420744 raw=0x20744 7f 4d jg 0x420793
0x420746 raw=0x20746 8b 44 24 0c mov eax, dword ptr [esp + 0xc]
0x42074a raw=0x2074a 66 8b 4c 24 10 mov cx, word ptr [esp + 0x10]
0x42074f raw=0x2074f ba 50 00 00 00 mov edx, 0x50
0x420754 raw=0x20754 66 89 48 05 mov word ptr [eax + 5], cx
0x420758 raw=0x20758 33 c9 xor ecx, ecx
0x42075a raw=0x2075a 88 50 04 mov byte ptr [eax + 4], dl
0x42075d raw=0x2075d c6 40 07 02 mov byte ptr [eax + 7], 2
0x420761 raw=0x20761 c6 40 08 01 mov byte ptr [eax + 8], 1
0x420765 raw=0x20765 c6 40 0c 22 mov byte ptr [eax + 0xc], 0x22
0x420769 raw=0x20769 88 48 0d mov byte ptr [eax + 0xd], cl
0x42076c raw=0x2076c 66 89 48 10 mov word ptr [eax + 0x10], cx
0x420770 raw=0x20770 66 c7 40 13 04 01 mov word ptr [eax + 0x13], 0x104
0x420776 raw=0x20776 66 89 50 15 mov word ptr [eax + 0x15], dx
0x42077a raw=0x2077a 66 89 48 19 mov word ptr [eax + 0x19], cx
0x42077e raw=0x2077e 66 89 48 1c mov word ptr [eax + 0x1c], cx
0x420782 raw=0x20782 66 89 50 1e mov word ptr [eax + 0x1e], dx
0x420786 raw=0x20786 88 48 22 mov byte ptr [eax + 0x22], cl
0x420789 raw=0x20789 66 89 70 26 mov word ptr [eax + 0x26], si
0x42078d raw=0x2078d 33 c0 xor eax, eax
0x42078f raw=0x2078f 5e pop esi
0x420790 raw=0x20790 c2 0c 00 ret 0xc
; MCVAR STORES CROSSCHECK
FILE /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
0x10003e30 raw=0x3e30 5e pop esi
0x10003e31 raw=0x3e31 c3 ret 
0x10003e32 raw=0x3e32 55 push ebp
0x10003e33 raw=0x3e33 8b ec mov ebp, esp
0x10003e35 raw=0x3e35 83 ec 28 sub esp, 0x28
0x10003e38 raw=0x3e38 53 push ebx
0x10003e39 raw=0x3e39 8b 5d 08 mov ebx, dword ptr [ebp + 8]
0x10003e3c raw=0x3e3c 56 push esi
0x10003e3d raw=0x3e3d 57 push edi
0x10003e3e raw=0x3e3e 6a 01 push 1
0x10003e40 raw=0x3e40 89 4d f8 mov dword ptr [ebp - 8], ecx
0x10003e43 raw=0x3e43 5a pop edx
0x10003e44 raw=0x3e44 33 ff xor edi, edi
0x10003e46 raw=0x3e46 66 c7 03 14 00 mov word ptr [ebx], 0x14
0x10003e4b raw=0x3e4b 66 89 53 02 mov word ptr [ebx + 2], dx
0x10003e4f raw=0x3e4f 66 89 7b 06 mov word ptr [ebx + 6], di
0x10003e53 raw=0x3e53 c7 43 10 f9 f8 f7 f6 mov dword ptr [ebx + 0x10], 0xf6f7f8f9
0x10003e5a raw=0x3e5a 66 8b 41 08 mov ax, word ptr [ecx + 8]
0x10004730 raw=0x4730 08 7c d6 83 or byte ptr [esi + edx*8 - 0x7d], bh
0x10004734 raw=0x4734 7d f0 jge 0x10004726
0x10004736 raw=0x4736 00 74 09 ff add byte ptr [ecx + ecx - 1], dh
0x1000473a raw=0x473a 75 f0 jne 0x1000472c
0x1000473c raw=0x473c ff 15 f4 d1 02 10 call dword ptr [0x1002d1f4]
0x10004742 raw=0x4742 85 f6 test esi, esi
0x10004744 raw=0x4744 89 7b 0c mov dword ptr [ebx + 0xc], edi
0x10004747 raw=0x4747 66 c7 43 04 64 00 mov word ptr [ebx + 4], 0x64
0x1000474d raw=0x474d 66 c7 43 06 06 00 mov word ptr [ebx + 6], 6
0x10004753 raw=0x4753 75 32 jne 0x10004787
0x10004755 raw=0x4755 8b 45 f8 mov eax, dword ptr [ebp - 8]
0x10004758 raw=0x4758 ba 88 84 03 10 mov edx, 0x10038488
0x1000475d raw=0x475d 8b 40 10 mov eax, dword ptr [eax + 0x10]
FILE /root/PL/PCU_old/H/mmc2/MCVar.dll
0x10003df3 raw=0x3df3 55 push ebp
0x10003df4 raw=0x3df4 8b ec mov ebp, esp
0x10003df6 raw=0x3df6 83 ec 28 sub esp, 0x28
0x10003df9 raw=0x3df9 53 push ebx
0x10003dfa raw=0x3dfa 8b 5d 08 mov ebx, dword ptr [ebp + 8]
0x10003dfd raw=0x3dfd 56 push esi
0x10003dfe raw=0x3dfe 57 push edi
0x10003dff raw=0x3dff 6a 01 push 1
0x10003e01 raw=0x3e01 89 4d f8 mov dword ptr [ebp - 8], ecx
0x10003e04 raw=0x3e04 5a pop edx
0x10003e05 raw=0x3e05 33 ff xor edi, edi
0x10003e07 raw=0x3e07 66 c7 03 14 00 mov word ptr [ebx], 0x14
0x10003e0c raw=0x3e0c 66 89 53 02 mov word ptr [ebx + 2], dx
0x10003e10 raw=0x3e10 66 89 7b 06 mov word ptr [ebx + 6], di
0x10003e14 raw=0x3e14 c7 43 10 f9 f8 f7 f6 mov dword ptr [ebx + 0x10], 0xf6f7f8f9
0x10003e1b raw=0x3e1b 66 8b 41 08 mov ax, word ptr [ecx + 8]
0x10004620 raw=0x4620 0f af 43 08 imul eax, dword ptr [ebx + 8]
0x10004624 raw=0x4624 83 c0 14 add eax, 0x14
0x10004627 raw=0x4627 66 c7 43 04 64 00 mov word ptr [ebx + 4], 0x64
0x1000462d raw=0x462d 3b 45 0c cmp eax, dword ptr [ebp + 0xc]
0x10004630 raw=0x4630 66 c7 43 06 17 00 mov word ptr [ebx + 6], 0x17
0x10004636 raw=0x4636 89 01 mov dword ptr [ecx], eax
0x10004638 raw=0x4638 7e 19 jle 0x10004653
0x1000463a raw=0x463a 83 c0 14 add eax, 0x14
0x1000463d raw=0x463d 85 ff test edi, edi
0x1000463f raw=0x463f 89 01 mov dword ptr [ecx], eax
0x10004700 raw=0x4700 c1 02 10 rol dword ptr [edx], 0x10
0x10004703 raw=0x4703 85 f6 test esi, esi
0x10004705 raw=0x4705 89 7b 0c mov dword ptr [ebx + 0xc], edi
0x10004708 raw=0x4708 66 c7 43 04 64 00 mov word ptr [ebx + 4], 0x64
0x1000470e raw=0x470e 66 c7 43 06 06 00 mov word ptr [ebx + 6], 6
0x10004714 raw=0x4714 75 32 jne 0x10004748
0x10004716 raw=0x4716 8b 45 f8 mov eax, dword ptr [ebp - 8]
0x10004719 raw=0x4719 ba 34 74 03 10 mov edx, 0x10037434
OLD RANGE 0x44a5f2
0x44a5f2 raw=0x4a5f2 8b 4c 24 2c mov ecx, dword ptr [esp + 0x2c]
0x44a5f6 raw=0x4a5f6 57 push edi
0x44a5f7 raw=0x4a5f7 8d 54 24 18 lea edx, [esp + 0x18]
0x44a5fb raw=0x4a5fb 51 push ecx
0x44a5fc raw=0x4a5fc 8d 44 24 2c lea eax, [esp + 0x2c]
0x44a600 raw=0x4a600 52 push edx
0x44a601 raw=0x4a601 50 push eax
0x44a602 raw=0x4a602 56 push esi
0x44a603 raw=0x4a603 53 push ebx
0x44a604 raw=0x4a604 8d 4c 24 34 lea ecx, [esp + 0x34]
0x44a608 raw=0x4a608 55 push ebp
0x44a609 raw=0x4a609 51 push ecx
0x44a60a raw=0x4a60a e8 2c 7a fb ff call 0x40203b
0x44a60f raw=0x4a60f 83 c4 20 add esp, 0x20
0x44a612 raw=0x4a612 83 f8 fd cmp eax, -3
0x44a615 raw=0x4a615 74 42 je 0x44a659
0x44a617 raw=0x4a617 83 f8 fe cmp eax, -2
0x44a61a raw=0x4a61a 74 47 je 0x44a663
0x44a61c raw=0x4a61c 85 c0 test eax, eax
0x44a61e raw=0x4a61e 74 39 je 0x44a659
0x44a620 raw=0x4a620 8b 44 24 18 mov eax, dword ptr [esp + 0x18]
0x44a624 raw=0x4a624 46 inc esi
0x44a625 raw=0x4a625 3b f0 cmp esi, eax
0x44a627 raw=0x4a627 7c c9 jl 0x44a5f2
0x44a629 raw=0x4a629 8b 44 24 24 mov eax, dword ptr [esp + 0x24]
OLD RANGE 0x44a730
0x44a730 raw=0x4a730 83 ec 20 sub esp, 0x20
0x44a733 raw=0x4a733 8b 44 24 28 mov eax, dword ptr [esp + 0x28]
0x44a737 raw=0x4a737 53 push ebx
0x44a738 raw=0x4a738 55 push ebp
0x44a739 raw=0x4a739 56 push esi
0x44a73a raw=0x4a73a 8b 88 a6 00 00 00 mov ecx, dword ptr [eax + 0xa6]
0x44a740 raw=0x4a740 8b 44 24 3c mov eax, dword ptr [esp + 0x3c]
0x44a744 raw=0x4a744 57 push edi
0x44a745 raw=0x4a745 8b 14 81 mov edx, dword ptr [ecx + eax*4]
0x44a748 raw=0x4a748 8b 4c 24 3c mov ecx, dword ptr [esp + 0x3c]
0x44a74c raw=0x4a74c 8b 5a 36 mov ebx, dword ptr [edx + 0x36]
0x44a74f raw=0x4a74f 8b 51 04 mov edx, dword ptr [ecx + 4]
0x44a752 raw=0x4a752 8b 3c 82 mov edi, dword ptr [edx + eax*4]
0x44a755 raw=0x4a755 c7 44 24 1c 04 00 00 00 mov dword ptr [esp + 0x1c], 4
0x44a75d raw=0x4a75d 83 c7 04 add edi, 4
0x44a760 raw=0x4a760 c7 44 24 20 00 00 00 00 mov dword ptr [esp + 0x20], 0
0x44a768 raw=0x4a768 89 7c 24 24 mov dword ptr [esp + 0x24], edi
0x44a76c raw=0x4a76c 8a 47 2a mov al, byte ptr [edi + 0x2a]
0x44a76f raw=0x4a76f 3c ff cmp al, 0xff
0x44a771 raw=0x4a771 75 08 jne 0x44a77b
0x44a773 raw=0x4a773 8b 43 19 mov eax, dword ptr [ebx + 0x19]
0x44a776 raw=0x4a776 8a 40 3e mov al, byte ptr [eax + 0x3e]
0x44a779 raw=0x4a779 3c ff cmp al, 0xff
0x44a77b raw=0x4a77b 8b 4f 02 mov ecx, dword ptr [edi + 2]
0x44a77e raw=0x4a77e 0f 95 44 24 3c setne byte ptr [esp + 0x3c]
0x44a783 raw=0x4a783 83 cd ff or ebp, 0xffffffff
0x44a786 raw=0x4a786 3b cd cmp ecx, ebp
0x44a788 raw=0x4a788 74 08 je 0x44a792
0x44a78a raw=0x4a78a 8b f1 mov esi, ecx
0x44a78c raw=0x4a78c 89 74 24 18 mov dword ptr [esp + 0x18], esi
0x44a790 raw=0x4a790 eb 19 jmp 0x44a7ab
0x44a792 raw=0x4a792 8b 53 19 mov edx, dword ptr [ebx + 0x19]
0x44a795 raw=0x4a795 8b 42 16 mov eax, dword ptr [edx + 0x16]
0x44a798 raw=0x4a798 3b c5 cmp eax, ebp
0x44a79a raw=0x4a79a 75 09 jne 0x44a7a5
0x44a79c raw=0x4a79c 8a 43 20 mov al, byte ptr [ebx + 0x20]
0x44a79f raw=0x4a79f c1 e8 05 shr eax, 5
0x44a7a2 raw=0x4a7a2 83 e0 01 and eax, 1
0x44a7a5 raw=0x4a7a5 89 44 24 18 mov dword ptr [esp + 0x18], eax
0x44a7a9 raw=0x4a7a9 8b f0 mov esi, eax
0x44a7ab raw=0x4a7ab 8b 47 12 mov eax, dword ptr [edi + 0x12]
0x44a7ae raw=0x4a7ae 3b c5 cmp eax, ebp
0x44a7b0 raw=0x4a7b0 75 12 jne 0x44a7c4
0x44a7b2 raw=0x4a7b2 3b cd cmp ecx, ebp
0x44a7b4 raw=0x4a7b4 75 08 jne 0x44a7be
0x44a7b6 raw=0x4a7b6 89 2d b8 6c 4a 00 mov dword ptr [0x4a6cb8], ebp
0x44a7bc raw=0x4a7bc eb 0f jmp 0x44a7cd
0x44a7be raw=0x4a7be 8b 47 06 mov eax, dword ptr [edi + 6]
0x44a7c1 raw=0x4a7c1 2b c1 sub eax, ecx
0x44a7c3 raw=0x4a7c3 40 inc eax
0x44a7c4 raw=0x4a7c4 3b c5 cmp eax, ebp
0x44a7c6 raw=0x4a7c6 a3 b8 6c 4a 00 mov dword ptr [0x4a6cb8], eax
0x44a7cb raw=0x4a7cb 75 2d jne 0x44a7fa
0x44a7cd raw=0x4a7cd 8b 4b 19 mov ecx, dword ptr [ebx + 0x19]
0x44a7d0 raw=0x4a7d0 8b 41 26 mov eax, dword ptr [ecx + 0x26]
0x44a7d3 raw=0x4a7d3 3b c5 cmp eax, ebp
0x44a7d5 raw=0x4a7d5 75 15 jne 0x44a7ec
0x44a7d7 raw=0x4a7d7 8b 51 16 mov edx, dword ptr [ecx + 0x16]
0x44a7da raw=0x4a7da 3b d5 cmp edx, ebp
0x44a7dc raw=0x4a7dc 75 08 jne 0x44a7e6
0x44a7de raw=0x4a7de 89 2d b8 6c 4a 00 mov dword ptr [0x4a6cb8], ebp
0x44a7e4 raw=0x4a7e4 eb 0f jmp 0x44a7f5
0x44a7e6 raw=0x4a7e6 8b 41 1a mov eax, dword ptr [ecx + 0x1a]
0x44a7e9 raw=0x4a7e9 2b c2 sub eax, edx
0x44a7eb raw=0x4a7eb 40 inc eax
0x44a7ec raw=0x4a7ec 3b c5 cmp eax, ebp
0x44a7ee raw=0x4a7ee a3 b8 6c 4a 00 mov dword ptr [0x4a6cb8], eax
0x44a7f3 raw=0x4a7f3 75 05 jne 0x44a7fa
0x44a7f5 raw=0x4a7f5 b8 01 00 00 00 mov eax, 1
0x44a7fa raw=0x4a7fa 8b 4c 24 44 mov ecx, dword ptr [esp + 0x44]
0x44a7fe raw=0x4a7fe 8d 44 30 ff lea eax, [eax + esi - 1]
0x44a802 raw=0x4a802 33 ff xor edi, edi
0x44a804 raw=0x4a804 3b f0 cmp esi, eax
0x44a806 raw=0x4a806 8b 29 mov ebp, dword ptr [ecx]
0x44a808 raw=0x4a808 89 44 24 28 mov dword ptr [esp + 0x28], eax
0x44a80c raw=0x4a80c 89 74 24 14 mov dword ptr [esp + 0x14], esi
OLD RANGE 0x448ac0
0x448ac0 raw=0x48ac0 55 push ebp
0x448ac1 raw=0x48ac1 8b ec mov ebp, esp
0x448ac3 raw=0x48ac3 6a ff push -1
0x448ac5 raw=0x48ac5 68 68 a9 46 00 push 0x46a968
0x448aca raw=0x48aca 64 a1 00 00 00 00 mov eax, dword ptr fs:[0]
0x448ad0 raw=0x48ad0 50 push eax
0x448ad1 raw=0x48ad1 64 89 25 00 00 00 00 mov dword ptr fs:[0], esp
0x448ad8 raw=0x48ad8 83 ec 58 sub esp, 0x58
0x448adb raw=0x48adb 53 push ebx
0x448adc raw=0x48adc 56 push esi
0x448add raw=0x48add 83 cb ff or ebx, 0xffffffff
0x448ae0 raw=0x48ae0 57 push edi
0x448ae1 raw=0x48ae1 b9 0c 00 00 00 mov ecx, 0xc
0x448ae6 raw=0x48ae6 8b c3 mov eax, ebx
0x448ae8 raw=0x48ae8 8d 7d 9c lea edi, [ebp - 0x64]
0x448aeb raw=0x48aeb 66 89 5d cc mov word ptr [ebp - 0x34], bx
0x448aef raw=0x48aef 89 65 f0 mov dword ptr [ebp - 0x10], esp
0x448af2 raw=0x48af2 f3 ab rep stosd dword ptr es:[edi], eax
0x448af4 raw=0x48af4 8b 75 08 mov esi, dword ptr [ebp + 8]
0x448af7 raw=0x48af7 33 ff xor edi, edi
0x448af9 raw=0x48af9 81 fe 90 40 00 00 cmp esi, 0x4090
0x448aff raw=0x48aff 89 7d fc mov dword ptr [ebp - 4], edi
0x448b02 raw=0x48b02 0f 87 6f 0d 00 00 ja 0x449877
0x448b08 raw=0x48b08 0f 84 fc 0a 00 00 je 0x44960a
0x448b0e raw=0x48b0e 81 fe 22 20 00 00 cmp esi, 0x2022
0x448b14 raw=0x48b14 0f 87 59 06 00 00 ja 0x449173
0x448b1a raw=0x48b1a 0f 84 d1 04 00 00 je 0x448ff1
0x448b20 raw=0x48b20 8d 86 d0 ef ff ff lea eax, [esi - 0x1030]
0x448b26 raw=0x48b26 83 f8 32 cmp eax, 0x32
0x448b29 raw=0x48b29 0f 87 4a 0f 00 00 ja 0x449a79
0x448b2f raw=0x48b2f 33 c9 xor ecx, ecx
0x448b31 raw=0x48b31 8a 88 c8 9a 44 00 mov cl, byte ptr [eax + 0x449ac8]
0x448b37 raw=0x48b37 ff 24 8d b8 9a 44 00 jmp dword ptr [ecx*4 + 0x449ab8]
OLD RANGE 0x44aa8a
0x44aa8a raw=0x4aa8a a0 84 68 48 00 mov al, byte ptr [0x486884]
0x44aa8f raw=0x4aa8f 66 33 d2 xor dx, dx
0x44aa92 raw=0x4aa92 66 0f b6 4c 24 20 movzx cx, byte ptr [esp + 0x20]
0x44aa98 raw=0x4aa98 8a d0 mov dl, al
0x44aa9a raw=0x4aa9a c1 e2 08 shl edx, 8
0x44aa9d raw=0x4aa9d 03 d1 add edx, ecx
0x44aa9f raw=0x4aa9f 8b 4c 24 18 mov ecx, dword ptr [esp + 0x18]
0x44aaa3 raw=0x4aaa3 66 89 15 d6 6b 48 00 mov word ptr [0x486bd6], dx
0x44aaaa raw=0x4aaaa 8b 54 24 28 mov edx, dword ptr [esp + 0x28]
0x44aaae raw=0x4aaae 2b d1 sub edx, ecx
0x44aab0 raw=0x4aab0 8b 4c 24 44 mov ecx, dword ptr [esp + 0x44]
0x44aab4 raw=0x4aab4 fe c0 inc al
0x44aab6 raw=0x4aab6 42 inc edx
0x44aab7 raw=0x4aab7 a2 84 68 48 00 mov byte ptr [0x486884], al
0x44aabc raw=0x4aabc 89 15 d8 6b 48 00 mov dword ptr [0x486bd8], edx
NEW MCVAR /root/PL/PCU_new/C/RECYCLER/S-1-5-21-4025392478-4199590385-3038547483-1005/Dc28/files/F/mmc2/MCVar.dll
0x1000465f raw=0x465f 0f af 43 08 imul eax, dword ptr [ebx + 8]
0x10004663 raw=0x4663 83 c0 14 add eax, 0x14
0x10004666 raw=0x4666 66 c7 43 04 64 00 mov word ptr [ebx + 4], 0x64
0x1000466c raw=0x466c 3b 45 0c cmp eax, dword ptr [ebp + 0xc]
0x1000466f raw=0x466f 66 c7 43 06 17 00 mov word ptr [ebx + 6], 0x17
0x10004675 raw=0x4675 89 01 mov dword ptr [ecx], eax
0x10004677 raw=0x4677 7e 19 jle 0x10004692
0x10004679 raw=0x4679 83 c0 14 add eax, 0x14
0x1000467c raw=0x467c 85 ff test edi, edi