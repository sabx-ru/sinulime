
/root/PL/PCU_old/H/mmc2/mbdde.exe:     file format pei-i386


Disassembly of section .text:

0040c4e0 <.text+0xb4e0>:
  40c4e0:	83 ec 28             	sub    esp,0x28
  40c4e3:	53                   	push   ebx
  40c4e4:	8b 5c 24 38          	mov    ebx,DWORD PTR [esp+0x38]
  40c4e8:	55                   	push   ebp
  40c4e9:	56                   	push   esi
  40c4ea:	85 db                	test   ebx,ebx
  40c4ec:	57                   	push   edi
  40c4ed:	75 0e                	jne    0x40c4fd
  40c4ef:	a1 24 cb 45 00       	mov    eax,ds:0x45cb24
  40c4f4:	8b 48 5c             	mov    ecx,DWORD PTR [eax+0x5c]
  40c4f7:	89 4c 24 44          	mov    DWORD PTR [esp+0x44],ecx
  40c4fb:	8b d9                	mov    ebx,ecx
  40c4fd:	8b 44 24 58          	mov    eax,DWORD PTR [esp+0x58]
  40c501:	85 c0                	test   eax,eax
  40c503:	75 08                	jne    0x40c50d
  40c505:	8d 54 24 18          	lea    edx,[esp+0x18]
  40c509:	89 54 24 58          	mov    DWORD PTR [esp+0x58],edx
  40c50d:	8b 44 24 50          	mov    eax,DWORD PTR [esp+0x50]
  40c511:	3d 90 40 00 00       	cmp    eax,0x4090
  40c516:	74 0e                	je     0x40c526
  40c518:	3d b0 20 00 00       	cmp    eax,0x20b0
  40c51d:	74 07                	je     0x40c526
  40c51f:	8b eb                	mov    ebp,ebx
  40c521:	e9 a0 00 00 00       	jmp    0x40c5c6
  40c526:	a1 0c cb 45 00       	mov    eax,ds:0x45cb0c
  40c52b:	85 c0                	test   eax,eax
  40c52d:	74 1a                	je     0x40c549
  40c52f:	8b c8                	mov    ecx,eax
  40c531:	8b 00                	mov    eax,DWORD PTR [eax]
  40c533:	8b 71 08             	mov    esi,DWORD PTR [ecx+0x8]
  40c536:	39 1e                	cmp    DWORD PTR [esi],ebx
  40c538:	74 0b                	je     0x40c545
  40c53a:	85 c0                	test   eax,eax
  40c53c:	75 f1                	jne    0x40c52f
  40c53e:	8b eb                	mov    ebp,ebx
  40c540:	e9 81 00 00 00       	jmp    0x40c5c6
  40c545:	85 f6                	test   esi,esi
  40c547:	75 04                	jne    0x40c54d
  40c549:	8b eb                	mov    ebp,ebx
  40c54b:	eb 79                	jmp    0x40c5c6
  40c54d:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  40c550:	85 c0                	test   eax,eax
  40c552:	75 1e                	jne    0x40c572
  40c554:	8b 46 10             	mov    eax,DWORD PTR [esi+0x10]
  40c557:	8b 4e 08             	mov    ecx,DWORD PTR [esi+0x8]
  40c55a:	8b 56 04             	mov    edx,DWORD PTR [esi+0x4]
  40c55d:	40                   	inc    eax
  40c55e:	89 46 10             	mov    DWORD PTR [esi+0x10],eax
  40c561:	8b 46 0c             	mov    eax,DWORD PTR [esi+0xc]
  40c564:	6a 00                	push   0x0
  40c566:	50                   	push   eax
  40c567:	51                   	push   ecx
  40c568:	52                   	push   edx
  40c569:	e8 d4 57 02 00       	call   0x431d42
  40c56e:	8b e8                	mov    ebp,eax
  40c570:	eb 54                	jmp    0x40c5c6
  40c572:	8b 46 1c             	mov    eax,DWORD PTR [esi+0x1c]
  40c575:	33 d2                	xor    edx,edx
  40c577:	8b 48 04             	mov    ecx,DWORD PTR [eax+0x4]
  40c57a:	8b 78 08             	mov    edi,DWORD PTR [eax+0x8]
  40c57d:	3b ca                	cmp    ecx,edx
  40c57f:	89 4e 1c             	mov    DWORD PTR [esi+0x1c],ecx
  40c582:	74 04                	je     0x40c588
  40c584:	89 11                	mov    DWORD PTR [ecx],edx
  40c586:	eb 03                	jmp    0x40c58b
  40c588:	89 56 18             	mov    DWORD PTR [esi+0x18],edx
  40c58b:	8b 4e 24             	mov    ecx,DWORD PTR [esi+0x24]
  40c58e:	89 08                	mov    DWORD PTR [eax],ecx
  40c590:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  40c593:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  40c596:	48                   	dec    eax
  40c597:	89 46 20             	mov    DWORD PTR [esi+0x20],eax
  40c59a:	75 28                	jne    0x40c5c4
  40c59c:	8b 46 18             	mov    eax,DWORD PTR [esi+0x18]
  40c59f:	3b c2                	cmp    eax,edx
  40c5a1:	74 06                	je     0x40c5a9
  40c5a3:	8b 00                	mov    eax,DWORD PTR [eax]
  40c5a5:	3b c2                	cmp    eax,edx
  40c5a7:	75 fa                	jne    0x40c5a3
  40c5a9:	8b 4e 28             	mov    ecx,DWORD PTR [esi+0x28]
  40c5ac:	89 56 20             	mov    DWORD PTR [esi+0x20],edx
  40c5af:	89 56 24             	mov    DWORD PTR [esi+0x24],edx
  40c5b2:	89 56 1c             	mov    DWORD PTR [esi+0x1c],edx
  40c5b5:	89 56 18             	mov    DWORD PTR [esi+0x18],edx
  40c5b8:	e8 ca 78 02 00       	call   0x433e87
  40c5bd:	c7 46 28 00 00 00 00 	mov    DWORD PTR [esi+0x28],0x0
  40c5c4:	8b ef                	mov    ebp,edi
  40c5c6:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  40c5cd:	00 
  40c5ce:	8b 54 24 58          	mov    edx,DWORD PTR [esp+0x58]
  40c5d2:	8b 74 24 54          	mov    esi,DWORD PTR [esp+0x54]
  40c5d6:	8b 44 24 50          	mov    eax,DWORD PTR [esp+0x50]
  40c5da:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  40c5de:	52                   	push   edx
  40c5df:	8b 54 24 4c          	mov    edx,DWORD PTR [esp+0x4c]
  40c5e3:	56                   	push   esi
  40c5e4:	50                   	push   eax
  40c5e5:	8b 44 24 4c          	mov    eax,DWORD PTR [esp+0x4c]
  40c5e9:	51                   	push   ecx
  40c5ea:	8b 4c 24 4c          	mov    ecx,DWORD PTR [esp+0x4c]
  40c5ee:	52                   	push   edx
  40c5ef:	55                   	push   ebp
  40c5f0:	50                   	push   eax
  40c5f1:	51                   	push   ecx
  40c5f2:	e8 45 57 02 00       	call   0x431d3c
  40c5f7:	8b f8                	mov    edi,eax
  40c5f9:	85 ff                	test   edi,edi
  40c5fb:	89 7c 24 14          	mov    DWORD PTR [esp+0x14],edi
  40c5ff:	0f 85 2e 01 00 00    	jne    0x40c733
  40c605:	3b eb                	cmp    ebp,ebx
  40c607:	0f 84 9b 00 00 00    	je     0x40c6a8
  40c60d:	a1                   	.byte 0xa1
  40c60e:	0c cb                	or     al,0xcb
